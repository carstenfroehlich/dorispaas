        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br /> 
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>
                <h1 class="header center orange-text">Pflege der Darmschleimhaut</h1>      
            </div>  
        </div> 
        <div class="container">    
            <div class="section">   
                <div class="row margintoprow">
                    <div class="col s12 m12">
                        Bei Erkrankungen des Darmes, einem schlecht funktionierenden Immunsystem, nach 
                        Antibiotika- oder Bestrahlungstherapien oder aber nach besonderen Stresssituationen 
                        ist es meist erforderlich, die Darmgesundheit wieder herzustellen. Hierzu geh&ouml;ren 
                        neben der Pflege der Darmflora auch die Gesunderhaltung der Darmschleimhaut.
                        <br />
                        <br />
                        Eine optimale Pflege der Darmschleimhaut erreichen Sie recht einfach durch den 
                        Umstieg auf eine naturbelassene Vollwertkost, den weitgehenden Verzicht 
                        auf industriell verarbeitete Produkte und S&uuml;&#223;es und durch die 
                        Reduzierung von Genussmitteln auf ein vern&uuml;nftiges Ma&#223;. Lassen 
                        Sie sich f&uuml;r diesen Umstieg gen&uuml;gend Zeit, denn zum einen kann 
                        ein kr&auml;nkliches Verdauungssystem eine abrupte &Auml;nderung &uuml;bel 
                        nehmen und mit verst&auml;rkten Beschwerden wie Durchf&auml;llen und 
                        Bl&auml;hungen reagieren, und zum anderen &auml;ndern sich jahrelang 
                        eingeschliffene Vorlieben nicht von heute auf morgen. Eine pl&ouml;tzliche 
                        Umstellung Ihrer Ern&auml;hrung w&uuml;rde mit gro&#223;er Sicherheit 
                        aufgrund der auftretenden Beschwerden und der Vergewaltigung Ihrer 
                        Gewohnheiten zum Scheitern verurteilt sein.
                        <br />
                        <br />
                        Mit dem Verzehr von immer mehr vollwertigen Nahrungsmitteln mit ihren rauhen 
                        Pflanzenfasern werden die alten, verhornten und abgestorbenen Zellen an der 
                        Oberfl&auml;che der Darmschleimhaut abgetragen, und die Schleimhaut 
                        verj&uuml;ngt sich. Der Verzicht auf industriell verarbeitete Produkte 
                        und S&uuml;&#223;es unterst&uuml;tzt die Regeneration der Darmflora, die nun 
                        wiederum mit ihren Schutzfunktionen der Darmschleimhaut hilft. Mit der 
                        Reduzierung von Genussmitteln und ggf. mit der Entw&ouml;hnung vom Rauchen 
                        wird die Darmschleimhaut wieder besser durchblutet, weil die zusammenziehende 
                        Wirkung des Nikotins auf die Gef&auml;&#223;e unterbleibt, und eine optimale Durchblutung 
                        die Zellen wieder ausreichend mit N&auml;hrstoffen versorgen kann. Trinken Sie 
                        ausreichend stille oder kohlens&auml;urearme Mineralw&auml;sser, Leitungswasser, 
                        Kr&auml;uter- oder Fr&uuml;chtetees und ab und an auch verd&uuml;nnte 
                        Fruchts&auml;fte, damit zum einen die Fl&uuml;ssigkeitsversorgung der 
                        Zellen gew&auml;hrleistet ist und zum anderen die Beschaffenheit des 
                        Stuhlganges nicht zu fest wird. Auf diese Weise wird die Arbeit des Darmes 
                        erleichtert, der Stuhl wird z&uuml;gig durch den Darm bef&ouml;rdert und eine 
                        zu intensive Einwirkung von Gift- und Schadstoffen auf die Darmschleimhaut unterbleibt.
                        <br />
                        <br />
                        Bewegen Sie sich m&ouml;glichst viel, treiben Sie leichten Sport, um die 
                        Darmperistaltik zu f&ouml;rdern, denn auch die Darmmuskulatur kann, wie die 
                        &uuml;brige Muskulatur, durch mangelhafte Bewegung verk&uuml;mmern und 
                        Beschwerden verst&auml;rken. Gehen Sie dazu m&ouml;glichst oft an die 
                        frische Luft, denn die Aufnahme von Sauerstoff f&ouml;rdert eine gute 
                        Durchblutung des gesamten Verdauungssystems.
                        <br />
                        <br />
                        <a href="guterrat" target="_blank"><img src="<?php echo IMG_PATH; ?>hilfreich.png" alt="" class="left" /></a>
                        <br />
                        <br />
                        <hr />
                        Lesen Sie auch folgende Betr&auml;ge:
                        <br />
                        <a href="darmgesundheit">&#149; Darmpflege: Gesunder Darm &ndash; gesunder Mensch</a>
                        <br />
                        <a href="verdauung">&#149; Gesunde Verdauung</a>
                        <br />
                        <a href="darmflora">&#149; Pflege der Darmflora</a>
                        <br />
                        <a href="darmsanierung">&#149; Sanierung der Darmflora</a>
                        <br />
                        <a href="duenndarmfehlbesiedelung">&#149; Dünndarmfehlbesiedelung und ihre Behandlung</a>
                        <br />
                        <hr />
                        <a href="javascript: scrollMainToTop();" class="nachoben">nach oben</a>
                    </div>
                </div>
            </div>    
            <br>
            <br> 
            <div class="bodyspacer"></div> 
        </div>