        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br /> 
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>
                <h1 class="header center orange-text">eMail-Anfragen</h1>      
                <div class="row center">        
                    <h5 class="header col s12 light">Bedingungen</h5>      
                </div>
            </div>  
        </div> 
        <div class="container">    
            <div class="section">   
                <div class="row margintoprow">        
                    <div class="col s12 m12">
                    <hr />
                    <h5>Bevor Sie mir eine eMail senden, lesen Sie bitte unbedingt die folgenden Bedingungen:</h5>
                    <hr />
                    </div>
                    </div>
                <div class="row">        
                    <div class="col s12 m12">
                        <a href="shop#beratung-email"><img src="<?php echo IMG_PATH; ?>beratung-shop-kurz.png" alt="" class="right" /></a>
                        Meine eMail-Adresse lautet &#187;<b><a href="mailto:kontakt@dorispaas.de" class="link">kontakt@dorispaas.de</a></b>&#171;.
                        <br />
                        <br />
                        
                        <b>&#149;</b> Aus rechtlichen Gründen darf ich <b>keine Fragen zu Ihren individuellen medizinischen 
                        Problemen oder zu Medikamenten</b>, die Ihnen verordnet wurden, außerhalb einer 
                        offiziellen Beratung beantworten! 
                        <br />
                        <br />
                        <b>&#149;</b> Grundsätzlich <b>nicht möglich</b> ist die Bearbeitung von Anfragen 
                        zu Krankheiten, deren Diagnose und Beurteilung eine ärztliche Beratung und Untersuchung 
                        erfordern. Auch Probleme, deren Beurteilung die Auswertung von Untersuchungsergebnissen 
                        erfordern, können selbstverständlich nicht per eMail beantwortet werden. 
                        <br />
                        <br />
                        <b>&#149;</b> Wenn Sie jedoch eine <b>allgemeine</b> Frage zu den auf dieser Website behandelten Themen haben, 
                        beantworte ich Ihnen diese gerne. 
                        <br />
                        <br />
                        <b>&#149;</b> Bitte formulieren Sie in diesem Falle Ihre Frage so ausführlich wie möglich, der 
                        Umfang sollte jedoch 1000 Zeichen (etwa eine viertel DIN A4-Seite) nicht überschreiten.
                        <br />
                        <p class=" hinweis">
                        <b>Bitte senden Sie mir keine Mails mit Anhängen, ohne dies zuvor mit mir abgesprochen zu haben. 
                        Aus Sicherheitsgründen werden Mails mit unerwarteten Anhängen in den Spamordner 
                        geleitet und gelöscht. </b>
                        </p>
                        <b>&#149;</b> Da ich mir für die Beantwortung Ihrer Frage Zeit nehme und Ihnen dazu eine ausführliche, 
                        individuelle Rückmeldung zusende, erbitte ich dafür eine Kurzberatungsgebühr von 20,-€. 
                        Sie haben die Möglichkeit, im Shop die 
                        &#187;<a href="shop#beratung-email">Beantwortung einer eMail-Anfrage</a>&#171; zu buchen.
                        <br />
                        <br />
                        <b>&#149;</b> <b>Mit der Buchungsbestätigung erhalten Sie eine Kundennummer, die Sie bitte mit Ihrer 
                        Frage als <a href="mailto:kontakt@dorispaas.de" class="link">eMail</a> an mich senden. Sicherlich 
                        haben Sie Verständnis dafür, dass ich ohne Kundennummer keine Fragen beantworten kann.</b>
                        <br />
                        <br />
                        <b>Tipp:</b> Es ist ratsam, wenn Sie zuvor auf der Seite <a href="faq">Fragen und Antworten</a>
                        schauen, ob es auf diese oder eine gleichgelagerte Frage bereits eine Antwort gibt, 
                        damit Sie nicht umsonst Geld ausgeben müssen.
                        <br />
                        <br />
                        <br />
                        <hr>
                        <a id="beratung">&nbsp;</a>
                        <div class="row">
                        <div class="col s12 m2">
                            <a href="http://www.ganzheitliche-gesundheitsberatung.de" target="_blank">
                                <img src="<?php echo IMG_PATH; ?>praxiswebsite.png" alt="" class="inline" /></a>
                        </div>
                        </div>
                        <div class="row">
                        <div class="col s12 m12">
                        <h5>Beratung</h5>
                        <br />
                        Wenn Sie eine umfassendere Beratung wünschen, stehe ich Ihnen im Rahmen meiner 
                        Tätigkeit in der &#187;<a href="http://www.ganzheitliche-gesundheitsberatung.de" target="_blank">Praxis 
                        für Ganzheitliche Gesundheitsberatung und Prävention</a>&#171; gerne zur Verfügung.
                        Rufen Sie mich an oder senden Sie mir eine eMail. 
                        Wenn Sie weiter entfernt wohnen, biete ich Ihnen in diesem Rahmen auch gerne 
                        eine Telefonberatung an.
                            <br />
                            Bitte informieren Sie sich auf meiner Praxis-Website <a href="http://www.ganzheitliche-gesundheitsberatung.de" target="_blank">&#187;www.Ganzheitliche-Gesundheitsberatung.de&#171;</a>
                        </div>
                        </div>
                        <hr>
                        <a href="javascript: scrollMainToTop();" class="nachoben">nach oben</a>
                    </div>
                </div>
            </div>    
            <br>
            <br> 
            <div class="bodyspacer"></div> 
        </div>