        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br /> 
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>
                <h1 class="header center orange-text">Nahrungsmittelallergien und -unvertr&auml;glichkeiten</h1>      
            </div>  
        </div> 
        <div class="container">    
            <div class="section">   
                <div class="row margintoprow">        
                    <div class="col s12 m5">
                        <img src="<?php echo IMG_PATH; ?>frontcover-allergien.png" alt="" class="book_img" />
                    </div>
                    <div class="col s12 m7">
                        <h5>Nahrungsmittelallergien und -unvertr&auml;glichkeiten<br /></h5>
                        <br />
                        Compact Verlag, M&uuml;nchen<br />
                        ISBN 978-3-8174-6631-3<br />
                        Broschur, 160 Seiten<br />
                        9,80 &euro;<br />
                        <span style="font-size:0.8em">Endpreis &ndash; nach §19UStG kein zusätzlicher MwSt.-Aufschlag</span>
                        <br />
                        <br /> 
                        <br />
                        <b><a href="<?php echo URL_ROOT; ?>book2/buchbeschreibung">&#149; Buchbeschreibung</a></b>
                        <br />
                        <br />
                        <b><a href="<?php echo URL_ROOT; ?>newbook-content">&#149; Inhaltsverzeichnis</a></b>
                        <br />
                        <br />
                        <br />
                        <b>Bestellmöglichkeit</b>
                        <br />
                        <br />
                        <a href="shop#buecher">direkt hier im Shop</a>  
                    </div>
                </div>
            </div>    
            <br>
            <br> 
            <div class="bodyspacer"></div> 
        </div>