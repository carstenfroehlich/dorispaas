        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br /> 
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>
                <h1 class="header center orange-text">Vitamin D und Sonne</h1>      
            </div>  
        </div> 
        <div class="container">    
            <div class="section">   
                <div class="row margintoprow">        
                    <div class="col s12 m12">
                        Vitamin D ist eines der wichtigsten Vitamine: Es ist nicht nur dafür verantwortlich, 
                        als so genanntes Antioxydans vor den gesundheitsschädlichen freien Radikalen 
                        zu schützen oder das Immunsystem widerstandsfähig zu erhalten. Vitamin 
                        D ist auch ein essentieller, also ein unverzichtbarer Stoff, der die Knochen 
                        gesund erhält und so u.a. vor Osteoporose schützen kann.
                        <br />
                        <br />
                        Es reicht allein nicht, mit der Nahrung den Mineralstoff Kalzium aufzunehmen, denn 
                        dieser benötigt ein &#187;Transportmittel&#171;, um in das Gerüst der 
                        Knochenstruktur eingelagert werden zu können. Eines dieser Transportmittel 
                        ist das Vitamin D (Calciferol). Eine gute Vitamin D-Versorgung stellt neben einer 
                        ausreichenden Kalzium-Aufnahme sicher, dass die Knochen gesund, stabil und 
                        belastungsfähig bleiben.
                        <br />
                        <br />
                        Auch wenn die Grundlagen für gesunde Knochen bereits im Kindesalter gelegt 
                        werden, darf man sich als Erwachsener jedoch keineswegs auf diesen &#187;Lorbeeren&#171; 
                        ausruhen. Jeden Tag ist es erforderlich, mit einer gesunden Ernährung dafür 
                        zu sorgen, dass die Knochen mit allen Nährstoffen versorgt werden, die sie 
                        benötigen. Ausreichend Bewegung und damit eine gesunde Belastung und ein 
                        vernünftiges Training tragen ebenfalls dazu bei, einem Knochenabbau entgegenzuwirken.
                        <br />
                        <br />
                        Jeder einzelne der über 200 Knochen unseres Skeletts ist stark beansprucht 
                        &ndash; und hätten die Knochen keine erneuernde und regenerierende Funktion, 
                        wäre es unmöglich, sich ein ganzes Menschenleben im wahrsten Sinne des 
                        Wortes darauf stützen zu können. Um eine solche Regeneration zu gewährleisten, 
                        bauen täglich bestimmte Zellen (die Osteoklasten) altes Knochenmaterial ab, 
                        während ihre Gegenspieler (die Osteoblasten) die Knochen wieder aufbauen und 
                        erneuern.
                        <br />
                        <br />
                        Für diesen intensiven Zellaufbau sind sowohl diverse Mineralstoffe erforderlich, 
                        insbesondere Kalzium und Magnesium, zusätzlich wird das Transportmittel Vitamin D 
                        benötigt. Die Deutsche Gesellschaft für Ernährung gibt in ihrer 
                        DACH-Liste die täglich zuzuführende Menge dieses Vitamins für 
                        Erwachsene mit 20 Mikrogramm bzw. 800 IE an, wobei diese Angaben von Zeit zu Zeit 
                        (zuletzt 2012) geändert werden, denn so wirklich genau kann ein Bedarf nicht 
                        ermittelt, sondern lediglich geschätzt werden.
                        <br />
                        <br />
                        Ein Vitamin D-Mangel führt bei Kindern u.a. zu Rachitis (eingefallenes Brustbein 
                        (&#187;Hühnerbrust&#171;), weicher, deformierter Schädel, O-Beine). Bei 
                        Erwachsenen ist die Osteomalzie &ndash; also die &#187;Aufweichung&#171; der Knochen 
                        &ndash; eine erste Stufe. Wird der Osteomalzie nicht entgegengewirkt, kann eine 
                        Osteoporose mit spontanen Knochenbrüchen die Folge sein.
                        <br />
                        <br />
                        DAS Vitamin D ist eigentlich eine Gruppe von Vitaminen, wobei das aus pflanzlichen 
                        Quellen stammende Vitamin D als Vitamin D<sub>2</sub> bzw. Ergocalciferol bezeichnet wird. 
                        Das Vitamin D aus tierischer Herkunft hei&#223;t Vitamin D<sub>3</sub> bzw. Cholecalciferol.
                        <br />
                        <br />
                        In vielen pflanzlichen und tierischen Produkten ist Vitamin D enthalten. Besonders 
                        gehaltvoll sind pflanzliche Öle, weil das Vitamin D (neben den Vitaminen A, 
                        D und K) eines der 4 fettlöslichen Vitamine ist, aber auch Pilze oder Avocados 
                        und viele andere pflanzliche Nahrungsmittel sind gute Vitamin D-Lieferanten. 
                        Besonders viel Vitamin D tierischer Herkunft ist enthalten in Fettfischen und Leber, 
                        aber auch in Milch und Milchprodukten. Wer von uns älteren Semestern erinnert 
                        sich nicht noch schaudernd an den täglichen Esslöffel Lebertran, den wir 
                        zur Rachitisprophylaxe von unseren wohlmeindenden Eltern eingetrichtert bekommen haben!
                        <br />
                        <br />
                        All diese Überlegungen und Klimmzüge um eine gesunde, Vitamin D-reiche 
                        Ernährung machen sich jedoch diejenigen Völker, die in den sonnenreichen 
                        Gebieten rund um den Äquator leben, nicht &ndash; und das aus einem guten Grund: 
                        Das Vitamin D ist nämlich das einzige Vitamin, das wir nicht allein mit der 
                        Nahrung aufnehmen müssen, sondern das unser Körper unter bestimmten 
                        Voraussetzung selbst bilden kann. Und diese Voraussetzung ist Sonneneinstrahlung. 
                        Mit Hilfe des Sonnenlichts kann in unserer Haut Vitamin D gebildet werden. 
                        <br />
                        <br />
                        Was in unseren eher sonnenarmen Breiten für viele Menschen ein Problem 
                        darzustellen scheint, ist in den sonnenreichen Gebieten überhaupt kein Thema: 
                        Menschen, die sich genügend der Sonne aussetzen, leiden nicht an Vitamin D-Mangel!
                        <br />
                        <br />
                        Auch wir können mit Hilfe von Sonnenlicht genügend Vitamin D bilden, 
                        um zusätzlich mit einer gesunden Ernährung unseren Vitamin D-Spiegel 
                        leicht decken zu können. Wir müssen hier auch nicht täglich rechnen, 
                        was wir essen, wie viel des Vitamins in den einzelnen Nahrungsmitteln enthalten 
                        ist und wie lange genau wir  mit wie viel unbedeckter Haut in die Sonne gehen. 
                        <br />
                        <br />
                        Vitamin D wird relativ lange im Körper gespeichert. Es reicht, im Sommer ein 
                        kurzes tägliches Sonnenbad zu nehmen, wobei wir uns keineswegs einen 
                        gefährlichen Sonnenbrand einhandeln müssen &ndash; 5-10 Minuten mit 
                        möglichst viel unbedeckter Haut sind völlig ausreichend. Diese Zeitspanne 
                        ist selbst in der Mittagssonne, deren Strahlungsspektrum optimal für die 
                        Vitamin D-Synthese ist, kurz genug, um auch empfindliche, hellhäutige Typen 
                        nicht zu gefährden. Dies muss jetzt natürlich auch nicht immer DAS 
                        gezielte Sonnenbad sein &ndash; ein Spaziergang, bei dem wir mal ganz bewusst die 
                        Sonne genie&#223;en, ist völlig ausreichend. 
                        <br />
                        <br />
                        Beachten Sie, dass Sie in dieser Zeit keine 
                        Sonnenschutzpräparate auftragen. Selbstverständlich müssen Sie nach 
                        dieser kurzen &#187;Auftankzeit&#171; anschlie&#223;end ein gutes Sonnenschutzpräparat 
                        auftragen, um keinen Schaden zu leiden. Und denken Sie bitte immer an einen 
                        ausreichenden Kopfschutz!
                        <br />
                        <br />
                        Selbstverständlich wird zu allen anderen Tages- und Jahreszeiten, die man 
                        drau&#223;en in der Sonne oder sogar &#187;nur&#171; im Tageslicht verbringt, ebenfalls Vitamin 
                        D in der Haut gebildet. Die Sommer- und Sonnenmonate füllen jedoch die Vitamin 
                        D-Speicher soweit auf, dass die Versorgung zusammen mit den relativ kleinen Mengen 
                        aus der Nahrung und der durch die ganzjährigen täglichen Spaziergänge 
                        zugeführten Portionen über das ganze Jahr ausreichend ist.
                        <br />
                        <br />
                        Besonders wichtig ist es auch für Menschen mit (zeitweise) geschädigter 
                        Darmschleimhaut, die körpereigene Vitamin D-Synthese zu nutzen. Patienten mit 
                        Zöliakie oder chronisch entzündlichen Darmerkrankungen wie Morbus Crohn 
                        oder Colitis ulcerosa beispielsweise haben durch die gestörte Aufnahme von 
                        Vitamin D aus der Nahrung ein stark erhöhtes Osteoporoserisiko, denn sie 
                        können das mit der Nahrung verzehrte Vitamin D nicht optimal über die 
                        Darmschleimhaut aufnehmen. Deshalb stellt hier die Nutzung der körpereigenen 
                        Vitamin D-Synthese durch Sonneneinstrahlung eine gute Alternative und phantastische 
                        Osteoporoseprophylaxe dar.
                        <br />
                        <br />
                        Auch in Kulturen, in denen insbesondere die Frauen häufig ihren Körper 
                        bedecken und verschleiern, sind die Menschen ganz besonders der Gefahr einer 
                        Unterversorgung mit Vitamin D ausgesetzt. Hier ist es besonders wichtig, dass 
                        auch diese Menschen sich in geschützten Räumen (z.B. einem 
                        einblicksgeschützten Garten) möglichst oft und mit möglichst viel 
                        unbedeckter Haut der Sonne aussetzen, um ihre Vitamin D-Speicher auffüllen 
                        zu können. 
                        <br />
                        <br />
                        Nur in ganz besonderen Fällen sollte man Vitamin D als Nahrungsergänzungs-Präparat 
                        substituieren, wobei man hier unbedingt einen Arzt zur Bestimmung der Blutwerte 
                        und der Verordnung eines geeigneten Präparates hinzuziehen sollte. Vom 
                        Gebrauch von Vitamin D als frei verkäufliches Mittel, das womöglich 
                        noch andere, meist völlig willkürlich dosierte Vitamine und/oder Mineralstoffe 
                        enthält, möchte ich Ihnen dringend abraten. Eine Überdosierung von 
                        Vitamin D durch Nahrungsergänzungsmittel ist rasch erreicht und kann fatale 
                        Folgen haben. 
                        <br />
                        <hr />
                        <b>Bitte lesen Sie hierzu auch den Beitrag &#187;<a href="ganz-vitamine" target="_blank">Vitamine
                        und Mineralstoffe &ndash; nützlich oder überflüssig?</a>&#171;.</b>
                        <hr />
                        <br />
                        Eine Überdosierung durch gesunde Nahrungsmittel und durch 
                        Sonneneinstrahlung &ndash; auch durch viel Sonneneinstrahlung &ndash; gibt es nicht. 
                        Allerdings empfehle ich Ihnen dringend, wie oben erwähnt, die Dauer von 
                        Sonnenbädern allein aufgrund der Hautkrebsgefahr auf ein vernünftiges 
                        Ma&#223; zu reduzieren.
                        <br />
                        <hr />
                        <a href="<?php echo URL_ROOT; ?>guterrat" target="_blank"><img src="<?php echo IMG_PATH; ?>hilfreich.png" alt="" class="left" /></a>
                        <br />
                        <br />
                        <hr />
                        <a href="javascript: scrollMainToTop();" class="nachoben">nach oben</a>
                    </div>
                </div>
            </div>    
            <br>
            <br> 
            <div class="bodyspacer"></div> 
        </div>