<div id="chapter_16" style="display: none;">
    <table border="0" cellspacing="0" cellpadding="0" class="chapter">
        <tr>
            <td class="num">16.1</td>
            <td class="caption">Das Hauptprogramm</td>
        </tr> 
        <tr>
            <td class="num">16.2</td>
            <td class="caption">Begleitprogramm: das Leben ist sch&ouml;n</td>
        </tr> 
        <tr>
            <td class="num">16.3</td>
            <td class="caption">Stress-Management</td>
        </tr> 
        <tr>
            <td class="num">16.3.1</td>
            <td class="caption">Eustress</td>
        </tr> 
        <tr>
            <td class="num">16.3.2</td>
            <td class="caption">Dysstress</td>
        </tr> 
        <tr>
            <td class="num">16.3.3</td>
            <td class="caption">Schlaf</td>
        </tr> 
        <tr>
            <td class="num">16.4</td>
            <td class="caption">Gef&uuml;hltes Befinden</td>
        </tr> 
    </table>
</div>
