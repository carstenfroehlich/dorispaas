<div id="chapter_10" style="display: none;">
    <table border="0" cellspacing="0" cellpadding="0" class="chapter">
        <tr>
            <td class="num">10.1</td>
            <td class="caption">Sanierung der Darmschleimhaut</td>
        </tr> 
        <tr>
            <td class="num">10.2</td>
            <td class="caption">Sanierung der Darmflora</td>
        </tr> 
    </table>
</div>
