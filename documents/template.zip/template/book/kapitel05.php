<div id="chapter_5" style="display: none;">
    <table border="0" cellspacing="0" cellpadding="0" class="chapter">
        <tr>
            <td class="num">5.1</td>
            <td class="caption">Verzehrtagebuch</td>
        </tr> 
        <tr>
            <td class="num">5.2</td>
            <td class="caption">Eliminations-Di&auml;t und Provokationstest</td>
        </tr> 
        <tr>
            <td class="num">5.3</td>
            <td class="caption">H<sub>2</sub>-Atemtest</td>
        </tr> 
        <tr>
            <td class="num">5.4</td>
            <td class="caption">Laktose-Belastungstest (Bluttest)</td>
        </tr> 
        <tr>
            <td class="num">5.5</td>
            <td class="caption">D&uuml;nndarmbiopsie</td>
        </tr> 
        <tr>
            <td class="num">5.6</td>
            <td class="caption">Gentest</td>
        </tr> 
    </table>
</div>
