<div id="chapter_15" style="display: none;">
    <table border="0" cellspacing="0" cellpadding="0" class="chapter">
        <tr>
            <td class="num">15.1</td>
            <td class="caption">Strategisches Vorgehen</td>
        </tr> 
        <tr>
            <td class="num">15.1.1</td>
            <td class="caption">Laktosekontrollierte Ern&auml;hrung</td>
        </tr> 
        <tr>
            <td class="num">15.1.2</td>
            <td class="caption">Ausschluss von bedrohlichen Krankheiten</td>
        </tr> 
        <tr>
            <td class="num">15.1.3</td>
            <td class="caption">Zauberwort &#187;Gelassenheit&#171;</td>
        </tr> 
        <tr>
            <td class="num">15.1.4</td>
            <td class="caption">Nicht in Panik geraten</td>
        </tr> 
        <tr>
            <td class="num">15.1.5</td>
            <td class="caption">Eins nach dem anderen</td>
        </tr> 
        <tr>
            <td class="num">15.1.6</td>
            <td class="caption">Selbsthilfegruppen</td>
        </tr> 
        <tr>
            <td class="num">15.2</td>
            <td class="caption">(K)eine anr&uuml;chige Sache &#150; der Toilettengang</td>
        </tr> 
        <tr>
            <td class="num">15.3</td>
            <td class="caption">Mein K&ouml;rper &#150; mein Freund</td>
        </tr> 
        <tr>
            <td class="num">15.4</td>
            <td class="caption">Berufst&auml;tigkeit mit Laktose-Intoleranz</td>
        </tr> 
        <tr>
            <td class="num">15.5</td>
            <td class="caption">Ausw&auml;rts Essen</td>
        </tr> 
        <tr>
            <td class="num">15.5.1</td>
            <td class="caption">Im Restaurant</td>
        </tr> 
        <tr>
            <td class="num">15.5.2</td>
            <td class="caption">In der Kantine</td>
        </tr> 
        <tr>
            <td class="num">15.5.3</td>
            <td class="caption">Einladung bei Verwandten und Freunden</td>
        </tr> 
        <tr>
            <td class="num">15.5.4</td>
            <td class="caption">Das kalte/warme B&uuml;ffet</td>
        </tr> 
        <tr>
            <td class="num">15.5.5</td>
            <td class="caption">Weihnachtsmann und Osterhase</td>
        </tr> 
        <tr>
            <td class="num">15.6</td>
            <td class="caption">Reisen mit Laktose-Intoleranz</td>
        </tr> 
        <tr>
            <td class="num">15.6.1</td>
            <td class="caption">Essen auf Reisen</td>
        </tr> 
        <tr>
            <td class="num">15.6.2</td>
            <td class="caption">Verstopfung auf Reisen</td>
        </tr> 
        <tr>
            <td class="num">15.6.3</td>
            <td class="caption">Durchfall auf Reisen</td>
        </tr> 
        <tr>
            <td class="num">15.6.4</td>
            <td class="caption">Reiseapotheke</td>
        </tr> 
        <tr>
            <td class="num">15.7</td>
            <td class="caption">Infekti&ouml;ser Brech-Durchfall</td>
        </tr> 
        <tr>
            <td class="num">15.8</td>
            <td class="caption">Genussmittel</td>
        </tr> 
        <tr>
            <td class="num">15.9</td>
            <td class="caption">Eine weitere Hilfe: die pulsierende Elektromagnetfeld-Therapie</td>
        </tr> 
        <tr>
            <td class="num">15.10</td>
            <td class="caption">Behindertenstatus bei Laktose-Intoleranz</td>
        </tr> 
        <tr>
            <td class="num">15.11</td>
            <td class="caption">Wenn Sie keinen Erfolg haben</td>
        </tr> 
    </table>
</div>
