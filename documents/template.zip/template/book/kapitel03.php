<div id="chapter_3" style="display: none;">
    <table border="0" cellspacing="0" cellpadding="0" class="chapter">
        <tr>
            <td class="num">3.1</td>
            <td class="caption">Durchfall (Diarrhoe)</td>
        </tr> 
        <tr>
            <td class="num">3.2</td>
            <td class="caption">Verstopfung (Obstipation)</td>
        </tr> 
        <tr>
            <td class="num">3.3</td>
            <td class="caption">Bl&auml;hungen (Meteorismus, Flatulenz)</td>
        </tr> 
        <tr>
            <td class="num">3.4</td>
            <td class="caption">St&auml;ndiger Stuhl- und Harndrang (Tenesmus)</td>
        </tr> 
        <tr>
            <td class="num">3.5</td>
            <td class="caption">Reizdarm-Syndrom als Folge der LI</td>
        </tr> 
        <tr>
            <td class="num">3.6</td>
            <td class="caption">V&ouml;llegef&uuml;hl</td>
        </tr> 
        <tr>
            <td class="num">3.7</td>
            <td class="caption">&Uuml;belkeit, Aufsto&#223;en und Mundgeruch</td>
        </tr> 
        <tr>
            <td class="num">3.8</td>
            <td class="caption">Bauchschmerzen und Kr&auml;mpfe</td>
        </tr> 
        <tr>
            <td class="num">3.9</td>
            <td class="caption">Herz-Kreislaufbeschwerden, Blutdruckabfall</td>
        </tr> 
        <tr>
            <td class="num">3.10</td>
            <td class="caption">Gest&ouml;rter Vitamin- und Mineralstoff-Haushalt</td>
        </tr> 
        <tr>
            <td class="num">3.11</td>
            <td class="caption">St&ouml;rungen der Sexualit&auml;t</td>
        </tr> 
        <tr>
            <td class="num">3.12</td>
            <td class="caption">Schlafst&ouml;rungen</td>
        </tr> 
        <tr>
            <td class="num">3.13</td>
            <td class="caption">Psychische Beeintr&auml;chtigungen</td>
        </tr>
    </table>
</div>
