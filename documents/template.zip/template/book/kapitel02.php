<div id="chapter_2" style="display: none;">
    <table border="0" cellspacing="0" cellpadding="0" class="chapter">
        <tr>
            <td class="num2"><i>F&uuml;r das Kapitel 2<br />ist keine Untergliederung vorhanden</i></td>
        </tr> 
    </table>
</div>
