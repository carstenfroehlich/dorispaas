<div id="chapter_17" style="display: none;">
    <table border="0" cellspacing="0" cellpadding="0" class="chapter">
        <tr>
            <td class="num">17.1</td>
            <td class="caption">Beckenbodengymnastik</td>
        </tr> 
        <tr>
            <td class="num">17.1.1</td>
            <td class="caption">Die Beckenbodenmuskulatur kennen lernen</td>
        </tr> 
        <tr>
            <td class="num">17.1.2</td>
            <td class="caption">Nicht nur f&uuml;r Frauen: Bauchtanz</td>
        </tr> 
        <tr>
            <td class="num">17.2</td>
            <td class="caption">Blasentraining</td>
        </tr> 
        <tr>
            <td class="num">17.3</td>
            <td class="caption">Atemtechniken</td>
        </tr> 
        <tr>
            <td class="num">17.3.1</td>
            <td class="caption">Atmen lernen</td>
        </tr> 
        <tr>
            <td class="num">17.3.2</td>
            <td class="caption">Die Dreieck&uuml;bung</td>
        </tr> 
        <tr>
            <td class="num">17.3.3</td>
            <td class="caption">Richtiges Sitzen ist wichtig</td>
        </tr> 
        <tr>
            <td class="num">17.3.4</td>
            <td class="caption">Singen</td>
        </tr> 
        <tr>
            <td class="num">17.3.5</td>
            <td class="caption">Richtiges Atmen durch Sport</td>
        </tr> 
        <tr>
            <td class="num">17.4</td>
            <td class="caption">Entspannungs&uuml;bungen</td>
        </tr> 
        <tr>
            <td class="num">17.4.1</td>
            <td class="caption">Konzentrierte Entspannungs&uuml;bungen</td>
        </tr> 
        <tr>
            <td class="num">17.4.2</td>
            <td class="caption">Progressive Muskelentspannung nach Jacobson</td>
        </tr>
        <tr>
            <td class="num">17.4.3</td>
            <td class="caption">Autogenes Training</td>
        </tr> 
        <tr>
            <td class="num">17.4.4</td>
            <td class="caption">Yoga</td>
        </tr> 
        <tr>
            <td class="num">17.4.5</td>
            <td class="caption">Meditation</td>
        </tr> 
    </table>
</div>
