<div id="chapter_14" style="display: none;">
    <table border="0" cellspacing="0" cellpadding="0" class="chapter">
        <tr>
            <td class="num">14.1</td>
            <td class="caption">Laktaseerg&auml;nzungsmittel</td>
        </tr> 
        <tr>
            <td class="num">14.2</td>
            <td class="caption">Probiotische Nahrungserg&auml;nzungsmittel</td>
        </tr> 
        <tr>
            <td class="num">14.3</td>
            <td class="caption">Kombinationspr&auml;parate</td>
        </tr> 
        <tr>
            <td class="num">14.4</td>
            <td class="caption">L&ouml;sung zum Zubereiten von laktosefreier Milch</td>
        </tr> 
        <tr>
            <td class="num">14.5</td>
            <td class="caption">Pr&auml;biotische Nahrungserg&auml;nzungsmittel</td>
        </tr> 
    </table>
</div>
