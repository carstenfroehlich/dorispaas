        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br /> 
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>
                <h1 class="header center orange-text">Das Laktose-Intoleranz Buch</h1>  
                <div class="row center">        
                    <h5 class="header col s12 light">Inhaltsverzeichnis</h5>      
                </div>       
            </div>  
        </div> 
        <div class="container">    
            <div class="section">   
                <div class="row margintoprow">        
                    <div class="col s12 m6">
                        <table border="0" cellspacing="0" cellpadding="0" class="chapters_index">
                            <tr>
                                <td class="num">1</td>
                                <td class="caption">
                                    <span style="cursor: pointer;" onclick="javascript: switchChapter( 'chapter_1' );">
                                        Du hast schon immer viel gepupst
                                    </span>
                                </td>
                            </tr>
                            <tr>
                                <td class="num">2</td>
                                <td class="caption">
                                    <span style="cursor: pointer;" onclick="javascript: switchChapter( 'chapter_2' );">
                                        Definition
                                    </span>
                                </td>
                            </tr>
                            <tr>
                                <td class="num">3</td>
                                <td class="caption">
                                    <span style="cursor: pointer;" onclick="javascript: switchChapter( 'chapter_3' );">
                                        Symptome der Laktose-Intoleranz
                                    </span>
                                </td>
                            </tr>
                            <tr>
                                <td class="num">4</td>
                                <td class="caption">
                                    <span style="cursor: pointer;" onclick="javascript: switchChapter( 'chapter_4' );">
                                        Jetzt wird's wissenschaftlich: was ist Laktose?
                                    </span>
                                </td>
                            </tr>
                            <tr>
                                <td class="num">5</td>
                                <td class="caption">
                                    <span style="cursor: pointer;" onclick="javascript: switchChapter( 'chapter_5' );">
                                        Diagnosesicherungs-Methoden
                                    </span>
                                </td>
                            </tr>
                            <tr>
                                <td class="num">6</td>
                                <td class="caption">
                                    <span style="cursor: pointer;" onclick="javascript: switchChapter( 'chapter_6' );">
                                        Reizdarm-Syndrom (RDS)
                                    </span>
                                </td>
                            </tr>
                            <tr>
                                <td class="num">7</td>
                                <td class="caption">
                                    <span style="cursor: pointer;" onclick="javascript: switchChapter( 'chapter_7' );">
                                        Weitere Nahrungsmittel-Unvertr&auml;glichkeiten und Abgrenzungsm&ouml;glichkeiten
                                    </span>
                                </td>
                            </tr>
                            <tr>
                                <td class="num">8</td>
                                <td class="caption">
                                    <span style="cursor: pointer;" onclick="javascript: switchChapter( 'chapter_8' );">
                                        Folge-Erkrankungen bei Laktose-Intoleranz
                                    </span>
                                </td>
                            </tr>
                            <tr>
                                <td class="num">9</td>
                                <td class="caption">
                                    <span style="cursor: pointer;" onclick="javascript: switchChapter( 'chapter_9' );">
                                        Viel zu wenig beachtet: Laktose-Intoleranz im Alter
                                    </span>
                                </td>
                            </tr>
                            <tr>
                                <td class="num">10</td>
                                <td class="caption">
                                    <span style="cursor: pointer;" onclick="javascript: switchChapter( 'chapter_10' );">
                                        Sanierung des Darmes
                                    </span>
                                </td>
                            </tr>
                            <tr>
                                <td class="num">11</td>
                                <td class="caption">
                                    <span style="cursor: pointer;" onclick="javascript: switchChapter( 'chapter_11' );">
                                        Allgemeine Ern&auml;hrungs-Richtlinien
                                    </span>
                                </td>
                            </tr>
                            <tr>
                                <td class="num">12</td>
                                <td class="caption">
                                    <span style="cursor: pointer;" onclick="javascript: switchChapter( 'chapter_12' );">
                                        Milch
                                    </span>
                                </td>
                            </tr>
                            <tr>
                                <td class="num">13</td>
                                <td class="caption">
                                    <span style="cursor: pointer;" onclick="javascript: switchChapter( 'chapter_13' );">
                                        Fahrplan f&uuml;r die Ern&auml;hrungsumstellung
                                    </span>
                                </td>
                            </tr>
                            <tr>
                                <td class="num">14</td>
                                <td class="caption">
                                    <span style="cursor: pointer;" onclick="javascript: switchChapter( 'chapter_14' );">
                                        Laktase- und andere Nahrungserg&auml;nzungsmittel
                                    </span>
                                </td>
                            </tr>
                            <tr>
                                <td class="num">15</td>
                                <td class="caption">
                                    <span style="cursor: pointer;" onclick="javascript: switchChapter( 'chapter_15' );">
                                        Praktische Tipps zum Leben mit Laktose-Intoleranz
                                    </span>
                                </td>
                            </tr>
                            <tr>
                                <td class="num">16</td>
                                <td class="caption">
                                    <span style="cursor: pointer;" onclick="javascript: switchChapter( 'chapter_16' );">
                                        Stabilisierung des seelischen Gleichgewichtes
                                    </span>
                                </td>
                            </tr>
                            <tr>
                                <td class="num">17</td>
                                <td class="caption">
                                    <span style="cursor: pointer;" onclick="javascript: switchChapter( 'chapter_17' );">
                                        Ein paar Sport-Stunden
                                    </span>
                                </td>
                            </tr>
                            <tr>
                                <td class="num">18</td>
                                <td class="caption">
                                    <span style="cursor: pointer;" onclick="javascript: switchChapter( 'chapter_18' );">
                                        Nur Mut!
                                    </span>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2" class="caption">
                                    <span style="cursor: pointer;" onclick="javascript: switchChapter( 'appendix' );">
                                        Anhang
                                    </span>
                                </td>
                            </tr>
                        </table>
                    </div>
                    <div class="col s12 m6 book content">
                        <div class="th">
                            Untergliederung
                        </div>
                
                            <div id="no_chapter" style="display: block;">
                                Bitte klicken Sie auf die <br />
                                gew&uuml;nschte
                                Kapitel&uuml;berschrift, <br />
                                um die zugeh&ouml;rige <br />
                                Untergliederung anzuzeigen.
                            </div>
                            <?php
                                include( "kapitel01.php" );
                                include( "kapitel02.php" );
                                include( "kapitel03.php" );
                                include( "kapitel04.php" );
                                include( "kapitel05.php" );
                                include( "kapitel06.php" );
                                include( "kapitel07.php" );
                                include( "kapitel08.php" );
                                include( "kapitel09.php" );
                                include( "kapitel10.php" );
                                include( "kapitel11.php" );
                                include( "kapitel12.php" );
                                include( "kapitel13.php" );
                                include( "kapitel14.php" );
                                include( "kapitel15.php" );
                                include( "kapitel16.php" );
                                include( "kapitel17.php" );
                                include( "kapitel18.php" );
                                include( "kapitel19.php" );
                            ?>
                        </div>
                </div>
            </div>    
            <br>
            <br> 
            <div class="bodyspacer"></div> 
        </div>