<div id="chapter_6" style="display: none;">
    <table border="0" cellspacing="0" cellpadding="0" class="chapter">
        <tr>
            <td class="num">6.1</td>
            <td class="caption">Definition des RDS</td>
        </tr> 
        <tr>
            <td class="num">6.2</td>
            <td class="caption">Symptome des RDS (Rom-II-Kriterien)</td>
        </tr> 
        <tr>
            <td class="num">6.3</td>
            <td class="caption">Ausl&ouml;ser und Verst&auml;rker des RDS</td>
        </tr> 
        <tr>
            <td class="num">6.4</td>
            <td class="caption">Diagnosesicherung des RDS</td>
        </tr> 
        <tr>
            <td class="num">6.5</td>
            <td class="caption">Behandlung des RDS</td>
        </tr> 
        <tr>
            <td class="num">6.6</td>
            <td class="caption">Prognose bei RDS</td>
        </tr> 
        <tr>
            <td class="num">6.7</td>
            <td class="caption">Unterscheidungsmerkmale RDS und LI</td>
        </tr> 
    </table>
</div>
