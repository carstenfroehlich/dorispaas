<div id="chapter_8" style="display: none;">
    <table border="0" cellspacing="0" cellpadding="0" class="chapter">
        <tr>
            <td class="num">8.1</td>
            <td class="caption">Psychische Erkrankungen infolge der LI</td>
        </tr> 
        <tr>
            <td class="num">8.2</td>
            <td class="caption">RDS infolge der LI</td>
        </tr> 
        <tr>
            <td class="num">8.3</td>
            <td class="caption">Zerst&ouml;rung von Darmschleimhaut und Darmflora infolge der LI</td>
        </tr> 
        <tr>
            <td class="num">8.4</td>
            <td class="caption">Osteoporose infolge der Laktose-Intoleranz?</td>
        </tr> 
    </table>
</div>
