<div id="chapter_7" style="display: none;">
    <table border="0" cellspacing="0" cellpadding="0" class="chapter">
        <tr>
            <td class="num">7.1</td>
            <td class="caption">Intestinale Fruktose-Intoleranz</td>
        </tr> 
        <tr>
            <td class="num">7.2</td>
            <td class="caption">Histamin-Intoleranz</td>
        </tr> 
        <tr>
            <td class="num">7.3</td>
            <td class="caption">Milcheiwei&#223;allergie</td>
        </tr> 
        <tr>
            <td class="num">7.4</td>
            <td class="caption">Abgrenzung verschiedener Nahrungsmittel-
		Unvertr&auml;glichkeiten <br />und des Reizdarm-Syndromes</td>
        </tr> 
    </table>
</div>
