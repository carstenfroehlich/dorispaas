<div id="chapter_11" style="display: none;">
    <table border="0" cellspacing="0" cellpadding="0" class="chapter">
        <tr>
            <td class="num">11.1</td>
            <td class="caption">Was bin ich &#150; Fleisch- oder Pflanzenesser?</td>
        </tr> 
        <tr>
            <td class="num">11.2</td>
            <td class="caption">Vollwertige Kost</td>
        </tr> 
        <tr>
            <td class="num">11.2.1</td>
            <td class="caption">Wasser</td>
        </tr> 
        <tr>
            <td class="num">11.2.2</td>
            <td class="caption">Eiwei&#223; (Protein)</td>
        </tr> 
        <tr>
            <td class="num">11.2.3</td>
            <td class="caption">Fett</td>
        </tr> 
        <tr>
            <td class="num">11.2.4</td>
            <td class="caption">Kohlenhydrate</td>
        </tr> 
        <tr>
            <td class="num">11.2.5</td>
            <td class="caption">Vitamine</td>
        </tr> 
        <tr>
            <td class="num">11.2.6</td>
            <td class="caption">Mineralstoffe</td>
        </tr> 
        <tr>
            <td class="num">11.2.7</td>
            <td class="caption">Gift- und Schadstoffe, Krankheitserreger</td>
        </tr> 
        <tr>
            <td class="num">11.2.8</td>
            <td class="caption">So einfach ist Vollwertkost</td>
        </tr> 
        <tr>
            <td class="num">11.3</td>
            <td class="caption">Die Katabolit-Repression &#150; oder warum S&uuml;&#223;es 
		bei Laktose-Intoleranz besonders unvorteilhaft ist</td>
        </tr> 
        <tr>
            <td class="num">11.4</td>
            <td class="caption">Sind Sie sauer?</td>
        </tr> 
        <tr>
            <td class="num">11.5</td>
            <td class="caption">Wie viel Laktose vertrage ich?</td>
        </tr> 
        <tr>
            <td class="num">11.6</td>
            <td class="caption">Laktosebewusst einkaufen</td>
        </tr> 
        <tr>
            <td class="num">11.7</td>
            <td class="caption">Zutatenlisten</td>
        </tr> 
        <tr>
            <td class="num">11.7.1</td>
            <td class="caption">Original und F&auml;lschung</td>
        </tr> 
        <tr>
            <td class="num">11.7.2</td>
            <td class="caption">Laktose in der Zutatenliste</td>
        </tr> 
        <tr>
            <td class="num">11.7.3</td>
            <td class="caption">Zusatzstoffe (E-Nummern)</td>
        </tr> 
        <tr>
            <td class="num">11.7.4</td>
            <td class="caption">Wer soll das bezahlen ... ?</td>
        </tr> 
        <tr>
            <td class="num">11.8</td>
            <td class="caption">Functional Food</td>
        </tr> 
    </table>
</div>
