<div id="chapter_4" style="display: none;">
    <table border="0" cellspacing="0" cellpadding="0" class="chapter">
        <tr>
            <td class="num">4.1</td>
            <td class="caption">Ein bisschen Chemie-Unterricht</td>
        </tr> 
        <tr>
            <td class="num">4.2</td>
            <td class="caption">Eine kleine Anatomie-Stunde</td>
        </tr> 
        <tr>
            <td class="num">4.2.1</td>
            <td class="caption">Das Verdauungssystem</td>
        </tr> 
        <tr>
            <td class="num">4.2.2</td>
            <td class="caption">Die Darmschleimhaut</td>
        </tr> 
        <tr>
            <td class="num">4.2.3</td>
            <td class="caption">Die Darmflora</td>
        </tr> 
        <tr>
            <td class="num">4.2.4</td>
            <td class="caption">Der genetische Dimmer</td>
        </tr> 
        <tr>
            <td class="num">4.3</td>
            <td class="caption">Ein wenig Geographie</td>
        </tr> 
        <tr>
            <td class="num">4.4</td>
            <td class="caption">Wirtschaftskunde</td>
        </tr> 
        <tr>
            <td class="num">4.5</td>
            <td class="caption">Verschiedene Erkl&auml;rungs-Ans&auml;tze</td>
        </tr> 
        <tr>
            <td class="num">4.5.1</td>
            <td class="caption">Evolution</td>
        </tr> 
        <tr>
            <td class="num">4.5.2</td>
            <td class="caption">Fr&uuml;hzeitiges Abstillen der S&auml;uglinge</td>
        </tr> 
        <tr>
            <td class="num">4.5.3</td>
            <td class="caption">Operationen im Magendarm-Trakt</td>
        </tr> 
        <tr>
            <td class="num">4.5.4</td>
            <td class="caption">Convenienceprodukte</td>
        </tr>
        <tr>
            <td class="num">4.6</td>
            <td class="caption">Laktose als n&uuml;tzliches Medikament</td>
        </tr> 
        <tr>
            <td class="num">4.6.1</td>
            <td class="caption">Laktose als Abf&uuml;hrmittel</td>
        </tr> 
        <tr>
            <td class="num">4.6.2</td>
            <td class="caption">Laktose zur Sanierung der Darmflora</td>
        </tr> 
        <tr>
            <td class="num">4.6.3</td>
            <td class="caption">Laktose zur Osteoporoseprophylaxe und -behandlung</td>
        </tr> 
        <tr>
            <td class="num">4.6.4</td>
            <td class="caption">&#187;Doping&#171; mit Laktose</td>
        </tr> 
        <tr>
            <td class="num">4.7</td>
            <td class="caption">Kennzeichnung der Produkte</td>
        </tr> 
        <tr>
            <td class="num">4.8</td>
            <td class="caption">Warum wird Produkten Laktose zugesetzt?</td>
        </tr> 
    </table>
</div>
