<div id="chapter_13" style="display: none;">
    <table border="0" cellspacing="0" cellpadding="0" class="chapter">
        <tr>
            <td class="num">13.1</td>
            <td class="caption">Die Phasen der Ern&auml;hrungsumstellung</td>
        </tr> 
        <tr>
            <td class="num">13.1.1</td>
            <td class="caption">Phase 1: R&uuml;ckschau</td>
        </tr> 
        <tr>
            <td class="num">13.1.2</td>
            <td class="caption">Phase 2: Entr&uuml;mpelung und Planung</td>
        </tr> 
        <tr>
            <td class="num">13.1.3</td>
            <td class="caption">Phase 3: Erste Gehversuche</td>
        </tr> 
        <tr>
            <td class="num">13.1.4</td>
            <td class="caption">Phase 4: Vertrauen</td>
        </tr> 
        <tr>
            <td class="num">13.1.5</td>
            <td class="caption">Phase 5: Grenzen austesten</td>
        </tr> 
        <tr>
            <td class="num">13.1.6</td>
            <td class="caption">Phase 6: Routine</td>
        </tr> 
        <tr>
            <td class="num">13.1.7</td>
            <td class="caption">Phase 7: Mit Pannen umgehen lernen</td>
        </tr> 
        <tr>
            <td class="num">13.2</td>
            <td class="caption">Hilfe, ich vertrage mein Lieblingsgericht nicht mehr</td>
        </tr> 
        <tr>
            <td class="num">13.3</td>
            <td class="caption">Gewichtskontrolle mit Laktose-Intoleranz</td>
        </tr> 
        <tr>
            <td class="num">13.3.1</td>
            <td class="caption">Zunehmen</td>
        </tr> 
        <tr>
            <td class="num">13.3.2</td>
            <td class="caption">Abnehmen</td>
        </tr> 
        <tr>
            <td class="num">13.4</td>
            <td class="caption">Vegetarische Ern&auml;hrung bei Laktose-Intoleranz</td>
        </tr>
    </table>
</div>
