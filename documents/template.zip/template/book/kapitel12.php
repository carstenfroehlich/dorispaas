<div id="chapter_12" style="display: none;">
    <table border="0" cellspacing="0" cellpadding="0" class="chapter">
        <tr>
            <td class="num">12.1</td>
            <td class="caption">Ist es wirklich notwendig, Milch zu trinken?</td>
        </tr> 
        <tr>
            <td class="num">12.1.1</td>
            <td class="caption">Zusammensetzung der Kuhmilch</td>
        </tr> 
        <tr>
            <td class="num">12.1.2</td>
            <td class="caption">Konservierungsmethoden</td>
        </tr> 
        <tr>
            <td class="num">12.1.3</td>
            <td class="caption">Milchprodukte</td>
        </tr> 
        <tr>
            <td class="num">12.1.4</td>
            <td class="caption">Milch &#150; Wunder der Sch&ouml;pfung?</td>
        </tr> 
        <tr>
            <td class="num">12.2</td>
            <td class="caption">Laktosearme Milchprodukte</td>
        </tr> 
        <tr>
            <td class="num">12.2.1</td>
            <td class="caption">Milch- und Sauermilchprodukte</td>
        </tr> 
        <tr>
            <td class="num">12.2.2</td>
            <td class="caption">Nicht jeder Käse ist Käse</td>
        </tr> 
    </table>
</div>
