<div id="appendix" style="display: none;">
    <table border="0" cellspacing="0" cellpadding="0" class="chapter">
        <tr>
            <td class="num">A</td>
            <td class="caption">Rezepte f&uuml;r die Eingew&ouml;hnungsphase</td>
        </tr> 
        <tr>
            <td class="num">B</td>
            <td class="caption">Hilfe f&uuml;r Einkauf, Kantine oder Restaurant</td>
        </tr> 
        <tr>
            <td class="num">C</td>
            <td class="caption">Infoblatt f&uuml;r Freunde</td>
        </tr> 
        <tr>
            <td class="num">D</td>
            <td class="caption">Urlaub im Ausland</td>
        </tr> 
        <tr>
            <td class="num">E</td>
            <td class="caption">Adressen</td>
        </tr> 
        <tr>
            <td class="num">E.1</td>
            <td class="caption">Selbsthilfegruppen</td>
        </tr> 
        <tr>
            <td class="num">E.2</td>
            <td class="caption">Verbraucherzentralen</td>
        </tr> 
        <tr>
            <td class="num">E.3</td>
            <td class="caption">Psychotherapeutenkammern</td>
        </tr> 
        <tr>
            <td class="num">E.4</td>
            <td class="caption">Verschiedene Adressen(Diagnose-Zentren, Vereine, 
            Info-Brosch&uuml;ren)</td>
        </tr> 
        <tr>
            <td class="num">E.5</td>
            <td class="caption">Hersteller-Adressen zur Anforderung von 
            allgemeinen Informationen oder Allergiker-Infos</td>
        </tr> 
        <tr>
            <td class="num">F</td>
            <td class="caption">Internet-Links</td>
        </tr> 
        <tr>
            <td class="num">G</td>
            <td class="caption">Literatur</td>
        </tr> 
        <tr>
            <td class="num">H</td>
            <td class="caption">Bildnachweis</td>
        </tr>
        <tr>
            <td class="num">I</td>
            <td class="caption">Glossar</td>
        </tr>
        <tr>
            <td class="num">J</td>
            <td class="caption">Stichwortverzeichnis</td>
        </tr>
    </table>
</div>
