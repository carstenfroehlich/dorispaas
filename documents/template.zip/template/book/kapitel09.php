<div id="chapter_9" style="display: none;">
    <table border="0" cellspacing="0" cellpadding="0" class="chapter">
        <tr>
            <td class="num">9.1</td>
            <td class="caption">Trinken im Alter</td>
        </tr> 
        <tr>
            <td class="num">9.2</td>
            <td class="caption">Essenszubereitung</td>
        </tr> 
        <tr>
            <td class="num">9.3</td>
            <td class="caption">Das Problem mit den Zutatenlisten</td>
        </tr> 
        <tr>
            <td class="num">9.4</td>
            <td class="caption">Eiwei&#223;- und Kalziumbedarf im Alter</td>
        </tr> 
        <tr>
            <td class="num">9.5</td>
            <td class="caption">Medikamentenkonsum im Alter</td>
        </tr> 
        <tr>
            <td class="num">9.6</td>
            <td class="caption">Auch im Alter gibt es das Reizdarm-Syndrom</td>
        </tr> 
        <tr>
            <td class="num">9.7</td>
            <td class="caption">Wer rastet, der rostet</td>
        </tr> 
    </table>
</div>
