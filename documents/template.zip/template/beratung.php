        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br />      
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>
                <h1 class="header center orange-text">Praxis </h1>   
                    <div class="row center">        
                    <h5 class="header col s12 light">für Ganzheitliche Gesundheitsberatung und Prävention</h5>      
                    </div>     
            </div>  
        </div>
        <div class="container">    
            <div class="section">  
                <div class="row">        
                    <div class="col s12 m12">          
                        <br />
                        <hr />
                        <h5>Sie wünschen sich eine individuelle Beratung?</h5>
                        <hr />
                        <a href="http://www.ganzheitliche-gesundheitsberatung.de/" target="_blank">
                        <img src="<?php echo IMG_PATH; ?>home-ggb-neu.png" alt="" border="0" hspace="0" vspace="0" style="float: right; margin-left: 15px; padding-bottom: 0px;" /></a>
                        <br />
                        Neben all den Informationen, die Sie hier auf dieser Website finden, wünschen Sie sich vielleicht eine individuelle Beratung. Gerne stehe ich Ihnen in meiner 
                        <b>Praxis für Ganzheitliche Gesundheitsberatung und Prävention</b> zur Verfügung.
                        <br />
                        <br />
                        Es kann viele gute Gründe geben, eine Beratung unter ganzheitlicher Betrachtungsweise 
                        oder eine der verschiedenen Service-Leistungen in Anspruch zu 
                        nehmen &#150; immer jedoch kann man den Wunsch auf einen Nenner bringen: Sie
                        wollen etwas für Ihre Gesundheit tun und benötigen dabei einen 
                        fundierten Rat, der ganz auf Ihre individuellen Bedürfnisse zugeschnitten ist.
                        <br />
                        <br />
                        Natürlich können Sie im Internet surfen und schauen, welche Informationen 
                        zu finden sind &#150; hier auf dieser Website sind ja jede 
                        Menge Informationen für Sie bereitgestellt.
                        Vielen Menschen helfen die hier und auf anderen Quellen zugänglichen Informationen 
                        auch weiter. Manchmal jedoch ist es erforderlich, sich ganz individuell beraten 
                        zu lassen, um ein persönliches Problem zu besprechen, weil die immer recht 
                        allgemein gefassten Informationen eben gerade nicht auf die eigene Situation 
                        übertragbar sind. Hier kann nur eine persönliche Beratung wirklich 
                        weiterhelfen. 
                        <br />
                        <br />
                        Die Zeit und das Geld, das Sie hierfür investieren, ist auf jeden Fall gut 
                        angelegt &#150; für Ihre eigene Gesundheit. Da ich Sie anleite, <b>selbst</b> 
                        zu erkennen, wo Ihre Probleme liegen und welches die Ursachen sind sind, können 
                        Sie schon sehr bald in Eigenregie weiter für Ihre Gesundheit sorgen. Die 
                        einzelnen Beratungssitzungen finden meist in größeren Abständen 
                        statt, so dass dazwischen genügend Zeit für Sie bleibt, neue Verhaltensmuster 
                        zu erproben und zu schauen, ob gemeinsam erarbeitete Wege die richtigen für 
                        Sie sind. Somit sind Sie schon nach wenigen Sitzungen in der Lage, selbst zu 
                        erkennen, wie Sie für sich und Ihre Gesundheit sorgen können.
                        <br />
                        <br />
                        Ich nehme Sie ich also gar nicht monatelang kostenträchtig an die Hand, 
                        sondern gebe Ihnen (im übertragenen Sinne) eigentlich nur einen kleinen 
                        &#187;Schubs&#171; damit Sie selber laufen können. 
                        <br />
                        <br />
                        Allerdings braucht es nicht nur fundiertes Wissen und jahrelange Erfahrung, sondern 
                        auch kontinuierliche Weiterbildung, damit die Richtung stimmt, in die Sie in 
                        Zukunft laufen werden &#150; Werte, die ich Ihnen gerne anbiete. Ich wäre 
                        stolz und dankbar, wenn Sie mir Ihr Vertrauen schenken.
                        <br />
                        <br />
                        Ich freue mich auf Ihre Kontaktaufnahme &#150; rufen Sie mich an oder senden Sie mir eine
                        <a href="email-anfrage" target="_blank">eMail</a>.
                        <br />
                        <br />
                        <a href="http://www.ganzheitliche-gesundheitsberatung.de/" target="_blank">
                        <img src="<?php echo IMG_PATH; ?>praxiswillkommen.png" alt="willkommen" border="0" hspace="0" vspace="0" style="float: left; margin-right: 15px; padding-bottom: 0px;" /></a>

                        Die persönlichen Beratungen finden <b>in den Praxisräumen in Troisdorf</b>  
                        statt. Hier haben wir Zeit, Ihre Probleme in 
                        zwangloser und ungestörter Atmosphäre zu besprechen und gemeinsam 
                        Lösungen zu erarbeiten.
                        <br />
                        <br />
                        Wenn Sie weiter entfernt wohnen, können Sie die Möglichkeit der 
                        <a href="http://www.ganzheitliche-gesundheitsberatung.de/u-telefonberatung.php" target="_blank"><b>telefonischen Beratung</b></a> 
                        nutzen. Hierbei werden &ndash; wie zu den persönlichen 
                        Beratungen &ndash; feste Zeiten vereinbart, zu denen ich Sie anrufe.
                        <br />
                        <br />
                        Darüber hinaus gibt es eine Fülle von zusätzlichen Service-Leistungen, 
                        wie beispielsweise Vorträge, Seminare, Beratung von Selbsthilfegruppen und 
                        vieles mehr. Gerne kooperiere ich auch mit Ärzten und Fachärzten und 
                        übernehme die Beratung von Patienten, die bereits erkrankt oder gefährdet 
                        sind.
                        <br />
                        <br />
                        Auf meiner <b><a href="http://www.ganzheitliche-gesundheitsberatung.de/" target="_blank">Praxis-Website</a></b>
                        finden Sie ausführliche Informationen über das 
                        gesamte Beratungs-Angebot und die Service-Leistungen.</a>
                    </div>
                        </div>                                                            
                        <hr />
                        <a href="javascript: scrollMainToTop();" class="nachoben">nach oben</a>
                    </div>
                </div>
                <div class="bodyspacer"></div> 
            </div>
        </div>