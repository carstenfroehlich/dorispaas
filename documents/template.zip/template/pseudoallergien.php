        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br /> 
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>
                <h1 class="header center orange-text">Was sind Pseudoallergien?</h1>      
            </div>  
        </div> 
        <div class="container">    
            <div class="section">   
                <div class="row margintoprow">        
                    <div class="col s12 m12">
                        Um zu erklären, was Pseudo-Allergien (Pseudoallergien) sind, müssen Sie zuerst 
                        den Unterschied zwischen Nahrungsmittel-Unverträglichkeiten (Intoleranzen) 
                        und Nahrungsmittel-Allergien kennenlernen. Lesen Sie hierzu den Beitrag auf der 
                        Seite &#187;<a href="abgrenzung">Abgrenzung zwischen 
                        Nahrungsmittel-Unverträglichkeiten und Nahrungsmittel-Allergien</a>&#171;. 
                        Erst, wenn diese Abgrenzungen klar sind, wird deutlich, was eine Pseudo-Allergie ist.
                        <br />
                        <br />
                        Es gibt verschiedene Stoffe, die bekannt dafür sind, häufig Pseudo-Allergien 
                        auslösen zu können: insbesondere sind dies:
                        <br />
                        <br />
                        <b>Histamin</b>: Zur Histamin-Unverträglichkeit gibt es einen eigenen Beitrag, den Sie
                        <a href="wasisthi">hier</a> lesen kännen. 
                        <br />
                        <br />
                        <b>Glutamate</b>: Auch zur Glutamat-Intoleranz (Chinarestaurant-Syndrom) gibt es 
                        einen separaten Beitrag. Bitte klicken Sie auf diesen <a href="glutamat">Link</a>. 
                        <br />
                        <br />
                        Leider können auch diverse Substanzen, die mit den so genannten E-Nummern von 
                        der EU als unbedenklich für den Verzehr gekennzeichnet worden sind, problematisch 
                        in Bezug auf Pseudo-Allergien sein. Hier sind folgende Stoffgruppen zu nennen:
                        <br />
                        <br />
                        <b>Salicylate</b>: enthalten in salicylsäurehaltigen Schmerzmitteln wie Aspirin, 
                        ASS u.a.), aber durchaus auch in natürlicher Form in Weidenrinde (salix=Weide), 
                        die als natürliches Schmerzmittel verwendet wird oder auch in Lebensmitteln wie 
                        u.a. in Äpfeln oder Aprikosen. Eine Salicylat-Intoleranz (Salicylsäure-Unverträglichkeit) 
                        ist oftmals gekoppelt mit einer Unverträglichkeit von Benzoesäure (E210-213) 
                        (siehe unten).
                        <br />
                        <br />
                        <b>Schwefeldioxide</b>: (E220-228, Antioxidationsmittel), verwendet in Wein, Trockenfrüchten 
                        und Trockenkartoffelerzeugnissen.
                        <br />
                        <br />
                        <b>Sorbinsäure</b>: (E200-203, Konservierungsstoff), verwendet in Schnittbrot, Käse, 
                        Obst, Fruchtzubereitungen für Joghurts.
                        <br />
                        <br />
                        <b>Benzoesäure</b>: (E210-213, Konservierungsstoff), verwendet in sauren 
                        Limonadengetränken, Fisch- und Salatzubereitungen.
                        <br />
                        <br />
                        <b>Azofarbstoffe</b>: (E102, E110, E122, E124, E129, E1150, Farbstoffe), verwendet in 
                        Getränken, Süßwaren, Senf, Puddingpulver.
                        <br />
                        <br />
                        <hr />
                        <div class="oneline">
                            <div class="left">
                                <a href="lebensmittel-datenbank-info">
                                    <img src="<?php echo IMG_PATH; ?>lebensmitteldatenbank.png" alt="home video small" class="inline" />
                                </a>
                            </div>
                            <p class="left">
                                <b>Empfehlung:</b>
                                <br />
                                Eine zusätzliche Hilfe bei der Ermittlung geeigneter Lebensmittel stellt die
                                <br />
                                &#187;<b>DorisPaas.de &ndash; Lebensmittel-Datenbank</b>&#171; dar. 
                                Informieren Sie sich <a href="lebensmittel-datenbank-info" target="_blank">hier</a>.
                            </p>
                        </div> 
                        <br style="clear: left;" />
                        <br />
                        <hr>
                        <br />
                        <a href="guterrat" target="_blank"><img src="<?php echo IMG_PATH; ?>hilfreich.png" alt="" class="left" /></a>
                        <br />
                        <br />
                        <br />
                        Lesen Sie auch folgende Beträge:
                        <br />
                        <a href="wasisthi">Was ist Histamin-Intoleranz?</a>
                        <br />
                        <a href="glutamat">Glutamat-Intoleranz</a>
                        <br />
                        <a href="salicylatintoleranz">Salicylat-Intoleranz</a>
                        <br />
                        <br />
                        Gerne können Sie zu diesem Thema auch das folgende Tutorial anschauen:
                        <br /> 
                        <a href="videos#abgrenzung" target="_blank">Abgrenzung zwischen Nahrungsmittel-Unverträglichkeit und -allergie</a>
                        <br />
                        <br />
                        <a href="javascript: scrollMainToTop();" class="nachoben">nach oben</a>
                    </div>
                </div>
            </div>    
            <br>
            <br> 
            <div class="bodyspacer"></div> 
        </div>