        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br /> 
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>
                <h1 class="header center orange-text">Bücher anderer Autoren (Fremdliteratur)</h1>      
            </div>  
        </div> 
        <div class="container">    
            <div class="section">   
                <div class="row margintoprow">        
                    <div class="col s12 m4">
                        <ul class="nav">
                            <li>
                                <b>Zur den Büchern:</b>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>fremdliteratur#aggarwal-gewuerze">Aggarwal, Bharat et al: <b>Heilende Gewürze</b></a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>fremdliteratur#bannenberg-leitfaden">Bannenberg, Thomas: <b>Der Leitfaden</b></a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>fremdliteratur#davis-weizenwampe">Davis, William: <b>Weizenwampe</b></a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>fremdliteratur#enders-charmedarm">Enders, Giulia: <b>Darm mit Charme</b></a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>fremdliteratur#grimm-verzehr">Grimm, Hans-Ulrich: <b>Vom Verzehr wird abgeraten</b></a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>fremdliteratur#korn-zoeliakie">Korn, Danna: <b>Glutenfrei leben für Dummies</b></a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>fremdliteratur#oberbeil-milchfalle">Oberbeil, Klaus: <b>Die Milchfalle</b></a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>fremdliteratur#perlmutter-weizengehirn">Perlmutter, David: <b>Dumm wie Brot</b></a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>fremdliteratur#rollinger-milch">Rollinger, Maria: <b>Milch besser nicht</b></a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>fremdliteratur#vogelreuter-nmu">Vogelreuter, Axel: <b>Nahrungsmittelunverträglichkeiten</b></a>
                            </li> 
                        </ul>
                    </div>
                    </div>
                    <div class="row">
                    <div class="col s12 m12">
                        Neben den von mir selbst geschriebenen Büchern gibt verschiedene Titel von anderen 
                        Autoren, auf die ich Sie aufmerksam machen möchte. Teils sind dies Bücher, deren 
                        Lektüre ich Ihnen gerne ans Herz legen möchte, teils aber auch Bücher, von deren 
                        Qualität ich überhaupt nicht überzeugt bin.
                        <br />
                        <br />
                        Gegebenenfalls können Sie meine Bewertung (mit maximal 5 Sternchen) als Grundlage dafür benutzen, sich
                        die entsprechenden Bücher zu kaufen und ein eigenes Bild von deren Inhalt zu 
                        machen. Und bei eher negativ beurteilten Büchern hilft Ihnen meine Einschätzung 
                        vielleicht, dass Sie kein unnötiges Geld ausgeben. 
                        <br />
                        <br />
                        In der Liste sind die Bücher alphabetisch nach ihren Verfassern geordnet, weiter 
                        unten chronologisch nach der Reihenfolge, in der ich sie gelesen und bewertet habe. 
                        Zur besseren Übersicht finden Sie auf dieser Seite lediglich einen ersten Abschnitt 
                        und können bei Bedarf mit einem Klick auf &#187;Weiterlesen&#171; zum ausführlichen 
                        Text gelangen.
                        <hr />
                    </div>
                </div>
                <div class="row margintoprow">        
                    <div class="col s12 m12">
                        <a id="aggarwal-gewuerze"></a>
                        <div class="left">
                            <div class="left" style="width: 148px">
                            <a href="https://www.amazon.de/gp/product/3955820262/ref=as_li_tl?ie=UTF8&camp=1638&creative=6742&creativeASIN=3955820262&linkCode=as2&tag=daslaktintobu-21&linkId=e53649c83355c6b2e205e26952dab1a4" target="_blank">
                                    <img src="<?php echo IMG_PATH; ?>aggarwal.png" alt="Aggarwal" class="left" />
                                </a>
                            </div>
                            <div class="right" style="width: 502px;">
                                <p>
                                    Dr. Bharat B. Aggarwal und Debora Yost: 
                                    <br />
                                    <b>Heilende Gewürze</b>
                                    <br />
                                    Wie 50 heimische und exotische Gewürze Gesundheit erhalten und Krankheiten heilen können
                                    <br />
                                    <br />
                                    Meine persönliche Bewertung: 
                                    <br />
                                    <img src="<?php echo IMG_PATH; ?>bewertungssternchen-5.png" alt="" border="0" hspace="0" vspace="0" style="float: left; margin-right: 0px; padding-bottom: 0px;" />
                                    <br />
                                    <br />
                                    <i>Wenn man nicht schon bisher ein Fan von Gewürzen gewesen ist, macht spätestens dieses Buch gesunden Appetit darauf </i>
                                    <br />
                                </p>
                            </div>
                            <br class="cb" />
                        </div>
                            <br class="cb" />
                        </div>
                        <div class="row">
                        <div class="col s12 m12">
                        (19.9.2017) Wie einfach es doch sein kann, etwas für seine Gesundheit zu tun &ndash; und dies 
                        nicht mit Mittelchen und Pülverchen (und deren Nebenwirkungen) aus der Apotheke, 
                        sondern lecker einfach nur beim Essen.
                        <br />
                        Aggarwal weiß ganz offensichtlich, wovon er spricht. Nicht nur aufgrund seiner 
                        ethnischen Herkunft, die seine natürliche Affinität zum reichlichen Gebrauch von 
                        Gewürzen erklärt, sondern auch durch seine Tätigkeit als Wissenschaftler darf man 
                        als Leser sicher sein, hier wirklich fundiertes Fachwissen serviert zu bekommen. 
                        Und die Zusammenarbeit mit Debora Yost hat hier ganz offensichtlich wunderbare 
                        Früchte getragen.
                        </div>
                        </div>
                        <a href="blog-2017-09-19" target="_blank">Weiterlesen</a>
                        <hr />
                        
                        
                        
                        
                        
                        
                        
                        
                        <a id="enders-charmedarm">&nbsp;</a>
                        <br />
                        <div class="left">
                            <div class="left" style="width: 148px">
                                <a href="http://www.amazon.de/gp/product/3550080417/ref=as_li_qf_sp_asin_tl?ie=UTF8&camp=1638&creative=6742&creativeASIN=3550080417&linkCode=as2&tag=daslaktintobu-21" target="_blank">
                                    <img src="<?php echo IMG_PATH; ?>enders.png" alt="Darm mit Charme" class="left" />
                                </a>
                            </div>
                            <div class="right" style="width: 502px;">
                                <p>
                                    Giulia Enders: 
                                    <br />
                                    <b>Darm mit Charme</b>
                                    <br />
                                    <br />
                                    <br />
                                    <br />
                                    Meine persönliche Bewertung: 
                                    <br />
                                    <img src="<?php echo IMG_PATH; ?>bewertungssternchen-5.png" alt="" border="0" hspace="0" vspace="0" style="float: left; margin-right: 0px; padding-bottom: 0px;" />
                                    <br />
                                    <br />
                                    <i>Gute Informationen witzig und kurzweilig aufbereitet</i>
                                </p>
                            </div>
                            <br class="cb" />
                        </div>
                            <br class="cb" />
                        </div>
                        <div class="row">
                        <div class="col s12 m12">
                        (1.7.2014) Wer wollte nicht schon einmal sein Verdauungssystem von innen kennenlernen? Giulia 
                        Enders lädt uns in ihrem Buch &#187;Darm mit Charme&#171; zu einer solchen Reise ein.
                        <br />
                        Auf recht unkonventionelle Art führt sie uns  
                        durch unser Darmrohr: aus dem Mund mit seinen Speicheldrüsen geht es durch die 
                        &#187;gargelige&#171; Speiseröhre in das &#187;schiefe Magenbeutelchen&#171;, 
                        dann in den &#187;unherschlängelnden Dünndarm&#171;, vorbei am &#187;unnötigen 
                        Blinddarm&#171; in den &#187;pummeligen Dickdarm&#171;.
                        </div>
                        </div>
                        <a href="blog-2014-07-01" target="_blank">Weiterlesen</a>
                        <hr />
                        
                        
                        
                        <a id="bannenberg-leitfaden">&nbsp;</a>
                        <br />
                        <div class="left">
                            <div class="left" style="width: 148px">
                                <a href="http://www.amazon.de/gp/product/392740005X/ref=as_li_qf_sp_asin_tl?ie=UTF8&camp=1638&creative=6742&creativeASIN=392740005X&linkCode=as2&tag=daslaktintobu-21" target="_blank">
                                    <img src="<?php echo IMG_PATH; ?>bannenberg.png" alt="Bannenberg" class="left" />
                                </a>
                            </div>
                            <div class="right" style="width: 502px;">
                                <p>
                                    Thomas Bannenberg: 
                                    <br />
                                    <b>Der Leitfaden</b>
                                    <br />
                                    für freie unterrichtende, beratende und therapeutische Berufe
                                    <br />
                                    <br />
                                    Meine persönliche Bewertung: 
                                    <br />
                                    <img src="<?php echo IMG_PATH; ?>bewertungssternchen-5.png" alt="" border="0" hspace="0" vspace="0" style="float: left; margin-right: 0px; padding-bottom: 0px;" />
                                    <br />
                                    <br />
                                    <i>Wertvolle Hinweise für Gesundheits- oder Ernährungsberater, Heilpraktiker, Entspannungstherapeuten, Coaches etc.</i>
                            </div>
                            <br class="cb" />
                        </div>
                            <br class="cb" />
                        </div>
                        <div class="row">
                        <div class="col s12 m12">
                        (30.6.2014) Sie sind bereits als Gesundheits- oder Ernährungsberater, Heilpraktiker, 
                        Entspannungstherapeut, Coach oder als Spezialist in einem verwandten Berufsfeld 
                        selbstständig? Oder Sie nutzen Ihre Ausbildung bisher &#187;nur&#171; für sich 
                        selbst und liebäugeln mit einer selbstständigen Tätigkeit in Ihrem Berufsfeld? 
                        Oder Sie wollen erst demnächst eine solche Ausbildung beginnen?
                        <br />
                        Egal, ob Sie (noch) gar nicht an eine Selbstständigkeit denken oder aber in 
                        absehbarer Zeit ein neues (kleines) Unternehmen gründen wollen oder ob Sie schon 
                        richtig im Geschäft sind &ndash;  für alle ist das Buch &#187;Der Leitfaden&#171; 
                        von Thomas Bannenberg eine wahre Fundgrube von Tipps!
                        </div>
                        </div>
                        <a href="blog-2014-07-03" target="_blank">Weiterlesen</a>
                        <hr />
                        
                        
                        
                        <a id="korn-zoeliakie">&nbsp;</a>
                        <br />
                        <div class="left">
                        
                            <div class="left" style="width: 148px">
                                <a href="http://www.amazon.de/gp/product/3527708928/ref=as_li_qf_sp_asin_tl?ie=UTF8&camp=1638&creative=6742&creativeASIN=3527708928&linkCode=as2&tag=daslaktintobu-21" target="_blank">
                                    <img src="<?php echo IMG_PATH; ?>zoeliakie-dummies.png" alt="Korn" class="left" />
                                </a>
                            </div>
                            <div class="right" style="width: 502px;">
                                <p>
                                    Danna Korn: 
                                    <br />
                                    <b>Glutenfrei leben für Dummies</b>
                                    <br />
                                    <br />
                                    Meine persönliche Bewertung: 
                                    <br />
                                    <img src="<?php echo IMG_PATH; ?>bewertungssternchen-4.png" alt="" border="0" hspace="0" vspace="0" style="float: left; margin-right: 0px; padding-bottom: 0px;" />
                                    <br />
                                    <br />
                                    <i>Vor allem mit den ersten Kapiteln ein hervorragender Ratgeber</i>
                                </p>
                            </div>
                            <br class="cb" />
                        </div>
                        <div class="row">
                        <div class="col s12 m12">
                        (21.2.2014) Vor allem mit den ersten Kapiteln ist dieses Buch ein hervorragender Ratgeber für 
                        Menschen mit Zöliakie und Gluten-Sensitivität. Es gibt zahlreiche Informationen 
                        zu Hintergründen und Zusammenhängen, die es dem Leser ermöglichen, zu verstehen, 
                        was es mit dem Gluten auf sich hat. Vor allem sollten sich hier sicherlich Menschen 
                        mit einer frischen Diagnose angesprochen fühlen.
                        </div>
                        </div>
                        <a href="blog-2014-02-21" target="_blank">Weiterlesen</a>
                        <hr />
                        
                        
                        
                        
                        <a id="davis-weizenwampe">&nbsp;</a>
                        <br />
                        <div class="left">
                            <div class="left" style="width: 148px">
                                <a href="http://www.amazon.de/gp/product/3442173582/ref=as_li_qf_sp_asin_tl?ie=UTF8&camp=1638&creative=6742&creativeASIN=3442173582&linkCode=as2&tag=daslaktintobu-21" target="_blank">
                                    <img src="<?php echo IMG_PATH; ?>weizenwampe.png" alt="Weizenwampe" class="left" />
                                </a>
                            </div>
                            <div class="right" style="width: 502px;">
                                <p>
                                    Dr. med. William Davis: 
                                    <br />
                                    <b>Weizenwampe</b>
                                    <br />
                                    <br />
                                    <br />
                                    Meine persönliche Bewertung: 
                                    <br />
                                    <img src="<?php echo IMG_PATH; ?>bewertungssternchen-3.png" alt="" border="0" hspace="0" vspace="0" style="float: left; margin-right: 0px; padding-bottom: 0px;" />
                                    <br />
                                    <br />
                                    <i>Bitte mit Vorsicht genießen</i>
                                </p>
                            </div>
                            <br class="cb" />
                        </div>
                        <div class="row">
                        <div class="col s12 m12">
                        (17.2.2014) Das Buch &#187;Weizenwampe&#171; von Dr. med. William Davis zeigt eine völlig andere 
                        Betrachtungsweise des Themas &#187;Weizen&#171; und vor allem auch &#187;Vollkorn&#171; 
                        als allgemein üblich. Es wirft die bisherige Ansicht, Vollkorn sei gesund, über 
                        den Haufen und sagt &ndash; auf einen Nenner gebracht &ndash; dass nicht nur 
                        Auszugsmehle und deren Produkte, sondern auch das Vollkorn aus Weizen und allen 
                        anderen glutenhaltigen Getreiden ungesund seien.
                        </div>
                        </div>
                        <a href="blog-2014-02-17" target="_blank">Weiterlesen</a>
                        <hr />
                        
                        
                        <a id="vogelreuter-nmu">&nbsp;</a>
                        <br />
                        <div class="left">
                            <div class="left" style="width: 148px">
                                <a href="http://www.amazon.de/gp/product/380472938X/ref=as_li_qf_sp_asin_tl?ie=UTF8&camp=1638&creative=6742&creativeASIN=380472938X&linkCode=as2&tag=daslaktintobu-21" target="_blank">
                                    <img src="<?php echo IMG_PATH; ?>vogelreuter.png" alt="Vogelreuter" class="left" />
                                </a>
                            </div>
                            <div class="right" style="width: 502px;">
                                <p>
                                    Dr. Axel Vogelreuter: 
                                    <br />
                                    <b>Nahrungsmittelunverträglichkeiten</b>
                                    <br />
                                    <br />
                                    <br />
                                    Meine persönliche Bewertung: 
                                    <br />
                                    <img src="<?php echo IMG_PATH; ?>bewertungssternchen-5.png" alt="" border="0" hspace="0" vspace="0" style="float: left; margin-right: 0px; padding-bottom: 0px;" />
                                    <br />
                                    <br />
                                    <i>Exzellente Informationen für Fachleute</i>
                                </p>
                            </div>
                            <br class="cb" />
                        </div>
                        <div class="row">
                        <div class="col s12 m12">
                        (3.10.2012) Auf den ersten Blick mag es irritieren: Kann ein Apotheker wirklich erschöpfend 
                        über Nahrungsmittelunverträglichkeiten informieren? Der zweite Blick, 
                        also der Blick ins gleichnamige Buch, beantwortet diese Frage mit einem eindeutigen 
                        &#187;Ja&#171;. Zumindest gilt dies für den auf dem Rückentext ausgelobten 
                        Adressatenkreis &ndash; für Fachleute wie Berater, Begleiter und Therapeuten, 
                        also für Leser, die bereits umfangreiches Vorwissen mitbringen und sich vor 
                        allem in der durchgängig gebrauchten Verwendung der Fachausdrücke auskennen.<br />
                        </div>
                        </div>
                        <a href="blog-2012-10-03" target="_blank">Weiterlesen</a>
                        <hr />
                        
                        
                        
                        
                        <a id="grimm-verzehr">&nbsp;</a>
                        <br />
                        <div class="left">
                            <div class="left" style="width: 148px">
                                <a href="http://www.amazon.de/gp/product/3426275562/ref=as_li_qf_sp_asin_tl?ie=UTF8&camp=1638&creative=6742&creativeASIN=3426275562&linkCode=as2&tag=daslaktintobu-21" target="_blank">
                                    <img src="<?php echo IMG_PATH; ?>grimm.png" alt="Grimm" class="left" />
                                </a>
                            </div>
                            <div class="right" style="width: 502px;">
                                <p>
                                    Hans-Ulrich Grimm: 
                                    <br />
                                    <b>Vom Verzehr wird abgeraten</b>
                                    <br />
                                    <br />
                                    <br />
                                    Meine persönliche Bewertung: 
                                    <br />
                                    <img src="<?php echo IMG_PATH; ?>bewertungssternchen-5.png" alt="" border="0" hspace="0" vspace="0" style="float: left; margin-right: 0px; padding-bottom: 0px;" />
                                    <br />
                                    <br />
                                    <i>Sehr empfehlenswerte Lektüre &ndash; spätestens jetzt wissen wir Bescheid!</i>
                                </p>
                            </div>
                            <br class="cb" />
                        </div>
                        <div class="row">
                        <div class="col s12 m12">
                        (18.8.2012) Der Titel &#187;Vom Verzehr wird abgeraten&#171; nimmt die Schussfolgerung des Autors 
                        zum Thema schon vorweg und unterstreicht die Gewichtigkeit des Themas. Auch der 
                        Untertitel &#187;Wie uns die Industrie mit Gesundheitsnahrung krank macht&#171; 
                        lädt zum Kauf des Buches ein, und spätestens der Klappentext &#187;Gesunde 
                        Ernährung kann Ihre Gesundheit gefährden &ndash; wenn Sie der Werbung 
                        vertrauen ... &#171; macht den kritischen Konsumenten noch neugieriger. Und er wird 
                        nicht enttäuscht: Das Buch informiert über die diversen Praktiken der 
                        Nahrungsmittelproduzenten, uns mit Gesundheitsversprechen für dumm zu verkaufen.
                        </div>
                        </div>
                            <a href="blog-2012-08-18-2" target="_blank">Weiterlesen</a>
                        <hr />
                        
                        
                        <a id="oberbeil-milchfalle">&nbsp;</a>
                        <br />
                        <div class="left">
                            <div class="left" style="width: 148px">
                                <a href="http://www.amazon.de/gp/product/3776624949/ref=as_li_qf_sp_asin_tl?ie=UTF8&camp=1638&creative=6742&creativeASIN=3776624949&linkCode=as2&tag=daslaktintobu-21" target="_blank">
                                    <img src="<?php echo IMG_PATH; ?>oberbeil.png" alt="Oberbeil" class="left" />
                                </a>
                            </div>
                            <div class="right" style="width: 502px;">
                                <p>
                                    Klaus Oberbeil: 
                                    <br />
                                    <b>Die Milchfalle</b>
                                    <br />
                                    <br />
                                    <br />
                                    Meine persönliche Bewertung: 
                                    <br />
                                    <img src="<?php echo IMG_PATH; ?>bewertungssternchen-1.png" alt="" border="0" hspace="0" vspace="0" style="float: left; margin-right: 0px; padding-bottom: 0px;" />
                                    <br />
                                    <br />
                                    <i>Achtung: gefährliches Halbwissen!</i>
                                </p>
                            </div>
                            <br class="cb" />
                        </div>
                        <div class="row">
                        <div class="col s12 m12">
                        Allein der Untertitel &#187;Warum wir auf Milcheiweiß und Milchzucker allergisch 
                        reagieren … &#171; zeigt dem informierten Leser schon, dass er bei der Lektüre 
                        dieses Buches aufpassen muss!
                        <br />
                        Der Verfasser, der sich selbst als &#187; Medizinjournalist und Ernährungsexperte&#171; 
                        bezeichnet, schlägt in diesem Buch einen abenteuerlichen Bogen &ndash; oder sollte 
                        ich besser Zickzack sagen? &ndash; zwischen einer Milchzucker-Unverträglichkeit 
                        und einer Milcheiweiß-Allergie. Dabei gerät ihm nicht nur ab und an etwas durcheinander, 
                        nein, er hat bei der wichtigen Unterscheidung der beiden Phänomene seine Hausarbeiten 
                        überhaupt nicht gemacht.
                        <br />
                        Am Anfang unterscheidet er noch fast korrekt zwischen Unverträglichkeit unf Allergie, 
                        in der Mitte wirft er beides in einen Topf, beschreibt aber nur die Unverträglichkeit 
                        auf Milchzucker, und am Ende kommt er auf die Allergie zurück, gibt dabei aber 
                        lebensgefährliche Ratschläge.
                        </div>
                        </div>
                        <a href="blog-2014-07-07" target="_blank">Weiterlesen</a>
                        <hr />
                        
                        
                        <a id="perlmutter-weizengehirn">&nbsp;</a>
                        <br />
                        <div class="left">
                        
                            <div class="left" style="width: 148px">
                            <a href="http://www.amazon.de/gp/product/3442392578/ref=as_li_tl?ie=UTF8&camp=1638&creative=6742&creativeASIN=3442392578&linkCode=as2&tag=daslaktintobu-21&linkId=4XDHG4ETJV2RVVCF" target="_blank">
                                    <img src="<?php echo IMG_PATH; ?>perlmutter.png" alt="Perlmutter" class="left" />
                                </a>
                            </div>
                            <div class="right" style="width: 502px;">
                                <p>
                                    <a href="http://www.amazon.de/gp/cdp/member-reviews/A5MX7PXD1ZYMY/ref=cm_cr_pr_auth_rev?ie=UTF8&sort_by=MostRecentReview" target="_blank">Buchrezension bei Amazon.de vom 10.11.2014</a>
                                </p>
                                <p>
                                    Dr. David Perlmutter mit Kristin Loberg: 
                                    <br />
                                    <b>Dumm wie Brot</b>
                                    <br />
                                    Wie Weizen schleichend Ihr Gehirn zerstört
                                    <br />
                                    <br />
                                    Meine persönliche Bewertung: 
                                    <br />
                                    <img src="<?php echo IMG_PATH; ?>bewertungssternchen-3.png" alt="" border="0" hspace="0" vspace="0" style="float: left; margin-right: 0px; padding-bottom: 0px;" />
                                    <br />
                                    <br />
                                    <i>Eher für den bereits sachlich umfassend informierten Leser als für den &#187;einfach nur Neugierigen&#171;</i>
                                </p>
                            </div>
                            <br class="cb" />
                        </div>
                        <div class="row">
                        <div class="col s12 m12">
                        Den Tenor seines Buches lässt uns Dr. David Perlmutter bereits im Untertitel wissen: 
                        &#187;Wie Weizen schleichend Ihr Gehirn zerstört&#171; und versucht aufzuzeigen, 
                        dass Weizen dafür verantwortlich ist, dass neurologisch-degenerative Erkrankungen 
                        wie u.a. Demenz und Alzheimer (wobei er diese beiden Erkrankungen leider in einen 
                        Topf wirft) durch Glutenverzehr verursacht werden. 
                        <br />
                        So zeigt er auf, dass Arteriosklerose nicht nur die landläufig bekannten Folgeerkrankungen 
                        wie u.a. Herzinfarkte nach sich zieht, sondern auch die Blutgefäße im Gehirn 
                        beeinträchtigt, was neben Schlaganfällen auch zu Demenz und Alzheimer führt. 
                        Dies ist eine Schlussfolgerung, der ich ohne weiteres folgen kann &ndash; denn 
                        warum sollte eine Mangeldurchblutung nur in den Körperregionen Folgen haben, im 
                        Gehirn aber nicht?
                        </div>
                        </div>
                        <a href="blog-2014-11-10">Weiterlesen</a>
                        <hr />
                        
                        
                        
                        
                        <a id="rollinger-milch">&nbsp;</a>
                        <br />
                        <div class="left">
                            <div class="left" style="width: 148px">
                                <a href="http://www.amazon.de/gp/product/3940236004/ref=as_li_qf_sp_asin_tl?ie=UTF8&camp=1638&creative=6742&creativeASIN=3940236004&linkCode=as2&tag=daslaktintobu-21" target="_blank">
                                    <img src="<?php echo IMG_PATH; ?>rollinger.png" alt="Rollinger" class="left" />
                                </a>
                            </div>
                            <div class="right" style="width: 502px;">
                                <p>
                                    Maria Rollinger: 
                                    <br />
                                    <b>Milch besser nicht</b>
                                    <br />
                                    <br />
                                    Meine persönliche Bewertung: 
                                    <br />
                                    <img src="<?php echo IMG_PATH; ?>bewertungssternchen-5.png" alt="" border="0" hspace="0" vspace="0" style="float: left; margin-right: 0px; padding-bottom: 0px;" />
                                    <br />
                                    <br />
                                    <i>Ein beeindruckendes Buch!</i>
                                </p>
                            </div>
                            <br class="cb" />
                        </div>
                        <div class="row">
                        <div class="col s12 m12">
                        (25.3.2008) Ein beeindruckendes Buch! Was die Nahrungsmittelindustrie geschickt 
                        zu verschleiern versteht, wird hier offen dargelegt, alle Hintergründe anschaulich 
                        erklärt und fundiert belegt. Es fällt oftmals schwer, das alles zu glauben, was 
                        von Maria Rollinger sehr plastisch geschildert wird, denn wir alle werden von den 
                        Produzenten der &#187;gesunden Milch&#171; bewusst für dumm verkauft, um die durch 
                        fehlgeleitete Subventionen entstandenen Milchseen und Butterberge abzutragen. 
                        Doch scheint die Verfasserin über genügend Hintergründe zu verfügen, so dass man 
                        die schrecklichen Tatsachen schaudernd zur Kenntnis nehmen muss.
                        <br />
                        Auch dem eingefleischtesten Milchfan wird spätestens nach der Lektüre dieses Buches 
                        der Appetit gründlich vergangen sein. Und falls man sich das Milchtrinken dann nicht 
                        gänzlich abgewöhnt, so wird man doch mit Sicherheit ins Grübeln geraten und den 
                        Konsum sehr viel kritischer überdenken. Ein sehr empfehlenswertes Buch, das zum 
                        Umdenken zwingt.
                        </div>
                        </div>
                        <hr />
                        <a href="javascript: scrollMainToTop();" class="nachoben">nach oben</a>
                    </div>
                </div>
            </div>    
            <br>
            <br> 
            <div class="bodyspacer"></div> 
        </div>