        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br /> 
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>
                <h1 class="header center orange-text">Das Immunsystem</h1> 
                    <div class="row center">        
                    <h5 class="header col s12 light">ganzheitlich betrachtet</h5>      
                    </div>     
            </div>  
        </div> 
        <div class="container">    
            <div class="section">   
                <div class="row margintoprow">        
                    <div class="col s12 m4">
                        <ul class="nav">
                            <li>
                                <b>Abschnitte dieser Seite:</b>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-immun#immunsystem">Was ist das &uuml;berhaupt &ndash; das Immunsystem?</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-immun#fehlreaktionen">&Uuml;ber- und Fehlregaktionen des Immunsystems</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-immun#warum">Warum ist es wichtig, das Immunsystem zu st&auml;rken? </a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-immun#was">Was st&auml;rkt das Immunsystem?</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-immun#ernaehrung">Ernährung</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-immun#trinken">Trinken</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-immun#darmflora">Pflege der Darmflora</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-immun#leben">Gesundes Leben</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-immun#psyche">Immunsystem und Psyche</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-immun#abhaertung">Abh&auml;rtung</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-immun#krankheiten">Bei Krankheiten auch an das Immunsystem denken</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-immun#verdauung">Starkes Immunsystem f&uuml;r eine Gesunde Verdauung</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-immun#beratung">Beratung</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>guterrat" target="_blank">War dieser Beitrag hilfreich für Sie?</a>
                            </li> 
                        </ul>
                    </div>
                </div>
                <div class="row margintoprow">        
                    <div class="col s12 m12">
                        Erkrankungen des Verdauungssystems k&ouml;nnen sich u.a. auch gravierend auf unser 
                        Immunsystem und damit auf unsere Gesundheit insgesamt auswirken. Und nat&uuml;rlich 
                        kann auch umgekehrt ein robustes Immunsystem g&uuml;nstige Auswirkungen auf das 
                        Verdauungssystem haben. Deshalb ist es wichtig, das Immunsystem kennenzulernen 
                        und uns diese Zusammenh&auml;nge klar zu machen. Gerade auch bei Problemen mit dem 
                        Verdauungssystem k&ouml;nnen wir selbst viel daf&uuml;r tun, unser Immunsystem zu 
                        st&auml;rken und gute Abwehrkr&auml;fte gegen Krankheiten zu entwickeln und damit 
                        letztendlich dazu beitragen, dass die Verdauungsprobleme minimiert werden.
                        <br />
                        <a id="immunsystem"></a>
                        <hr />
                        <h5>Was ist das &uuml;berhaupt &ndash; das Immunsystem? </h5>
                        <hr />
                        Das Immunsystem muss unseren Organismus gegen &#187;Feinde&#171; verteidigen. Es 
                        muss unterscheiden k&ouml;nnen zwischen &#187;Freund&#171; und &#187;Feind&#171; 
                        &ndash; also zwischen k&ouml;rpereigenen und k&ouml;rperfremden, gef&auml;hrlichen 
                        Substanzen und letztere abwehren oder unsch&auml;dlich machen. Feinde k&ouml;nnen 
                        hier Fremdk&ouml;rper wie z.B. Staubpartikel sein, aber auch Mikroorganismen wie 
                        Bakterien, Viren, Pilze oder Parasiten. K&ouml;rpereigene Zellen sollen als 
                        &#187;Freunde&#171; erkannt und somit nicht bek&auml;mpft werden.
                        <br />
                        <br />
                        Eigentlich gibt das nicht &#187;das&#171; Immunsystem, denn unser Immunsystem besteht 
                        aus drei voneinander abh&auml;ngigen Systemen: das Haut- und Schleimhaut-bezogene 
                        Immunsystem, das Organ-bezogene Immunsystem und das Immunsystem im Darm.
                        <br />
                        <br />
                        Haut und Schleimh&auml;ute bilden eine erste Abwehrbarriere zur Au&#223;enwelt. 
                        Sowohl unsere Haut an Gesicht, H&auml;nden und K&ouml;rper als auch die Schleimh&auml;ute 
                        in Nase, Rachen, Bronchien und Lunge, in Mund, Speiser&ouml;hre, Magen und Darm 
                        kommen mit der Au&#223;enwelt, mit Fremdk&ouml;rpern, mit der Luft, mit Mikroorganismen 
                        und mit der aufgenommenen Nahrung in Ber&uuml;hrung. Sie stellen eine erste und 
                        wichtige Barriere dar, die bei intakter Haut und gesunden Schleimh&auml;uten schwer 
                        zu durchdringen ist. Allein schon die mechanische Barriere, aber auch Schleimschichten 
                        oder Flimmerh&auml;rchen (z.B. auf den Nasenschleimh&auml;uten) und eine gesunde 
                        S&auml;urebarriere hindern Fremdk&ouml;rper, in unser K&ouml;rperinneres zu gelangen. 
                        Erst, wenn Haut und Schleimh&auml;ute gesch&auml;digt sind, gelingt es den sch&auml;dlichen 
                        Mikroorganismen, von der der Au&#223;enwelt zugewandten Seite ins Innere vorzudringen. 
                        <br />
                        <br />
                        Hierbei ist es zum besseren Verst&auml;ndnis wichtig zu wissen, dass auch unser 
                        Atemsystem und unser Verdauungssystem zur Au&#223;enseite gez&auml;hlt werden. 
                        Stellen Sie sich den K&ouml;rper wie einen eingest&uuml;lpten Handschuhfinger vor: 
                        Somit sind eben auch Lunge, Magen und Darm eigentlich &#187;au&#223;en&#171;. Erst 
                        unser Blut, unsere Muskeln, unsere Nerven und Organe sind wirklich &#187;innen&#171;.
                        <br />
                        <br />
                        Im Organ-bezogenen Immunsystem werden im Knochenmark und in der Milz Blutk&ouml;rperchen 
                        gebildet, die zur Verteidigung unseres Organismus gegen Eindringlinge ausgebildet 
                        werden m&uuml;ssen. Diese Ausbildung der zuerst v&ouml;llig unspezifischen Zellen geschieht in 
                        der Thymusdr&uuml;se, einer zum Zeitpunkt unserer Geburt etwa walnussgro&#223;en, 
                        hinter dem Brustbein gelegenen Dr&uuml;se. Sie w&auml;chst bis ins Jugendalter nur 
                        noch sehr wenig und bildet sich dann im Alter zur&uuml;ck, bis sie fast nicht mehr 
                        nachweisbar ist. Die Blutk&ouml;rperchen wandern durch die Thymusdr&uuml;se und 
                        werden dort &#187;gepr&auml;gt&#171;. Dabei werden sie zu f&uuml;r die Immunabwehr 
                        relevanten &#187;Killerzellen&#171;, &#187;Fresszellen&#171; oder auch zu den 
                        &#187;Ged&auml;chtniszellen&#171; herangebildet, die dann mit ihren ganz speziellen 
                        Funktionen Fremdk&ouml;rper erkennen und unsch&auml;dlich machen sollen. Zus&auml;tzlich 
                        werden im Lymphsystem mit den Lymphknoten Fremdk&ouml;rper abgefangen und zerst&ouml;rt.
                        <br />
                        <br />
                        Der weitaus gr&ouml;&#223;te Teil unseres Immunsystems jedoch befindet sich im 
                        Darm &ndash; namentlich im Dickdarm. Hier lebt eine riesige Zahl von Darmbakterien, 
                        die sich aus &#187;guten&#171; (n&uuml;tzlichen) und &#187;schlechten&#171; 
                        (krankmachenden) Mikroorganismen wie Bakterien und Pilzen zusammensetzt. Es muss 
                        immer ein gesundes Gleichgewicht zwischen guten und schlechten Keimen vorhanden 
                        sein, wobei die vielen n&uuml;tzlichen Arten die (im g&uuml;nstigen Falle) wenigen 
                        sch&auml;dlichen in Schach halten m&uuml;ssen. Hierbei besetzen die guten Arten 
                        die Darmschleimhaut und hindern so die schlechten daran, durch die Schleimhaut 
                        ins K&ouml;rperinnere vordringen und ihr krankmachendes Potenzial entfalten zu 
                        k&ouml;nnen. 
                        <br />
                        <br />
                        Zus&auml;tzlich gibt es absichtlich durchl&auml;ssige Stellen in der Darmschleimhaut 
                        (die Peyer’schen Plaques), durch die eine begrenzte Menge an Keimen ins Innere 
                        eindringen k&ouml;nnen. Dort kann sich dann das Immunsystem mit diesen Keimen 
                        auseinandersetzen und quasi wie mit einem Sparringspartner trainieren, um ge&uuml;bt 
                        zu bleiben und im Krankheitsfalle gr&ouml;&#223;ere Mengen von Krankheitskeimen 
                        abwehren zu k&ouml;nnen.
                        <br />
                        <br />
                        Diese drei Systeme greifen ineinander, sind von einander abh&auml;ngig und nur 
                        zusammen voll funktionsf&auml;hig.
                        <br />
                        <br />
                        Bei der Geburt ist das Immunsystem nur sehr wenig ausgebildet. Das Neugeborene 
                        besitzt neben den Haut- und Schleimhautbarrieren ein &#187;angeborenes 
                        Immunsystem&#171;, dieses kann aber nur die f&uuml;r alle Bakterien typischen, 
                        groben Kennzeichen erkennen und diese Keime dann bek&auml;mpfen. Erreger schwererer 
                        Krankheiten, insbesondere von Viruserkrankungen, w&uuml;rden ein Problem f&uuml;r den 
                        S&auml;ugling darstellen. Er bekommt jedoch Immunk&ouml;rper durch die Muttermilch, 
                        so dass er auch in solchen F&auml;llen meist gesund bleiben kann. 
                        Erst im Laufe des Heranwachsens bildet sich nach und nach das &#187;erworbene 
                        Immunsystem&#171; aus, das dann ganz spezifische Krankheitserreger erkennen kann 
                        und im Krankheitsfalle gleich effektive und wirksame Waffen einsetzen kann. Einmal 
                        durchgemachte Kinderkrankheiten brechen im Normalfall kein zweites Mal aus, weil 
                        das erworbene Immunsystem in seinen Ged&auml;chtniszellen die speziellen Merkmale 
                        der Erreger gespeichert hat und sofort ein wirksames Abwehrprogramm starten kann, 
                        wenn die gleiche Keimart ein zweites Mal erkannt wird. So k&ouml;nnen sich die Keime 
                        gar nicht erst vermehren, so dass die Krankheit nicht mehr ausbrechen kann.
                        <br />
                        <br />
                        Auch bei Impfungen wird diese F&auml;higkeit des Immunsystems genutzt: Abgeschw&auml;chte 
                        oder abget&ouml;tete Erreger werden in den K&ouml;rper gebracht, das Immunsystem 
                        lernt diese kennen und speichert diese Information in den Ged&auml;chtniszellen 
                        ab. Bei einem Kontakt mit den &#187;richtigen&#171; Erregern werden diese sofort 
                        erkannt und zunichte gemacht.
                        <br />
                        <br />
                        &Uuml;brigens ist das Immunsystem nicht nur gegen Erreger wie Fremdk&ouml;rper, 
                        Bakterien, Viren oder W&uuml;rmer im Einsatz. Auch Krebszellen, die entartete, 
                        k&ouml;rpereigene Zellen sind, werden von einem gesunden und funktionsf&auml;higen 
                        Immunsystem erkannt und vernichtet. Durch zahlreiche Umweltbelastungen wie z.B. 
                        Gifte oder Strahlung entarten st&auml;ndig einzelne K&ouml;rperzellen, aber nur 
                        vergleichsweise selten bricht eine Krebserkrankung aus. Somit ist es auch eine gute 
                        Krebsprophylaxe, f&uuml;r ein gesundes Immunsystem zu sorgen.
                        <br />
                        <a id="fehlreaktionen">&nbsp;</a>
                        <hr />
                        <h5>&Uuml;ber- und Fehlregaktionen des Immunsystems</h5>
                        <hr />
                        Leider arbeitet in manchen F&auml;llen das Immunsystem nicht fehlerfrei. Manchmal 
                        werden auch an sich harmlose Stoffe wie Pollen oder bestimmte Nahrungsmittel 
                        (Allergene) als &#187;bek&auml;mpfenswert&#171; angesehen, und das Immunsystem 
                        entwickelt Antik&ouml;rper, um diese f&uuml;r gesunde Menschen v&ouml;llig 
                        unbedenklichen Stoffe mit gro&#223;em Abwehrprogramm zu vernichten. Dies sind die 
                        bekannten Allergien, bei denen nach einer Sensibilisierungsphase &ndash; also einer 
                        Phase des Kennenlernens &ndash; sp&auml;ter bereits bei Aufnahme kleinster Mengen 
                        der &#187;verd&auml;chtigen&#171; Stoffe gleich das ganze Abwehrprogramm gestartet 
                        wird. Dies kann zu Hautjucken oder Ausschl&auml;gen &uuml;ber Atembeschwerden bis 
                        hin zu einem lebensbedrohlichen Zusammenbruch (anaphylaktischer Schock) f&uuml;hren. 
                        <br />
                        <br />
                        Die Behandlung von Allergien besteht in strengster Meidung der Allergene und 
                        eventuell einer Hyposensibilisierung, in der durch Einbringen der Allergene in 
                        anfangs allergr&ouml;&#223;ter Verd&uuml;nnung das Immunsystem &uuml;berlistet wird. 
                        Es soll lernen, diese Stoffe doch zu tolerieren. Nach und nach werden die Mengen 
                        gesteigert, bis das Immunsystem gelernt hat, normale Mengen ohne Probleme zu 
                        akzeptieren.
                        <br />
                        <br />
                        Weiterhin gibt es so genannte Autoimmunerkrankungen, bei denen sich das Immunsystem 
                        gegen k&ouml;rpereigene Zellen richtet, also k&ouml;rpereigene Zellen als Feinde 
                        interpretiert. Hier sind z.B. Diabetes (Typ 1), Rheuma oder auch Multiple Sklerose 
                        (MS) zu nennen, bei denen Zellen der Bauchspeicheldr&uuml;se, Gelenke bzw. Nervengewebe 
                        angegriffen und zerst&ouml;rt werden. Solche Erkrankungen werden h&auml;ufig mit 
                        so genannten Immunsuppressiva behandelt, also Substanzen, die die Funktion und 
                        Aktivit&auml;t des Immunsystems unterdr&uuml;cken. Dies f&uuml;hrt nat&uuml;rlich 
                        in einen Teufelskreis, denn ein unterdr&uuml;cktes Immunsystem arbeitet dann 
                        nat&uuml;rlich auch gegen Krankheitserreger mit gebremster Kraft.
                        <br />
                        <br />
                        Auch die Z&ouml;liakie ist eine Autoimmunerkrankung, bei der das Immunsystem bei 
                        Kontakt mit Gluten, dem Klebereiwei&#223; in Weizen, Roggen und Gerste (und ihren 
                        Abk&ouml;mmlingen) dahingehend reagiert, dass es die Zellen der D&uuml;nndarmschleimhaut 
                        zerst&ouml;rt. Wird keine strenge glutenfreie Kost eingehalten, l&ouml;sen sich die 
                        Darmzotten auf, und die Nahrung kann nicht mehr richtig aufgenommen werden. 
                        <br />
                        <a id="warum">&nbsp;</a>
                        <hr />
                        <h5>Warum ist es wichtig, das Immunsystem zu st&auml;rken? </h5>
                        <hr />
                        Nat&uuml;rlich leuchtet sofort ein, dass wir mit einem gest&auml;rkten Immunsystem 
                        besser gegen Erk&auml;ltungskrankheiten gewappnet sind. Auch viele andere Krankheiten 
                        brechen bei einem robusten Immunsystem erst gar nicht aus oder verlaufen zumindest 
                        wesentlich leichter. 
                        <br />
                        <br />
                        B&ouml;sartige Erkrankungen treten seltener auf, wenn das Immunsystem die kleinen 
                        Entartungen gleich &#187;im Keim erstickt&#171;. Erst wenn das Immunsystem 
                        geschw&auml;cht ist, k&ouml;nnen Krebserkrankungen ausbrechen und sich Tumore 
                        und ggf. auch Tochtergeschw&uuml;lste (Metastasen) bilden.
                        <br />
                        <br />
                        <b>Hinweis: </b> Eine Besonderheit bilden die Allergien und die Autoimmunerkrankungen: 
                        Hier l&auml;uft das Immunsystem ohnehin schon auf Hochtouren. Nat&uuml;rlich sind 
                        moderate, nat&uuml;rliche Methoden, das Immunsystem zu st&auml;rken, immer richtig, 
                        aber bestimmte Mittel, die das Immunsystem stimulieren (z.B. Echinacea), sollten 
                        in solchen F&auml;llen nur nach R&uuml;cksprache mit dem behandelnden Arzt 
                        eingenommen werden.
                        <br />
                        <br />
                        Da ein gest&auml;rktes Immunsystem immer auch zu einer robusteren Gesundheit und 
                        damit zu mehr Wohlbefinden f&uuml;hrt, k&ouml;nnen meist auch Probleme des Verdauungssystems 
                        leichter ertragen werden oder treten auch abgeschw&auml;chter oder seltener auf. 
                        Somit h&auml;ngen die Qualit&auml;t des Immunsystems und die gesunde Verdauung auch 
                        eng zusammen. Beachtet werden muss jedoch bei Allergien und Unvertr&auml;glichkeiten 
                        immer, dass die landl&auml;ufig als &#187;gesund&#171; geltenden Lebensmittel 
                        teilweise auch zu den Ausl&ouml;sern z&auml;hlen und in diesen F&auml;llen gemieden 
                        werden m&uuml;ssen. Aber es gibt ja eine reichhaltige Palette an Alternativen, 
                        die ebenfalls das Immunsystem st&auml;rken k&ouml;nnen.
                        <br />
                        <br />
                        Auf jeden Fall m&uuml;ssen bei Nahrungsmittel-Unvertr&auml;glichkeiten und -Allergien 
                        die Beschwerdeausl&ouml;ser so weit wie m&ouml;glich gemieden werden, um die 
                        Darmschleimhaut nicht zu reizen und das Immunsystem an Fronten &#187;k&auml;mpfen&#171; 
                        zu lassen, an denen es gar nicht erforderlich ist. Die Darmschleimhaut und damit 
                        auch die Darmflora m&uuml;ssen gesch&uuml;tzt werden, damit das Immunsystem &#187;sein 
                        Pulver nicht unn&ouml;tig vergeudet&#171;, sondern an Stellen zur Verf&uuml;gung steht, 
                        an denen es besser gebraucht wird.
                        <br />
                        <a id="was">&nbsp;</a>
                        <hr />
                        <h5>Was st&auml;rkt das Immunsystem? </h5>
                        <hr />
                        Vor dem Hintergrund von Verdauungsproblemen muss ganz besonders aufmerksam geschaut 
                        werden, welche Methoden und Mittel geeignet sind, das Immunsystem zu st&auml;rken, 
                        um eine ganzheitliche Gesundheit zu gew&auml;hrleisten.
                        <br />
                        <a id="ernaehrung">&nbsp;</a>
                        <hr />
                        <h5>Ern&auml;hrung</h5>
                        <hr />
                        Grunds&auml;tzlich ist eine gesunde Ern&auml;hrung mit vielen frischen, vollwertigen 
                        pflanzlichen Lebensmitteln geeignet, das Immunsystem zu st&auml;rken. Die hier 
                        enthaltenen Vitamine, Mineralstoffe und sekund&auml;ren Pflanzenstoffen tragen zu 
                        einer besseren Gesundheit bei, denn s&auml;mtliche Stoffwechselvorg&auml;nge 
                        werden auch durch diese Vitalstoffe gesteuert. Fehlen sie oder stehen sie nur in 
                        zu geringer oder unausgeglichener Menge zur Verf&uuml;gung, k&ouml;nnen diese 
                        K&ouml;rperfunktionen nicht oder nicht richtig arbeiten.
                        <br /> 
                        <br />
                        Auch die Ballaststoffe &uuml;ben eine ganz wichtige Funktion aus: Sie pflegen die 
                        Darmschleimhaut wie ein Peeling und tragen alte, abgestorbene Schleimhautzellen ab 
                        und geben den jungen Zellen die M&ouml;glichkeit, die Nahrung optimal zu verwerten. 
                        Die n&uuml;tzlichen Mikroorganismen der Darmflora k&ouml;nnen die Ballaststoffe 
                        verwerten, die eigentlich f&uuml;r unser Verdauungssystem unverdaulich sind und 
                        sich dadurch vermehren und zur gesunden Balance der Darmflora beitragen.
                        <br />
                        <br />
                        Kontraproduktiv w&auml;re allerdings der Verzehr unvertr&auml;glicher Lebensmittel, 
                        weil dann zum einen die Darmschleimhaut gereizt oder sogar gesch&auml;digt wird 
                        und zu anderen das gesunde S&auml;uremilieu im Darm ver&auml;ndert und die Darmflora 
                        gesch&auml;digt w&uuml;rde. Somit ist im Falle von Nahrungsmittel-Unvertr&auml;glichkeiten 
                        und -Allergien immer auf eine ad&auml;quate und bek&ouml;mmliche Auswahl zu achten.
                        <br />
                        <br />
                        Neben frischem Obst, Gem&uuml;se und Getreideprodukten sollte der Speisezettel 
                        Eiwei&#223;lieferanten in Form von viel frischem Fisch, wenigen Eiern (2-3 pro Woche) und 1-2 
                        Fleischmahlzeiten enthalten. S&uuml;&#223;- und Knabberwaren wie Geb&auml;ck, 
                        S&uuml;&#223;igkeiten, Salzstangen, Chips etc. sind ebenfalls den Genussmitteln zuzurechnen 
                        und d&uuml;rfen bei Bedarf im Rahmen von sehr begrenzten Mengen zum &#187;Streicheln 
                        der Seele&#171; verzehrt, ansonsten aber weitestgehend gemieden werden.
                        <br />
                        <a id="trinken">&nbsp;</a>
                        <hr />
                        <h5>Trinken</h5>
                        <hr />
                        Ganz wichtig ist ein richtiges Trinkverhalten mit einer ausreichenden Trinkmenge. 
                        Die Trinkmenge sollte mindestens 1,5-2 Liter pro Tag betragen. Bei Erkrankungen 
                        (insbesondere fiebrigen Erkrankungen), Durchf&auml;llen, bei hohen Au&#223;entemperaturen 
                        und bei sportlichen Aktivit&auml;ten muss diese Menge angemessen gesteigert werden, 
                        damit der K&ouml;rper immer ausreichend mit Fl&uuml;ssigkeit versorgt ist. Alle 
                        K&ouml;rperfunktionen arbeiten nur mit einer ausreichenden Fl&uuml;ssigkeitsversorgung. 
                        Unterbleibt der Nachschub, gibt es Fehlfunktionen, und gerade das Immunsystem erleidet 
                        Schaden. Die Darmschleimhautzellen schrumpfen, und die Zwischenr&auml;ume zwischen 
                        den Schleimhautzellen vergr&ouml;&#223;ern sich, wenn sie nicht mit ausreichend 
                        Fl&uuml;ssigkeit versorgt werden. Dies bewirkt eine gr&ouml;&#223;ere Durchl&auml;ssigkeit 
                        der Darmschleimhaut, so dass Keime ins K&ouml;rperinnere eindringen und Krankheiten 
                        ausbrechen k&ouml;nnen.
                        <br />
                        <br />
                        Die Auswahl der Getr&auml;nke sollte vorrangig auf Wasser (Mineralwasser oder 
                        Leitungswasser) und Kr&auml;uter- und/oder Fr&uuml;chtetees und Fruchtsaftschorlen 
                        fallen. Kaffee und Schwarztee sind Genussmittel, die nur in begrenztem Rahmen 
                        genossen werden sollten.
                        <br />
                        <br />
                        Alle ges&uuml;&#223;ten Getr&auml;nke und auch Milch sind zum Durstl&ouml;schen 
                        nicht geeignet. Ges&uuml;&#223;te Getr&auml;nke enthalten Zucker und damit 
                        &#187;leere&#171; Kalorien und sind als Genussmittel einzustufen und zu begrenzen. 
                        Milch ist ein Nahrungsmittel, das durchaus seine Berechtigung auf dem Speisezettel 
                        haben k&ouml;nnte, aber nicht zu den Getr&auml;nken gez&auml;hlt wird.
                        <br />
                        <a id="darmflora">&nbsp;</a>
                        <hr />
                        <h5>Pflege der Darmflora</h5>
                        <hr />
                        Viele Tipps zum Thema &#187;Pflege der Darmflora&#171; haben Sie bereits bei der 
                        Ern&auml;hrung gelesen. Es ist wichtig, durch den Verzehr m&ouml;glichst vieler 
                        frischer pflanzlicher Lebensmittel auch f&uuml;r die Zufuhr von gesunden 
                        Mikroorganismen zu sorgen. Auch wenn man das Gem&uuml;se und Ost gut w&auml;scht, 
                        haften doch immer noch Bakterien an. Dies sind auch n&uuml;tzliche Milchs&auml;urebakterien, 
                        
                        <br />
                        Aber auch der Verzehr von milchsauer eingelegtem Gem&uuml;se und Obst (Sauerkraut, 
                        Mixed Pickles, Rote Beete, K&uuml;rbis) f&uuml;hrt Milchs&auml;urebakterien zu, 
                        dar&uuml;ber hinaus die f&uuml;r die gesunde Darmflora vorteilhaften S&auml;uren 
                        wie Milch-, Essig- und Apfels&auml;ure. Diese Bestandteile enthalten auch Brottrunk 
                        oder Kombucha, der mit dem so genannten Teepilz hergestellt wird.
                        <br />
                        <br />
                        In meinen Augen weniger sinnvoll sind die seit einiger Zeit f&uuml;r teures Geld 
                        angebotenen, mit Milchs&auml;urebakterien  angereicherten Milchprodukte (Probiotika), 
                        denn hier ist die Anzahl der zugesetzten Keime sehr gering. Da die Magens&auml;ure 
                        viele der Bakterien zerst&ouml;rt, kommen nur verschwindend geringe Mengen im 
                        Darm an &ndash; somit kann man sich dieses Geld auch sparen. Wenn man Milchprodukte 
                        verzehren will und vertr&auml;gt, eignet sich hier eher ein guter Naturjoghurt, 
                        dessen Bakteriengehalt nicht durch Erhitzung zunichte gemacht wurde. Lesen Sie 
                        hierzu auch die Beitr&auml;ge aus der Rubrik &#187;<a href="darmgesundheit">Darmgesundheit</a>&#171;.
                        <br />
                        <a id="leben">&nbsp;</a>
                        <hr />
                        <h5>Gesundes Leben</h5>
                        <hr />
                        Unter dem &Uuml;berbegriff &#187;gesunder Lebenswandel&#171; m&ouml;chte ich alle 
                        weiteren Ma&#223;nahmen wie ausreichend Bewegung an der frischen Luft und unter 
                        Sonnenlicht zusammenfassen. Es ist f&uuml;r das Immunsystem sehr wichtig, sich 
                        ausreichend zu bewegen, denn Tr&auml;gheit wirkt sich nicht nur nachteilig auf eine 
                        gesunde Verdauung aus, auch insgesamt wird die Gesundheit gesch&auml;digt, wenn 
                        man sich nicht gen&uuml;gend bewegt. W&auml;hlen Sie Bewegungs- oder Sportarten, 
                        die Ihnen Spa&#223; machen &ndash; Spazierengehen, Radfahren, Schwimmen, (Nordic) 
                        Walking oder Joggen, ganz wie Sie Ihre Priorit&auml;ten setzen. Wenn Sie einen 
                        &#187;Antreiber&#171; brauchen, w&auml;hlen Sie den Sport in der Gruppe, sind Sie 
                        ein Individualist, k&ouml;nnen Sie alles alleine machen. Hauptsache, Sie bewegen 
                        sich ausreichend &ndash; im Idealfall dreimal ca. 30 Minuten pro Woche &ndash; 
                        anfangs aber ist jeder Schritt, den Sie mehr als vorher gehen, auch schon vorteilhaft. 
                        Vermeiden Sie Leistungssport, denn hier setzen Sie sich unter Druck, und das 
                        Immunsystem wird bei &Uuml;beranstrengung eher gesch&auml;digt als gest&auml;rkt.
                        <br />
                        <br />
                        Nach M&ouml;glichkeit bewegen Sie sich drau&#223;en an der frischen Luft, dies 
                        f&uuml;hrt zu einer tieferen Atmung und Sauerstoffzufuhr. Das Sonnen- oder zumindest 
                        Tageslicht sorgt ebenfalls f&uuml;r eine Stimulation des Immunsystems. Vermeiden 
                        sollten Sie jedoch sportliche Bet&auml;tigung mitten im Stra&#223;enverkehr oder 
                        in Industriegebieten, da Sie sich hier einer erh&ouml;hten Belastung mit 
                        Schadstoffen aussetzen w&uuml;rden. Bevorzugen Sie deshalb l&auml;ndliche Gegenden 
                        oder Vorstadtgebiete.
                        <br />
                        <a id="psyche">&nbsp;</a>
                        <hr />
                        <h5>Immunsystem und Psyche</h5>
                        <hr />
                        Ganz eng verbunden mit der k&ouml;rperlichen Gesundheit und einem stabilen Immunsystem ist 
                        das psychische Wohlergehen. Wenn Sie sich seelisch schlecht f&uuml;hlen, leidet 
                        auch das Immunsystem. Sorgen Sie deshalb nicht nur f&uuml;r ein m&ouml;glichst 
                        stressfreies Leben &ndash; hierbei ist nat&uuml;rlich nur der negative &#187;Disstress&#171; 
                        gemeint. Sollten sich stressige Zeiten nicht vermeiden lassen, so versuchen Sie, 
                        diese auszugleichen, indem Sie Entspannungszeiten einlegen. Es bieten sich hier 
                        nicht nur Ihre entspannenden Hobbys an, sondern ganz bewusst auch Entspannungstechniken 
                        wie Autogenes Training, Progressive Muskelentspannung nach Jacobsen oder auch Chi 
                        Gong. Diese Techniken k&ouml;nnen Sie u.a. in der Volkshochschule erlernen und zu 
                        Hause immer dann aus&uuml;ben, wenn Sie Stress kompensieren wollen.
                        <br />
                        <br />
                        G&uuml;nstig hingegen ist der gute &#187;Eustress&#171;, der entsteht, wenn Sie 
                        etwas gerne tun, sich anregen lassen. Nur im immer gleichen Trott vor sich hin zu 
                        leben, ist ebenso wenig gesund wie das Gegenteil. Sorgen Sie deshalb f&uuml;r 
                        eine vern&uuml;nftige Ausgeglichenheit. Dar&uuml;ber hinaus bringt ein nettes 
                        soziales Umfeld zus&auml;tzlich positive Impulse, die auch mit zu einem starken 
                        Immunsystem beitragen.
                        <br />
                        <br />
                        Und nat&uuml;rlich, last but not least, ist ein ausreichender und gesunder Schlaf 
                        ein Garant daf&uuml;r, dass Sie ganzheitlich gesund und mit einem starken Immunsystem 
                        ausgestattet sind.
                        <br />
                        <a id="abhaertung">&nbsp;</a>
                        <hr />
                        <h5>Abh&auml;rtung</h5>
                        <hr />
                        Abh&auml;rtung leistet einen gro&#223;en Beitrag f&uuml;r ein starkes Immunsystem. 
                        Es muss nicht gleich das Bad im Eisloch sein, auch sich bei Wind und Wetter 
                        drau&#223;en zu bewegen, ist eine gute Ma&#223;nahme zur Abh&auml;rtung. Weiterhin 
                        k&ouml;nnen Sie in die Sauna gehen, sich Kneipp’sche Anwendungen zunutze machen, 
                        Haut, Bindegewebe und Immunsystem mit B&uuml;rstenmassagen st&auml;rken oder auch 
                        einfach nur unter der Dusche mal F&uuml;&#223;e, Beine und Arme kalt abbrausen.
                        <br />
                        <br />
                        Vermeiden Sie grunds&auml;tzlich Ausk&uuml;hlung und wenden Sie kaltes Wasser nur 
                        bei warmen Gliedern an. Generell wirkt Ausk&uuml;hlung schw&auml;chend auf das 
                        Immunsystem, vermeiden Sie deshalb Zug oder unangemessene Kleidung, damit Ihr 
                        K&ouml;rper und H&auml;nde und F&uuml;&#223;e immer warm bleiben. Wenn Sie merken, 
                        dass Ihnen kalt ist, ziehen Sie sich w&auml;rmer an, &uuml;berpr&uuml;fen Sie die 
                        Luftverh&auml;ltnisse im Raum und bewegen Sie sich, denn Bewegungslosigkeit l&auml;sst 
                        den Blutdruck und damit die w&auml;rmende Durchblutung sinken. 
                        <br />
                        <br />
                        Sobald Sie sich durch geeignete Ma&#223;nahmen abgeh&auml;rtet haben, steigt die 
                        Toleranz gegen&uuml;ber K&auml;lte, so dass Sie hier in Zukunft besser gewappnet 
                        sind. Vielleicht ist dann tats&auml;chlich irgendwann das Eisbad m&ouml;glich 
                        &ndash; muss es aber nicht. Ich habe vor einigen Jahren bei -40°C in Finnland 
                        zwischen zwei Saunag&auml;ngen im Eisloch gebadet und kann nur sagen: &#187;Ja, 
                        es war kalt, sehr kalt, aber hinterher herrlich!&#171;
                        <br />
                        <a id="krankheiten">&nbsp;</a>
                        <hr />
                        <h5>Bei Krankheiten auch an das Immunsystem denken</h5>
                        <hr />
                        Auch wenn Sie krank sind, k&ouml;nnen Sie durch ein richtiges Verhalten viel 
                        f&uuml;r Ihr Immunsystem tun. Grunds&auml;tzlich w&auml;re es nat&uuml;rlich das 
                        Beste, gar nicht erst zu erkranken und durch Vorbeugung das Krankwerden vermeiden. 
                        Leider erwischt es uns ab und an aber auch mit dem robustesten Immunsystem. 
                        <br />
                        <br />
                        In diesem Fall geben Sie Ihrem K&ouml;rper die Ruhe, nach der er verlangt und 
                        kurieren Sie diese Krankheit richtig aus. Jede Krankheit mit Medikamenten 
                        niederzukn&uuml;ppeln, ist sehr sch&auml;dlich: Oftmals r&auml;cht sich der 
                        K&ouml;rper, und Sie erleiden einen R&uuml;ckfall, der nur noch schwerer ausf&auml;llt 
                        als die Ersterkrankung.
                        <br />
                        <br />
                        Wenden Sie ggf. Naturheilmittel an. Beispielsweise hilft bei Erk&auml;ltungen ein 
                        Kamillendampfbad oder das Einatmen von Salzwasserdampf. Das Spülen der Nase mit 
                        Salzwasser kann helfen, die Nasenschleimhäute zu reinigen und zu befeuchten (siehe 
                        auch <a href="lexikon-naturheilmethoden#nasenspuelung" targel="_blank">Lexikon der 
                        Naturheilmethoden/Nasenspülung</a>). Warme Fu&#223;b&auml;der 
                        oder auch ansteigende Wechselb&auml;der und &auml;therische &Ouml;le (Pfefferminze, 
                        Lavendel, Thymian) helfen ebenfalls, die Erk&auml;ltungen zu vertreiben. Wenn es 
                        Sie so richtig erwischt hat, und Sie Fieber haben, ist dies ein gutes Mittel, mit 
                        dem sich der K&ouml;rper selbst hilft: Viren, die meistens die Verursacher von 
                        Erk&auml;ltungen oder Grippe sind, sind sehr hitzeempfindlich und werden durch 
                        das Fieber abget&ouml;tet. Sollte das Fieber zu hoch ansteigen, helfen kalte 
                        Wadenwickel. 
                        <br />
                        <br />
                        Es gibt auch sehr wirksame hom&ouml;opathische Mittel, die man m&ouml;glichst 
                        bereits im Anfangsstadium von Erk&auml;ltungs- oder Grippeerkrankungen einnehmen 
                        kann. Als erweisenerma&#223;en g&uuml;nstig haben sich folgende Mittel erwiesen: 
                        Bryonia D6, Eupatorium perfoliatum D6, Luffa operculata D6 und Phytolacca D6. 
                        Beachten Sie, dass diese Mittel nur bei der entsprechenden Zuordnung zu bestimmten 
                        Leitsymptomen wirken k&ouml;nnen: Diese sind bei Bryonia Reiz- und Krampfhusten 
                        oder Bronchitis ohne Sekret, bei Eupatorium perfoliatum Grippe mit Gliederschmerzen 
                        und &Uuml;belkeit, bei Luffa operculata Kopfschmerzen bei Entz&uuml;ndung der oberen Luftwege, 
                        Rachenentz&uuml;ndung, Entz&uuml;ndung der Nasenschleimhaut und/oder der Nasennebenh&ouml;hlen
                        und/oder der Mundschleimhaut, bei Phytolacca Halsschmerzen, Mandelentz&uuml;ndung 
                        und/oder geschwollene Lymphknoten.
                         Bei der Auswahl und richtigen Zuordnung der Mittel passend zu Ihren Symptomen hilft 
                        Ihnen ein versierter Heilpraktiker oder auch ein spezialisierter Apotheker. 
                        <br />
                        <br />
                        Gegen Husten hilft ein Sirup aus Zwiebeln und Kandiszucker oder, wenn Sie die 
                        M&ouml;glichkeit haben, unged&uuml;ngte Wiesen zu finden, auch Sirup von Spitzwegerich. 
                        Auch ein Heublumensack, auf die Brust gelegt, kann bei Husten gute Dienste leisten, 
                        und bei Halsschmerzen sind warme oder kalte Wickel wirksam.
                        <br />
                        <br />
                        Sie sehen, es ist in den meisten F&auml;llen m&ouml;glich, sich auch mit 
                        &#187;harmlosen&#171; Mitteln selbst zu helfen. Sollten wegen einer bakteriellen 
                        Infektion tats&auml;chlich Antibiotika erforderlich sein, dann bedenken Sie, dass 
                        diese leider auch immer die Darmflora sch&auml;digen oder sogar zerst&ouml;ren. 
                        Im Anschluss ist es immer erforderlich, diese mit geeigneten Mitteln wieder zu 
                        sanieren, denn &ndash; wie oben erw&auml;hnt &ndash; befindet sich ein Gro&#223;teil 
                        Ihres Immunsystems im Darm, und eine optimale Darmflora ist der beste Garant 
                        f&uuml;r ein robustes Immunsystem. Lesen Sie hier bitte auch den Beitrag 
                        &#187;<a href="darmsanierung">Darmsanierung</a>&#171;.
                        <br />
                        <a id="verdauung">&nbsp;</a>
                        <hr />
                        <h5>Starkes Immunsystem f&uuml;r eine Gesunde Verdauung</h5> 
                        <hr />
                        Gerade bei der St&auml;rkung des Immunsystems ist eine ganzheitliche Betrachtungsweise 
                        unabdingbar. Das Immunsystem ist an so vielen Stellen unseres Organismus lokalisiert, 
                        es arbeitet mit so vielen gr&ouml;&#223;eren und kleineren Einzelsystemen zusammen, 
                        dass hier eine punktuelle Betrachtung zu nichts f&uuml;hrt.
                        <br />
                        <br />
                        Und insbesondere bei Verdauungsproblemen ist es wichtig, mit einem starken 
                        Immunsystem die Gesundheit und damit auch das Wohlbefinden zu stabilisieren. 
                        Verdauungsprobleme verst&auml;rken sich auch immer, wenn man sich nicht so richtig 
                        wohl f&uuml;hlt. Umso wichtiger ist es, alles daf&uuml;r zu tun, dass man nicht 
                        oder zumindest nicht so h&auml;ufig und nicht so schwer krank wird, um sich so 
                        weit wie m&ouml;glich wohl zu f&uuml;hlen und Verdauungsbeschwerden und/oder deren 
                        Intensit&auml;t zu minimieren.
                        <br />
                        <br />
                        Wenn Sie sich diese Ganzheitlichkeit in Bezug auf Ihre Verdauung 
                        bewusst machen und bei allen Ihren Einzelschritten immer das Ganze im Auge behalten, 
                        k&ouml;nnen Sie eine robuste, ganzheitliche Gesundheit mit einem starken Immunsystem 
                        und einer gesunden Verdauung f&uuml;r sich, f&uuml;r Ihren K&ouml;rper, Ihren Geist
                        und Ihre Seele erreichen.
                        <br />
                        <hr>
                        <a id="beratung">&nbsp;</a>
                        <div class="row">
                        <div class="col s12 m2">
                            <a href="http://www.ganzheitliche-gesundheitsberatung.de" target="_blank">
                                <img src="<?php echo IMG_PATH; ?>praxiswebsite.png" alt="" class="inline" /></a>
                        </div>
                        </div>
                        <div class="row">
                        <div class="col s12 m12">
                        <h5>Beratung</h5>
                        <br />
                            Gerne biete ich Ihnen eine individuelle Beratung an &ndash; 
                            auf Wunsch auch telefonisch oder per Skype.
                            <br />
                            Bitte informieren Sie sich auf meiner Praxis-Website <a href="http://www.ganzheitliche-gesundheitsberatung.de" target="_blank">&#187;www.Ganzheitliche-Gesundheitsberatung.de&#171;</a>
                        </div>
                        </div>
                        <hr>
                        <br />
                        <a href="guterrat" target="_blank"><img src="<?php echo IMG_PATH; ?>hilfreich.png" alt="" class="left" /></a>
                        <br />
                        <br />
                        <hr />
                        <b>Bitte lesen Sie auch folgende Beitr&auml;ge:</b>
                        <br />
                        <a href="ganz-gesund">&#149; Ganzheitliche Gesundheit</a>
                        <br />
                        <a href="ganz-magendarm">&#149; Ganzheitliche Betrachtung von Magen-/Darmbeschwerden</a>
                        <br />
                        <hr />
                        <a href="javascript: scrollMainToTop();" class="nachoben">nach oben</a>
                    </div>
                </div>
            </div>    
            <br>
            <br> 
            <div class="bodyspacer"></div> 
        </div>