        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br /> 
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>
                <h1 class="header center orange-text">Rezept-Videos</h1>      
            </div>  
        </div> 
        <div class="container">    
            <div class="section">   
                <div class="row margintoprow">        
                    <div class="col s12 m4">
                        <ul class="nav">
                            <li>
                                <b>Auf dieser Seite finden Sie Videos zu folgenden Rezepten:</b>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>rezepte#kartoffelsuppe"><b>Warme Gerichte</b>: Kartoffelsuppe</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>rezepte#kuerbiseintopf"><b>Warme Gerichte</b>: Kürbis-Eintopf</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>rezepte#erdbeerspeise"><b>Desserts</b>: Rhabarber-Erdbeer-Speise</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>rezepte#bratapfel"><b>Desserts</b>: Bratäpfel</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>rezepte#kokosananaslongdrink"><b>Getränke</b>: Erfrischender Kokos-Ananas-Longdrink</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>rezepte#smoothie"><b>Getränke</b>: Smoothie</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>rezepte#kokosmakronen"><b>Gebäck</b>: Kokosmakronen</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>rezepte#tortasdeaceite"><b>Gebäck</b>: Tortas de Aceite</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>rezepte#avocadobrotaufstrich"><b>Verschiedenes</b>: Avocado-Brotaufstrich</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>rezepte#hustensaft"><b>Verschiedenes</b>: Selbstgemachter Hustensaft</a>
                            </li> 
                    <!--
                            <li>
                                <a href="<?= URL_ROOT ?>rezepte#stellungnahme">Stellungnahme zum Thema &#187;Werbung vor den Videos&#171;</a>
                            </li> 
                    -->
                        </ul>
                    </div>
                    <div class="row">
                    <div class="col s12 m12">
                        <br />
                        <br />
                        Was koche ich heute? Was kann ich Gästen anbieten? Was macht wenig Arbeit und kommt rasch auf den Tisch?
                        Auf diese Fragen (leckere) Antworten zu finden, ist manchmal 
                        schon für all diejenigen eine Herausforderung, die alles ohne Probleme essen dürfen.
                        Sehr viel schwieriger aber ist häufig die Suche nach geeigneten Rezepten für 
                        Menschen mit Nahrungsmittel-Unverträglichkeiten oder Allergien.
                        <br />
                        <br />
                        Auf dieser Seite, die nach und nach mit immer mehr Rezepten gefüttert wird, 
                        finden Sie Ideen für verschiedene Gerichte, Brotaufstriche, Gebäck und
                        vieles mehr. In den Videos, in denen ich die Rezepte vorstelle und die Zubereitung 
                        zeige, wird jeweils dargestellt, bei welchen Intoleranzen oder Allergien die 
                        Vorschläge geeignet sind.
                        <br />
                        <br />
                        <!--
                        Die Videos sind in Zusammenarbeit mit der Firma sevenload entstanden und sind auch 
                        im Portal &#187;<a href="http://mahlzeit.tv/partner/Doris%20Paas" target="_blank">Mahlzeit.tv</a>&#171; 
                        eingebunden. 
                        <br />
                        <br />
                        Bitte lesen Sie auch die <a href="<?= URL_ROOT ?>rezepte#werbung">Stellungnahme zum Thema &#187;Werbung vor den Videos&#171;</a>.
                        <br />
                        <br />
                        -->
                        Viel Spaß beim Zubereiten und guten Appetit.
                        <br />
                        <br />
                        ... und wenn Sie sich erklären lassen möchten, was beispielsweise eine 
                        Laktose-Intoleranz oder eine Zöliakie sind, empfehle ich Ihnen die 
                        <b><a href="videos" target="_blank">Tutorials</a></b>.  
                        In diesen kleinen &#187;Erklär-Videos&#171; werden grundlegende Hintergründe 
                        erläutert. Schnuppern Sie doch einmal hinein.  
                        
                        <br />
                        <br />
                        <a href="guterrat" target="_blank"><img src="<?php echo IMG_PATH; ?>hilfreich-5.png" alt="" class="left" /></a>
                        <br />
                        <br />
                        <hr class="double" />
                    </div>
                </div>
                </div>
                <div class="row margintoprow">        
                    <div class="col s12 m12">
                        <hr />
                        <h5>Warme Gerichte</h5>
                        <hr />
                        <a id="kartoffelsuppe">&nbsp;</a>
                        <br />
                        <span style="font-weight:bold; text-decoration:underline">Kartoffelsuppe</span> (12:11 Min)
                        <br />
                        <br />
                        <div class="icon-block height100">
                            <div class="video-wrapper">
                                <video poster="<?php echo VIDEO_PATH; ?>foto-kartoffelsuppe.jpg" autobuffer controls>
                                    <source src="<?php echo VIDEO_PATH; ?>kartoffelsuppe.mp4" type="video/mp4" />
                                    <source src="<?php echo VIDEO_PATH; ?>kartoffelsuppe.ogg" type="video/ogg" />
                                </video>
                            </div>
                        </div>
                        
                        
                        <a id="kuerbiseintopf">&nbsp;</a>
                        <br />
                        <br />
                        <span style="font-weight:bold; text-decoration:underline">Kürbis-Eintopf</span> (11:09 Min)
                        <br />
                        <br />
                        <div class="icon-block height100">
                            <div class="video-wrapper">
                                <video poster="<?php echo VIDEO_PATH; ?>foto-kuerbiseintopf.jpg" autobuffer controls>
                                    <source src="<?php echo VIDEO_PATH; ?>kuerbiseintopf.mp4" type="video/mp4" />
                                    <source src="<?php echo VIDEO_PATH; ?>kuerbiseintopf.ogg" type="video/ogg" />
                                </video>
                            </div>
                        </div>
                        
                        
                        <br />
                        <br />
                        <div class="obenlink">
                        <a href="javascript: scrollMainToTop();" class="nachoben">nach oben</a>
                        </div>
                        <hr />
                        <h5>Desserts</h5>
                        <hr />
                        
                        
                        <a id="erdbeerspeise">&nbsp;</a>
                        <br />
                        <span style="font-weight:bold; text-decoration:underline">Rhabarber-Erdbeer-Speise</span> (11:30 Min)
                        <br />
                        <br />
                        <div class="icon-block height100">
                            <div class="video-wrapper">
                                <video poster="<?php echo VIDEO_PATH; ?>foto-rhabarber-erdbeerspeise.jpg" autobuffer controls>
                                    <source src="<?php echo VIDEO_PATH; ?>rhabarber-erdbeerspeise.mp4" type="video/mp4" />
                                    <source src="<?php echo VIDEO_PATH; ?>rhabarber-erdbeerspeise.ogg" type="video/ogg" />
                                </video>
                            </div>
                        </div>
                        <br />
                        
                        
                        <a id="bratapfel">&nbsp;</a>
                        <br />
                        <span style="font-weight:bold; text-decoration:underline">Bratäpfel</span> (7:26 Min)
                        <br />
                        <br />
                        <div class="icon-block height100">
                            <div class="video-wrapper">
                                <video poster="<?php echo VIDEO_PATH; ?>foto-bratapfel.jpg" autobuffer controls>
                                    <source src="<?php echo VIDEO_PATH; ?>bratapfel.mp4" type="video/mp4" />
                                    <source src="<?php echo VIDEO_PATH; ?>bratapfel.ogg" type="video/ogg" />
                                </video>
                            </div>
                        </div>
                        <br />
                        
                        
                        <br />
                        <div class="obenlink">
                        <a href="javascript: scrollMainToTop();" class="nachoben">nach oben</a>
                        </div>
                        <hr />
                        <h5>Getränke</h5>
                        <hr />
                        
                        
                        <a id="kokosananaslongdrink">&nbsp;</a>
                        <br />
                        <span style="font-weight:bold; text-decoration:underline">Erfrischender Kokos-Ananas-Longdrink</span> (4:21 Min)
                        <br />
                        <br />
                        <div class="icon-block height100">
                            <div class="video-wrapper">
                                <video poster="<?php echo VIDEO_PATH; ?>foto-kokos-ananas-longdrink.jpg" autobuffer controls>
                                    <source src="<?php echo VIDEO_PATH; ?>kokos-ananas-longdrink.mp4" type="video/mp4" />
                                    <source src="<?php echo VIDEO_PATH; ?>kokos-ananas-longdrink.ogg" type="video/ogg" />
                                </video>
                            </div>
                        </div>
                        <br />
                        
                        
                        <a id="smoothie">&nbsp;</a>
                        <br />
                        <span style="font-weight:bold; text-decoration:underline">Smoothie</span> (3:09 Min)
                        <br />
                        <br />
                        <div class="icon-block height100">
                            <div class="video-wrapper">
                                <video poster="<?php echo VIDEO_PATH; ?>foto-smoothie.jpg" autobuffer controls>
                                    <source src="<?php echo VIDEO_PATH; ?>smoothie.mp4" type="video/mp4" />
                                    <source src="<?php echo VIDEO_PATH; ?>smoothie.ogg" type="video/ogg" />
                                </video>
                            </div>
                        </div>
                        <br />
                        
                        
                        <br />
                        <div class="obenlink">
                        <a href="javascript: scrollMainToTop();" class="nachoben">nach oben</a>
                        </div>
                        <hr />
                        <h5>Gebäck</h5>
                        <hr />
                        
                        
                        <a id="kokosmakronen">&nbsp;</a>
                        <br />
                        <span style="font-weight:bold; text-decoration:underline">Kokosmakronen</span> (9:37 Min)
                        <br />
                        <br />
                        <div class="icon-block height100">
                            <div class="video-wrapper">
                                <video poster="<?php echo VIDEO_PATH; ?>foto-kokosmakronen.jpg" autobuffer controls>
                                    <source src="<?php echo VIDEO_PATH; ?>kokosmakronen.mp4" type="video/mp4" />
                                    <source src="<?php echo VIDEO_PATH; ?>kokosmakronen.ogg" type="video/ogg" />
                                </video>
                            </div>
                        </div>
                        <br />
                        
                        
                        <a id="tortasdeaceite">&nbsp;</a>
                        <br />
                        <span style="font-weight:bold; text-decoration:underline">Tortas de Aceite</span> (16:49 Min)
                        <br />
                        <br />
                        <div class="icon-block height100">
                            <div class="video-wrapper">
                                <video poster="<?php echo VIDEO_PATH; ?>foto-tortas-de-aceite.jpg" autobuffer controls>
                                    <source src="<?php echo VIDEO_PATH; ?>tortas-de-aceite.mp4" type="video/mp4" />
                                    <source src="<?php echo VIDEO_PATH; ?>tortas-de-aceite.ogg" type="video/ogg" />
                                </video>
                            </div>
                        </div>
                        <br />
                        
                        
                        <br />
                        <div class="obenlink">
                        <a href="javascript: scrollMainToTop();" class="nachoben">nach oben</a>
                        </div>
                        <hr />
                        <h5>Verschiedenes</h5>
                        <hr />
                        
                        
                        <a id="avocadobrotaufstrich">&nbsp;</a>
                        <br />
                        <span style="font-weight:bold; text-decoration:underline">Avocado-Brotaufstrich</span> (5:16 Min)
                        <br />
                        <br />
                        <div class="icon-block height100">
                            <div class="video-wrapper">
                                <video poster="<?php echo VIDEO_PATH; ?>foto-avocado-brotaufstrich.jpg" autobuffer controls>
                                    <source src="<?php echo VIDEO_PATH; ?>avocado-brotaufstrich.mp4" type="video/mp4" />
                                    <source src="<?php echo VIDEO_PATH; ?>avocado-brotaufstrich.ogg" type="video/ogg" />
                                </video>
                            </div>
                        </div>
                        <br />
                        
                        
                        <a id="hustensaft">&nbsp;</a>
                        <br />
                        <span style="font-weight:bold; text-decoration:underline">Selbstgemachter Hustensaft</span> (3:24 Min)
                        <br />
                        <br />
                        <div class="icon-block height100">
                            <div class="video-wrapper">
                                <video poster="<?php echo VIDEO_PATH; ?>foto-hustensaft.jpg" autobuffer controls>
                                    <source src="<?php echo VIDEO_PATH; ?>hustensaft.mp4" type="video/mp4" />
                                    <source src="<?php echo VIDEO_PATH; ?>hustensaft.ogg" type="video/ogg" />
                                </video>
                            </div>
                        </div>
                        <br />
                        
                        <!--
                        <a id="stellungnahme">&nbsp;</a>
                        <hr>
                        <br />
                        <br />
                        <span style="font-weight:bold; text-decoration:underline">Stellungnahme zum Thema &#187;Werbung vor den Videos&#171;</span>
                        <br />
                        <br />
                        Wie Sie wissen, verzichte ich auf der kompletten Website
                        <a href="http://www.dorispaas.de" target="_blank">www.DorisPaas.de</a> auf 
                        Werbung, f&uuml;r die ich finanzielle oder sonstige
                        Verg&uuml;nstigungen erhalten w&uuml;rde. Wenn ich Ihnen an verschiedenen Stellen 
                        trotzdem Produkte empfehle, dann nur solche, die ich selbst getestet und f&uuml;r 
                        gut befunden habe. Nur so ist es mir m&ouml;glich, eine glaubhaft unabh&auml;ngige 
                        Meinung zu vertreten und zu behalten.
                        <br />
                        <br />
                        Trotzdem sehen Sie vor den Videos, die &uuml;brigens nicht auf meinem eigenen Server, sondern 
                        auf dem von auf &#187;Mahlzeit.tv&#171; liegen, jeweils eine kurze Werbeeinblendung. Auf die Auswahl
                        der beworbenen Produkte habe ich keinen Einfluss, ebensowenig auf die Entscheidung, ob 
                        sie sich mit meiner Meinung zu einer ganzheitlich gesunden Ern&auml;hrung und 
                        Lebensweise und mit Aussagen und Themen meiner Videos decken. Es handelt sich hier 
                        auch nicht um Produkte, die von mir pers&ouml;nlich ausgesucht und/oder empfohlen werden. 
                        In diesem Zusammenhang m&ouml;chte ich Sie zudem noch einmal auf den 
                        <a href="http://www.dorispaas.de/index.php?page=impressum#disclaimer" target="_blank">Disclaimer</a> hinweisen.
                        <br />
                        <br />
                        Die Firma sevenload finanziert jedoch mit den Einnahmen von Werbepartnern die
                        Herstellung der Videos und die Pflege des Portals &#187;Mahlzeit.tv&#171;. Dies 
                        finde ich akzeptabel, denn nur so ist es m&ouml;glich, Ihnen, lieber Leser und 
                        Zuschauer, aufw&auml;ndig produzierte Videos kostenlos zur Verf&uuml;gung zu stellen.
                        <br />
                        <br />
                        Ein Teil der Werbeeinnahmen der Firma sevenload wird an mich weitergeleitet. Um
                        meine Unabh&auml;ngigkeit ganz deutlich zu unterstreichen, erkl&auml;re ich hiermit, 
                        dass ich diese Betr&auml;ge nicht behalte, sondern sie ohne jegliche Abz&uuml;ge 
                        an von mir ausgew&auml;hlte gemeinn&uuml;tzige Organisationen spende.
                        -->
                        <br />
                        <a href="javascript: scrollMainToTop();" class="nachoben">nach oben</a>
                    </div>
                </div>
            </div>    
            <br>
            <br> 
            <div class="bodyspacer"></div> 
        </div>