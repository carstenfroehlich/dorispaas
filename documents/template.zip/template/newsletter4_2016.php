        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br /> 
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>
                <h1 class="header center orange-text">DorisPaas-Newsletter</h1>      
            </div>  
        </div> 
        <div class="container">    
            <div class="section">   
                <div class="row margintoprow">        
                    <div class="col s12 m12">
                        <img src="<?php echo IMG_PATH; ?>dorispaas-de-titelfoto-newsletter-w.png" alt="" border="0" hspace="0" vspace="0" style="float: left; margin-left: 0px; margin-right: 20px; padding-bottom: 0px;" /></a><br />
                        <br />
                        <br />
                        <br />
                        <br />
                        <br />
                        <br />
                        <br />
                        <br />
                        <b>Ausgabe 29 (Juli 2016)</b>
                        <br />
                        <br />
                        
                        _____________________________________________________________________________________________
                        <br />
                        <br />
                        <br />
                        
                        <a href="http://www.dorispaas.de/" target="_blank"><img src="<?php echo IMG_PATH; ?>nl-2016-04-titel.png" alt="" border="0" hspace="0" vspace="0" style="float: left; margin-left: 0px; margin-right: 20px; padding-bottom: 10px;" /></a>
                        Liebe Leserin, lieber Leser.
                        <br />
                        Endlich beginnt wieder die Urlaubszeit! Egal, ob Sie Ferien auf &#187;Balkonien&#171; 
                        machen oder aber verreisen &ndash; erholen kann man sich &uuml;berall. Und selbst 
                        wenn Sie jetzt noch keinen Urlaub bekommen, k&ouml;nnen Sie die Abendstunden nutzen, 
                        ein wenig die Seele baumeln zu lassen. Das ist noch nicht einmal abh&auml;ngig vom 
                        Wetter (das ja leider bis jetzt ziemlich unberechenbar war). Schauen Sie sich doch 
                        einmal das nebenstehende Bild an: Es muss nicht immer so ein spektakul&auml;rer 
                        Sonnenuntergang sein, wie ich ihn an einem Abend auf der d&auml;nischen Insel Fan&#248; 
                        erlebt habe, aber allein das Abschalten vom Alltag, es sich gem&uuml;tlich machen, 
                        ein gutes Buch lesen, sich mit Freunden treffen &ndash; es gibt so vieles, wof&uuml;r 
                        man die langen Abende in dieser Jahreszeit f&uuml;r sich nutzen kann. F&uuml;llen 
                        Sie Ihre Akkus wieder auf, die im Laufe der vergangenen Monate sicherlich die 
                        Grenzen ihrer Kapazit&auml;t erreicht haben und sammeln Sie Kr&auml;fte f&uuml;r 
                        die kommende Zeit. Und wenn Sie schon aus Ihrem Urlaub zur&uuml;ck gekehrt sind, 
                        k&ouml;nnen Sie so Ihre Kraftreservern l&auml;nger bewahren. 
                        <br />
                        <br />
                        <hr>
                        <br />
                        <a href="http://www.dorispaas.de/index.php?page=bitterstoffe" target="_blank"><img src="<?php echo IMG_PATH; ?>nl-2016-04-loewenzahn.png" alt="" border="0" hspace="0" vspace="0" style="float: left; margin-left: 0px; margin-right: 20px; padding-bottom: 0px;" /></a>
                        <b>&#149;	<a href="http://www.dorispaas.de/index.php?page=bitterstoffe" target="_blank">Bitterstoffe f&uuml;r die Verdauung nutzen</a></b>
                        <br />
                        Bitterstoffe k&ouml;nnen einen sehr positiven Einfluss auf unsere Verdauung haben. 
                        Wie kommt das? Eigentlich sind wir doch aufgrund unserer Entwicklung so programmiert, 
                        bittere Nahrung abzulehnen, denn wir verbinden diese Geschmacksrichtung mit 
                        &#187;sch&auml;dlich&#171; oder gar &#187;giftig&#171;! Gerade in dieser genetischen 
                        Programierung in Bezug auf Bitteres aber liegt das Geheimnis: Der K&ouml;rper will 
                        vermeintlich sch&auml;dliche Stoffe, die mit der Nahrung aufgenommen werden, so 
                        schnell wie m&ouml;glich wieder los werden, damit sie kein Unheil anrichten k&ouml;nnen. 
                        Der Magen und die Verdauungsdr&uuml;sen Leber, Galle und Bauchspeicheldr&uuml;se 
                        produzieren vermehrt Verdauungss&auml;fte, um damit die Inaktivierung und vor allem 
                        die Ausscheidung der Substanzen zu beschleunigen. Aber auch die Verdauungsleistung 
                        insgesamt wird so gef&ouml;rdert. Ein paar L&ouml;wenzahnbl&auml;tter im Salat sind 
                        genauso gesund wie ein Espresso oder sogar ein St&uuml;ckchen dunkle, hochprozentige 
                        Schokolade. Und es gibt noch viele andere Bitterstoffe in der Variante &#187;besonders 
                        lecker&#171;. 
                        <br />
                        <br />
                        <hr>
                        <br />
                        <a href="http://www.dorispaas.de/index.php?page=praeparatetest" target="_blank"><img src="<?php echo IMG_PATH; ?>praeparate-newsletter.png" alt="" border="0" hspace="0" vspace="0" style="float: left; margin-left: 0px; margin-right: 20px; padding-bottom: 10px;" /></a>
                        <b>&#149;	<a href="http://www.dorispaas.de/index.php?page=praeparatetest" target="_blank">Aktualisierung der Seite &#187;Pr&auml;paratrestests&#171; mit neuen Pr&auml;paraten</a></b>
                        <br />
                        Wer meine Website und meine B&uuml;cher kennt, wei&#223;, dass ich Nahrungserg&auml;nzungsmitteln 
                        im Allgemeinen skeptisch gegen&uuml;berstehe &ndash; insbesondere, wenn es sich 
                        um Vitamin- und Mineralstoff-Pr&auml;parate handelt. Eine Ausnahme k&ouml;nnen 
                        jedoch die Mittel darstellen, die bei Nahrungsmittel-Unvertr&auml;glichkeiten 
                        Enzyme oder andere Stoffe erg&auml;nzen, an denen es in diesen F&auml;llen mangelt.
                        Aber nicht immer sind alle Produkte empfehlenswert &ndash; und hier die Spreu vom 
                        Weizen zu trennen, ist f&uuml;r den Laien oft nicht einfach. Aus diesem Grund gibt es 
                        eine Seite, auf der ich Pr&auml;parate getestet habe und Ihnen meine ganz 
                        pers&ouml;nlichen Ergebnisse zur Verf&uuml;gung stelle. Diese Seite wird st&auml;ndig 
                        aktualisiert, und neue Produkte werden hinzugef&uuml;gt. Es lohnt sich auf jeden 
                        Fall, sich hier regelm&auml;&#223;ig auf den neuesten Stend zu bringen. Aktuell 
                        finden Sie u.a. mit &#187;Fructaid&#171; ein neues Pr&auml;parat, das bei 
                        Fruktose-Intoleranz helfen soll, und das seit wenigen Wochen auch in Deutschland erh&auml;ltlich ist.
                        <br />
                        <br />
                        <hr>
                        <br />
                        <a href="https://www.tuebiom.de/" target="_blank"><img src="<?php echo IMG_PATH; ?>tuebiom.png" alt="" border="0" hspace="0" vspace="0" style="float: left; margin-left: 0px; margin-right: 20px; padding-bottom: 10px;" /></a>
                        <b>&#149;	<a href="http://www.dorispaas.de/index.php?page=blog#blog-2016-07-04" target="_blank">T&uuml;biom</a></b>
                        <br />
                        Einmal nicht in eigener Sache m&ouml;chte ich Sie an dieser Stelle auf eine sehr 
                        unterst&uuml;tzenswertes Projekt aufmerksam machen: das T&uuml;biom-Projekt.
                        Das Ziel dieses Projektes ist es, die Zusammenh&auml;nge zwischen Darm-Mikrobiom, 
                        Gesundheit und unserem Lebensstil besser zu verstehen. Daf&uuml;r muss zun&auml;chst 
                        ermittelt werden, welche Zusammensetzungen des Darm-Mikrobioms normal sind. Erst 
                        dann kann man jene, die ein Krankheitsrisiko bergen als solche erkennen. 
                        Mit den erhobenen Daten soll eine Referenzdatenbank aufgebaut, die f&uuml;r 
                        zuk&uuml;nftige Interpretationen von Mikrobiomen ben&ouml;tigt wird. 
                        Hierf&uuml;r braucht die CeMeT GmbH, die das T&uuml;biom Projekt in Zusammenarbeit 
                        mit der Universit&auml;tsklinik und der Universit&auml;t T&uuml;bingen durchf&uuml;hrt, 
                        Ihre Mithilfe: Jeder Teilnehmer sendet eine Stuhlprobe ein und beantwortet den 
                        zugeh&ouml;rigen Fragebogen. Es ist ganz einfach: Bitte regisitrieren Sie sich und 
                        fordern Sie ein Probenr&ouml;hrchen an. Sobald Sie die Auswertung erhalten haben, 
                        k&ouml;nnen Sie sogar online die eigenen Ergebnisse mit denen anderer Teilnehmer vergleichen.
                        Dabei werden selbstverst&auml;ndlich keine pers&ouml;nlichen Daten ver&ouml;ffentlicht! 
                        Ich finde, das ist eine gute Sache und bin dabei!
                        <br />
                        <br />
                        <hr>
                        <br />
                        Liebe Leserin, lieber Leser, ich hoffe, dass Sie wieder viel Interessantes und viel 
                        Neues auf meiner Website finden werden. Ich lade Sie ganz herzlich zum intensiven 
                        St&ouml;bern ein. Und wenn Sie bei der F&uuml;lle der Informationen den &Uuml;berblick 
                        verloren haben, was wo zu finden ist, klicken Sie doch einfach die <a href="http://www.dorispaas.de/index.php?page=sitemap-html" target="_blank">Sitemap</a> 
                        an. Dort sind alle Seiten ganz &uuml;bersichtlich aufgelistet &ndash; vielleicht finden 
                        Sie ja sogar die eine oder andere Seite, die Sie noch gar nicht kennen!
                        <br />
                        <br />
                        Bis zum n&auml;chsten Newsletter, den Sie in zwei Monaten, also 
                        etwa Mitte September 2016 erhalten, sende ich Ihnen ganz herzliche Gr&uuml;&#223;e aus dem Rheinland 
                        <br />
                        Ihre
                        <br />
                        <img src="<?php echo IMG_PATH; ?>nl-unterschrift-dopa.png" alt="" border="0" hspace="0" vspace="0" style="float: left; margin-left: 0px; margin-right: 10px; padding-bottom: 0px;" />
                        </p>
                        <br />
                        <br />
                        <br />
                        <i>P.S. Gerne k&ouml;nnen Sie diesen Newsletter auch an Freunde und Bekannte weiterleiten!</i>
                        <p>
                        <hr>
                        <hr>
                        <a href="http://www.dorispaas.de/index.php?page=termine" target="_blank"><img src="<?php echo IMG_PATH; ?>newsletter-zettel.png" alt="" border="0" hspace="0" vspace="0" style="float: left; margin-left: 0px; margin-right: 20px; padding-bottom: 0px;" /></a>
                        <br />
                        &#149;	Beachten Sie bitte auch die Hinweise zu den <a href="http://www.dorispaas.de/index.php?page=termine" target="_blank">Terminen</a> 
                        f&uuml;r die Veranstaltungen, zu denen ich Sie herzlich einlade.  
                        <br />
                        &#149;	S&auml;mtliche neuen Beitr&auml;ge finden Sie immer unter dem Button 
                        &#187;<a href="http://www.dorispaas.de/index.php?page=news" target="_blank">neueste Betr&auml;ge</a>&#171; 
                        in der Seiten-Navigation.
                        <br />
                        &#149;	Den besten &Uuml;berblick &uuml;ber die kompletten Inhalte auf www.DorisPaas.de 
                        finden Sie in der <a href="http://www.dorispaas.de/sitemap-html" target="_blank">Sitemap</a> 
                        in der Seiten-Navigation.
                        <br />
                        &#149;	www.dorispaas.de &ndash; garantiert <a href="http://www.dorispaas.de/guterrat" target="_blank">werbefreie 
                        und unabh&auml;ngige Informationen</a>. 
                        
                        <br />
                        <br />
                        <hr>
                        <br />
                        Sie k&ouml;nnen den Erhalt des Newsletters jederzeit abbestellen.
                        Bitte klicken Sie auf <a href="http://www.dorispaas.de/index.php?page=unsubscribe_newsletter&amp;ticket=%UNSUBSCRIBE_TICKET%" target="_blank">diesen Link</a>.
                        <br />
                        Ihre Mailadresse wird im Verteiler gel&ouml;scht, und Sie erhalten keine Mails mehr.
                        </p>
                    </div>
                </div>
            </div>    
            <br>
            <br> 
            <div class="bodyspacer"></div> 
        </div>