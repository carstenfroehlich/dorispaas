        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br /> 
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>
                <h1 class="header center orange-text">Probiotische Gärgetränke</h1>      
            </div>  
        </div> 
        <div class="container">    
            <div class="section">   
                <div class="row margintoprow">        
                    <div class="col s12 m12">
                        Die Stabilität Ihres Immunsystems hängt zu einem sehr großen Teil auch von der 
                        Qualität Ihrer Darmflora ab. Überwiegen hier die nützlichen Bakterienstämme, so 
                        schützen diese weitestgehend davor, dass krankmachende Keime überhand nehmen, in 
                        den Körper eindringen und sich vermehren können.
                        <br />
                        <br />
                        Wenn Sie neben den vielen anderen Maßnahmen zur Stärkung Ihres Immunsystems (siehe 
                        auch Beitrag &#187;<a href="ganz-immun">Stärkung des Immunssystems</a>&#171;) für 
                        eine gesunde und widerstandsfähige Darmflora sorgen, unterstützen Sie Ihre Gesundheit 
                        und Ihr Wohlbefinden. Nebenbei hilft eine ausbalancierte Darmflora, bei 
                        Nahrungsmittel-Intoleranzen oder einem Reizdarm-Syndrom kleine Sünden besser 
                        auszugleichen.
                        <br />
                        <br />
                        Es ist gar nicht erforderlich, die Darmflora mit probiotischen Präparaten 
                        &#187;aufzupeppen&#171;. Eine hervorragende Möglichkeit, die Darmflora zu 
                        unterstützen, sind probiotische Gärgetränke wie Kombucha, Kefir oder Brottrunk, 
                        denn diese Getränke enthalten neben probiotischen Keimen auch gesunde Säuren wie 
                        Milch-, Essig- und Glucuronsäure, die ein günstiges Säure-Milieu für die nützlichen 
                        Darmbakterien fördern und dabei gleichzeitig das Wachstum und die übermäßige 
                        Vermehrung der schädlichen Keimarten hemmen.
                        <br />
                        <br />
                        Auch wenn die Werbung uns hier anderes zu suggerieren versucht, sind die entsprechenden 
                        käuflichen Produkte leider oftmals industriell so behandelt, dass die wertvollen 
                        Inhaltsstoffe nicht mehr oder nicht mehr in ausreichender Menge vorhanden sind. 
                        Lebende Bakterien nämlich würden ein industrielles Produkt relativ rasch verderben 
                        lassen, so dass es sich weder für die Hersteller noch für die Händler lohnt, ein 
                        solch kurzlebiges Produkt anzubieten.
                        <br />
                        <br />
                        Sie können aber beispielsweise Kefir und Kombucha selbst herstellen, wenn Sie sich 
                        einen Kefirpilz bzw. einen Kombuchapilz (Teepilz) besorgen können. Fragen Sie in 
                        Ihrem Bekanntenkreis, wer einen solchen abzugeben hat, denn beide Pilzarten vermehren 
                        sich rasch. Sie können die Zutaten auch über das Internet bei vertrauenswürdigen 
                        Händlern bestellen. Zwei mir bekannte und empfehlenswerte Lieferadressen für 
                        Kombucha und Kefir-Knollen sind <a href="http://www.natural-kefir-drinks.de/" target="_blank">www.natural-kefir-drinks.de</a> 
                        und <a href="http://www.kombucha-shop.de/" target="_blank">www.kombucha-shop.de</a>.
                        <br />
                        <br />
                        Hier finden Sie die &#187;Rezepte&#171; für Kefir und für Kombucha:
                        <br />
                        <br />
                        <img src="<?php echo IMG_PATH; ?>pdf-logo.png" alt="" class="left" />
                        <a href="<?php echo FILES_PATH; ?>www.dorispaas.de-rezept-kefir.pdf" target="_blank">Rezept für selbstgemachten Kefir</a>
                        <br stlye="clear: left;" />
                        <br />
                        <br />
                        <br />
                        <img src="<?php echo IMG_PATH; ?>pdf-logo.png" alt="" class="left" />
                        <a href="<?php echo FILES_PATH; ?>www.dorispaas.de-rezept-kombucha.pdf" target="_blank">Rezept für selbstgemachten Kombucha</a>
                        <br />
                        <br />
                        <br />
                        <hr />
                        <h5>Hinweis für Menschen mit Histamin-Intoleranz:</h5>
                        <hr />
                        In den allermeisten Fällen haben Menschen mit Histamin-Intoleranz Probleme mit 
                        vergorenen Lebensmitteln. Da jedoch die gesundheitlichen Vorteile der probiotischen 
                        Gärgetränke nicht unbeträchtlich sind, kann man versuchen, sehr vorsichtig auszutesten, 
                        ob kleinere Mengen eventuell doch bekömmlich sind. 
                        <br />
                        <hr />
                        <h5>Hinweise für Menschen mit Laktose-Intoleranz:</h5>
                        <hr />
                        Kefir wir im Allgemeinen aus Milch zubereitet, die Milchzucker enthält. 
                        Menschen mit Laktose-Intoleranz sollten beachten, dass bei der Vergärung 
                        der Milch zu Kefir ein Teil des in der Milch enthaltenen Milchzuckers zu 
                        Traubenzucker und Schleimzucker aufgespalten wird. Bei einer nur leicht ausgeprägten 
                        Laktose-Intoleranz kann man austesten, wie viel Kefir vertragen wird. Man
                        kann den Kefir jedoch auch aus laktosefreier Milch herstellen. Dabei ist zu beachten, 
                        dass nur Frischmilch aus dem Kühlregal verwendet werden kann, denn die üblicherweise 
                        verkaufte H-Milch ist nicht geeignet.
                        <br />
                        <br />
                        <a href="guterrat" target="_blank"><img src="<?php echo IMG_PATH; ?>hilfreich.png" alt="" class="left" /></a>
                        <br />
                        <br />
                        <hr />
                        <a href="javascript: scrollMainToTop();" class="nachoben">nach oben</a>
                    </div>
                </div>
            </div>    
            <br>
            <br> 
            <div class="bodyspacer"></div> 
        </div>