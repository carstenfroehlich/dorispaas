        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br /> 
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>
                <h1 class="header center orange-text">Nahrungsmittelallergien und -unvertr&auml;glichkeiten</h1>      
                <div class="row center">        
                    <h5 class="header col s12 light">Genussvoll essen &ndash; unbeschwert leben</h5>      
                </div>
            </div>  
        </div> 
        <div class="container">    
            <div class="section">   
                <div class="row margintoprow">        
                    <div class="col s12 m12">
                        <hr />
                        <h5>Inhaltsverzeichnis</h5>
                        <hr />
                        <br />
                        
                        <img src="<?php echo IMG_PATH; ?>book2-content-1.png" alt="" class="left" />
                        <br />
                        <br />
                    </div>
                    <div class="col s12 m12">
                    <br />
                        <img src="<?php echo IMG_PATH; ?>book2-content-2.png" alt="" class="left" />
                    </div>
                </div>
            </div>    
            <br>
            <br> 
            <div class="bodyspacer"></div> 
        </div>