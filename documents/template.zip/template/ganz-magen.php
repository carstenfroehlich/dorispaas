        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br /> 
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>
                <h1 class="header center orange-text">Funktionsst&ouml;rungen des Magens</h1>      
            </div>  
        </div> 
        <div class="container">    
            <div class="section">   
                <div class="row margintoprow">        
                    <div class="col s12 m12">
                        Sie fragen Sie sich, was ein gesunder Magen mit einer gesunden Verdauung zu tun hat? 
                        Oder anders herum: Wie k&ouml;nnen St&ouml;rungen des Magens zu Verdauungsproblemen 
                        f&uuml;hren, die wir ja eigentlich immer im Darm angesiedelt sehen? 
                        <br />
                        <br />
                        Magenfunktionsst&ouml;rungen k&ouml;nnen sogar sehr h&auml;ufig zu Verdauungsproblemen 
                        f&uuml;hren, denn wenn die Nahrung, die in den Darm gelangt, nicht richtig vom Magen
                        vorbereitet wurde, kann sie auch im Darm nicht mehr richtig oder zumindest nicht 
                        ohne Probleme verdaut werden &ndash; Verdauungsbeschwerden sind eine nat&uuml;rliche 
                        Folge, die wahren Zusammenh&auml;nge werden aber h&auml;ufig &uuml;bersehen.
                        <br />
                        <br />
                        Aber eigentlich k&ouml;nnen Verdauungsprobleme noch viel fr&uuml;her anfangen 
                        &ndash; n&auml;mlich im Mund. Wenn Nahrung nicht gen&uuml;gend gekaut und eingespeichelt 
                        wird, kann auch ein normalerweise gut funktionierender Magen diese nur unter 
                        erschwerten Bedingungen verarbeiten.
                        <br />
                        <br />
                        Der Magen hat verschiedene, wichtige Aufgaben: zum einen muss er die Nahrung 
                        m&ouml;glichst keimfrei machen, um zu verhindern, dass sch&auml;dliche Mikroorganismen 
                        weiter in den K&ouml;rper eindringen k&ouml;nnen. Dazu sch&uuml;ttet 
                        er Magensaft aus, der durch den hohen Gehalt an Salzs&auml;ure (PH-Wert 1,5 &ndash; 2) 
                        einen Gro&#223;teil der verschluckten Keime abt&ouml;tet. Um die Magenw&auml;nde 
                        vor diesem &auml;tzenden Magensaft zu sch&uuml;tzen, sind sie mit einer Schleimschicht 
                        &uuml;berzogen, damit sich der Magen nicht selbst verdaut. Sobald der Nahrungsbrei 
                        schl&uuml;ckchenweise nach einer der Zusammensetzung der Nahrung angepassten 
                        Verweildauer durch den Magenpf&ouml;rtner in den Zw&ouml;lffingerdarm abgegeben 
                        wird, wird die S&auml;urekonzentration durch an dieser Stelle hinzugegebene 
                        Verdauungss&auml;fte neutralisiert, wodurch die Darmw&auml;nde vor Sch&auml;den 
                        gesch&uuml;tzt werden.
                        <br />
                        <br />
                        Ist zu wenig Magenschleim vorhanden, werden die Schleimh&auml;ute von der 
                        Magens&auml;ure angegriffen, was zu Magenschleimhautentz&uuml;ndungen oder sogar 
                        zu Magengeschw&uuml;ren f&uuml;hren kann. Das Mittel der Wahl sind hier nicht 
                        immer die fast schon gie&#223;kannenm&auml;&#223;ig verabreichten S&auml;ureblocker, 
                        sondern eher schleimf&ouml;rdernde Ma&#223;nahmen wie das Trinken von Schleimbildnern 
                        (spezielle Leinsamenzubereitungen) &ndash; am besten als 
                        <a href="lexikon-naturheilmethoden#rollkur">Rollkur</a> angewandt.
                        <br />
                        <br />
                        Der Magensaft enth&auml;lt verschiedene Enzyme, die bestimmte Nahrungsbestandteile 
                        vorverdauen und aufspalten k&ouml;nnen. Am bekanntesten ist das Pepsin, das 
                        Eiwei&#223;e aus der Nahrung aufspaltet hilft. Und weiterhin ist im Magensaft 
                        der so genannte Intrinsic-Faktor enthalten, der erforderlich ist, das mit der 
                        Nahrung aufgenommene Vitamin B12 sp&auml;ter im Darm verwerten zu k&ouml;nnen.
                        <br />
                        <br />
                        Der Magen ist ein starker Muskel, der die verschluckte Nahrung kr&auml;ftig 
                        durchknetet und mit den Magens&auml;ften durchmischt. Wird die Nahrung vor dem 
                        Herunterschlucken nicht gen&uuml;gend gekaut, sind die Brocken zu gro&#223;, 
                        und die Durchmischung ist wesentlich schlechter, die Vorverdauung damit um ein 
                        Vielfaches uneffektiver. Au&#223;erdem wird die Nahrung beim Kauen gr&uuml;ndlich 
                        mit Speichel vermengt, der ebenfalls wichtige Enzyme zur Aufspaltung der N&auml;hrstoffe 
                        enth&auml;lt, was dem Magen die Arbeit erleichtert.
                        <br />
                        <br />
                        Oftmals wird gesagt, dass man es vermeiden sollte, zum Essen zu trinken, um die 
                        Magens&auml;fte nicht unn&ouml;tig zu verd&uuml;nnen. Dieser Rat gilt jedoch nur 
                        f&uuml;r Menschen, deren Magensaftproduktion ohnehin schwach ist. Normalerweise 
                        ist es g&uuml;nstig, nicht nur generell viel zu trinken, sondern auch ein Glas 
                        Wasser zum Essen zu trinken, um den Nahrungsbrei geschmeidig zu machen. Eine schwache 
                        Magensaftproduktion kann man durch das Verzehren von Bitterstoffen (z.B. Wermut-Tee 
                        oder Artischocken-Presssaft) anregen.
                        <br />
                        <br />
                        F&uuml;r einen gesunden Magen (und damit f&uuml;r eine gesunde Verdauung) ist es 
                        also wichtig, langsam zu essen und die Nahrung gr&uuml;ndlich zu kauen. Dadurch 
                        wird der Magen entlastet und kann seine Aufgabe optimal ausf&uuml;hren.
                        
                        Man sollte sich deshalb zum Essen Zeit und Ruhe g&ouml;nnen und nicht &#187;zwischen 
                        T&uuml;r und Angel&#171; essen. Dies f&uuml;hrt meistens zu zu hastigem Essen mit der 
                        Folge von vermehrtem Verschlucken von Luft, die dann zum Teil durch unangenehmes 
                        Aufsto&#223;en wieder entweicht. Ein anderer Teil gelangt in den Darm und bedingt 
                        hier unangenehme bis sogar schmerzhafte Bl&auml;hungen.
                        <br />
                        <br />
                        Und wir alle wissen ja auch: Das Auge isst mit. Somit sollten wir beim 
                        gen&uuml;sslichen Essen auch schauen, was wir essen &ndash; beim Essen auf der 
                        Hand oder gar beim Autofahren ist dies schlecht m&ouml;glich.
                        <br />
                        <br />
                        Da die Magenperistaltik (die Bewegungen des Magens) und die Sekretion der 
                        Magens&auml;fte durch Nerven gesteuert werden, 
                        sollten wir schon durch den optischen Reiz, aber auch durch ausgiebiges Riechen 
                        und Hinschmecken unsere Verdauung ankurbeln. Schon beim Anblick oder Geruch von 
                        Speisen kann uns das sprich&ouml;rtliche &#187;Wasser im Munde zusammenlaufen&#171; 
                        &ndash; und nicht nur im Munde, sondern auch im Magen werden dadurch bereits die 
                        erforderlichen Sekrete vorbereitet, damit die Nahrung beststens verdaut werden kann.
                        <br />
                        <br />
                        Weiterhin ist es f&uuml;r eine reibungslose Verdauung erforderlich, die Nahrungsmengen 
                        zu beachten. Der Magen ist zwar ein sehr dehnungsf&auml;higes Hohlorgan, jedoch 
                        sind auch hier die Kapazit&auml;ten begrenzt. Hat man zu viel gegessen, ist der 
                        Magen im wahrsten Sinne des Wortes &uuml;berlastet &ndash; mit Folgen, die sicherlich 
                        jeder von uns schon einmal versp&uuml;rt hat: V&ouml;llegef&uuml;hl (das Wort 
                        &#187;V&ouml;lle&#171; leitet sich von &#187;voll&#171; her) oder sogar &Uuml;belkeit.
                        <br />
                        <br />
                        Auch Sodbrennen kann als Folge von zu &uuml;ppigen Mahrzeiten auftreten: Dabei flie&#223;t 
                        oder dr&uuml;ckt Magensaft aus dem Magen in die Speiser&ouml;hre zur&uuml;ck. 
                        Die Ursache kann hier ein &#187;einfaches
                        Zuviel&#171; sein, manchmal jedoch auch eine Schw&auml;che des oberen 
                        Speiser&ouml;hrenschlie&#223;muskels (&Ouml;sophagus-Sphinkter) sein (des Muskels, 
                        der normalerweise eben dieses Zur&uuml;ckflie&#223;en verhindert und uns bef&auml;higt, 
                        auch im Kopfstand schlucken zu k&ouml;nnen). Meistens jedoch ist es ein Zuviel und 
                        oftmals auch ein zu sp&auml;tes Essen, denn wenn der Magen noch voll ist, wenn 
                        wir zu Bett gehen und uns hinlegen, wird die Kraft des Speiser&ouml;hrenschlie&#223;muskels 
                        schlichtweg &uuml;berfordert.
                        <br />
                        <br />
                        Der sogenannte &#187;Reizmagen&#171; ist meist eine Folge der Missachtung aller 
                        oder einzelner der beschriebenen Faktoren, die zu einer optimalen Funktion des 
                        Magens erforderlich sind. Insbesondere aber sind es h&auml;ufig auch zu schnelles 
                        und zu hastiges Essen unter stressigen Bedingungen, weshalb ein &Uuml;berdenken 
                        gerade dieser Faktoren besonders wichtig ist, um einen Reizmagen mit all seinen 
                        unangenehmen Folgen zu heilen.
                        <br />
                        <br />
                        Alle Verdauungsproszesse &ndash; angefangen im Mund bis hin zum Dickdarm &ndash; 
                        sind optimal aufeinander abgestimmt. Ist in dieser Kette irgendein &#187;Haken&#171; 
                        oder gehen wir zu sorglos mit unseren K&ouml;rperfunktionen um, treten 
                        Verdauungsprobleme auf, die teils an v&ouml;llig anderen Stellen wahrgenommen 
                        werden und damit oftmals nicht mit dem eigentlichen Ursprung in Verbindung gebracht 
                        werden.
                        <br />
                        <br />
                        <a href="<?php echo URL_ROOT; ?>guterrat" target="_blank"><img src="<?php echo IMG_PATH; ?>hilfreich.png" alt="" class="left" /></a>
                        <br />
                        <br />
                        <br />
                        <hr />
                        <a href="javascript: scrollMainToTop();" class="nachoben">nach oben</a>
                    </div>
                </div>
            </div>    
            <br>
            <br> 
            <div class="bodyspacer"></div> 
        </div>