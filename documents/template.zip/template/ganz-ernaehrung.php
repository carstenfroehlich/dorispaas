        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br /> 
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>
                <h1 class="header center orange-text">Was ist &#187;gesunde Ernährung&#171;?</h1> 
                    <div class="row center">        
                    <h5 class="header col s12 light">Fleisch oder kein Fleisch</h5>      
                    </div>     
            </div>  
        </div> 
        <div class="container">    
            <div class="section">   
                <div class="row margintoprow">        
                    <div class="col s12 m4">
                        <ul class="nav">
                            <li>
                                <b>Abschnitte dieser Seite:</b>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-ernaehrung#verdauungssystem">Wie sieht unser Verdauungssystem aus?</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-ernaehrung#ursprung">Was aßen unsere Vorfahren?</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-ernaehrung#jetzt">Was essen wir heute?</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-ernaehrung#vorzug">Welche Kostform ist zu bevorzugen?</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-ernaehrung#anderegruende">Zusätzliche Entscheidungskriterien</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-ernaehrung#schluss">Schlussbemerkung</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-ernaehrung#beratung">Beratung</a>
                            </li> 
                        </ul>
                    </div>
                    <div class="col s12 m8">
                        <a href="paas-heftchen-ge" target="_blank"><img src="<?php echo IMG_PATH; ?>buchzumthema-ge.png" alt="" class="right" /></a>
                        </div>
                </div>
                <div class="row margintoprow">        
                    <div class="col s12 m12">
                        Es gibt zahlreiche verschiedene Ernährungsformen, und jeder Mensch, der sich gemäß 
                        einer dieser Variationen ernährt, hat seine Gründe dafür. Gleich vorweg: Ich möchte 
                        hier keineswegs dogmatisch für die eine oder gegen eine andere Ernährungsform Partei 
                        ergreifen! Die Rheinische Lebensweisheit &#187;Jeder Jeck ist anders&#171; gilt 
                        selbstverständlich auch für die Art, sich zu ernähren. Ob jedoch alles und  
                        vor allem alles für jeden gesund ist, bleibt dahingestellt.
                        <br />
                        <br />
                        An dieser Stelle möchte ich einmal versuchen, das Für und Wider der verschiedenen 
                        Ernährungsformen zu beleuchten.
                        <br />
                        <a id="verdauungssystem"></a>
                        <hr />
                        <h5>Wie sieht unser Verdauungssystem aus?</h5>
                        <hr />
                        Je nach Wohnort auf der Erde ernähren sich die Menschen völlig unterschiedlich: 
                        Das reicht vom fast ausschließlichen Verzehr von Fleisch und Fisch bei den Inuit bis 
                        hin zu der so gut wie <b>vegetarischen</b> Kost in Indien. Und dazwischen gibt es 
                        alle Spielarten. Eine völlig <b>vegane Ernährung</b>, d.h. der Verzicht auf jegliche 
                        tierische Produkte oder Produkte, zu deren Herstellung tierische Bestandteile 
                        verwendet werden, ist in keiner Region zu finden. Der Veganismus hat andere als 
                        landestypische und gesundheitsbezogene Gründe und wird später beleuchtet.
                        <br />
                        <br />
                        Um einen Eindruck davon zu bekommen, was <b>für gesunde Menschen</b> gesund sein könnte, 
                        müssen wir uns unseren Körper genauer anschauen und uns überlegen, was unsere 
                        Vorfahren gegessen hatten.
                        <br />
                        <br />
                        Unser <a href="<?= BASE_LINK ?>?page=ganz-verdauungssystem" target="_blank">Verdauungssystem</a>, 
                        beginnend bei den Zähnen und endend beim After ist weder auf gänzlich fleischlose 
                        Kost noch auf den ausschließlichen Verzehr tierischer Kost eingerichtet 
                        &ndash; jedoch ist unser Organismus flexibel und kann sich in Grenzen an bestimmte 
                        Gegebenheiten anpassen.
                        <br />
                        <br />
                        Schauen wir zuerst unser Gebiss an &ndash; oder besser: schauen wir uns die Gebisse 
                        von Fleisch- und von Pflanzenfressern an. Fleischfresser <b>(Karnivoren)</b>, 
                        beispielsweise Löwen oder  Hunde, haben im vorderen Bereich spitze Reißzähne 
                        und im hinteren Bereich ebenfalls spitze Zähne, die es ermöglichen, ein Beutetier 
                        festzuhalten, Fleischstücke herauszureißen und diese weitestgehend unzerkaut 
                        hinunterzuschlingen. Die Pflanzenfresser <b>(Herbivoren)</b>, beispielsweise Pferde 
                        oder Hasen, haben vorne relativ scharfe Zähne, um Gras und Pflanzen ausrupfen zu 
                        können und im hinteren Bereich Mahlzähne mit breiten Kauflächen, um das Futter 
                        mit seinen harten Zellwänden zermahlen und so besser verdauen zu können.
                        <br />
                        <br />
                        Auch der Darm unterscheidet sich beim Fleisch- und beim Pflanzenfresser: Fleisch 
                        ist zum einen schnell verdaulich, enthält aber zum anderen auch relativ viele 
                        schädliche Stoffe bzw. kann diese beim Verdauungsprozess entwickeln. Dies erfordert 
                        einen im Vergleich zur Körpergröße kurzen Darm, den Fleischfresser aufzuweisen haben. 
                        Die Nahrung wird rasch verdaut, die Reste können und müssen den Körper so schnell wie möglich wieder verlassen. 
                        Pflanzenfresser hingegen benötigen einen relativ langen Darm, um die festen 
                        Pflanzenzellen aufzuschließen und den Inhalt optimal auszunutzen. Somit haben 
                        Pflanzenfresser bezogen auf ihre Körpergröße immer einen im Vergleich zum Fleischfresser 
                        sehr langen Darm.
                        <br />
                        <br />
                        Dies waren &ndash; zur Verdeutlichung &ndash; die beiden Extreme. Natürlich gibt 
                        es Mischformen, und unser eigenes Verdauungssystem zeigt sowohl beim Gebiss als
                        auch in Bezug auf die Darmlänge eine solche Mischform. Dies klassifiziert uns somit 
                        als Alles(fr)esser <b>(Omnivoren)</b> oder auch als Früchteesser <b>(Frutarier)</b>.
                        <br />
                        <a id="ursprung">&nbsp;</a><br />
                        <hr />
                        <h5>Was aßen unsere Vorfahren?</h5>
                        <hr />
                        Beschäftigen wir uns nun damit, welche Kost unsere Vorfahren verzehrt haben. In 
                        der Zeit, als sie Jäger und Sammler waren &ndash; also die wirklich ursprüngliche 
                        Form des Menschseins &ndash; verzehrten die Menschen vorwiegend pflanzliche Kost, 
                        vorrangig Früchte. Weiterhin wurden Wurzeln ausgegraben, und am Wegesrand streifte 
                        man auf der Wanderschaft einzelne Körner und Samen von den Halmen. Zur Bereicherung 
                        des Speisezettels dienten Würmer und Insekten, aber auch das eine oder andere gefundene 
                        Vogelei, um die Kost mit tierischen Proteinen anzureichern. Alles wurde natürlich 
                        mangels Feuer roh gegessen.
                        <br />
                        <br />
                        Später dann, als der Mensch das Feuer entdeckte und Waffen erfand, wurden mit 
                        Schleudern zuerst kleinere Tiere wie Hasen gefangen und irgendwann war es ihnen 
                        auch möglich, größere Tiere wie z.B. Mammuts zu erlegen. Die Jagd war aufwändig 
                        und mit großen körperlichen Anstrengungen verbunden. Das Fleisch wurde dann sofort 
                        und dann auch in großen Mengen verzehrt, denn eine Vorratshaltung war damals 
                        nicht möglich, und die wertvolle Energiequelle durfte man nicht verderben lassen. 
                        Danach jedoch war solange wieder pflanzliche Kost angesagt, bis man unter erneuten 
                        Strapazen weitere Beute machen konnte.
                        <br />
                        <br />
                        Menge und Art der Nahrung waren also sowohl den körperlichen Gegebenheiten als 
                        auch der Lebensweise angepasst.
                        <br />
                        <br />
                        Im weiteren Verlauf der Entwicklung wurde der Mensch sesshaft und gewann seine 
                        Lebensmittel als Ackerbauer. Die Feldfrüchte wurden im Laufe vieler Jahrhunderte 
                        durch Zucht immer ertragreicher &ndash; trugen ursprünglich Getreidesorten wie 
                        das Einkorn eben nur ein oder sehr wenige Samenkörner, so wurden mit der Zeit 
                        und &#187;Zucht&#171; die Ähren länger und trugen sehr viel mehr Körner an jedem 
                        Halm. 
                        <br />
                        <br />
                        Hinzu kam später dann die Viehhaltung, um leichter an tierische Zusatzkost zu gelangen. 
                        Aber das Vieh war wertvoll, es wurde nicht einfach so geschlachtet, sondern diente 
                        nur zur gelegentlichen und physiologisch erforderlichen Bereicherung des Speisezettels. 
                        Und auf dem mehrere Jahrtausende umfassenden Zeitstrahl  fast schon in der Gegenwart 
                        kam dann die Milchviehhaltung hinzu, um eben die wertvollen Nutztiere nicht gleich 
                        schlachten zu müssen, wenn man tierisches Eiweiß verzehren wollte. 
                        <br />
                        <br />
                        So weit, so gut, denn immer noch verzehrte der Mensch überwiegend pflanzliche Kost. 
                        Nur der Inuit, der keinen Zugang zu pflanzlichen Produkten hatte, musste sich auf 
                        die so gut wie reine tierische Kost einstellen, was sich aber mit seiner Lebensweise 
                        vertrug. Denn in dem kalten Umfeld, in dem er sich aufhielt, war tierisches Fett 
                        als gehaltvoller Energielieferant lebensnotwenig, und die Fische, die er fing, 
                        lieferten ihm die entsprechenden Vitalstoffe. Die für eine gesunde Verdauung 
                        benötigten Ballaststoffe verschaffte sich der Inuit, indem er den Mageninhalt 
                        seiner Tiere mit verspeiste.
                        <br />
                        <br />
                        In allen anderen Regionen der Welt bestand die übliche Kost aus vollwertiger 
                        pflanzlicher Kost &ndash; in der Menge den jeweiligen Lebensumständen instinktiv 
                        angepasst. 
                        <br />
                        <br />
                        Im Laufe der menschlichen Entwicklung wurde jedes potenzielle Nahrungsmittel nach 
                        dem System von &#187;Versuch und Irrtum&#171; auf seine Wertigkeit und vor allem 
                        auf seine Bekömmlichkeit ausgetestet 
                        &ndash; wobei &#187;Irrtümer&#171; sehr verhängnisvoll sein und sogar mit 
                        dem Leben bezahlt werden konnten. Folglich wurde Unbekömmliches gemieden, denn 
                        die Menschen waren damals noch vernünftig. Isolierten Zucker oder Weißmehl gab 
                        es natürlich genauso wenig wie süße Getränke oder Fruchtsäfte, und natürlich 
                        keinerlei künstliche Zusatzstoffe oder sonstige Chemikalien oder gar Giftstoffe, 
                        auf deren Verdauung und Verarbeitung kein menschliches Verdauungssystem eingestellt 
                        ist. Gegessen wurde nicht nur, was das &#187;normale&#171; Verdauungssystem ohne 
                        Schaden für den Gesamtorganismus verdauen konnte sondern auch, was den Körper 
                        gesund und leistungsfähig erhielt. Die Nahrung diente also nicht nur zum Energiegewinn, 
                        sondern auch der Gesunderhaltung des Menschen.
                        <br />
                        <br />
                        War der Mensch trotz aler Sorgfalt bei der Nahrungsauswahl krank, wurden Kräuter, 
                        Ruhe und liebevoller Zuspruch verwendet, bis der Kranke wieder genesen war. Die 
                        Folgekost war dann wieder die übliche, gesunderhaltende Nahrung.
                        <br />
                        <a id="jetzt">&nbsp;</a><br />
                        <hr />
                        <h5>Was essen wir heute? </h5>
                        <hr />
                        Unsere heutige &#187;zivilisierte&#171; Kost entspricht jedoch weder in der Auswahl 
                        der Lebensmittel noch in deren Qualität oder Menge mehr dieser ursprünglichen und 
                        an unser Verdauungssystem angepassten Ernährungsform. Denn auch wenn ich hier in 
                        dieser Beschreibung einen Zeitraum von vielen Tausend Jahren umrissen habe, so hat 
                        sich das Verdauungssystem des Menschen doch keineswegs weiter entwickelt und sieht 
                        immer noch genauso aus, wie in der Zeit der Sammler und Jäger.
                        <br />
                        <br />
                        Abgesehen von dem unstrittigen Verzicht auf Schadstoffe und hochbearbeitete Zutaten 
                        ist es deshalb für gesunde Menschen nach wie vor am besten, sich überwiegend 
                        pflanzlich zu ernähren und den Speisezettel mit wenig tierischen Produkten 
                        anzureichern. Vor allem aber sollten wir die Menge und die Qualität an unsere 
                        meist bewegungsarme Lebensweise anpassen.
                        <br />
                        <br />
                        Was aber tun wir (oder tun zumindest sehr viele Menschen)? Ohne nachzudenken verzehren 
                        wir in großer Menge Produkte, die uns von verantwortungslosen und gewinngierigen 
                        Herstellern für viel Geld zum Verzehr angedreht werden! Diese Produkte sind in ihren 
                        Inhaltsstoffen und in ihrer Struktur so verändert, dass man sie mit gutem Gewissen 
                        keineswegs mehr als &#187;<b>Lebens</b>mittel&#171; bezeichnen kann. Deshalb ist 
                        es erforderlich, sich selbst zu schützen und gut zu überlegen, welche Nahrungsmittel 
                        für uns geeignet sind, welche tatsächlich Lebensmittel sind, unserer Gesundheit 
                        und damit unserem Leben dienen.
                        <br />
                        <a id="vorzug">&nbsp;</a>
                        <hr />
                        h5>Welche Kostform ist zu bevorzugen? </h5>
                        <hr />
                        Leider (oder dankenswerter Weise) zeigt uns unser Körper nicht sofort, ob uns 
                        etwas bekommt oder nicht, was wir gerade verzehrt haben, denn gesundheitliche 
                        Folgen treten bei insgesamt schlechter Kost meistens erst mit einem Zeitversatz 
                        von mehreren Jahrzehnten auf. Hier einen direkten Zusammenhang herzustellen, ist 
                        schwer, und jeder nutzt diese Tatsache in seinem Sinne: Die &#187;Gesundheitsapostel&#171; 
                        warnen, und die Lobbyisten streiten ab. Deshalb sollte hier aus meiner Sicht gelten: 
                        &#187;lieber Vorsicht als Nachsicht&#171;. 
                        <br />
                        <br />
                        Eine Kost, die überwiegend aus tierischen Produkten wie Fleisch, Wurst, Fisch, 
                        Eiern und Milch und Milchprodukten besteht, ist für unser Verdauungssystem und 
                        für unseren Organismus nicht förderlich &ndash; es sei denn, Sie wohnen in Grönland 
                        und ernähren und vor allem bewegen sich wie ein Inuit. 
                        <br />
                        <br />
                        Auch das andere Extrem, die vegane Kost, ist nur möglich, wenn die Auswahl der 
                        Lebensmittel sehr gut überlegt wird, denn nur bei kluger Zusammenstellung der 
                        verschiedenen Pflanzen kann deren Eiweiß für den menschlichen Organismus vollwertig 
                        genutzt werden. Weiterhin müssen bestimmte Nährstoffe, wie das Vitamin B12, 
                        substituiert werden, denn pflanzliche Lebensmittel enthalten dieses Vitamin nicht. 
                        Es wird zwar &ndash; so die Argumentation der Veganer &ndash; von den Bakterien 
                        im Darm synthetisiert, jedoch an einer Stelle im Dickdarm, aus dem keine Nährstoffe 
                        mehr vom Körper wieder aufgenommen werden. Ich persönlich halte eine Kostform, 
                        bei der nur ein zusätzlicher Verzehr von künstlichen Vitaminen den Körper gesund 
                        erhält, insgesamt für nicht adäquat.
                        <br />
                        <br />
                        Vegetarismus &ndash; und hier ist im Gegensatz zum Veganismus eine Ernährung aus 
                        pflanzlichen Produkten plus Milch und Milchprodukten (laktovegetarisch) oder plus 
                        Eier (ovovegetarisch) oder beiden und oftmals auch plus Fisch (pescarisch) &ndash; 
                        kann für gesunde Menschen eine gesunde Kostform sein. Vor allem aber ist Vegetarismus 
                        <b>eine</b> Möglichkeit, der Massen- und der nicht artgerechten Tierhaltung ebenso wie 
                        der daraus resultierenden Umweltbelastung und ungerechten Ressourcenverteilung 
                        den Kampf anzusagen.
                        <br />
                        <br />
                        Am ehesten an unser Verdauungssystem angepasst und damit in meinen Augen  
                        die gesündeste Ernährungsform stellt für gesunde Menschen, die möglichst lange 
                        gesund bleiben wollen, folgende Kost dar, die den neu kreierten Namen &#187; 
                        <b>Flexitarismus</b>&#171; trägt (als altmodischer Mensch könnte man genauso gut 
                        &#187;<b>gesunde, abwechslungsreiche, sehr fleischarme Kost</b>&#171; sagen).
                        Hier ist die Nahrung weitestgehend vegetarisch mit Milch, Eiern und/oder Fisch. 
                        Fleisch wird im Allgemeinen nicht gegessen, lediglich ab und an in sehr geringen 
                        Mengen wird der Speisezettel mit <b>hochwertigem</b> Fleisch aus vernünftiger Tierhaltung 
                        bereichert &ndash; eine Form also, wie sie unsere Großelterngeneration noch praktizierte, 
                        bei der es Fleisch bei reichen Leuten nur als &#187;Sonntagsbraten&#171; gab 
                        &ndash; bei ärmeren Menschen sogar noch seltener.
                        <br />
                        <br />
                        Bei einer weltweiten flexitarischen Ernährung in angemessenen Mengen würden die 
                        Menschen gesund (oder zumindet gesünder) bleiben, ernährungsbedingte Erkrankungen 
                        würden weitestgehend zurück gehen, würde die Umwelt (zumindest in Beziehung
                        auf die Erzeugung von Nahrung) geschont, und alle könnten satt werden.
                        <br />
                        <a id="anderegruende">&nbsp;</a>
                        <hr />
                        <h5>Zusätzliche Entscheidungskriterien</h5>
                        <hr />
                        Natürlich gibt es Ernährungsformen, die man weniger unter gesundheitlichen Gesichtspunkten 
                        als aus Überzeugung einhält. Die meisten Vegetarier bzw. Veganer ernähren sich  
                        ohne Fleisch bzw. frei von jeglichen 
                        tierischen Produkten &ndash; auch wenn deren Herstellung nicht den Tod des Tieres, 
                        nach der Auslegung der Veganer jedoch eventuell deren Ausbeutung bedeutet. 
                        Dies ist selbstverständlich zu respektieren. Ob es jedoch auch gesundheitlich das 
                        Optimum darstellt, steht dann nicht zur Debatte. Ein Veganer würde sich diese Frage 
                        auch nicht stellen, denn er stellt sich als Mensch nicht über sondern auf die gleiche 
                        Stufe wie das Tier. 
                        <br />
                        <br />
                        Sich als Mensch <b>nicht</b> als die &#187;Krone der Schöpfung&#171; zu betrachten,
                        ist auch in meinen Augen richtig. Aber jedes Lebewesen &ndash; gleich ob Mensch 
                        oder Tier &ndash; sollte sich so ernähren dürfen, wie es die Natur vorgesehen hat 
                        und wie es für dieses Lebewesen am gesündesten ist. Dabei sollten jedoch Respekt 
                        und Achtung vor anderen Lebenwesen nicht außer Acht gelassen werden.
                        <br />
                        <a id="schluss">&nbsp;</a>
                        <hr />
                        <h5>Und noch ein paar (für mich) wichtige Bemerkungen zum Schluss</h5>
                        <hr />
                        Dieses ist meine ganz persönliche Meinung zu gesunder Ernährung und meine dahin 
                        gehende Entscheidung &ndash; basierend auf einer langjährigen Beschäftigung mit 
                        den wissenschaftlichen Erkenntnissen und der Beobachtung meines eigenen Körpers 
                        und meiner Gesundheit. Trotz dieser Erkentnisse und trotz der Entscheidung für 
                        &#187;meine&#171; flexitarische Ernährungsform möchte ich niemanden für eine von meiner eigenen 
                        Entscheidung abweichende Ernährungsform be- oder sogar verurteilen. Aber genauso 
                        wenig möchte ich von Menschen, die sich für davon abweichende Kostformen entschieden 
                        haben, angegriffen werden, denn jede Art von Fanatismus lehne ich ab.
                        <br />
                        <br />
                        Letztendlich muss jeder selbst entscheiden, ob und wie viel und in welcher 
                        Weise produziertes Fleisch er isst. Nur ob die gewählte Ernährungsform gesund 
                        ist oder ob man bei einer fleischlastigeren Ernährung nicht irgendwann zum eigenen 
                        Schaden erkrankt und der Allgemeinheit zur Last fällt, ob man mit übermäßigem 
                        Fleischverzehr der Massentierhaltung Vorschub leistet, ob man der 
                        Umwelt Schaden zufügt und Mitmenschen in anderen Regionen der Weltkugel in den 
                        Hunger treibt, muss dann jeder für sich verantworten. 
                        <br />
                        <br />
                        Und es muss auch jeder entscheiden dürfen, Fleisch zu essen, ohne von anderen 
                        dafür angegriffen zu werden. Gerade Veganer, die sich ja aus tiefstem Herzen und 
                        fester Überzeugung dafür entschieden haben, auf jegliche tierischen Produkte zu 
                        verzichten, neigen leider aus meiner Erfahrung gerne dazu, andere belehren zu wollen 
                        und gebetsmühlenartig auf diversen Plattformen und in zahlreichen Foren zu 
                        missionieren, dass Fleisch- und auch Milchverzehr 
                        ungesund sei. Dies ist so gesagt falsch. Nicht der Fleisch- oder Milchverzehr an 
                        sich ist ungesund &ndash; es ist immer die Menge, die das Gift macht! 
                        <br />
                        <br />
                        Somit bitte 
                        ich jeden, der diesen Beitrag liest &ndash; egal ob Fleisch- oder Pflanzenesser, 
                        Andersdenkende zu tolerieren. Für sich selbst darf jeder 
                        entscheiden, was er isst. Denn auch das gehört zum gesunden Menschsein: die eigene 
                        Entscheidung zu vertreten und trotzdem andere Meinungen zu respektieren.
                        <br />
                        <br />
                        Lesen Sie hierzu auch das Buch &#187; <a href="paas-heftchen-ge">Kurz und klar: Gesunde Ernährung</a>&#171;
                        aus der Paas&#039;schen Heftchenreihe
                        <br />
                        <hr>
                        <a id="beratung">&nbsp;</a>
                        <div class="row">
                        <div class="col s12 m2">
                            <a href="http://www.ganzheitliche-gesundheitsberatung.de" target="_blank">
                                <img src="<?php echo IMG_PATH; ?>praxiswebsite.png" alt="" class="inline" /></a>
                        </div>
                        </div>
                        <div class="row">
                        <div class="col s12 m12">
                        <h5>Beratung</h5>
                        <br />
                            Gerne biete ich Ihnen eine individuelle Beratung an &ndash; 
                            auf Wunsch auch telefonisch oder per Skype.
                            <br />
                            Bitte informieren Sie sich auf meiner Praxis-Website <a href="http://www.ganzheitliche-gesundheitsberatung.de" target="_blank">&#187;www.Ganzheitliche-Gesundheitsberatung.de&#171;</a>
                        </div>
                        </div>
                        <hr>
                        <a href="javascript: scrollMainToTop();" class="nachoben">nach oben</a>
                    </div>
                </div>
            </div>    
            <br>
            <br> 
            <div class="bodyspacer"></div> 
        </div>