        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br /> 
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>
                <h1 class="header center orange-text">Vitalpilze</h1>      
            </div>  
        </div> 
        <div class="container">    
            <div class="section">   
                <div class="row margintoprow">        
                    <div class="col s12 m4">
                        <ul class="nav">
                            <li>
                                <b>Abschnitte dieser Seite:</b>
                            </li>
                            <li>
                                <a href="<?= URL_ROOT ?>vitalpilze#arten">Welche Vitalpilze gibt es? </a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>vitalpilze#anwendungsgebiete">Anwendungsgebiete von Vitalpilzen</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>vitalpilze#wirkung">Adaptogene Wirkung</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>vitalpilze#darreichungsformen">Darreichungsformen</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>vitalpilze#dosierung">Dosierung</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>vitalpilze#anwendungsdauer">Anwendungsdauer</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>vitalpilze#nebenwirkungen">Nebenwirkungen</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>vitalpilze#wechselwirkungen">Wechselwirkungen mit anderen Medikamenten</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>vitalpilze#qualitaet">Qualität</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>vitalpilze#fazit">Fazit</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>vitalpilze#beratung">Beratung</a>
                            </li> 
                        </ul>
                    </div>
                </div>
                <div class="row margintoprow">        
                    <div class="col s12 m12">
                        <img src="<?php echo IMG_PATH; ?>vitalpilze.png" alt="" class="right" />
                        <br />
                        <br />
                        Vitalpilze werden seit langer Zeit in der östlichen Medizin verwendet, aber auch 
                        die westliche Klostermedizin nutzte die Heilkräfte der Pilze. Nur sehr zaghaft 
                        hat sich bei uns bis heute die Erkenntnis durchgesetzt, was diese kleinen Wunderwerke 
                        der Natur leisten können. Dabei ist gerade bei Verdauungsproblemen der Einsatz 
                        von Vitalpilzen besonders hilfreich.
                        <br />
                        <br />
                        Pilze sind eine eigene Form im Pflanzenreich und den meisten entweder als schmackhafte 
                        Zutat zu einer Mahlzeit oder aber als giftige Gefahr bekannt. Auch die halozinogene, 
                        berauschende Wirkung oder auch die Möglichkeit, mit Giftpilz-Gerichten unliebsame 
                        Mitmenschen beseitigen zu können, haben zumindest in der Kriminalliteratur ihre 
                        Plätze. Dass bestimmte Pilze aber auch Heilwirkungen haben, wissen die wenigsten.
                        <br /> 
                        <a id="arten"></a>
                        <hr>
                        <h5>Welche Vitalpilze gibt es? </h5>
                        <hr>
                        Zu Vitalpilzen zählen u.a. zwölf Arten, von denen Ihnen ganz bestimmt einer bekannt 
                        ist: der Champignon (Agaricus bisporus). Die weiteren Arten haben teils sehr 
                        interessante Namen:
                        <br />
                        &#149; Agaricus blazei Murrill, ABM (Sonnen- oder Mandelpilz)
                        <br />
                        &#149; Auricularia polytricha (Judasohr)
                        <br />
                        &#149; Coprinus comatus (Schopftintling)
                        <br />
                        &#149; Cordyceps sinensis (Chinesische Raupenpilz)
                        <br />
                        &#149; Coriolus versicolor (Schmetterlingstramete)
                        <br />
                        &#149; Hericium erinaceus (Igelstachelbart)
                        <br />
                        &#149; Maitake (Klapperschwamm)
                        <br />
                        &#149; Pleurotus ostreatus (Austernpilz)
                        <br />
                        &#149; Polyporus umbellatus (Eichhase)
                        <br />
                        &#149; Reishi (Glänzender Lackporling)
                        <br />
                        &#149; Shiitake (Lentinula edodes)
                        <br />
                        <a id="anwendungsgebiete">&nbsp;</a>
                        <hr>
                        <h5>Anwendungsgebiete von Vitalpilzen</h5>
                        <hr>
                        Vitalpilze können vorbeugend, aber auch heilend eingesetzt werden. Vor allem aber 
                        ist es ihre ausgleichende, regulierende Wirkung, die sie besonders wertvoll machen. 
                        <br />
                        <br />
                        Die Mykotherapie ist ein wichtiger Bereich in der Naturheilkunde, und die Anwendungsgebiete 
                        von Vitalpilzen sind sehr breit gefächert. Jede Art hat ihre ganz speziellen Wirkungen, 
                        die sich teilweise ideal ergänzen. Alle haben jedoch einen hohen Anteil an Mineralstoffen 
                        und Vitaminen, aber auch Polysaccharide sind enthalten, die einen regulierenden Einfluss auf die 
                        Darmflora haben. Viele Arten wirken stabilisierend auf das Immunsystem und stärken 
                        die körperliche Belastbarkeit. Sogar zur Unterstützung bei Krebstherapien werden 
                        Vitalpilze sehr erfolgreich eingesetzt, wobei sie teils direkt die Tumorrückentwicklung 
                        unterstützen bzw. die Neuentwicklung hemmen, vor allem aber die Nebenwirkungen 
                        von chemotherapeutischen Substanzen und Strahlenbelastungen reduzieren können.
                        <br />
                        <br />
                        <b>Hier an dieser Stelle soll hervorgehoben werden, dass Vitalpilze ganz entscheidend 
                        bei den verschiedensten Verdauungsproblemen helfen können. </b>
                        <br />
                        <br />
                        Angefangen bei Magen- 
                        und insbesondere bei <a href="reflux" target="_blank">Refluxbeschwerden</a> können Hericium, Reishi, Cordyceps und/oder 
                        Shiitake eingesetzt werden.
                        <br />
                        <br />
                        Der Coprinus wirkt anregend und regulierend auf das Verdauungssystem und den 
                        Stoffwechsel, aber auch andere Vitalpilze können &ndash; je nach den individuellen 
                        Gegebenheiten und Voraussetzungen Anwendung finden. Sowohl bei Verstopfung als 
                        auch bei Blähungen und Durchfällen sind Vitalpilze geeignet.
                        <br />
                        <br />
                        Auch ein Leaky-Gut-Syndrom oder eine entzündete Darmschleimhaut können mit 
                        Vitalpilzen günstig beeinflusst werden.
                        <br />
                        <br />
                        Vitalpilze sind auch ein interessanter Ersatz für Probiotika, denn meist ist der 
                        Einsatz dieser Präparate, die lebende Mikroorganismen enthalten, eher ein Versuch, 
                        bei dem gescheut wird, ob die erwünschte Wirkung eintritt. Vitalpilze wie z.B. 
                        Hericium, Reishi oder Coriolus hingegen unterstützen, dass die Darmflora selbst 
                        wieder zu ihrer gesunden Balance zurückfindet. So finden sie ihr Einsatzgebiet 
                        ganz besonders auch bei Fehlbesiedelungen des Darms (Dünndarmfehlbesiedelung und/oder 
                        Dickdarmfehlbesiedelungen).
                        <br />
                        <a id="wirkung">&nbsp;</a>
                        <hr>
                        <h5>Adaptogene Wirkung</h5>
                        <hr>
                        Die in den Vitalpilzen enthaltenen Substanzen wirken nicht &ndash; wie pharmazeutische 
                        Medikamente &ndash; für oder gegen ein bestimmtes Problem, sondern ausgleichend 
                        (adaptogen), d.h. sie können dazu beitragen, beim Patienten Zustände auszugleichen, die sich 
                        im Ungleichgewicht befinden. Ein Beispiel unter vielen sind hier Durchfall 
                        oder auch Verstopfung: beide können mit dem gleichen Vitalpilz behandelt werden.
                        <br />
                        <a id="darreichungsformen">&nbsp;</a>
                        <hr>
                        <h5>Darreichungsformen</h5>
                        <hr>
                        Natürlich können Sie den frischen Pilz essen &ndash; und wahrscheinlich wird zumindest 
                        der Champignon oder seit einiger Zeit auch der Austernpilz ab und an auf Ihrem 
                        Speisezettel stehen. 
                        <br />
                        <br />
                        Als &#187;Vitalpilz&#171; wird entweder der ganze Pilz getrocknet und gemahlen oder aber er wird 
                        in Form von Extrakten verabreicht. Je feiner das Pulver vermahlen ist, das in Kapseln 
                        angeboten wird, desto besser ist die Wirkung. Man kann entweder &#187;nur&#171; 
                        den ganzen, vermahlenen Pilz oder den Extrakt einnehmen, meist jedoch werden beide 
                        Formen miteinander kombiniert, um die Wirkungen zu ergänzen. Für Menschen mit 
                        Problemen bei der Einnahme von Kaspeln sind Vitalpilzprodukte auch als Tropfen erhältlich.
                        <br />
                        <a id="dosierung">&nbsp;</a>
                        <hr>
                        <h5>Dosierung</h5>
                        <hr>
                        Es gibt keine allgemeingültige Dosierung für Vitalpilze &ndash; immer hängt dies 
                        von der Erkrankung, aber vor allem auch vom Erkrankten selbst ab. Kinder und 
                        Erwachsene nehmen selbstverständlich unterschiedliche Mengen ein. Wenn Sie sich 
                        für die Anwendung von Vitalpilzen interessieren, sollten Sie sich von einem 
                        erfahrenen Mykotherapeuten beraten lassen. 
                        <br />
                        <br />
                        Wichtig ist auf jeden Fall, dass die Dosierung aller Vitalpilze immer eingeschlichen 
                        werden muss. D.h. man beginnt vorsichtig mit einer kleinen Dosierung und steigert 
                        diese über etwa 2 Wochen, bis man die vorgesehene, komplette Dosis erreicht.
                        <br />
                        <a id="anwendungsdauer">&nbsp;</a>
                        <hr>
                        <h5>Anwendungsdauer</h5>
                        <hr>
                        Bei Beschwerden sollten Vitalpilze in der Regel über einen Zeitraum von zunächst 6 Monaten 
                        eingenommen werden, um eine Besserung zu festigen. Später können geeignete Vitalpilze 
                        die weitere Stabilisierung und/oder Vorbeugung mit einer Einnahme von 3 Monaten 
                        pro Jahr sichern.
                        <br />
                        <a id="nebenwirkungen">&nbsp;</a>
                        <hr>
                        <h5>Nebenwirkungen</h5>
                        <hr>
                        Die meisten Vitalpilze haben &ndash; wenn sie richtig und mit Bedacht eingesetzt 
                        werden &ndash; keine Nebenwirkungen. Es gibt aber auch bei diesen Präparaten einige 
                        Kontraindikationen, z.B. darf der Reishi nicht bei einer Unterfunktion der Schilddrüse 
                        eingesetzt werden. Dies bedeutet, dass man nicht so ohne Weiteres in Eigenregie 
                        zu Vitalpilz-Präparaten greifen sollte. Besser ist es, sich beraten zu lassen.
                        <br />
                        <a id="wechselwirkungen">&nbsp;</a>
                        <hr>
                        <h5>Wechselwirkungen mit anderen Medikamenten</h5>
                        <hr>
                        Auch, wenn andere Medikamente eingenommen werden (müssen), können Vitalpilze ergänzend 
                        eingesetzt werden. Auf keinen Fall dürfen von heute auf morgen die bisherigen 
                        Medikamente weggelassen und durch Vitalpilze ersetzt werden. Wenn jedoch nach einiger 
                        Zeit eine Besserung eintritt, kann in Rücksprache mit dem verordnenden Arzt ggf. 
                        das pharmazeutische Medikament reduziert und in einigen Fällen auch ganz 
                        weggelassen werden.
                        <br />
                        <a id="qualitaet">&nbsp;</a>
                        <hr>
                        <h5>Qualität</h5>
                        <hr>
                        Wie alle Nahrungsergänzungsmittel, unterliegen Vitalpilze nicht der Arzneimittelkontrolle. 
                        Es ist jedoch zu befürchten, dass sich auch hier schwarze Schafe einen Teil des Kuchens 
                        am Markt abschneiden wollen und Vitalpilzprodukte aus dubiosen Quellen anbieten 
                        &ndash; insbesondere im Internet. Wenn Sie ein Vitalpilz-Präparat einnehmen wollen, 
                        fragen Sie Ihren Behandler immer nach der Zertifizierung für das jeweilige Präparat, 
                        die bescheinigt, dass das Produkt unbedenklich ist und keine Schadstoffe enthält.
                        <br />
                        <br />
                        Bevor Sie ein Vitalpilz-Präparat kaufen wollen, sollten Sie sich bitte sowohl zur 
                        Auswahl geeigneter Pilzsorten als auch zu empfehlenswerten Bezugsadressen beraten lassen.
                        Ich selbst bin ausgebildete Mycoberaterin und biete Ihnen gerne meine Hilfe an.
                        <br />
                        <a id="fazit">&nbsp;</a>
                        <hr>
                        <h5>Fazit</h5>
                        <hr>
                        Für Verdauungsprobleme jeder Art bieten Vitalpilze zahlreiche Möglichkeiten, eine 
                        Therapie zu unterstützen und eine Besserung zu erzielen und zu stabilisieren. Der 
                        &#187;richtige&#171; Pilz bzw. die &#187;richtige&#171; Kombination von Vitalpilzen 
                        zum &#187;richtigen&#171; Zeitpunkt eingenommen können helfen, Symptome zu lindern, 
                        die Ursache zu beheben und einen dauerhaften Erfolg zu unterstützen.
                        <br />
                        <br />
                        <hr>
                        <a id="beratung">&nbsp;</a>
                        <div class="row">
                        <div class="col s12 m2">
                        <h5>Beratung</h5>
                        <br />
                            <a href="http://www.ganzheitliche-gesundheitsberatung.de" target="_blank">
                                <img src="<?php echo IMG_PATH; ?>praxiswebsite.png" alt="" class="inline" /></a>
                        </div>
                        </div>
                        <div class="row">
                        <div class="col s12 m12">
                            Gerne biete ich Ihnen eine individuelle Beratung an &ndash; 
                            auf Wunsch auch telefonisch oder per Skype.
                            <br />
                            Bitte informieren Sie sich auf meiner Praxis-Website <a href="http://www.ganzheitliche-gesundheitsberatung.de" target="_blank">&#187;www.Ganzheitliche-Gesundheitsberatung.de&#171;</a>
                        </div>
                        </div>
                        <hr>
                        <br />
                        <a href="guterrat" target="_blank"><img src="<?php echo IMG_PATH; ?>hilfreich.png" alt="" class="left" /></a>
                        <br />
                        <br />
                        <hr />
                        <b>Lesen Sie hierzu bitte auch folgende Beträge:</b>
                        <br />
                        <a href="duenndarmfehlbesiedelung" target="_blank">&#149; Dünndarmfehlbesiedelung und ihre Behandlung</a>
                        <br />
                        <a href="rds-ursache-sibo" target="_blank">&#149; Dünndarmfehlbesiedelung als Ursache des Reizdarm-Syndroms</a>
                        <br />
                        <a href="darmflora">&#149; Pflege der Darmflora</a>
                        <br />
                        <a href="darmsanierung">&#149; Sanierung der Darmflora</a>
                        <br />
                        <a href="ganz-parasiten">&#149; Parasiten- und Pilzbesiedelung des Darms</a>
                        <br />
                        <a href="ganz-genussmittel">&#149; Genussmittel bei Darmempfindlichkeit</a>
                        <br />
                        <a href="ganz-gaergetraenke">&#149; Probiotische Gärgetränke</a>
                        <br />
                        <a href="rds-ursache-sibo">&#149; Dünndarmfehlbesiedelung als Ursache des Reizdarm-Syndroms</a>
                        <br />
                        <hr />
                        <a href="javascript: scrollMainToTop();" class="nachoben">nach oben</a>
                    </div>
                </div>
            </div>    
            <br>
            <br> 
            <div class="bodyspacer"></div> 
        </div>