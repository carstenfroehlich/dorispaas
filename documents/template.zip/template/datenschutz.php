        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br />  
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>    
                <h1 class="header center orange-text">Datenschutzerklärung</h1>   
            </div>  
        </div>
        <div class="container">    
            <div class="section">  
                <div class="row">        
                    <div class="col s12 m12">          
                        <br />
                        <br />
                        Sämtliche persönlichen Daten, die auf dieser Website verwendet 
                        werden, sind &ndash; falls der Urheber sich im Vorfeld einverstanden erklärt hat &ndash;  
                        gekennzeichnet, anderenfalls sind die entsprechenden Passagen 
                        anonymisiert, so dass keinerlei Rückschlüsse auf den Verfasser möglich sind. 
                        Wenn Sie Daten an mich weitergeben, werden diese absolut 
                        vertraulich behandelt. Sie werden nur zum vereinbarten Zweck (Beantwortung von Fragen, 
                        Versand der bestellten Bücher oder des Newsletters, Freischaltung der 
                        Lebensmittel-Datenbank) verwendet. Sie 
                        werden nicht an Dritte weitergegeben oder für Werbezwecke genutzt.
                        <br />
                        <br />
                        <b>Bei Buchbestellungen:</b> Nach dem Versand der von Ihnen bestellten 
                        Bücher werden Ihre Daten nicht mehr verwendet.
                        <br />
                        <br />
                        <b>Newsletterabo:</b> Ihre eMail-Adresse wird nur so lange für den 
                        Newsletterversand verwendet, wie Sie es wünschen. Sobald Sie 
                        den Newsletter abbestellen, wird Ihre Mailadresse gelöscht, und 
                        Sie erhalten keine weiteren Mails mehr.
                        <br />
                        <br />
                        <b>Abonnement der DorisPaas.de &ndash; Lebensmittel-Datenbank:</b> Nach Ablauf des 
                        Abonnements der DorisPaas.de &ndash; Lebensmittel-Datenbank werden die Daten 
                        nicht mehr verwendet.
                        <br />
                        <br />
                        Für einige Anwendungen, beispielsweise die DorisPaas.de &ndash; Lebensmittel-Datenbank
                        oder den Shop ist das Anlegen von <b>Cookies</b> erforderlich. Dies dient ausschließlich 
                        dazu, Ihren Anwendungskomfort zu erhöhen. Ich versichere 
                        ausdrücklich, dass die Cookies <b>nicht</b> dazu verwendet werden, Daten von 
                        Ihrem Rechner abzufischen, um sie für Werbung oder ähnliches zu nutzen.
                        <br />
                        <br />
                        Ich bedanke mich herzlich für Ihr Vertrauen
                        <br />
                        <br />
                        Ihre Doris Paas
                    </div>
                </div>
            </div>    
            <br>
            <br> 
            <div class="bodyspacer"></div> 
        </div>