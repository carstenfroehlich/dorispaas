        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br /> 
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>
                <h1 class="header center orange-text">Nahrungsmittel-Unverträglichkeiten</h1>      
            </div>  
        </div> 
        <div class="container">    
            <div class="section">
                <div class="row margintoprow">        
                    <div class="col s12 m12">
                        Auf dieser Seite finden Sie Links zu allen Informationen zum Thema 
                        &#187;<b>Nahrungsmittel-Unverträglichkeiten</b>&#171; auf www.DorisPaas.de.
                        <br />
                        <br />
                        Bitte klicken Sie auf die entsprechenden Links, um zu den gew&uuml;nschten Seiten zu gelangen:
                        <br />
                        <br />
                        
                                    
                    <div class="col s12 m6">
                        <ul class="nav">
                            <li>
                                <b>&#149; Laktose-Intoleranz</b>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>wasistli">Was ist Laktose-Intoleranz?</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>diagnose">Diagnose-Methoden zur Ermittlung einer Laktose-Intoleranz</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>behandlung">&#187;Behandlung&#171; der Laktose-Intoleranz</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>milch">Informationen über Milch</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>laktase">Informationen zu Laktase-Präparaten</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>studienauswertung">Auswertung der Laktase-Studie</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>probiotika">Probiotika statt Laktase?</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>probiotika-studienauswertung">Auswertung der Probiotika-Studie</a>
                            </li> 
                            <li>
                                <b>&#149; Fruktose-Intoleranz</b>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>wasistfma">Was ist Fruktose-Intoleranz?</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>fmadiagnose">Diagnosemethoden zur Ermittlung einer Fruktose-Intoleranz</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>fmabehandlung">Behandlung der Fruktose-Intoleranz</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>fmaernaehrung">Ernährung bei Fruktose-Intoleranz</a>
                            </li> 
                            <li>
                                <b>&#149; Oligosaccharid-Unverträglichkeit</b>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>oligosaccharide-wasistdas">Oligosaccharid-Unverträglichkeit &ndash; was ist das?</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>oligosaccharide-diagnose">Diagnose der Oligosaccharid-Unverträglichkeit</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>oligosaccharide-behandlung">Behandlung der Oligosaccharid-Unverträglichkei</a>
                            </li> 
                            <li>
                                <b>&#149; Zöliakie und Gluten-Unverträglichkeit</b>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>gluten">Zöliakie und Gluten-Unverträglichkeit</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>zoeliakie">Zöliakie &ndash; was ist das?</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>zoeliakie-diagnose">Diagnose der Zöliakie</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>glutensensitivitaet">Gluten-Sensitivität &ndash; was ist das?</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>glutensensitivitaet-diagnose">Diagnose der Gluten-Sensitivität</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>zoeliakie-behandlung">Behandlung der Zöliakie und der Gluten-Sensitivität</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>weizenallergie">Weizenallergie</a>
                            </li> 
                            <li>
                                <b>&#149; Pseudo-Allergien</b>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>pseudoallergien">Was sind Pseudo-Allergien?</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>wasisthi">Histamin-Intoleranz</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>glutamat">Glutamat-Intoleranz</a>
                            </li> 
                            <li>
                                <b>&#149; Behandlungsgrundsätze</b>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>nmu-behandlung">Behandlungsgrundsätze bei Nahrungsmittel-Unverträglichkeiten</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>nmu-karenz">Karenz</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>nmu-fasten">Fasten als Vorbereitung der Karenz</a>
                            </li> 
                            <li>
                                <b>&#149; Abgrenzung</b>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>abgrenzung">Abgrenzung Unverträglichkeit / -Allergie</a>
                            </li> 
                        </ul>
                    </div>
                </div>

                        <a href="javascript: scrollMainToTop();" class="nachoben">nach oben</a>
                    </div>
                </div>
            </div>    
            <br>
            <br> 
            <div class="bodyspacer"></div> 
        </div>