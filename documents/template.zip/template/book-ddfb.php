        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br /> 
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>
                <h1 class="header center orange-text">Dünndarmfehlbesiedelung</h1>      
            </div>  
        </div> 
        <div class="container">    
            <div class="section">   
                <div class="row margintoprow">        
                    <div class="col s12 m3">
                        <img src="<?php echo IMG_PATH; ?>book-ddfb-gross.png" alt="" class="right" />
                    </div>
                    <div class="col s12 m9">
                        <h5>Dünndarmfehlbesiedelung</h5>
                        <br />
                        erkennen, verstehen, erfolgreich behandeln
                        <br />
                        <br />
                        <br />
                        BoD &ndash; Books on Demand, Norderstedt<br />
                        ISBN 978-3-8370-3767-8
                        <br />
                        Paperback
                        <br />
                        220 Seiten, 10 farbige Abbildungen<br />
                        17,99&euro;<br />
                        <span style="font-size:0.8em">Endpreis &ndash; kein zusätzlicher MwSt.-Aufschlag</span>
                        <br />
                        <br />
                        <br />
                        <span style="font-weight:bold"><a href="<?= URL_ROOT ?>book-ddfb#buchbeschreibung">&#149; Buchbeschreibung</a></span>
                        <br />
                        <span style="font-weight:bold"><a href="<?= URL_ROOT ?>book-ddfb#inhaltsverzeichnis">&#149; Inhaltsverzeichnis</a></span>
                        <br />
                        <br />
                        <hr />
                        <span style="font-weight:bold">Bestellmöglichkeiten </span>
                        <br />
                        <br />
                        <a href="shop#buecher" Target="_blank">direkt hier im Shop</a>
                        <br />
                        <br />
                        <div id="bodShopWidget_01674093_print" class="bodShopWidget">
                        </div><script type="text/javascript">if(typeof checkLibExist == "undefined"){var script = document.createElement("script");
                        script.src ="//www.bod.de/public/js/bod/shopWidget.min.js?123";script.type = "text/javascript";
                        document.head.appendChild(script);var checkLibExist = true;} if(typeof books === "undefined") var books=[];books.push({"objID":"01674093",
                        "swKey":"05573a0631d7580bbc67b9815d46a65d","type":"print",
                        "size":"button","font":"nonSerif","shadow":true,"contour":true,
                        "coverContour":true,"fontColor":"#c8f7ef","contourColor":"#c8f7ef",
                        "shadowBtn":true,"contourBtn":true,"bgColor":"#295b8f","btnFontColor":"#4c4f52",
                        "btnColor":"#c8f7ef","btnContourColor":"#4c4f52","shop":"",
                        "bookSampleLinkText":"Jetzt probelesen","descriptionTitle":"Beschreibung","mandantShopUrl":"https://www.bod.de/buchshop",
                        "btnText":"beim Verlag","errMsg1Obj":"Dieser Titel ist leider<br>nicht länger vefügbar.",
                        "errMsg2Obj":"Aber im BoD-Buchshop gibt es viele weitere spannende Titel zu entdecken!",
                        "errMsg1Server":"Dieser Titel ist derzeit<br>leider nicht verfügbar.",
                        "errMsg2Server":"Bitte versuchen Sie es<br>später noch einmal.",
                        "errMsg3Server":"TITEL DERZEIT NICHT VERFÜGBAR"});</script>
                        <br />
                        <a href="http://www.amazon.de/gp/product/3837037673/ref=as_li_tl?ie=UTF8&camp=1638&creative=6742&creativeASIN=3734771382&linkCode=as2&tag=daslaktintobu-21&linkId=BZ6K4MDQJXBIFORA" target="_blank">bei Amazon</a>
                        <br />
                        <br />
                        Darüber hinaus in jeder Buchhandlung erhältlich 
                    </div>
                </div>
                <hr class="visual" />
                <a id="ebook">&nbsp;</a>
                <div class="row">        
                    <div class="col s12 m3">
                        <img src="<?php echo IMG_PATH; ?>als-ebook-erhaeltlich-neu.png" alt="" class="left" />
                    </div>
                    <div class="col s12 m9">
                        <h5>Dünndarmfehlbesiedelung</h5>
                        <br />
                        erkennen, versehen, erfolgreich behandeln
                        <br />
                        <br />
                        BoD &ndash; Books on Demand, Norderstedt<br />
                        <br />
                        ISBN: 978-3-7412-1932-0
                        <br />
                        220 Seiten, 10 farbige Abbildungen
                        <br />
                        Format: EPUB
                        <br />
                        14,99&euro;
                        <br />
                        <br />
                        <br />
                        <span style="font-weight:bold">Bestellmöglichkeiten</span>
                        <br />
                        <br />
                        <div id="bodShopWidget_01674093_ebook" class="bodShopWidget"></div>
                        <script type="text/javascript">
                            if(typeof checkLibExist == "undefined") {
                                var script = document.createElement("script");
                                script.src ="//www.bod.de/public/js/bod/shopWidget.min.js?123";
                                script.type = "text/javascript";
                                document.head.appendChild(script);
                                var checkLibExist = true;
                            } 
                            if(typeof books === "undefined") 
                                var books=[];
                            books.push({
                                "objID":"01674093",
                                "swKey":"05573a0631d7580bbc67b9815d46a65d",
                                "type":"ebook",
                                "size":"button",
                                "font":"nonSerif",
                                "shadow":true,
                                "contour":true,
                                "coverContour":true,
                                "fontColor":"#c8f7ef",
                                "contourColor":"#c8f7ef",
                                "shadowBtn":true,
                                "contourBtn":true,
                                "bgColor":"#295b8f",
                                "btnFontColor":"#4c4f52",
                                "btnColor":"#c8f7ef",
                                "btnContourColor":"#4c4f52",
                                "shop":"",
                                "bookSampleLinkText":"Jetzt probelesen",
                                "descriptionTitle":"Beschreibung",
                                "mandantShopUrl":"https://www.bod.de/buchshop",
                                "btnText":"im BoD Buchshop",
                                "errMsg1Obj":"Dieser Titel ist leider<br>nicht länger vefügbar.",
                                "errMsg2Obj":"Aber im BoD-Buchshop gibt es viele weitere spannende Titel zu entdecken!",
                                "errMsg1Server":"Dieser Titel ist derzeit<br>leider nicht verfügbar.",
                                "errMsg2Server":"Bitte versuchen Sie es<br>später noch einmal.",
                                "errMsg3Server":"TITEL DERZEIT NICHT VERFÜGBAR"
                            });
                        </script>
                        <br />
                        oder
                        <br />
                        <br />
                        <a rel="nofollow" href="http://www.amazon.de/gp/product/B01EG7049Y/ref=as_li_tl?ie=UTF8&camp=1638&creative=6742&creativeASIN=B01EG7049Y&linkCode=as2&tag=daslaktintobu-21" target="_blank">als Kindle Edition bei Amazon</a>
                    </div>
                </div>
                <hr class="visual" />
                <div class="row">        
                    <div class="col s12 m12">
                        <a id="buchbeschreibung"></a>
                        <h5>Buchbeschreibung:</h5>
                        <hr />
                        <p><span style="font-weight:bold">Dünndarmfehlbesiedelung</span>
                        <br />
                        erkennen, verstehen, erfolgreich behandeln
                        </p>
                        Sie leiden immer wieder unter Verdauungsproblemen wie Bauchschmerzen, Krämpfen, 
                        einem aufgeblähten Bauch, Durchfällen oder Verstopfung, Völlegefühl und Sodbrennen? 
                        Dann besteht die Möglichkeit, dass eine bakterielle Fehlbesiedelung des Dünndarms 
                        vorliegt. 
                        <br />
                        <br />
                        Die Dünndarmfehlbesiedelung ist wahrscheinlich derzeit eine der am häufigsten 
                        verkannte und auch unterschätzte Erkrankung des Verdauungssystems. Und weil die  
                        quälenden Beschwerden kaum mit dem Verzehr bestimmter Lebensmittel in 
                        Verbindung gebracht werden können, ist sie so schwer &#187;zu packen&#171;. Dass 
                        die Dünndarmfehlbesiedelung oft in enger Beziehung mit Nahrungsmittel-Unverträglichkeiten 
                        und auch mit der bisher als &#187;Reizdarm-Syndrom&#171; bezeichneten Problematik 
                        steht, ist mittlerweile zwar nachgewiesen, aber leider noch nicht im allgemeinen 
                        medizinischen Bewusstsein verankert. 
                        <br />
                        <br />
                        Wenn man einmal die Zusammenhänge erkannt und verstanden hat, wie sich die 
                        langanhaltenden und belastenden Beschwerden begründen, ist es möglich, eine 
                        Dünndarmfehlbesiedelung zu erkennen und dauerhaft zu beseitigen.
                        <br />
                        <br />
                        Vor einer erfolgreichen Behandlung steht immer eine korrekte Diagnose &ndash; und
                        diese sollte auf der einen Seite alle erforderlichen Maßnahmen umfassen, auf 
                        der anderen Seite aber belastende und oft auch überflüssige und vielleicht 
                        sogar kostenträchtige Untersuchungen vermeiden. 
                        <br />
                        <br />
                        Eine zielführende Therapie 
                        erfolgt dann in mehreren Phasen, wobei verschiedene Mittel und Möglichkeiten 
                        zur Verfügung stehen. Auch die gleichzeitig erforderlichen behandlungs-
                        begleitenden Maßnahmen und allgemeinen Regeln zur Gesunderhaltung der 
                        Darmflora werden thematisiert. Nur die konsequente Einhaltung aller notwendigen
                        Schritte kann zu einem dauerhaften Erfolg führen und die größtmögliche
                        Sicherheit vor Rückfällen gewährleisten.
                        <br />
                        <br />
                        Sie lernen alle möglichen Ursachen, Diagnosemethoden und 
                        Behandlungsalternativen kennen und werden das Zusammenspiel aller 
                        Therapiekomponenten verstehen. Als Betroffene können Sie letztendlich durch Ihr 
                        eigenes Verhalten einen dauerhaften Behandlungserfolg sicherstellen. 
                        Und natürlich erhalten Sie die Möglichkeit, gemeinsam mit Ihren Ärzten und Beratern 
                        auf Augenhöhe zu sprechen und darüber entscheiden zu können, welche der 
                        Behandlungsalternativen für Sie die geeignetste ist.
                        <br />
                        <br />
                        Dieses Buch soll in erster Linie die Betroffenen 
                        selbst ansprechen: Jeder, der vermutet, an einer Dünndarmfehlbesiedelung zu leiden,
                        sollte dieses Buch lesen, ebenso wenn Nahrungsmittel-Unverträglichkeiten vorliegen 
                        und die Diät, bei der die entsprechenden Lebensmittel gemieden werden, nicht zu 
                        der gewünschten Beschwerdefreiheit führt oder aber wenn immer wieder auftretende 
                        Reizdarm-Probleme quälen. Der Text ist verständlich geschrieben, Fachausdrücke 
                        werden weitestgehend vermieden, trotzdem jedoch erwähnt und erklärt, damit diese bei einem 
                        Arztgespräch verstanden werden können.
                        <br />
                        <br />
                        Der sorgfältig recherchierte, umfassende Titel sollte aber auch in keiner ärztlichen 
                        Praxis und auf keinem Schreibtisch von Heilpraktikern und Ernährungs- und 
                        Gesundheitsberatern fehlen.
                    </div>
                </div>
                <hr class="visual" />
                <div class="row">        
                    <div class="col s12 m12">
                        <a id="inhaltsverzeichnis"></a>
                        <hr />
                        <h5>Inhaltsverzeichnis</h5> (Bitte klicken Sie auf die gewünschte Überschrift, um die Unterkapitel einzublenden)
                        <hr />
                        <br />
                        <ul class="struc">
                            <?php
                                $bookPath = "book3/";
                                include( $bookPath . "kapitel01.php" );
                                include( $bookPath . "kapitel02.php" );
                                include( $bookPath . "kapitel03.php" );
                                include( $bookPath . "kapitel04.php" );
                                include( $bookPath . "kapitel05.php" );
                                include( $bookPath . "kapitel06.php" );
                                include( $bookPath . "kapitel07.php" );
                                include( $bookPath . "kapitel08.php" );
                                include( $bookPath . "kapitel09.php" );
                                include( $bookPath . "kapitel10.php" );
                                include( $bookPath . "kapitel11.php" );
                                include( $bookPath . "kapitel12.php" );
                                include( $bookPath . "kapitel13.php" );
                                include( $bookPath . "kapitel14.php" );
                                include( $bookPath . "kapitel15.php" );
                                include( $bookPath . "kapitel16.php" );
                                include( $bookPath . "kapitel17.php" );
                            ?>
                        </ul>
                        <br />
                        <hr>
                        <br />
                        <b>Lesen Sie hierzu auch folgenden Beitrag auf dieser Website: </b>
                        <br />
                        <br />
                        <a href="duenndarmfehlbesiedelung" target="_blank">&#149: Dünndarmfehlbesiedelung</a>
                        <br />
                        <hr />
                        <a href="siboschulung">
                            <img src="<?php echo IMG_PATH; ?>schulungslogo-klein.png" alt="Siboschulung" class="left" />
                        </a>
                        <p class="right">
                        Zum Thema &#187;Dünndarmfehlbesiedelung&#171; biete ich 
                        <b>Schulungen</b></a> speziell für Mediziner, Heilpraktiker, Ernährungs- und 
                        Gesundheitsberater und ihr Praxispersonal an.
                        <br />
                        <br />
                        <a href="siboschulung" target="_blank">Bitte klicken Sie hier für mehr Informationen</a>
                        </p>
                        <br style="clear: left;" />
                        <br />
                        <hr />
                        <a href="javascript: scrollMainToTop();" class="nachoben">nach oben</a>
                    </div>
                </div>
            </div>    
            <br>
            <br> 
            <div class="bodyspacer"></div> 
        </div>