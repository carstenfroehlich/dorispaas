        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br /> 
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>
                <h1 class="header center orange-text">Sü&#223;ungsmittel</h1> 
                    <div class="row center">        
                    <h5 class="header col s12 light">was ist empfehlenswert?</h5>      
                    </div>     
            </div>  
        </div> 

        <div class="container">    
            <div class="section">   
                <div class="row margintoprow">        
                    <div class="col s12 m4">
                        <ul class="nav">
                            <li>
                                <b>Abschnitte dieser Seite:</b>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-zuckerempfehlung#zucker">Zucker</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-zuckerempfehlung#honig">Honig</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-zuckerempfehlung#sirup">Fruchtdicksäfte und -sirups</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-zuckerempfehlung#fruchtzucker">Fruchtzucker</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-zuckerempfehlung#traubenzucker">Traubenzucker</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-zuckerempfehlung#austauschstoffe">Zuckeraustauschstoffe (Zuckeralkohole)</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-zuckerempfehlung#suessstoffe">Sü&#223;stoffe</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-zuckerempfehlung#stevia">Stevia</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-zuckerempfehlung#fazit">Fazit</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-zuckerempfehlung#beratung">Beratung</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>guterrat" target="_blank">War dieser Beitrag hilfreich für Sie?</a>
                            </li> 
                        </ul>
                    </div>
                    <div class="col s12 m8">
                        <img src="<?php echo IMG_PATH; ?>zucker-gross.png" alt="" class="right" />
                    </div>
                </div>
                <div class="row margintoprow">        
                    <div class="col s12 m12">
                        Immer wieder werde ich gefragt, welches der vielen Sü&#223;ungsmittel 
                        empfehlenswert oder zumindest am empfehlenswertesten sei.
                        <br />
                        <br />
                        Hierzu gibt es keine allgemein gültige Antwort. Trotzdem möchte ich 
                        einmal versuchen, die Gründe aufzuzeigen, die für oder gegen die 
                        verschiedenen Sü&#223;ungsmittel sprechen. Am Schluss dieser Seite lesen 
                        Sie danach (m)ein <a href="<?= URL_ROOT ?>ganz-zuckerempfehlung#fazit">Fazit</a>.
                        <br />
                        <br />
                        Mehr Informationenzu den einzelnen Zuckerarten finden Sie auch im <a href="lexikonzucker">Lexikon 
                        für Zucker und Sü&#223;ungsmittel</a>.
                        <br />
                        <a id="zucker">&nbsp;</a>
                        <hr />
                        <h5>Zucker (Saccharose) </h5>
                        <hr />
                        Beginnen wir mit dem eigentlichen &#187;<b>Zucker</b>&#171;, der auch unter den 
                        Bezeichnungen <b>Haushaltszucker</b>, <b>Kristallzucker</b>, <b>wei&#223;er</b> oder 
                        <b>Raffinadezucker</b>, <b>brauner Zucker</b> und je nach Herkunft <b>Rüben- 
                        oder Rohrzucker</b> gehandelt wird. Er wird aus dem Saft von Zuckerrüben oder 
                        Zuckerrohr gewonnen, danach mehr oder weniger gereinigt (raffiniert) und dann als 
                        wei&#223;er oder brauner Zucker verkauft. Da der braune Zucker ein besseres Image 
                        hat als der wei&#223;e, wird der wei&#223;e Zucker gerne auch mit dem 
                        Herstellungsrückstand <b>Melasse</b> ein wenig angefärbt, um ihn dann 
                        als braunen Zucker und dessen &#187;gesünderem&#171; Ruf teurer zu verkaufen. 
                        Die in der Melasse enthaltenen Mineralstoffe (die Vitamine sind durch die Erhitzungsprozesse 
                        ohnehin gänzlich zerstört) sind so gering, dass sie absolut nicht der 
                        Rede wert sind. Lediglich der Verzehr der reinen Melasse wäre eine gesunde, 
                        mineralstoffreiche Alternative, sie sü&#223;t jedoch so gut wie gar nicht 
                        mehr und hat sogar einen gewöhnungsbedürftigen, leicht bitteren Geschmack.
                        <br />
                        <br />
                        Zucker ist eine Verbindung aus je einem Baustein Glukose und Fruktose und somit 
                        ein Zweifachzucker (Disaccharid), der mithilfe des Enzyms Saccharase aufgespalten 
                        werden muss, um durch die Schleimhaut des Dünndarms ins Blut bzw. die Leber 
                        und anschlie&#223;end zu den 
                        Körperzellen gelangen zu können, wo er dann als Energie genutzt werden 
                        kann. Nicht benötigte, durch Zucker zugeführte Energie kann im 
                        Stoffwechsel in Fett umgewandelt und in den ungeliebten Fettpölsterchen 
                        abgelagert werden.
                        <br />
                        <br />
                        <b>Vorteile</b>: Zucker ist ein Stoff, der Speisen schmackhaft macht, denn bereits 
                        im Säuglingsalter hat der Mensch eine Vorliebe für Sü&#223;es. 
                        Haushaltszucker ist preiswert und gut zu verarbeiten.
                        <br />
                        <br />
                        <b>Nachteile</b>: Zuviel Zucker führt zu Übergewicht und ist für 
                        Diabetiker und für Menschen mit Fruktosemalabsorption eingeschränkt 
                        und nur in Ma&#223;en empfehlenswert.
                        <br />
                        <br />
                        <b>Sü&#223;kraft</b>: Alle im Folgenden angeführten Vergleiche zur 
                        Sü&#223;kraft beziehen sich immer auf den Haushaltszucker, dessen 
                        Sü&#223;kraft mit 1 definiert wurde.
                        <br />
                        <a id="honig">&nbsp;</a>
                        <hr />
                        <h5>Honig</h5>
                        <hr />
                        Eines der ältesten Sü&#223;ungsmittel dürfte der <b>Honig</b> 
                        sein, der von den Bienen aus dem aus den Blüten gesammelten Nektar in der 
                        Honigblase gebildet wird. Während des Sammelvorgangs werden dem Nektar 
                        verschiedene Drüsensekrete wie z.B. Enzyme hinzugegeben. Bei der Abgabe 
                        des so aufbereiteten Nektars in die Vorratswaben wird er eingedickt, indem durch 
                        Fächeln mit den Flügeln aus dem noch sehr dünnflüssigen Gemisch 
                        Wasser verdunstet.
                        <br />
                        <br />
                        Honig enthält je nach Sorte ein Gemisch aus ca. 20-40% Fruktose und 20-40% 
                        Glukose und Wasser. Weiterhin sind Pollen enthalten, die beim Sammeln 
                        des Nektars mit aufgenommen werden. Auch verschiedene andere Zuckerarten, 
                        Mineralstoffe und Vitamine sind im Honig enthalten.
                        <br /> 
                        <br />
                        Nach der &#187;Ernte&#171; durch den Imker wird der Honig gefiltert (in Fabriken 
                        zum Erhalt eines gleichmä&#223;igen Geschmacks häufig auch mit anderen 
                        Sorten gemischt) und in Gläser gefüllt. Bei längerer Lagerung wird 
                        jeder Honig im Laufe der Zeit fest &ndash; er kristallisiert. Das ist immer ein 
                        Zeichen von Qualität. Nur Honig, der erwärmt wurde, bleibt flüssig, 
                        dann sind jedoch die wertvollen Vitamine und Enzyme zerstört &ndash; der Honig 
                        ist dann nur noch wenig mehr als Zuckersaft.
                        <br />
                        <br />
                        <b>Vorteile</b>: Honig ist &ndash; sofern es sich um hochwertigen Imkerhonig 
                        handelt &ndash; ein wertvolles Naturprodukt, das neben Vitaminen und Mineralstoffen 
                        auch Blütenpollen enthält. Es gibt sogar Versuche, mit dem vorsichtigen, 
                        gezielten Verzehr von Honig aus der eigenen Umgebung eine Hyposensibilisierung 
                        bei Pollenallergie zu behandeln. Honig hat &ndash; je nachdem, aus welchen 
                        Blüten er gesammelt wurde &ndash; ganz verschiedene Geschmacksrichtungen. 
                        Ihn nur als reines Sü&#223;ungsmittel zu betrachten, wäre zu kurz 
                        gegriffen. Honig ist deshalb ein sehr vielfältiger Geschmacksstoff.
                        <br />
                        <br />
                        <b>Nachteile</b>: Auch Honig enthält viel Zucker. Es wäre deshalb 
                        unüberlegt, Honig generell als &#187;gesund&#171; zu bezeichnen. Die 
                        zugegebenerma&#223;en wertvollen Zusatz-Inhaltsstoffe wie Pollen, Enzyme, Vitamine 
                        und Mineralstoffe machen den Honig zwar etwas gesünder als 
                        Zucker, aufgrund des hohen Energiegehalts sollte er trotzdem nur in Ma&#223;en 
                        genossen werden. Für Menschen mit einer Fruktosemalabsorption ist Honig 
                        nicht empfehlenswert. 
                        <br />
                        <br />
                        Sü&#223;kraft</b>: Durch den hohen Fruktose-Anteil hat Honig mit 
                        durchschnittlich rund 1,7 eine relativ hohe Sü&#223;kraft. 
                        <br />
                        <a id="sirup">&nbsp;</a>
                        <hr />
                        <h5>Fruchtdicksäfte und -sirups</h5>
                        <hr />
                        Gerne werden insbesondere von Menschen, die gesundheitsbewusster leben, zum 
                        Sü&#223;en Dicksäfte (Fruchtsirups) aus Früchten verwendet. Hier 
                        sind z.B. der <b>Agaven-, Birnen-, oder Apfeldicksaft</b> zu nennen (letztere auch 
                        unter den Namen Apfel- oder Birnenkraut bekannt) und aus Kanada der karamellig schmeckende 
                        <b>Ahornsirup</b>.
                        <br />
                        <br />
                        Zur Gewinnung von Dicksäften werden Fruchtsäfte oder (beim Ahornsirup) 
                        abgezapfte Baumsäfte solange eingekocht, bis sie dickflüssig sind. 
                        Hierbei wird das Wasser entzogen und der Gesamtzuckergehalt steigt enorm an. 
                        <br />
                        Nicht verwechselt werden dürfen die Fruchtsirups mit den Sirups, die industriell 
                        aus Zucker, Wasser Farb- und Aromastoffen hergestellt werden und beispielsweise 
                        als &#187;Waldmeistersirup&#171;, &#187;Himbeersirup&#171; u.ä. zu 
                        Erfrischungsgetränken etc. verwendet werden.
                        <br />
                        <br />
                        <b>Vorteile</b>: Fruchtdicksäfte haben immer einen mehr oder weniger starken 
                        Eigengeschmack und eignen sich daher nicht zum neutralen Sü&#223;en. Aber 
                        gerade wegen ihres Eigengeschmacks werden sie ganz gezielt für bestimmt 
                        Gerichte verwendet (beispielsweise der Ahornsirup zum Sü&#223;en von Pfannkuchen). 
                        <br />
                        <br />
                        <b>Nachteile</b>: Trotz der natürlichen Herkunft enthalten die Fruchtdicksäfte 
                        durch das lange Einkochen zum einen hohen Zucker- und damit Energiegehalt. Je 
                        nach Art enthalten sie verschiedene Zuckerarten, in fast allen Fällen jedoch 
                        einen hohen Anteil an Fruchtzucker. Somit eigenen sich die Dicksäfte weder 
                        für Diabetiker noch für Menschen mit einer Fruktosemalabsorption. Trotz 
                        der natürlichen Herkunft sind so gut wie keine Vitamine mehr vorhanden, 
                        lediglich Mineralstoffe können enthalten sein.
                        <br />
                        <br />
                        <b>Sü&#223;kraft</b>: Die Sü&#223;kraft richtet sich nach der Sorte des 
                        Dicksafts und auch nach dem Grad der Einkochung und kann deshalb nicht beziffert 
                        werden.
                        <br />
                        <a id="fruchtzucker">&nbsp;</a>
                        <hr />
                        <h5>Fruchtzucker (Fruktose) </h5>
                        <hr />
                        Neben dem Haushaltszucker wird insbesondere der <b>Fruchtzucker</b> gerne auch 
                        zu Sü&#223;en verwendet, weil er vom Verdauungssystem insulinunabhängig 
                        verstoffwechselt wird. Aus diesem Grunde wurde der Fruchtzucker früher als 
                        &#187;Diabetikerzucker&#171; bezeichnet und speziell Produkten zugesetzt, die 
                        für Diabetiker angeboten wurden. Dies ist heute jedoch nicht mehr erlaubt.
                        <br />
                        <br />
                        <b>Vorteile</b>: Fruchtzucker wird insulinunabhängig verstoffwechselt &ndash; 
                        der Blutzucker bleibt nach dem Verzehr auf einem ausgeglicheneren Niveau als bei 
                        Verzehr von Haushaltszucker.
                        <br />
                        <br />
                        <b>Nachteile</b>: Fruchtzucker ist für Menschen mit Fruktosemalabsorption 
                        keinesfalls geeignet und führt bei übermä&#223;igem Verbrauch 
                        auch bei Menschen ohne Intoleranz zu Verdauungsproblemen. Als besonders 
                        problematisch ist hier auch der aus Mais gewonnene (und für die 
                        Nahrungsmittelindustrie billige) <b>HFCS</b> (High Fructose Corn Syrup) zu nennen, 
                        auch <b>Maissirup</b> oder <b>Glukose-Fruktose-Sirup</b> genannt, der verstärkt 
                        vielen sü&#223;en Nahrungsmitteln beigesetzt wird, wodurch der Fruktoseverbrauch 
                        soweit gesteigert wird, dass die Verträglichkeitsschwelle der meisten Menschen 
                        dadurch letztendlich überschritten wird. 
                        <br />
                        <br />
                        <b>Sü&#223;kraft</b>: Wegen seiner im Vergleich zum Haushaltszucker wesentlich 
                        höheren Sü&#223;kraft von rund 1,7 wird Fruchtzucker gerne Nahrungsmitteln 
                        zugesetzt, die als so genannte &#187;Lightprodukte&#171; angeboten und beworben werden. 
                        <br />
                        <a id="traubenzucker">&nbsp;</a>
                        <hr />
                        <h5>Traubenzucker (Glukose) </h5>
                        <hr />
                        <b>Traubenzucker</b> wird gerne als der Zucker verzehrt, der &#187;sofort ins 
                        Blut geht&#171; und &#187;sofort Energie liefert&#171;. Als einer der 
                        Einfachzucker muss Traubenzucker nicht mehr vom 
                        Verdauungssystem aufgespalten werden, um über die Schleimhäute ins 
                        Blut aufgenommen und mit diesem zu den Körperzellen transportiert werden 
                        zu können, wo er direkt als Energie genutzt werden kann. Bereits im Mund 
                        kann der Traubenzucker über die Mundschleimhaut absorbiert werden, der Rest 
                        wird über die Dünndarmschleimhaut aufgenommen. 
                        <br />
                        <br />
                        <b>Vorteile</b>: Traubenzucker tatsächlich ein &#187;schneller&#171; Zucker, 
                        der die enthaltene Energie rasch verfügbar macht. Gesunde Menschen ziehen 
                        aber aus dem Verzehr von Traubenzucker keinen Vorteil. Diabetiker jedoch sollten immer 
                        ein Stückchen Traubenzucker mit sich führen, um ggf. bei einem 
                        Blutzuckerabfall im Notfall (!) den Wert rasch anheben zu können, bevor sie mit 
                        dem gleichzeitigen Verzehr von langsameren Kohlenhydraten (z.B. Vollkornbrot) einen 
                        gesünderen, dauerhafteren und gleichmä&#223;igeren Blutzuckerspiegel 
                        herstellen. Bei einer Fruktosemalabsorption kann die Beigabe von etwas Traubenzucker 
                        helfen, Fruktose bekömmlicher zu machen.
                        <br />
                        <br />
                        <b>Nachteile</b>: Isolierter Traubenzuckerverzehr führt zu hohen 
                        Blutzuckerspitzen und heftigen Blutzuckerschwankungen, da hohe Glukosewerte 
                        zu einer vermehrten Insulinausschüttung führen. Dieses Insulin 
                        wiederum drückt den Blutzucker schnell wieder weit nach unten, was einen 
                        sehr niedrigen Blutzuckerspiegel zur Folge hat. Bei gesunden Menschen macht sich 
                        dies als Hei&#223;hunger bemerkbar, Diabetiker können rasch in eine gefährliche 
                        Unterzuckerung geraten. Auch kann Traubenzucker bei übermä&#223;igem 
                        Genuss Durchfall erzeugen. Der Verzehr von Traubenzucker sollte deshalb in Ma&#223;en 
                        gehalten werden.
                        <br />
                        <br />
                        <b>Sü&#223;kraft</b>: Die Sü&#223;kraft ist gegenüber dem Haushaltszucker 
                        kleiner, nämlich nur 0,75. Auch aus diesem Grunde eignet sich Traubenzucker 
                        nicht zum Ersatz von Haushaltszucker.
                        <br />
                        <a id="austauschstoffe">&nbsp;</a>
                        <hr />
                        <h5>Zuckeraustauschstoffe (Zuckeralkohole) </h5>
                        <hr />
                        Als so genannte Zuckeraustauschstoffe werden die Zuckeralkohole <b>Sorbit </b> 
                        (Sorbitol/E420), <b>Xylit</b> (Xylitol/ E967), <b>Erythrit</b> (Erythirtol/E968), 
                        <b>Maltit</b> (Maltitol/E965) und <b>Mannit</b> (Mannitol/E421) bezeichnet. Es 
                        gibt sie unter diversen Handelbezeichnungen, und sie werden gerade in letzter Zeit 
                        heftig und vor allem als gesunde Zuckeralternative beworben. Zuckeralkohole sind 
                        natürlichen Ursprungs, das Sorbit beispielsweise ist auch in verschiedenen 
                        Früchten wie Vogelbeeren (Sorbus aucuparia &ndash; daher der Name), u.a. 
                        Pflaumen, Birnen und Äpfeln enthalten.
                        <br />
                        <br />
                        Zuckeralkohole sind mit den so genannten E-Nummern versehen, d.h. sie sind lt. 
                        Definition von der Europäischen Union als &#187;unbedenklich&#171; erklärt 
                        worden. Trotzdem müssen Produkte, die mit Zuckeralkoholen gesü&#223;t 
                        wurden, mit einem Warnhinweis (siehe Nachteile) gekennzeichnet werden &ndash; das 
                        ist für mich persönlich ein Widerspruch.
                        <br />
                        <br />
                        <b>Vorteile</b>: Zuckeraustauschstoffe werden bei der Verdauung langsamer als 
                        Haushaltszucker (Saccharose) und weitgehend unabhängig von Insulin verwertet, 
                        was sie für die Ernährung von Diabetikern interessant macht. Auch haben 
                        sie einen geringeren Kaloriengehalt, weshalb sie gerne in den so genannten &#187;Diät- 
                        oder Lightprodukten&#171; eingesetzt werden.
                        <br />
                        <br />
                        <b>Nachteile</b>: Zuckeralkohole führen in höherer Dosierung stark 
                        abführend, aber auch schon bei geringer Dosierung zu Blähungen. Deshalb 
                        ist auf allen Produkten, die Zuckeraustauschstoffe enthalten, folgender Warnhinweis 
                        gesetzlich vorgeschrieben: &#187;kann bei übermä&#223;igem Verzehr abführend 
                        wirken&#171;.
                        <br />
                        <br />
                        Zuckeralkohole werden seit einiger Zeit in kristallisierten Formen angeboten, 
                        die tatsächlich aussehen wie Zucker. Dabei wird geworben, die Produkte 
                        (meist mit Mischungen verschiedener Zuckersorten) hätten &#187;die gleiche 
                        Sü&#223;kraft wie Zucker&#171; und seien &#187;eine gesunde Alternative zu
                        Zucker&#171;. Durch Aussehen und Textur, die tatsächlich dem Zucker 
                        angenähert sind, ist es nicht auszuschlie&#223;en, dass der 
                        Verbraucher Zuckeraustauschstoffe in gleicher Menge &ndash; mit den beschriebenen 
                        Nebenwirkungen &ndash; verwendet.
                        <br />
                        <br />
                        Insbesondere Sü&#223;igkeiten, die mit Zuckeralkoholen gesü&#223;t 
                        werden, werden als &#187;zuckerfrei&#171; und/oder auch als &#187;zahnschonend&#171; 
                        beworben. Sowohl der Hinweis auf die Zuckerfreiheit ist irreführend, weil 
                        die Produkte sehr wohl ungesunde Leerkalorien enthalten, und der Hinweis auf die 
                        Schonung der Zähne ist schlichtweg falsch, weil auch Zuckeralkohole einen 
                        Nährboden für schädliche Bakterien bieten können.
                        <br />
                        <br />
                        <b>Sü&#223;kraft</b>: Die Sü&#223;kraft ist je nach Art unterschiedlich, 
                        jedoch mit 0,6 &ndash; 0,9 geringer als die von Haushaltszucker, was bei isolierter 
                        Verwendung zu einem höheren Verzehr verleiten könnte.
                        <br />
                        <a id="suessstoffe">&nbsp;</a>
                        <hr />
                        <h5>Sü&#223;stoffe</h5>
                        <hr />
                        Sü&#223;stoffe können aus natürlichen oder künstlichen 
                        Grundsubstanzen hergestellt werden. 
                        <br />
                        Folgende Sü&#223;stoffe sind in der EU zugelassen (Quelle: Wikipedia): 
                        <br />
                        Acesulfam (E 950, Sü&#223;kraft 130-200) 
                        <br />
                        Aspartam (E 951, Sü&#223;kraft 200) 
                        <br />
                        Aspartam-Acesulfam-Salz (E 962, Sü&#223;kraft 350) 
                        <br />
                        Cyclamat (E 952, Sü&#223;kraft 30-50) 
                        <br />
                        Saccharin (E 954, Sü&#223;kraft 300-500) 
                        <br />
                        Sucralose (E 955, Sü&#223;kraft 600) 
                        <br />
                        Thaumatin (E 957, Sü&#223;kraft 2000-3000) 
                        <br />
                        Neohesperidin (E 959, Sü&#223;kraft 400-600) 
                        <br />
                        Neotam (E 961, Sü&#223;kraft 7000-13000) 
                        <br />
                        <br />
                        <b>Vorteile</b>: Sü&#223;stoffe haben eine erhebliche Sü&#223;kraft 
                        (bis zu 13000-fach) und dabei so gut wie keine Kalorien. Dadurch, dass sie keinen 
                        nennenswerten Brennwert haben, wirken sie nicht karieserzeugend. Sü&#223;stoffe 
                        gibt es als Tabletten, aber auch flüssig oder als Pulver, mit denen man
                        seine Speisen oder Kaffee oder Tee fast kalorienfrei sü&#223;en kann. 
                        <br />
                        <br />
                        <b>Nachteile</b>: Sü&#223;stoffe haben teilweise einen typischen und als 
                        unangenehm empfundenen Eigengeschmack, weshalb sie auch gerne als Gemische in 
                        den Handel kommen. Menschen mit Nahrungsmittel-Unverträglichkeiten, insbesondere 
                        mit Laktose-, Fruktose- und Sorbit-Unverträglichkeit sollten beachten, dass 
                        Sü&#223;stoff-Zubereitungen Laktose enthalten und den Verstoffwechselungsprozess 
                        von Fruktose und Sorbit beeinträchtigen können. 
                        <br />
                        <br />
                        Über die gesundheitliche 
                        Unbedenklichkeit von Sü&#223;stoffen gibt es unterschiedliche Bewertungen 
                        &ndash; die genannten Sü&#223;stoffe sind zumindest von der EU als insbesondere 
                        im Hinblick auf ein Krebsrisiko unbedenklich freigegeben und auch von der Deutschen 
                        Gesellschaft für Ernährung so beurteilt, obwohl es durchaus auch Studien 
                        gibt, die zu einem anderen Urteil gekommen sind.
                        <br />
                        <br />
                        <b>Sü&#223;kraft</b>: je nach Art unterschiedlich (siehe oben)
                        <br />
                        <a id="stevia">&nbsp;</a>
                        <hr />
                        <h5>Stevia</h5>
                        <hr />
                        Die Bezeichnung &#187; <b>Stevia</b>&#171; steht eigentlich nicht für das 
                        mittlerweile hier bei uns stark in Mode gekommene Sü&#223;ungsmittel, sondern 
                        ist die Bezeichnung der krautigen Pflanze (Stevia rebaudiana, Sü&#223;kraut), 
                        aus deren Blättern 
                        ein stark sü&#223;ender Extrakt gewonnen werden kann. Seit Jahrhunderten 
                        benutzen vor allem die Völker Südamerikas diese dort beheimateten 
                        Korbblütler zum Sü&#223;en ihrer Speisen. Das hier gebräuchliche 
                        Sü&#223;ungsmittel wird aus der chemisch isolierten Substanz Steviolglycosid 
                        hergestellt und hat eine sehr hohe Sü&#223;kraft und keine Kalorien.
                        <br />
                        <br />
                        Lange Zeit war Stevia in Deutschland nicht zum Verzehr zugelassen, obwohl die 
                        Pflanze seit Jahrhunderten (nicht nur) in ihrem Heimatland ohne gesundheitliche 
                        Beeinträchtigungen verwendet wird. Immer wieder wurde hier auch angeführt, 
                        dass eine krebserregende und erbgutschädigende Wirkung nicht auszuschlie&#223;en 
                        sei. Ich persönlich könnte mir jedoch vorstellen, 
                        dass diese langfristige Ablehnung vielleicht mit einer Blockadehaltung 
                        der Zuckerindustrie zusammenhängen könnte, die dieses natürliche 
                        Sü&#223;ungsmittel als Bedrohung für ihren Profit ansehen könnte.
                        <br />
                        <br />
                        Aufgrund neuerer Studien aus dem Jahre 2010 durch die Europäische 
                        Behörde für Lebensmittelsicherheit (EFSA) konnten diese Wirkungen 
                        für Stevia jedoch nicht nachgewiesen werden, und seit November 2011 ist 
                        Stevia nun endlich auch in der EU zugelassen &ndash; bisher 
                        allerdings nur für bestimmte Produkte wie Joghurt oder Softgetränke. 
                        Jedoch gibt es Stevia auch in Tabletten- oder Tropfenform, womit Sie Ihre Speisen 
                        selbst sü&#223;en können. Man kann die (nicht winterharte) Pflanze auch 
                        im Garten oder auf dem Balkon ziehen und die Blätter verwenden. 
                        <br />
                        <br />
                        <b>Vorteile</b>: Stevia ist nach meiner Einschätzung ein unproblematisches 
                        Sü&#223;ungsmittel ohne Kalorien.
                        <br />
                        <br />
                        <b>Nachteile</b>: Stevia-Präparate haben bei Höherdosierungen einen 
                        lakritzartigen, leicht bitteren Beigeschmack.
                        <br />
                        <br />
                        <b>Sü&#223;kraft</b>: Stevia hat eine sehr hohe Sü&#223;kraft (300 &ndash; 400) 
                        und bei richtiger Dosierung so gut wie keinen Nebengeschmack.
                        <br />
                        <a id="fazit">&nbsp;</a>
                        <hr />
                        <h5>Fazit</h5>
                        <hr />
                        Grundsätzlich wird Sü&#223;es bereits vom Säuglingsalter an bevorzugt. 
                        Somit ist es ein Grundbedürfnis, Speisen zu sü&#223;en. Früher 
                        wurde mit Honig gesü&#223;t, aber auch sü&#223;ende Pflanzenextrakte 
                        oder Obst und Trockenfrüchte konnten die Nahrungsmittel schmackhaft sü&#223; 
                        machen.
                        Später dann wurde der isolierte &#187;Zucker&#171; erfunden, der mit damals 
                        noch sehr teuren Verfahren hergestellt wurde. Somit war er nur den Wohlhabenden 
                        vorbehalten. Deshalb galt es natürlich als erstrebenswert, (viel) Zucker zu 
                        verzehren und mit daraus resultierender gro&#223;er Körperfülle zu 
                        demonstrieren, dass &#187;man es sich leisten kann&#171;. 
                        <br />
                        <br />
                        Erst als sich &#187;Zivilisationskrankheiten&#171; wie Übergewicht und 
                        Diabetes (Typ II) verbreiteten und diese offensichtlich auch mit einem hohen 
                        Zuckerkonsum in Verbindung gebracht wurden, begann man über Alternativen 
                        nachzudenken &ndash; Zuckeraustauschstoffe und Sü&#223;stoffe wurden entdeckt 
                        und verstärkt verwendet. Gesundheitsbewusste Menschen verwendeten hingegen 
                        weiterhin eher Honig, Trockenobst und Fruchtdicksäfte zum Sü&#223;en.
                        <br />
                        <br />
                        Zuallererst muss erwähnt werden, dass es grundsätzlich am besten wäre, 
                        die Speisen eigentlich überhaupt nicht zusätzlich zu ihrem natürlichen 
                        Geschmack zu sü&#223;en &ndash; aber das wird wohl heute kaum noch jemand 
                        so dogmatisch handhaben. Und wenn dann doch Sü&#223;ungsmittel verwendet 
                        werden? Welches ist/welche sind dann empfehlenswert? 
                        <br />
                        <br />
                        Jedes Sü&#223;ungsmittel hat Vor-, 
                        aber auch Nachteile &ndash; und man kann nicht pauschal sagen, dieses oder jenes 
                        Sü&#223;ungsmittel ist für alle Menschen das Non plus ultra. 
                        <br />
                        <br />
                        Es ist unbestritten, dass man sich in Bezug auf das Sü&#223;en 
                        folgenderma&#223;en ernähren sollte:
                        <br />
                        <b>&#149;</b> so gesund wie möglich
                        <br />
                        <b>&#149;</b> mit möglichst wenig leeren Kalorien
                        <br />
                        <b>&#149;</b> mit möglichst wenigen künstlichen Stoffen
                        <br />
                        <br />
                        Somit ist unter den aufgeführten Sü&#223;ungsmitteln eigentlich keine 
                        &#187;eierlegende Wollmilchsau&#171; dabei. Keines der Sü&#223;ungsmittel 
                        ist uneingeschränkt gesund und erfüllt alle geforderten Kriterien 
                        gleichzeitig &ndash; erst recht nicht für alle Menschen unabhängig von 
                        eventuellen verschiedenen Vorerkrankungen. 
                        <br />
                        <br />
                        Eines ist jedoch für mich ganz klar: Sowohl die Sü&#223;stoffe als 
                        auch die Zuckeraustauschstoffe sind in meinen Augen entbehrlich (au&#223;er 
                        vielleicht für einen Diabetiker, für den sich u.U. Zuckeraustauschstoffe 
                        als Ausweichalternative anbieten könnten). 
                        <br />
                        <br />
                        Nach meiner persönlichen Meinung ist es für einen gesunden Menschen am besten, die Speisen 
                        teils mit wenig (!) ganz normalem Haushaltszucker zu sü&#223;en und zu einem 
                        anderen Teil (beispielsweise in Kaffee oder Tee) Stevia-Präparate zu benutzen.
                        <br />
                        <br />
                        Als leckeren Brotaufstrich oder zum aromatischen Sü&#223;en von 
                        Sü&#223;speisen können Honig oder Fruchtdicksäfte genossen werden. 
                        <br />
                        <br />
                        Für bestimmte Anwendungsgebiete (z.B. bei Fruktosemalabsorption oder 
                        für den unterzuckerten Diabetiker) kann der moderate Einsatz von 
                        Traubenzucker sinnvoll sein. 
                        <br />
                        <br />
                        Wägen Sie also für sich ab, für welches Einsatzgebiet Sie welche 
                        Zuckerart verwenden. Immer aber sollte es in Ma&#223;en und ganz bewusst sein!
                        <br />
                        <hr>
                        <a id="beratung">&nbsp;</a>
                        <div class="row">
                        <div class="col s12 m2">
                            <a href="http://www.ganzheitliche-gesundheitsberatung.de" target="_blank">
                                <img src="<?php echo IMG_PATH; ?>praxiswebsite.png" alt="" class="inline" /></a>
                        </div>
                        </div>
                        <div class="row">
                        <div class="col s12 m12">
                        <h5>Beratung</h5>
                        <br />
                            Gerne biete ich Ihnen eine individuelle Beratung an &ndash; 
                            auf Wunsch auch telefonisch oder per Skype.
                            <br />
                            Bitte informieren Sie sich auf meiner Praxis-Website <a href="http://www.ganzheitliche-gesundheitsberatung.de" target="_blank">&#187;www.Ganzheitliche-Gesundheitsberatung.de&#171;</a>
                        </div>
                        </div>
                        <hr>
                        <br />
                        <a href="guterrat" target="_blank"><img src="<?php echo IMG_PATH; ?>hilfreich-4.png" alt="" class="left" /></a>
                        <br />
                        <br />
                        <hr />
                        <b>Lesen Sie auch folgende Beträge</b>:
                        <br />
                        <a href="zuckerkrankheiten" target="_blank">&#149; Wird man von Zuckergenuss krank &ndash; und wenn ja, warum?</a>
                        <br />
                        <a href="lexikonzucker" target="_blank">&#149; Lexikon der Zuckerarten und Süßungsmittel</a>
                        <br />
                        <hr />
                        <a href="javascript: scrollMainToTop();" class="nachoben">nach oben</a>
                    </div>
                </div>
            </div>    
            <br>
            <br> 
            <div class="bodyspacer"></div> 
        </div>