        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br /> 
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>
                <h1 class="header center orange-text">Gesunde Verdauung</h1>      
            </div>  
        </div> 
        <div class="container">    
            <div class="section">   
                <div class="row margintoprow">        
                    <div class="col s12 m4">
                        <ul class="nav">
                            <li>
                                <b>Abschnitte dieser Seite:</b>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>verdauung#beschwerden">Beschwerden bei gestörter Verdauung</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>verdauung#verstopfung">Verstopfung</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>verdauung#durchfall">Durchfall</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>verdauung#blaehungen">Blähungen</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>verdauung#bauchschmerzen">Bauchschmerzen</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>verdauung#behandlung">Behandlungsmöglichkeiten</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>verdauung#abfuehrmittel">Abführmittel</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>verdauung#reisedurchfall">Stoppen von Reisedurchfall</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>verdauung#trinkmenge">Trinkmenge</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>verdauung#ballaststoffe">Ballsatstoffe</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>verdauung#ernaehrung">Gesunde Ernährung</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>verdauung#bewegung">Bewegung</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>verdauung#stressvermeidung">Stressvermeidung</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>verdauung#zeiterziehung">Zeiterziehung</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>verdauung#beratung">Beratung</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>guterrat" target="_blank">War dieser Beitrag hilfreich für Sie?</a>
                            </li> 
                        </ul>
                    </div>
                    <div class="col s12 m8">
                        <a href="paas-heftchen-gv" target="_blank"><img src="<?php echo IMG_PATH; ?>buchzumthema-gv.png" alt="" class="right" /></a>
                        <a href="paas-heftchen-ge" target="_blank"><img src="<?php echo IMG_PATH; ?>buchzumthema-ge.png" alt="" class="right" /></a>
                    </div>
                </div>
                <div class="row margintoprow">        
                    <div class="col s12 m12">
                        Eine gesunde Verdauung trägt wesentlich zur Darmgesundheit und damit zum 
                        Wohlbefinden bei. Nicht nur eine vernünftige Ernährung, sondern auch 
                        viele andere Faktoren können Ihnen zu einer gesunden und regelmäßigen 
                        Verdauung verhelfen.
                        <br />
                        <br />
                        Viele Menschen machen sich keinerlei Gedanken um ihre Verdauung, und bei vielen 
                        funktioniert sie auch völlig normal. Erst, wenn Probleme auftreten und 
                        Bauchschmerzen, Verstopfung, Durchfall oder Blähungen quälen, werden 
                        die Betroffenen auf ihre Verdauung aufmerksam.
                        <br />
                        <br />
                        Leider jedoch können auch versteckte Probleme auftreten, die wir gar nicht 
                        wahrnehmen, die aber &ndash; vor allem nach längerer Zeit &ndash; zu Krankheiten 
                        führen können.
                        <br />
                        <br />
                        Somit sollten Sie sich &ndash; auch wenn Sie derzeit keine Probleme zu haben meinen 
                        &ndash; mit der Funktion des Verdauungssystems vertraut machen und vorbeugen, dass 
                        Ihre Verdauung und damit Ihr gesamter Organismus gesund bleiben.
                        <br />
                        <br />
                        Die Natur hat es wunderbar eingerichtet: Wird Nahrung verzehrt, sendet das Nervensystem 
                        vom Magen einen Impuls an das Nervensystem um den Darm (das &#187;Bauchhirn&#171;), 
                        dass Platz zu schaffen sei. Dadurch wird der Dickdarm angeregt, sich zu entleeren. 
                        Das ist der so genannte &#187;gastrokolische Reflex&#171; (gaster = Bauch (gr.)  
                        &ndash; wird in vielen Wortkombinationen mit dem Magen in Verbindung gebracht, 
                        Kolon = Darm (gr.)). Dieser Reflex funktioniert optimal, wenn der Stuhl, der sich 
                        im Dickdarm befindet, eine gute Konsistenz und ein angemessenes Volumen hat und 
                        wenn die Darmperistaltik &ndash; also die Darmbewegungen &ndash; ausreichend arbeitet. 
                        <br />
                        <br />
                        Wenn Sie möchten, schauen Sie sich zur Aufheiterung doch einmal den 
                        köstlichen <a href="https://www.youtube.com/watch?v=Lob7Sdxs3b0" target="_blank">Film von Otto Waalkes</a> 
                        zum Thema Reizweiterleitung an.
                        <br />
                        <br />
                        Einem weiteren, sehr kurzweiligen <a href="http://www.youtube.com/watch?v=iC0LbBQunjY" target="_blank">Beitrag 
                        über das &#187;Darmrohr&#171;</a> von Giulia Enders kann ich Ihnen ebenfalls 
                        sehr empfehlen. Sie belegte im 6. Freiburger Science Slam zu Recht damit den 1. Platz.
                        <br />
                        <a id="beschwerden"></a>
                        <hr />
                        <h5>Beschwerden bei gestörter Verdauung</h5>
                        <hr />
                        Wenn einer oder gar mehrere der o.a. Parameter gestört sind, gibt es Probleme. 
                        Ist beispielsweise zu wenig Volumen vorhanden, weil die &#187;falschen&#171; 
                        Nahrungsmittel verzehrt werden, ist der Stuhl zu sehr eingedickt, weil er aus 
                        verschiedenen Gründen zu lange im Dickdarm verweilt. Und wenn der Darm träge 
                        und faul geworden ist, ist das empfindliche System gestört. 
                        <br />
                        <br />
                        Es kann jedoch auch das Gegenteil eintreten: Durch vielerlei Störungen können 
                        Durchfälle auftreten, und es wird vermehrt und vor allem zu dünner Stuhl 
                        auch ohne diesen Reflex abgesetzt.
                        <br />
                        <a id="verstopfung">&nbsp;</a>
                        <br />
                        <br />
                        <b>&#149; Verstopfung</b>
                        <br />
                        Die häufigste Verdauungsstörung ist die Verstopfung. Nicht nur falsche 
                        Essgewohnheiten mit zu wenig Ballaststoffen führt zu Verstopfung, auch mangelnde 
                        Flüssigkeitsaufnahme und mangelnde Bewegung kann dazu führen, dass der 
                        Stuhl zu lange im Dickdarm liegt. Der Dickdarm hat &ndash; wie sein Name sagt &ndash; 
                        die Aufgabe, den dünnflüssigen Nahrungsbrei aus dem Dünndarm einzudicken. 
                        Wenn dieser Nahrungsbrei zu wenig Masse hat, verbleibt er zu lange im Dickdarm, der 
                        den Stuhl nun zu sehr eindickt und verfestigt, mit dem Ergebnis, dass der Weitertransport 
                        erschwert wird und der Stuhl nun noch langsamer transportiert wird &ndash; ein 
                        Teufelskreis beginnt. 
                        <br />
                        <br />
                        Auch eine zu geringe Trinkmenge dickt den Stuhl weiter ein, und leider ist dieser 
                        simple Zusammenhang den wenigsten Menschen mit Verstopfung bewusst.
                        <br />
                        <br />
                        Darüber hinaus kann die Darmperistaltik durch vielerlei Faktoren verlangsamt 
                        sein: Allen voran ist mangelnde körperliche Bewegung einer der Hauptgründe 
                        für die Verstopfung. Die Bauchmuskulatur, die bei sportlicher Betätigung, 
                        aber auch schon bei einem einfachen Spaziergang in Bewegung ist, reizt auch die 
                        Darmmuskulatur zu gesunder Bewegung. Und nur eine fleißige Darmperistaltik 
                        kann den Stuhl durch den Darm zum Ausgang befördern und zu einem regelmäßigen 
                        Stuhlgang führen.
                        <br />
                        <br />
                        Zusätzlich neigt leider im Alter, aber durch hormonelle Bedingungen auch in 
                        der Schwangerschaft, dem Zeitpunkt rund um die Menstruation und nach den Wechseljahren 
                        der Darm häufiger zu Trägheit. Und auch Medikamente (z.B. Schmerzmittel, 
                        wassertreibende Mittel oder Blutdrucksenker) können die Darmtätigkeit 
                        beeinträchtigen.
                        <br />
                        <br />
                        Die wiederholte Unterdrückung des Stuhldrangs kann ein &Uuml;briges tun, eine regelmäßige 
                        Verdauung zu verhindern und Verstopfung zu erzeugen. Dies ist besonders oft bei 
                        Lastwagenfahrern, Berufspendlern, Lehrern und ähnlichen Berufsgruppen oder 
                        auch bei Reisenden zu beobachten, die öfter verhindert sind, bei Stuhldrang 
                        sofort die Toilette aufsuchen zu können.
                        <br />
                        <br />
                        Und last, but not least, kann auch Stress zu Verstopfung führen, denn das 
                        oben erwähnte &#187;Bauchhirn&#171; ist ein sehr empfindliches Organ, das 
                        Störungen genau registriert und sehr leicht Fehlfunktionen auslösen kann.
                        <br />
                        <a id="durchfall">&nbsp;</a>
                        <br />
                        <br />
                        <b>&#149; Durchfall</b>
                        <br />
                        Statt Verstopfung kann auch das genaue Gegenteil eintreten &ndash; Durchfall. 
                        Es gibt hier viele Gründe: Wenn die Stuhlpassage aus verschiedenen 
                        Gründen beschleunigt ist, hat der Dickdarm zuwenig Zeit zum Eindicken des 
                        Stuhls. Weiterhin kann eine ungünstige Zusammensetzung wie z.B. ein zu hoher 
                        Säuregrad den Dickdarm reizen. Hier gibt dann die Schleimhaut Flüssigkeit 
                        in den Nahrungsbrei ab, anstatt sie zu entziehen. 
                        <br />
                        <br />
                        Und natürlich können auch verdorbene Lebensmittel mit einen hohen Gehalt 
                        an krankmachenden Bakterien oder Viren Durchfall erzeugen &ndash; jeder kennt mit 
                        Sicherheit &#187;Montezumas Rache&#171;, die heftige Durchfallerkrankung, die auf 
                        Reisen nach dem Genuss unsauberer Lebensmittel oder Wasser auftreten kann.
                        <br />
                        <br />
                        Unverträglichkeiten bestimmter Nahrungsmittelbestandteile, die nicht korrekt 
                        verdaut werden können, wenn verschiedene Verdauungsenzyme fehlen, können 
                        ebenfalls zu wiederkehrenden Durchfällen führen. Medikamente sind 
                        zusätzlich häufig für Durchfälle verantwortlich &ndash; eine 
                        auf den Beipackzetteln bei vielen Präparaten aufgeführte Nebenwirkung.
                        <br />
                        <br />
                        Und &ndash; wie auch bereits bei der Verstopfung erwähnt &ndash; kann Stress 
                        das Bauchhirn irritieren und statt zu einer verlangsamten Verdauung zu deren 
                        Beschleunigung führen.
                        <br />
                        <a id="blaehungen">&nbsp;</a>
                        <br />
                        <br />
                        <b>&#149; Blähungen</b>
                        <br />
                        Wenn die Verdauung nicht richtig funktioniert, Nahrungsbestandteile nicht korrekt 
                        enzymatisch verarbeitet werden oder aber die Darmflora geschädigt ist, 
                        können leicht Blähungen auftreten. Hier sammeln sich Gase im Darm und 
                        blähen diesen auf. Die Gase können zum Teil über die Darmschleimhaut 
                        und das Blut an die Lunge geleitet und dort &#187;entsorgt&#171; werden, zum anderen 
                        Teil entweichen Sie aber auch als Darmwinde.
                        <br />
                        <a id="bauchschmerzen">&nbsp;</a>
                        <br />
                        <br />
                        <b>&#149; Bauchschmerzen/Krämpfe</b>
                        <br />
                        Alle zuvor geschilderten Probleme können zu Bauchschmerzen führen &ndash; 
                        von einem kaum merklichen &#187;Ziepen&#171; bis hin zu heftigen Bauchkrämpfen. 
                        Wenn der Darm durch eine zu große Füllung überdehnt ist, wenn er 
                        durch Gase aufgebläht oder durch Säuren gereizt ist, wenn die Darmperistaltik 
                        zu heftig ist, wird dies vom Bauchhirn weitergeleitet und als mehr oder weniger 
                        intensiver Schmerz registriert, wobei die Schmerzwahrnehmung individuell unterschiedlich 
                        sein kann.
                        <br />
                        <a id="behandlung">&nbsp;</a>
                        <br />
                        <hr />
                        <h5>Behandlungsmöglichkeiten</h5>
                        <hr />
                        Die meisten Verdauungsbeschwerden können Sie recht einfach selbst behandeln 
                        und beheben, da Sie nun die Zusammenhänge kennengelernt und die Verursacher 
                        ausgemacht haben.
                        <br />
                        <a id="abfuehrmittel">&nbsp;</a>
                        <br />
                        <br />
                        <b>&#149; Abführmittel</b>
                        <br />
                        Auf jeden Fall sollten Sie es soweit wie möglich vermeiden, Abführmittel 
                        zu nehmen! Es gibt verschiedene Wirkprinzipien: So gibt es Mittel, die die 
                        Darmperistaltik steigern und so zu einem schnelleren Transfer führen. Weiterhin 
                        gibt es Mittel, die unverdaubare Kohlenhydrate enthalten, die dann von der Darmflora 
                        zersetzt werden, wobei Stoffe entstehen, die die Darmschleimhaut reizen und so 
                        zu vermehrter Flüssigkeitsabgabe in den Darm führen. Und es gibt Quellstoffe, 
                        die das Stuhlvolumen erhöhen. 
                        <br />
                        <br />
                        Abführmittel führen letztendlich immer zu einer Gewöhnung, und immer 
                        größere Mengen werden erforderlich. Weiterhin sind die Wirkstoffe teilweise 
                        auf Dauer schädlich, so dass die Einnahme eines Abführmittels wirklich 
                        nur eine allerletzte Notlösung sein darf.
                        <br />
                        <a id="reisedurchfall">&nbsp;</a>
                        <br />
                        <br />
                        <b>&#149; Stoppen von Reisedurchfall</b>
                        <br />
                        Durchfall ist die vom Körper vorgesehene Lösung, schädliche Stoffe 
                        loswerden zu wollen &ndash; und somit sinnvoll. Früher gaben die &Auml;rzte bei
                        Durchfall abführende Mittel, um diese Reinigung zu unterstützen. 
                        Heute, insbesondere bei heftigen, durch verseuchte Lebensmittel verursachte Durchfälle 
                        im Urlaub, wenn jeder Reisetag genossen werden will, nehmen wir Mittel zum Stoppen 
                        der Durchfälle. Eigentlich ist dies der falsche Weg, denn es bewirkt einen 
                        längeren Verbleib der schädlichen Stoffe oder Krankheitserreger im Darm.
                        In Ausnahmefällen sind solche Mittel für wenige Tage akzeptabel. 
                        <br />
                        <br />
                        Lesen Sie hierzu auch den Beitrag &#187;<a href="ganz-reisedurchfall">Reisedurchfall</a>&#171;.
                        <br />
                        <br />
                        <b>Hinweis:</b> Bei sehr heftigen und vor allem längerfristigen Durchfällen &ndash; 
                        insbesondere, wenn Sie gleichzeitig erbrechen müssen &ndash; suchen Sie unbedingt einen Arzt auf!
                        <br />
                        <br />
                        Normale Durchfälle, die durch unverträgliche Nahrungsmittel hervorgerufen 
                        werden, behandelt man ganz  einfach durch das Weglassen der betreffenden Nahrungsmittel.
                        <br />
                        <a id="trinkmenge">&nbsp;</a>
                        <br />
                        <br />
                        <b>&#149; Trinkmenge</b>
                        <br />
                        Ganz wichtig ist es für eine gesunde Verdauung, genügend zu trinken. Nur 
                        durch eine ausreichende Flüssigkeitsbeigabe kann der Nahrungsbrei die richtige 
                        Konsistenz erreichen. Sollten Sie ab und zu an Verstopfung leiden, ist ausreichendes 
                        Trinken immer das erste Mittel der Wahl. Geeignete Getränke sind hier Wasser 
                        (still oder mit (wenig) Kohlensäure), Kräuter- oder Früchtetee und 
                        Fruchtsaftschorlen. Kaffee und Schwarztee sind nur in Maßen geeignet &ndash; 
                        sie sind als Genussmittel zu betrachten. Weniger geeignet sind gesüßte 
                        Getränke, Milch und natürlich alkoholische Getränke. 
                        <br />
                        <br />
                        Die tägliche Trinkmenge sollte mindestens 1,5 &ndash; 2 Liter betragen, im 
                        Sommer oder bei sportlichen Aktivitäten ist sie den Gegebenheiten entsprechend 
                        zu erhöhen - ein Zuviel gibt es nicht.
                        <br />
                        <a id="ballaststoffe">&nbsp;</a>
                        <br />
                        <br />
                        <b>&#149; Ballaststoffe</b>
                        <br />
                        Eine gute Möglichkeit, den trägen Darm zu aktivieren, ist der Verzehr 
                        von Ballaststoffen. Diese sind Stoffe, die der Körper nicht verdauen kann. 
                        Somit wird das Stuhlvolumen vergrößert, wodurch die Passagezeit verringert 
                        wird. Ballaststoffe sind in allen pflanzlichen Nahrungsmitteln in mehr oder weniger 
                        großen Anteilen enthalten. Es gibt lösliche Ballaststoffe, die sich durch 
                        ihr Wasserbindungsvermögen auszeichnen und im Dickdarm vielen nützlichen 
                        Bakterien verstoffwechselt werden und der Darmflora als &#187;Futter&#171; dienen. 
                        Eine Darmflora, die reich an nützlichen Bakterien ist, verhilft zu einer gesunden 
                        Verdauung. Wasserlösliche Ballaststoffe finden sich in vielen Obst- und 
                        Gemüsesorten wie z.B. in &Auml;pfeln.
                        <br />
                        <br />
                        Weiterhin gibt es wasserunlösliche Ballaststoffe (Zellulose und Hemizellulose), 
                        die sich in den Zellwänden von Pflanzen und Körnern befinden. Diese 
                        quellen auf und vergrößern das Stuhlvolumen, außerdem pflegen sie 
                        wie ein Peeling die Darmschleimhaut und sorgen für eine Verjüngung der 
                        Zellen. Eine gesunde Darmschleimhaut begünstigt ebenfalls eine geregelte 
                        Verdauung.
                        <br />
                        <br />
                        <b>Hinweis</b>: Beachten Sie bitte, dass ein erhöhter Verzehr von Ballaststoffen auch immer 
                        <b>eine erhöhte Trinkmenge</b> erfordert &ndash; die Flüssigkeitsmenge, 
                        die die Ballaststoffe beim Quellen aufnehmen, muss zusätzlich zugeführt 
                        werden.
                        <br />
                        <a id="ernaehrung">&nbsp;</a>
                        <br />
                        <br />
                        <b>&#149; Gesunde Ernährung</b>
                        <br />
                        Es wird viel geschrieben, wie viel Gramm Ballaststoffe für eine gesunde 
                        Verdauung förderlich sein sollen &ndash; all dies ist aber sehr theoretisch 
                        und macht wenig Spaß. Bereichern Sie einfach Ihren Speisezettel mit soviel 
                        gesundem, frischen Gemüse und Obst wie möglich, teilweise als Rohkost, 
                        zum Teil aber auch ruhig zu leckeren warmen Gerichten verarbeitet. Verzehren Sie 
                        Getreideprodukte wie Müsli, Nudeln und Brot &ndash; diese bitte möglichst 
                        immer in der Vollkorn-Variante und gerne ab und an mit verschiedenen Saaten wie 
                        Sesam, Leinsamen, Sonnenblumen- oder Kürbiskernen angereichert. So ergänzen 
                        Sie Ihre Nahrung ganz automatisch mit einer ausreichenden Menge an Ballaststoffen 
                        &ndash; zählen und wiegen ist dann nicht erforderlich.
                        <br />
                        <br />
                        Vermeiden Sie weitestgehend industriell hochbearbeitete Fertigprodukte, die in den 
                        meisten Fällen sehr ballaststoffarm sind. Auch der Fleischverzehr kann 
                        bedenkenlos auf ein bis zwei Fleischmahlzeiten pro Woche reduziert werden &ndash; 
                        eine Mangelversorgung mit Eiweiß oder den in Fleisch enthaltenen Vitaminen 
                        ist nicht zu befürchten.
                        <br />
                        <br />
                        <b>Hinweis</b>: Die Umstellung auf eine ballaststoffreiche Ernährung sollte 
                        langsam durchgeführt werden, da sich Darm und Darmflora umstellen und an die 
                        neue Kost gewöhnen müssen. Bei einer abrupten Umstellung können 
                        leicht Blähungen und ggf. sogar Durchfälle auftreten. Deshalb ist es 
                        besser, wenn Sie Ihrem Darm etwas Zeit geben und die Verzehrmengen nach und nach 
                        steigern.
                        <br />
                        <a id="bewegung">&nbsp;</a>
                        <br />
                        <br />
                        <b>&#149; Bewegung </b>
                        <br />
                        Eine weitere wichtige Maßnahme für eine gesunde Verdauung ist Bewegung. 
                        Wie oben erwähnt, führt mangelnde körperliche Bewegung zu Verstopfung. 
                        Wenn Sie den ganzen Tag am Schreibtisch sitzen, womöglich noch mit eingeklemmtem 
                        Bauch, muss der Darm einschlafen. Somit gilt der Rat, sich körperlich zu bewegen, 
                        sei es durch eine oder mehrere verschiedenen Sportarten oder aber einfach nur durch 
                        einen Spaziergang an der frischen Luft. Je wohler Sie sich dabei fühlen, desto 
                        besser, denn eine gesunde Verdauung ist durchaus auch seelisch (mit-)bedingt. 
                        Und wenn mal gar keine Zeit für sportliche Betätigungen bleibt, kann 
                        auch schon mal ein kräftiges Recken und Strecken und tiefes Durchatmen als 
                        kleiner Ersatz dienen.
                        <br />
                        <a id="stressvermeidung">&nbsp;</a>
                        <br />
                        <br />
                        <b>&#149; Stressvermeidung</b>
                        <br />
                        Stress wurde bereits oben als Verursacher für Verdauungsbeschwerden ausgemacht. 
                        Somit sollten Sie negativen Stress vermeiden, soweit es sich einrichten lässt. 
                        Sollte es allerdings doch manchmal hektischer zugehen, versuchen Sie, diesen Stress 
                        zu kompensieren, indem Sie Entspannungsübungen durchführen. Es bieten 
                        sich hier Autogenes Training, Progressive Muskelentspannung, Qui Gong und viele 
                        weitere Techniken an, die Sie großteilig u.a. in der Volkshochschule erlernen 
                        können.
                        <br />
                        <a id="zeiterziehung">&nbsp;</a>
                        <br />
                        <br />
                        <b>&#149; Zeiterziehung</b>
                        <br />
                        Wenn Sie diese Ratschläge beherzigen, sollte einem gesunden, wohlgeformten 
                        und regelmäßigen Stuhlgang nichts im Wege stehen. Trainieren Sie Ihren 
                        Darm, sich regelmäßig zu leeren, indem Sie immer zur gleichen Zeit &ndash; 
                        z.B. morgens nach einem ersten Frühstück &ndash; die Toilette aufsuchen. 
                        Nehmen Sie sich dort genügend Zeit für diesen &#187;Stuhlgang&#171;, 
                        denn nichts ist abträglicher als Hetze.
                        <br />
                        <br />
                        <b>Wichtiger Hinweis</b>: Sollten Sie an länger andauernden und heftigen Verdauungsproblemen 
                        leiden, die sich durch diese Ratschläge nicht bessern, suchen Sie einen Arzt auf. 
                        Vor allem aber, wenn Sie Blut im Stuhl feststellen, vereinbaren Sie bitte <b>umgehend </b>
                        einen Arzttermin.
                        <br />
                        <br />
                        <hr>
                        <br />
                        <a href="guterrat" target="_blank"><img src="<?php echo IMG_PATH; ?>hilfreich.png" alt="" class="left" /></a>
                        <br />
                        <br />
                        <hr>
                        <a id="beratung">&nbsp;</a>
                        <div class="row">
                        <div class="col s12 m2">
                            <a href="http://www.ganzheitliche-gesundheitsberatung.de" target="_blank">
                                <img src="<?php echo IMG_PATH; ?>praxiswebsite.png" alt="" class="inline" /></a>
                        </div>
                        </div>
                        <div class="row">
                        <div class="col s12 m12">
                        <h5>Beratung</h5>
                        <br />
                            Gerne biete ich Ihnen eine individuelle Beratung an &ndash; 
                            auf Wunsch auch telefonisch oder per Skype.
                            <br />
                            Bitte informieren Sie sich auf meiner Praxis-Website <a href="http://www.ganzheitliche-gesundheitsberatung.de" target="_blank">&#187;www.Ganzheitliche-Gesundheitsberatung.de&#171;</a>
                        </div>
                        </div>
                        <hr>
                        <br />
                        <b>Lesen Sie auch folgende Beträge:</b>
                        <br />
                        <a href="darmgesundheit">&#149; Darmpflege: Gesunder Darm &ndash; gesunder Mensch</a>
                        <br />
                        <a href="darmschleimhaut">&#149; Pflege der Darmschleimhaut</a>
                        <br />
                        <a href="darmflora">&#149; Pflege der Darmflora</a>
                        <br />
                        <a href="darmsanierung">&#149; Sanierung der Darmflora</a>
                        <br />
                        <a href="ganz-gaergetraenke">&#149; Probiotische Gärgetränke</a>
                        <br />
                        <br />
                        <hr />
                        <a href="javascript: scrollMainToTop();" class="nachoben">nach oben</a>
                    </div>
                </div>
            </div>    
            <br>
            <br> 
            <div class="bodyspacer"></div> 
        </div>