<?php
    header('Access-Control-Allow-Origin: *');  	
?>
                    <div class="col s12 m12"> 
                        <a href="basket" class="btn btn-secondary basketbutton">
                            <?php 
                                $entries = array();
                                if(isset($_COOKIE['shopcookie'])) {
                                    $entries = getCartEntriesByToken($_COOKIE['shopcookie']); 
                                }
                            ?>
                            Warenkorb: (<?php echo count($entries); ?> Artikel)
                        </a>
                    </div>