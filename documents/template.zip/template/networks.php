        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br /> 
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>
                <h1 class="header center orange-text">Social Networks</h1>      
                <div class="row center">        
                    <h5 class="header col s12 light">Besuchen Sie mich doch auch einmal im Social Network.</h5>      
                </div>
            </div>  
        </div> 
        <div class="container">    
            <div class="section">   
                <div class="row margintoprow">        
                    <div class="col s12 m12">
                    Zugegeben: Ich bin kein sehr fleißiger Besucher der sozialen Netzwerke. 
                    Aber gelegentlich bin auch ich dort zu Gast und habe meine eigenen Auftritte. 
                    Wenn Sie mögen, können Sie mich also auch dort finden.
                    <b>Wenn Sie mich kontaktieren wollen, nutzen Sie aber bitte ausschließlich 
                    die Möglichkeiten über diese Website.</b>
                    <br />
                    <br />
                    </div>
                    <div class="col s12 m12">
                        Natürlich freue ich mich aber über jedes 
                        <a href="http://www.facebook.com/www.dorispaas.de" target="_blank"><img src="<?php echo IMG_PATH; ?>network-facebook-daumen.png" alt="" /></a>
                    </div>
                    </div>
                <div class="row">        
                    <div class="col s12 m12">
                    <hr />
                    </div>
                    </div>
                <div class="row">        
                    <div class="col s12 m4">
                        <a href="http://www.facebook.com/www.dorispaas.de" target="_blank">
                            <img src="<?php echo IMG_PATH; ?>network-facebook-gross.png" alt="Facebook" />
                        </a><br />
                        Sie finden mich bei Facebook,
                    </div>
                    </div>
                    </div>
                <div class="row">        
                    <div class="col s12 m4">
                        <a href="https://www.xing.com/profile/Doris_Paas?sc_o=mxb_p" target="_blank">
                            <img src="<?php echo IMG_PATH; ?>network-xing-gross.png" alt="Xing" />
                        </a><br />
                        bei Xing
                    </div>
                    </div>
                <div class="row">        
                <div class="row">        
                    <div class="col s12 m4">
                        <a href="http://www.yelp.de/biz/doris-paas-praxis-f%C3%BCr-ganzheitliche-gesundheitsberatung-und-troisdorf" target="_blank">
                            <img src="<?php echo IMG_PATH; ?>network-yelp.png" alt="Yelp" />
                        </a><br />
                        und bei Yelp.
                    </div>
                </div>
                        <br />
                <div class="row">        
                    <div class="col s12 m3">
                        <a href="http://www.gutefrage.net/nutzer/DorisPaas/antworten/neue/1" target="_blank" class="left"><img src="<?php echo IMG_PATH; ?>network-gutefrage.png" alt="GuteFrage" /></a>
                        <br />
                        <br />
                        Bei der Ratgeber-Community &#187;Gutefrage.net&#171;</a> k&ouml;nnen Sie meine Antworten mit einem Klick auf den Silber-Fragant-Button finden.
                    </div>
                        <br />
                        <br />
                        <br />
                        <br />
                </div>
            </div>    
            <br>
            <br> 
            <div class="bodyspacer"></div> 
        </div>