        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">        
                <br />
                <br /> 
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>  
                <h1 class="header center orange-text">Doris Paas</h1>      
                <div class="row center">        
                    <h5 class="header col s12">Ernährungs- und Gesundheitspädagogin</h5>      
                </div>      
            </div>  
        </div> 
        <div class="container">    
            <div class="section">      
                <!--   Icon Section   -->      
                <div class="row relative-row">        
                    <div class="col s12 m6 height100">          
                        <div class="icon-block height100">
                            <div class="video-wrapper">
                                <iframe src="//player.vimeo.com/video/233650472" <?= ( strpos( strtolower( $_SERVER[ "HTTP_USER_AGENT" ] ), "webkit" ) !== FALSE ) ? "webkitallowfullscreen" : ( ( strpos( strtolower( $_SERVER[ "HTTP_USER_AGENT" ] ), "gecko" ) !== FALSE ) ? "mozallowfullscreen" : "allowfullscreen" ) ?>></iframe>        
                            </div>
                        </div>        
                    </div>  
                </div>
                <div class="row margintoprow">
                    <div class="col s12 m3">
                        <ul class="nav">
                            <li>
                                <b>Abschnitte dieser Seite:</b>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>index#nmu">Nahrungsmittel-Unverträglichkeiten <br />und Darmgesundheit</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>index#datenbank">DorisPaas.de &ndash; Lebensmittel-Datenbank</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>index#buecher">Bücher</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>index#videos">Videos, Tutorials, Radio- und TV-Beiträge</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>index#downloads">Kostenlose Downloads</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>index#studien">Studien</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>index#blog">Blog</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>index#beratung">Individuelle Beratung</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>index#werbefrei">Werbefreie Website</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>index#browser">Browseroptimierung</a>
                            </li> 
                        </ul>
                    </div>
                    <div class="col s12 m9">          
                        <div class="icon-block">        
                            <p class="light">
                                Laktose-Intoleranz, Fruktose-Intoleranz (Fruktosemalabsorption), 
                                Sorbit-Intoleranz, Histamin-Intoleranz, Salicylat- (Salicylsäure-) und 
                                Oligosaccharid-Intoleranz &ndash; diese 
                                Nahrungsmittel-Unverträglichkeiten, Nahrungsmittel-Allergien, das Reizdarm-Syndrom 
                                und das brandaktuelle Thema &#187;Dünndarmfehlbesiedelung (SIBO)&#171;
                                sind die Hauptthemen dieser Website. Weiterhin soll sie Fragen über 
                                gesunde Ernährung und gesunde Verdauung beantworten und stellt Ihnen diverse 
                                Vorlagen zum kostenlosen Download bereit. Und natürlich können Sie sich 
                                hier ausführlich über meine Bücher zu diesen Themen informieren und diese bestellen.
                                <br />
                                <br />
                                Liebe Besucher, ganz herzlich willkommen! 
                                Ich hoffe, Sie finden viel Interessantes beim Stöbern durch diese Seiten und wünsche 
                                Ihnen alles Gute. Wenn Sie Anregungen, Fragen oder konstruktive Kritik haben, freue 
                                ich mich über eine <a href="email-anfrage">Nachricht</a> von Ihnen.
                                <br />
                                <br />
                                Herzlichst Ihre
                                <br />
                                Doris Paas
                                <br />
                                <i>Ernährungs- und Gesundheitspädagogin</i>
                            </p>          
                        </div>        
                    </div>     
                </div>
                
                <div class="row">
                    <div class="col s12 m12">
                        <a id="nmu"></a>
                        <hr />
                        <h5>Nahrungsmittel-Unverträglichkeiten und Darmgesundheit</h5>
                        <hr />
                    </div>
                </div>

                <div class="row">
                    <div class="col s12 m2">          
                        <img src="<?php echo IMG_PATH; ?>home-FAQ-small.png" alt="home FAQ small" class="section-img" />
                    </div>
                    <div class="col s12 m10">          
                        Unter dem Menüpunkt &#187;<a href="wissensdatenbank">Wissensdatenbank</a>&#171; 
                        erhalten Sie eine Fülle von Informationen zum Thema Nahrungsmittel-Unverträglichkeiten 
                        und -Allergien und zum Reizdarm-Syndrom.  Alle diese Themen werden hier 
                        ausführlich thematisiert und aus ganzheitlicher Sicht betrachtet und bewertet.
                        <br />
                        Zusätzlich gibt es verschiedene Lexika, in denen Sie alphabetisch 
                        geordnete Begriffserklärungen suchen und finden können.
                        Derzeit ist ein Lexikon aller <a href="lexikon-li-begriffe">Begriffe 
                        im Zusammenhang mit der Laktose-Intoleranz</a>, ein ein Lexikon der 
                        <a href="lexikon-darmerkrankungen">Darmerkrankungen</a>, ein Lexikon der 
                        <a href="lexikon-naturheilmethoden">Naturheilmethoden</a>
                         und ein Lexikon aller 
                        <a href="lexikonzucker">Zuckerarten und Süßungsmittel</a> 
                        eingestellt &ndash; aber weitere sind in Arbeit und werden folgen.
                        Wenn Sie einen Begriff vermissen, können Sie mir gerne eine <a href="email-anfrage" target="_blank">eMail-Nachricht</a> senden.
                        <br />                
                        Auf der Seite <a href="faq">Fragen &amp; Antworten</a> 
                        werden kontinuierlich Fragen und die zugehörigen Antworten veröffentlicht, 
                        die an mich gestellt wurden und die ich 
                        für allgemein interessant halte. Schauen Sie ruhig ab und an mal vorbei.  
                        Wenn Sie selbst ein Frage zu Nahrungsmittel-Unverträglichkeiten, 
                        Nahrungsmittel-Allergien oder zum Reizdarm-Syndrom haben, können Sie mir 
                        diese gerne zusenden. Sie haben die Möglichkeit, im Shop die 
                        &#187;<a href="shop#beratung-email">Beantwortung einer eMail-Anfrage</a>&#171; zu buchen.
                    </div>
                </div>
                
                <div class="row">
                    <div class="col s12 m12">
                        <a id="datenbank"></a>
                        <hr />
                        <h5>DorisPaas.de &ndash; Lebensmittel-Datenbank</h5>
                        <hr />
                    </div>
                </div>
                
                <div class="row">
                    <div class="col s12 m2">          
                        <img src="<?php echo IMG_PATH; ?>lebensmitteldatenbank.png" alt="DorisPaas.de &ndash; Lebensmittel-Datenbank" class="section-img" />
                    </div>
                    <div class="col s12 m10">          
                        Leiden Sie an <b>mehreren</b> Nahrungsmittel-Unverträglichkeiten 
                        und haben sich schon immer gewünscht, eine Liste zur Verfügung zu haben, in 
                        der Sie alle Ihre verträglichen Nahrungsmittel <b>auf einen Blick</b> auswählen 
                        können? Eine Liste, die darüber hinaus auch noch über den FODMAP-Gehalt 
                        aller dieser Lebensmittel Auskunft gibt?
                        <br />
                        Mit der <b>DorisPaas.de &ndash; Lebensmittel-Datenbank</b> haben Sie jetzt 
                        diese Möglichkeit!
                        <br />
                        Sie finden hier <b>weit mehr als Tausend Lebenmittel</b>, unter denen Sie 
                        Ihre verträglichen, aber auch die unverträglichen mit einem Klick 
                        herausfiltern und gleichzeitig den Gehalt an FODMAPS erkennen können.
                    </div>
                </div>
                
                <div class="row">
                    <div class="col s12 m12">
                        <a id="buecher"></a>
                        <hr />
                        <h5>Bücher</h5>
                        <hr />
                    </div>
                </div>

                <div class="row">
                    <div class="col s12 m2">          
                        <img src="<?php echo IMG_PATH; ?>home-book-ddfb-small.png" alt="home book-ddfb small" class="section-img" />
                    </div>
                    <div class="col s12 m10">          
                        Sie leiden immer wieder unter Verdauungsproblemen wie Bauchschmerzen, einem 
                        aufgeblähten Bauch und Völlegefühl und können diese Symptome kaum mit 
                        bestimmten verzehrten Lebensmitteln in direkte Verbindung bringen? 
                        Dann besteht besteht die Möglichkeit, dasss eine Dünndarmfehlbesiedelung 
                        vorliegt. 
                        <br />
                        Das Buch &#187;<b>DÜNNDARMFEHLBESIEDELUNG &ndash; ERKENNEN, VERSTEHEN, ERFOLGREICH BEHANDELN</b>&#171;
                        klärt Sie umfassend über die gesamte Problematik auf.
                        Sie finden hier eine ausführliche <a href="book-ddfb#buchbeschreibung">Buchbeschreibung</a> 
                        und das komplette <a href="book-ddfb#inhaltsverzeichnis">Inhaltsverzeichnis</a>,
                        damit Sie sich ein Bild machen können.
                        <br />
                        Dieser sorgfältig recherchierte, umfassende Titel richtet sich in erster Linie an die Betroffenen selbst, sollte 
                        aber auch in keiner ärztlichen Praxis und auf dem Schreibtisch von 
                        Heilpraktikern und Ernährungs- und Gesundheitsberatern fehlen.
                    </div>
                </div>
                <div class="row">
                    <div class="col s12 m12">          
                        <hr />
                    </div>
                </div>
                <div class="row">
                    <div class="col s12 m2">          
                        <img src="<?php echo IMG_PATH; ?>home-book-small.png" alt="home book small" class="section-img" />
                    </div>
                    <div class="col s12 m10">          
                        Gehören auch Sie zu den vielen Menschen (allein in Deutschland, 
                        in Österreich, in der Schweiz, in Luxemburg und in Liechtenstein sind es 
                        schätzungsweise 20 Millionen), die nach dem Genuss von milchzuckerhaltigen 
                        Speisen Verdauungsprobleme bekommen? Dann empfehle ich Ihnen DAS LAKTOSE-INTOLERANZ BUCH. 
                        Sie finden hier eine ausführliche <a href="book&amp;subpage=1">Buchbeschreibung</a>, 
                        weiterhin das komplette <a href="book&amp;subpage=2">Inhaltsverzeichnis</a> 
                        und <a href="read">Leseproben</a>.
                        <br />
                        <b>DAS LAKTOSE-INTOLERANZ BUCH</b> richtet sich in erster Linie an Betroffene 
                        und vermeidet aus diesem Grunde weitgehend unverständliche 
                        Fachausdrücke. Trotzdem ist es sorgfältig recherchiert und 
                        eignet sich deshalb auch für für 
                        <a href="med">Fachleute</a> in der ärztlichen 
                        Praxis und für Menschen aus Pflegebrufen oder für 
                        Ernährungsberater.
                    </div>
                </div>
                <div class="row">
                    <div class="col s12 m12">          
                        <hr />
                    </div>
                </div>
                <div class="row">
                    <div class="col s12 m2">          
                        <img src="<?php echo IMG_PATH; ?>home-book2-small.png" alt="home book2 small" class="section-img" />
                    </div>
                    <div class="col s12 m10">          
                        Leiden Sie unter unklaren Beschwerden wie Bauchschmerzen, Blähungen, Durchfällen 
                        oder Völlegefühl nach den Mahlzeiten? Dann liegt der Verdacht nahe, dass Sie 
                        an einer Nahrungsmittelallergie oder an einer Nahrungsmittelunverträglichkeit 
                        leiden. 
                        <br />
                        Das Buch <b>NAHRUNSMITTELALLERGIEN UND -UNVERTRäGLICHKEITEN</b> ist 
                        für alle diejenigen die geeignete Lektüre, die den wahren 
                        Grund ihrer Beschwerden abklären wollen. 
                        Sie erfahren hier alles über Ursachen und Auslöser, 
                        Symptome und Diagnosemethoden, Vorbeugemaßnahmen und 
                        Behandlungsmöglichkeiten der verschiedenen Nahrungsmittel-Unverträglichkeiten 
                        und von Nahrungsmittel-Allergien und lernen das Reizdarm-Syndrom kennen.
                        Viele Hinweise und Tipps zeigen Ihnen, wie Sie auch mit den daraus resultierenden 
                        Einschränkungen gut leben können.
                        Lesen Sie hier die <a href="book2&amp;subpage=1">Buchbeschreibung</a>.
                    </div>
                </div>
                <div class="row">
                    <div class="col s12 m12">          
                        <hr />
                    </div>
                </div>
                <div class="row">
                    <div class="col s12 m3">          
                        <img src="<?php echo IMG_PATH; ?>home-ph-klein-neu.png" alt="home ph klein" class="section-img" />
                    </div>
                    <div class="col s12 m9">
                        Die <b>PAAS&#039;SCHE HEFTCHENREIHE</b> richtet sich an all 
                        diejenigen Leser, die sich kurz und klar über
                        gesunde Ernährung, gesunde Verdauung, Milchzucker-Unverträglichkeit, 
                        Fruchtzucker-Unverträglichkeit, Oligosaccharid-Unverträglichkeit, Zöliakie 
                        und Gluten-Sensitivität oder über das Reizdarm-Syndrom 
                        informieren möchten. 
                        <br />
                        Die Heftchen eignen sich darüberhinaus gut zur 
                        Weitergabe an interessierte Familienmitglieder, Freunde, Arbeitskollegen 
                        oder auch an Kinder, die (noch) kein umfangreiches Sachbuch lesen wollen.
                        <br />
                        Sie stellen wesentlich mehr Informationen zur Verfügung als eine 
                        Info-Broschüre und verstehen sich somit als Vereinigung von Informations-Broschüre 
                        und Sachbuch. Die Paas&#039;schen Heftchen erheben bewusst keinen Anspruch auf Ausführlichkeit, sondern 
                        verschaffen Ihnen in kurzer, aber korrekter Form einen ersten überblick über das jeweilige Thema. 
                        Trotz des geringen Umfangs bleiben sie jedoch nicht oberflächlich, sondern sind sorgfältig 
                        recherchiert: In rund einer Stunde wissen Sie alles Wesentliche zum Thema.
                        <br />
                        <br />
                        In der PAAS&#039;SCHEN HEFTCHENREIHE sind bisher folgende 
                        Titel erschienen:
                        <br />
                        <a href="paas-heftchen-ge">Kurz und klar: Gesunde Ernährung</a>      
                        <br />
                        <a href="paas-heftchen-gv">Kurz und klar: Gesunde Verdauung</a>      
                        <br />
                        <a href="paas-heftchen-mu">Kurz und klar: Milchzucker-Unverträglichkeit</a>      
                        <br />
                        <a href="paas-heftchen-fu">Kurz und klar: Fruchtzucker-Unverträglichkeit</a>      
                        <br />
                        <a href="paas-heftchen-oi">Kurz und klar: Oligosaccharid-Unverträglichkeit</a>      
                        <br />
                        <a href="paas-heftchen-gluten">Kurz und klar: Zöliakie und Gluten-Sensitivität</a>      
                        <br />
                        <a href="paas-heftchen-kinderzoeliakie">Kurz und klar: Mein Kind hat Zöliakie</a>      
                        <br />
                        <a href="paas-heftchen-rds">Kurz und klar: Reizdarm-Syndrom</a> 
                    </div>
                </div>
                <div class="row">
                    <div class="col s12 m12">
                        <a id="videos"></a>
                        <hr />
                        <h5>Videos, Tutorials, Radio- und TV-Beiträge</h5>
                        <hr />
                    </div>
                </div>

                <div class="row">
                    <div class="col s12 m2">          
                        <img src="<?php echo IMG_PATH; ?>videobutton.png" alt="home video small" class="section-img" />
                    </div>
                    <div class="col s12 m10">
                        Sind Sie ein &#187;visueller Typ&#171; und wünschen sich 
                        manchmal, Sachverhalte in kurzen Videos eindrucksvoll und bildhaft 
                        erklärt zu bekommen?
                        <br />
                        Kein Problem! Es gibt hier einige <a href="videos" target="_blank">Videos</a>, die Ihnen genau das 
                        ermöglichen. Beispielsweise wird kurz und anschaulich 
                        erläutert, was Laktose-Intoleranz ist. Auch über die 
                        Zöliakie gibt es ein Video, und einige weitere sind in Arbeit.
                        <br />
                        Zusätzlich gibt es Videos, in denen <a href="rezepte" target="_blank">Rezepte</a> für leckere 
                        Gerichte vorgestellt werden &ndash; für jeden Geschmack ist 
                        etwas dabei. 
                        <br />
                        Zusätzlich habe ich Links zu <a href="tv-beitraege" target="_blank">Radio- 
                        und TV-Beiträgen</a>, in denen ich zu bestimmten Sachverhalten 
                        interviewt wurde, für Sie zusammengestellt. Sie sind ganz herzlich 
                        eingeladen, sich diese anzuschauen bzw. anzuhören.
                    </div>
                </div>
                <div class="row">
                    <div class="col s12 m12">
                        <a id="downloads"></a>
                        <hr />
                        <h5>Kostenlose Downloads</h5>
                        <hr />
                    </div>
                </div>
                <div class="row">
                    <div class="col s12 m2">          
                        <img src="<?php echo IMG_PATH; ?>Selbstdiagnose-vorne.png" alt="Selbstdiagnose vorne" class="section-img" />
                    </div>
                    <div class="col s12 m10">
                        Leiden Sie häufig unter Verdauungsbeschwerden wie Bauchgrummeln, 
                        Bauchschmerzen oder sogar unter Durchfällen, Blähungen 
                        oder Völlegefühl? Und haben Sie die Vermutung, dies könnte 
                        eventuell mit bestimmten Nahrungsmitteln wie Milch und Milchprodukten 
                        oder auch Obst und Gemüse zusammenhängen?
                        <br />
                        Mithilfe eines einfachen Fragebogens können Sie einen Selbsttest machen. 
                        <br />
                        Und mit einer Vorlage für ein Verzehrtagebuch können Sie 
                        Ihre &#187;Selbstdiagnose&#171; untermauern.
                        <br />
                        Diese und weitere Vorlagen stehen Ihnen kostenlos unter dem Menüpunkt 
                        &#187;<a href="downloads">Downloads</a>&#171; 
                        zur Verfügung.
                    </div>
                </div>


                <div class="row">
                    <div class="col s12 m12">
                        <a id="studien"></a>
                        <hr />
                        <h5>Studien</h5>
                        <hr />
                    </div>
                </div>

                <div class="row">
                    <div class="col s12 m2">          
                        <img src="<?php echo IMG_PATH; ?>umfrage.png" alt="Umfrage" class="section-img" />
                    </div>
                    <div class="col s12 m10">          
                        <a href="probiotika">Studie zur Ermittlung der Wirksamkeit von Probiotika zur Anhebung der Laktose-Toleranzschwelle</a>
                        <br />
                        In der Zeit von Juli bis Dezember 2012 wurde eine Studie durchgeführt, 
                        die die Wirksamkeit von Probiotika zur Anhebung der Laktose-Toleranzschwelle 
                        ermitteln sollte. 
                        <br />
                        Hier gelangen Sie zur <a href="probiotika-studienauswertung">Auswertung der Probiotika-Studie</a>.
                        <br />
                        <br />
                        <a href="studienauswertung">Studie zur Ermittlung der Wirksamkeit von Laktase-Präparaten</a>
                        <br />
                        In der Zeit von Oktober 2010 bis Ende Juni 2012 wurde eine Studie zur 
                        Ermittlung der Wirksamkeit von Laktase-Präparaten durchgeführt.
                        <br />Hier gelangen Sie zur <a href="studienauswertung">Auswertung der Laktase-Studie</a>.
                    </div>
                </div>

                <div class="row">
                    <div class="col s12 m12">
                        <a id="blog"></a>
                        <hr />
                        <h5>Blog</h5>
                        <hr />
                    </div>
                </div>

                <div class="row">
                    <div class="col s12 m2">          
                        <img src="<?php echo IMG_PATH; ?>blog.png" alt="blog" class="section-img" />
                    </div>
                    <div class="col s12 m10">
                        Alle Welt bloggt! Nicht, dass ich nun auch unbedingt auf diesen Modezug
                        aufspringen möchte oder müsste &ndash; aber ich möchte 
                        Ihnen die Gelegenheit geben, mit einem Klick zu den Beiträgen 
                        zu gelangen, die ich an verschiedenen Stellen im World Wide Web zu den 
                        verschiedensten Themen veröffentliche. Seien Sie herzlich eingeladen, 
                        daran teilzuhaben und bei Bedarf auch gerne Ihre Meinung dazu kundzutun,
                        sich an den Diskussionen zu beteiligen und Ihre Kommentare hinzuzufügen.
                        <br />
                        <br />
                        <a href="blog">Hier gelangen Sie zum Blog</a>.
                    </div>
                </div>

                <div class="row">
                    <div class="col s12 m12">
                        <a id="beratung"></a>
                        <hr />
                        <h5>Individuelle Beratung</h5>
                        <hr />
                    </div>
                </div>

                <div class="row">
                    <div class="col s12 m2">          
                        <img src="<?php echo IMG_PATH; ?>praxiswillkommen-klein.png" alt="blog" class="section-img" />
                    </div>
                    <div class="col s12 m10">
                        Neben all den Informationen, die Sie hier auf dieser Website finden, 
                        wünschen Sie sich vielleicht eine individuelle Beratung. 
                        Gerne stehe ich Ihnen in meiner <b>Praxis für Ganzheitliche 
                        Gesundheitsberatung und Prävention</b> zur Verfügung.
                        <br />
                        <br />
                        <a href="beratung">Hier finde Sie mehr Informationen</a>.
                    </div>
                </div>


                <div class="row">
                    <div class="col s12 m12">
                        <a id="werbefrei"></a>
                        <hr />
                        <h5>Diese Website ist komplett werbefrei!</h5>
                        <hr />
                    </div>
                </div>    

                <div class="row">
                    <div class="col s12 m2">
                        <img src="<?php echo IMG_PATH; ?>werbefrei.png" alt="werbefrei" class="section-img" />
                    </div>
                    <div class="col s12 m10">          
                        <b>Haben Ihnen die Informationen auf www.DorisPaas.de weiter geholfen?</b>
                        <br />
                        Diese Website existiert seit 2007 und wächst stetig. Angefangen hat alles damit, 
                        dass ich Ihnen meine Bücher vorgestellt habe. Seitdem stelle ich in kurzen Abständen 
                        immer mehr Wissen zur Verfügung, und ich würde mich freuen, wenn Sie unter 
                        den vielen Informationen das gefunden haben, was Sie gesucht haben und dass 
                        Ihnen meine Ratschläge weitergeholfen haben.
                        <br />
                        <br />
                        Obwohl sich üblicherweise gleichartige Websites durch Werbung finanzieren,
                        ist diese Website komplett frei von kommerzieller Werbung. Nur so können 
                        Sie sicher sein, dass alle Informationen, die ich Ihnen hier kostenlos 
                        zur Verfügung stelle, garantiert neutral und unbeeinflusst 
                        durch Firmeninteressen zustande gekommen sind. 
                        <a href="guterrat">Lesen Sie hier weiter ...</a>
                    </div>
                </div>


                <div class="row">
                    <div class="col s12 m12">
                        <a id="browser"></a>
                        <hr />
                        <h5>Browseroptimierung</h5>
                        <hr />
                    </div>
                </div>        


                <div class="row">
                    <div class="col s12 m2">
                        <img src="<?php echo IMG_PATH; ?>firefox-neu.png" alt="Firefox" class="section-img" />
                        <img src="<?php echo IMG_PATH; ?>chrome.png" alt="Firefox" class="section-img" />
                    </div>
                    <div class="col s12 m10">
                        <b>Optimierung dieser Website</b>
                        <br />
                        <br />
                        Diese Website ist für die Browser Mozilla Firefox und Google Chrome optimiert. Sollten Sie 
                        mit einem anderen Browser arbeiten und Seiteninhalte nicht korrekt 
                        angezeigt bekommen, können Sie den <a href="http://www.mozilla.org/de/firefox" target="_blank">Firefox</a> 
                        bzw. <a https://www.google.de/chrome/browser/desktop/index.html" target="_blank">Chrome</a> hier kostenlos downloaden.
                        <br />
                        <br />
                        Weitere Tipps zu Betriebssystemen und Browsern 
                        <br />
                        finden Sie auf der Seite &#187;<a href="hilfe">Hilfe</a>&#171;
                        <br />
                        <br />
                        <i>Hinweis: Die Abbildungen für die Browser sind eingetragene Warenzeichen von Mozilla Firefox bzw. Google Chrome</i>
                    </div>
                </div>
                <div class="row">
                    <div class="col s12 m12">
                        <hr />
                    </div>
                </div>
                <div class="row">
                    <div class="col s12 m12">
                        <a href="javascript: scrollMainToTop();" class="nachoben">nach oben</a>
                    </div>
                </div>
                <div class="bodyspacer"></div> 
            </div>
        </div>