        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br /> 
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>
                <h1 class="header center orange-text">Informationen über Milch</h1> 
                    <div class="row center">        
                    <h5 class="header col s12 light">&ndash; meine persönliche Meinung</h5>      
                    </div>     
            </div>  
        </div> 
        <div class="container">    
            <div class="section">   
                <div class="row margintoprow">        
                    <div class="col s12 m12">
                        Milch ist im Normalfall die erste und ausschließliche Nahrung von Säuglingen. 
                        Muttermilch enthält Flüssigkeit gegen Durst und gegen den Hunger Eiweiß, 
                        Fett und Kohlehydrate in einem ausgeglichenen Verhältnis, daneben Vitamine 
                        und Mineralstoffe und damit sämtliche, in der ersten Lebensphase für 
                        die Entwicklung des Körpers und insbesondere des Gehirns notwendigen Stoffe. 
                        Wichtig ist auch zu erwähnen, dass mit der Muttermilch Abwehrstoffe gegen 
                        alle Krankheiten, die die Mutter erfolgreich überwunden hat, an den Säugling 
                        weitergegeben werden und ihn damit in der Stillzeit gegen diese Erkrankungen 
                        weitgehend immun machen. Somit sind gestillte Babys grundsätzlich gesünder 
                        als Kinder, die mit der Flasche und damit mit einer &#187;artfremden&#171; Milch 
                        aufgezogen werden, und ich bin sehr dafür, junge Mütter davon zu überzeugen, 
                        dass sie ihre Kinder möglichst lange stillen.
                        <br />
                        <br />
                        Von der Natur ist vorgesehen, menschliche Säuglinge mehrere Monate ausschließlich 
                        zu stillen, bis im Alter von etwa 4-6 Monaten langsam begonnen wird, zusätzliche 
                        Kost zu füttern und sie so nach und nach von der Muttermilch zu entwöhnen. 
                        <br />
                        <br />
                        Auch für heranwachsende Kinder und Erwachsene könnte Milch &ndash; 
                        bei uns ist es meistens Kuhmilch &ndash; ein wertvolles 
                        Nahrungsmittel sein, wenn sie &ndash; wie in anderen Regionen und Kulturen &ndash; in Maßen 
                        und in gesäuerter oder vergorener Form verzehrt würde. Kuhmilch enthält viele 
                        <a href="<?= URL_ROOT ?>milch#zusammensetzung">Bestandteile</a>, die auch für die menschliche 
                        Ernährung wertvoll sein können.
                        <br />
                        <br />
                        Bei uns gelangt Milch im Allgemeinen erst nach verschiedenen Konservierungs- 
                        und Verarbeitungsmethoden in den Handel, wo sie als Frischmilch, haltbare Milch 
                        oder als Milchprodukte wie Sahne, Butter, Käse, Quark und Joghurt etc. 
                        verkauft wird. Unbehandelte Milch würde schnell schlecht und damit für 
                        den Verbraucher ungenießbar, der heute nicht mehr täglich beim Bauern 
                        in der Nachbarschaft einkaufen kann. Die mittlerweile stark entwickelte Milchwirtschaft 
                        forciert die gesetzlichen Regelungen zur Konservierung, um die Vermarktungsfähigkeit 
                        von Milch und Milchprodukten zu einem für sie äußerst lukrativen 
                        Geschäft zu machen.
                        <br />
                        <br />
                        Bei der <a href="<?= URL_ROOT ?>milch#konservierung">Konservierung</a> wird die Milch mit verschiedenen Verfahren erhitzt. Dadurch 
                        werden nicht nur Keime abgetötet, die zum Verderb der Milch beitragen, sondern 
                        es wird auch das Eiweiß verändert (denaturiert), wodurch es schwerer 
                        verdaulich wird. Zusätzlich wird mit dem Homogenisieren das Milchfett in 
                        kleinste Tröpfchen zerteilt, damit es sich nicht mehr als Rahmschicht absetzt. 
                        Diese kleinsten Tröpfchen können &ndash; eventuell sogar beladen mit 
                        dem denaturierten Eiweiß &ndash; zwischen den Zellen der Darmschleimhaut 
                        hindurchschlüpfen und ins Blut gelangen. Dort können diese Stoffe 
                        Allergien verursachen. Die Milcheiweißallergie ist eine der bei Kindern 
                        am häufigsten beobachteten Allergieformen.
                        <br />
                        <br />
                        Darüber hinaus ist die Produktion von Milch und Milchprodukten für 
                        den Handel längst nicht mehr nur die Abfüllung, ggf. ein teilweiser 
                        Fettentzug oder die Verarbeitung der frischen Milch zu Joghurt, Quark oder 
                        Käse durch Hinzufügen von verschiedenen nützlichen Bakterienkulturen. 
                        Die Milchindustrie zerlegt heute die vom Bauern angelieferte Milch zuerst in 
                        alle ihre Bestandteile, die sie dann wie Designer ganz nach &#187;Verbraucherwünschen&#171; 
                        wieder zusammensetzt. Natürlich werden dabei dann diverse Zusatzstoffe hinzugefügt, 
                        um das Endprodukt möglichst über viele Wochen &#187;frisch&#171; zu halten, 
                        farblich oder in der Konsistenz anzupassen oder auch den gerade vorherrschenden 
                        Modegeschmack zu treffen &ndash; eine eher unangenehme Vorstellung.
                        <br />
                        <br />
                        Ein weiterer, wichtiger Gesichtspunkt ist die Tatsache, dass ein großer 
                        Teil der Milch, die in den Handel kommt, von trächtigen Kühen gemolken wird, 
                        weil eine Einhaltung einer sogenannten &#187;Trockenzeit&#171; &ndash; also einer 
                        Zeit, in der die Kühe nicht gemolken werden &ndash; den Tieren aus Profitgründen 
                        nur noch sehr kurz vor dem Kalben zugestanden wird. Dies hat zur Folge, dass 
                        die Milch Schwangerschaftshormone enthält, die zwar nicht hunderprozentig 
                        identisch mit den menschlichen Hormonen sind, sich jedoch ähneln. Es ist 
                        noch nicht bewiesen, ob nicht der rasante Anstieg der Brustkrebserkrankungen 
                        mit dieser Tatsache in Zusammenhang stehen könnte.
                        <br />
                        <br />
                        Leider sind in der Milch, die heutzutage im Handel angeboten wird, auch die
                        diversesten <a href="<?= URL_ROOT ?>milch#schadstoffe">Schadstoffe</a> enthalten &ndash; dies nicht nur, weil die Tiere nicht 
                        mehr artgerecht gehalten werden und somit immer mehr Medikamente zum Einsatz kommen 
                        (müssen), sondern auch, weil oftmals bereits Futter und Wasser hochgradig 
                        schadstoffbelastet sind: Ab und an erreicht ein Futtermittelskandal den 
                        Weg in die Öffentlichkeit, der uns dieses Problem bewusst macht. Aber alle 
                        Beteiligten sorgen mit vereinten Kräften dafür, dass diese 
                        profitschädigenden Misstände möglichst schnell wieder in Vergessenheit 
                        geraten können.
                        <br />
                        <br />
                        Aus diesem Grunde möchte ich persönlich Milch &ndash; wenn überhaupt &ndash; nur in sehr kleinen 
                        Mengen und eigentlich nur als Rohmilch empfehlen. Ansonsten sollten Sie Trinkmilch, wenn 
                        möglich, nur als Frischmilch verzehren. Besser ist der Verzehr von gesäuerten 
                        oder vergorenen Milchprodukten wie Quark, Joghurt, Kefir oder Käse.
                        <br />
                        <br />
                        Da Milch (mit Ausnahme von H-Milch oder gar Sterilmilch) in meinen Augen wegen 
                        ihrer Inhaltsstoffe trotz aller Verarbeitungsschritte ein wertvolles Nahrungsmittel 
                        darstellt, verzehre ich selbst Milchprodukte in vernünftigen Maßen.
                        Für mich bedeutet dies einen kleinen Schuss Trinkmilch in meinen morgendlichen 
                        Tee und ab und an einen kleinen Becher Joghurt als Zwischenmahlzeit, wobei ich 
                        mehr und mehr dazu übergehe, mir meinen &#187;Joghurt&#171; aus Sojamilch 
                        selbst herzustellen. Wegen meiner Laktose-Intoleranz kaufe 
                        ich laktosefreie Produkte. Die Milchmengen, die uns die Milchindustrie als unverzichtbar 
                        für unsere Gesundheit &ndash; besonders für die Gesundheit unserer 
                        Knochen &ndash; aufschwatzen will, sind jedoch ganz gewiss nicht erforderlich. 
                        <br />
                        <br />
                        Wer mehr über Milch und die industrielle Milchproduktion wissen möchte, 
                        dem sei das Buch &#187;Milch besser nicht&#171; 
                        oder die Website <a href="http://www.milchbessernicht.de" target="_blank">www.milchbessernicht.de</a>
                        von Maria Rollinger empfohlen. Danach sollte jeder selbst entscheiden, ob und 
                        in welchen Maßen er noch Milch verzehren möchte oder ob er lieber 
                        ganz darauf verzichten will.
                        <br />
                        <br />
                        Der Vollständigkeit halber wird auch am Ende dieser Seite noch einmal erklärt, 
                        ob man <a href="<?= URL_ROOT ?>milch#milchundmedikamente">Medikamente zusammen mit Milch einnehmen</a> 
                        darf, da diese Frage immer wieder gestellt wird. 
                        <br />
                        <a id="zusammensetzung">&nbsp;</a>
                        <hr />
                        <h5>Zusammensetzung der Kuhmilch</h5>
                        <hr />
                        Kuhmilch enthält etwa 87,5% Wasser. Das Kuhmilch-Eiweiß von ca. 3,5% 
                        enthält die meisten vom Menschen benötigten essentiellen Aminosäuren 
                        und kann gut vom Körper aufgenommen werden. Der Fettgehalt beträgt 
                        natürlicherweise etwa 4%. Bei der industriell hergestellten &#187;Vollmilch&#171; 
                        wird der Fettgehalt auf 3,5 - 3,8% eingestellt, weiterhin gibt es fettarme 
                        Milchsorten mit 1,5% und auch mit 0,5% Fett. Das in der Milch enthaltene Kohlenhydrat 
                        ist der Milchzucker (Laktose), deren Anteil 4,8% beträgt. Weitere Kohlenhydrate 
                        sind nur geringfügig enthalten. Als Besonderheit ist anzumerken, dass Milch 
                        als einziges tierisches Nahrungsmittel kleine Mengen Oligosaccharide (Mehrfachzucker) 
                        enthält, die bei einer entsprechenden Unverträglichkeit evtl. Probleme 
                        machen könnten.
                        <br />
                        <br />
                        Die Milch enthält verschiedene Fettsäuren, die meisten sind gesättigte 
                        Fettsäuren und somit weniger wertvoll für die menschliche Ernährung. 
                        Es sind jedoch auch &#187;gute&#171; Fettsäuren enthalten wie u.a. conjugierte 
                        Linolsäure (CLS), die den Stoffwechsel von Glukose und Fetten günstig 
                        beeinflusst und der Arteriosklerose vorbeugt, indem sie im Blut vorhandene Lipide 
                        (z.B. Cholesterin) verringert. Darüber hinaus werden im Milchfett die 
                        fettlöslichen Vitamine gespeichert, deren Aufnahme erwünscht ist. 
                        <br />
                        <br />
                        Neben dem Vitamin D sind die Vitamine A und E die in der Milch enthaltenen, 
                        fettlöslichen Vitamine. Weiterhin sind die wasserlöslichen Vitamine 
                        C, B1, B2, B6, B12, B3 (Niacin) und B9 (Folsäure) enthalten.
                        <br />
                        <br />
                        Die wichtigsten enthaltenen Mengen- und Spurenelemente in der Milch sind Kalzium, 
                        Phosphor, Magnesium, Jod und Zink, weiterhin Kalium, Natrium, Eisen, Kupfer, 
                        Cobalt, Zinn, Mangan, Aluminium, Fluor, Brom, Bor, Silicium und Selen. Ein Liter 
                        Vollmilch enthält ca. 7g Mineralstoffe. 
                        <br />
                        <a id="konservierung">&nbsp;</a>
                        <hr />
                        <h5>Konservierungsmethoden</h5>
                        <hr />
                        Milch gelangt im Allgemeinen erst nach verschiedenen Konservierungsmethoden 
                        in den Handel, weil unbehandelte Milch schnell schlecht und damit für den 
                        Verbraucher ungenießbar wird. Dies würde sich negativ auf die 
                        Vermarktungsfähigkeit auswirken. Die Konservierung von Milch ist gesetzlich 
                        geregelt.
                        <br />
                        <br />
                        Die wichtigste und erste Maßnahme gleich nach dem Melken noch beim Erzeuger 
                        ist die Kühlung, um die Keimentwicklung in der euterwarmen Milch zu verlangsamen. 
                        Gekühlte, ansonsten aber unbehandelte Milch (Rohmilch) ist etwa 2 - 3 Tage haltbar.
                        <br />
                        <br />
                        Weiterhin wird Milch homogenisiert. Dabei werden die relativ großen Fetttröpfchen 
                        durch Pressen der Milch durch äußerst feinmaschige Lochplatten um 
                        ein Vielfaches verkleinert. Ohne Homogenisierung setzt sich nach kurzer Zeit 
                        das Milchfett als Rahmschicht auf der Milchoberfläche ab und könnte 
                        von dort abgeschöpft und beispielsweise zu Butter verarbeitet werden. 
                        Da das Aufrahmen bei verkaufter Trinkmilch nicht erwünscht ist, wird mit 
                        der Homogenisierung dieser Vorgang unterbunden. Die Haltbarkeit wird dadurch 
                        nicht verändert. 
                        <br />
                        <br />
                        Milch gelangt mit Ausnahme bei der Direktvermarktung pasteurisiert in den Handel. 
                        Bei diesem Verfahren wird die Milch mit Dampf für 20 - 40 Sekunden auf 
                        71 - 75 &#176;C erhitzt. Dabei werden viele Keime abgetötet, wodurch die 
                        Haltbarkeit der Milch im Kühlschrank ca. 7 Tage beträgt. Pasteurisierte 
                        Milch darf trotz dieser Behandlung als &#187;Frischmilch&#171; bezeichnet werden.
                        <br />
                        <br />
                        Die so genannte H-Milch ist ultrahocherhitzt. Hierbei wird die Milch 1 - 3 
                        Sekunden auf 135 - 150 &#176;C erhitzt und ist ungeöffnet und ungekühlt 
                        ca. 3 Monate haltbar, nach dem Öffnen jedoch nur wenige Tage wie Frischmilch.
                        Sterilisierte Milch, die durch Erhitzen auf 110 - 120 &#176;C über einen 
                        Zeitraum von mindestens 30 Minuten so gut wie keimfrei gemacht wird, ist bei 
                        Zimmertemperatur mindestens 6 Monate haltbar, nach dem Öffnen wie Frischmilch 
                        etwa 2 - 3 Tage.
                        <br />
                        <br />
                        Sämtliche Methoden zur Haltbarmachung durch Erhitzen bewirken, dass Keime 
                        abgetötet werden, die die Milch verderben könnten. Dies können 
                        krankmachende Keime sein, aber auch Bakterien mit durchaus positiven Wirkungen, 
                        und sei es &#187;nur&#171;, dass durch die Auseinandersetzung mit normalerweise 
                        schädlichen Bakterien eine Abhärtung des Körpers und damit eine 
                        Stärkung des Immunsystems erreicht wird, oder sei es eine die Darmflora 
                        unterstützende Funktion der Milchsäurebakterien. 
                        <br />
                        <br />
                        Weiterhin wird mit der Haltbarmachung der Milch durch Erhitzen das Milcheiweiß 
                        denaturiert, also in seiner Struktur verändert und kann vom Körper 
                        nicht mehr korrekt verdaut werden. Frische Milch &ndash; am besten Rohmilch &ndash; 
                        ist also auf jeden Fall der behandelten vorzuziehen. Sie hat natürlich 
                        den Nachteil, dass sie schneller verdirbt und deshalb den täglichen Einkauf 
                        erforderlich macht. 
                        <br />
                        <br />
                        Hinweis: Für Kinder und Schwangere ist Rohmilch nicht uneingeschränkt 
                        zu empfehlen, da sie u.a. Listerien enthalten kann, eine Bakterienart, die 
                        eine Infektionskrankheit, die Listeriose verursachen können. Diese kann 
                        bei Menschen mit geschwächtem oder noch nicht voll ausgebildetem Immunsystem 
                        u.a. Blutvergiftungen oder sogar Hirnhautentzündungen hervorrufen. Bei 
                        Schwangeren ist eine Listeriose deshalb sehr gefährlich, weil eine Infektion, 
                        die schwere Schäden für das ungeborene Kind, Frühgeburten oder 
                        sogar das Absterben des Fötus nach sich ziehen kann, für die Mutter 
                        oftmals unbemerkt verläuft, so dass keine Behandlung erfolgt.
                        <br />
                        <a id="schadstoffe">&nbsp;</a>
                        <hr />
                        <h5>Schadstoffe in der Milch</h5>
                        <hr />
                        Kuhmilch &ndash; oder zumindest der Rohstoff, der zu den Erzeugnissen, die uns 
                        die Milchindustrie als Milch, Joghurt und Co. verkauft &ndash; ist eigentlich 
                        ein natürliches Produkt, das in den Milchdrüsen der Kuh gebildet wird. 
                        Aber die Qualität und die Inhaltsstoffe sind davon abhängig, wie das 
                        Tier gehalten wird, welches Futter es erhält und auch welche Medikamente 
                        verabreicht werden.
                        <br />
                        <br />
                        Mit der Massentierhaltung werden leider immer mehr Medikamente erforderlich, 
                        um die Tiere gesund zu erhalten (u.a. Antibiotika). Weiterhin kommen auch Hormone 
                        zum Einsatz, um die Fleischqualität oder die Milchleistung zu 
                        beeinflussen und somit die Gewinne der Bauern zu steigern. 
                        <br />
                        <br />
                        Viele dieser Medikamente gehen in die Milch über, auch wenn es gesetzliche 
                        Regelungen gibt, dieses Risiko zu minimieren. Unglücklicherweise sind die 
                        Gesetze aber aus meiner Sicht aufgrund des Einknickens der Politiker gegenüber 
                        der Bauernschaft und auch nicht zuletzt durch die Europäisierung, bei der 
                        grundsätzlich scheinbar immer nur der kleinste gemeinsame Nenner gefunden 
                        wird, viel zu lasch und deren Einhaltung wird darüber hinaus auch nicht ausreichend 
                        kontrolliert. In regelmäßigen Abständen aufflackernde Lebensmittelskandale 
                        bestätigen dies. 
                        <br />
                        <br />
                        Über Futter, Trinkwasser und auch die Luft können weitere Schadstoffe 
                        von den Tieren aufgenommen werden. Hier sind insbesondere Schimmelpilzgifte 
                        zu nennen, da sich in den feuchten Ställen leicht am Boden und in der 
                        Luft und auch im Futter Schimmelpilze bilden und halten können. Bei der 
                        frührer üblichen Haltung, bei der die Tiere tagsüber auf die 
                        Weiden getrieben und nur nachts in die Ställe geholt wurden, die dabei auch 
                        noch tagsüber offen standen und auslüften konnten, ergab sich dieses 
                        Problem nicht oder zumindest nicht in dem Maß. Heute jedoch werden die Kühe ausschließlich in den 
                        Ställen gehalten und kommen ihr gesamtes Leben nicht einmal auf eine Weide. 
                        Ställe und Futtersilos werden mit schimmelhemmenden Mitteln behandelt, 
                        die auf der einen Seite die Schimmelbildung nicht vollständig unterdrücken 
                        können und auf der anderen Seite zusätzlich von den Tieren aufgenommen 
                        werden. Und selbst abgetötete Schimmelpilze enthalten immer noch die 
                        gefährlichen Gifte, die sich dann zusätzlich mit den Chemikalien in 
                        Fleisch und Milch anreichern können.
                        <br />
                        <br />
                        Die meisten Schadstoffe werden aber durch das schwermetall- und nitratbelastete 
                        Trinkwasser und die Nahrung aufgenommen. Mit Tierfutter lässt sich nämlich 
                        trefflich Geld verdienen: Hier wird häufig von der Industrie hineingepanscht, 
                        was kaum vorstellbar ist &ndash; alles aus Gier nach Profit. Der Anfang 2011 an die 
                        Öffentlichkeit gelangte Dioxin-Skandal, der publik wurde, weil zufällig 
                        in Hühnereiern Dioxin gefunden wurde, ist ganz sicherlich nur die Spitze 
                        des Eisberges und zeigt, dass skrupellose Futtermittelhersteller 
                        billige Fette, die für industrielle Zwecke gedacht waren, in Tierfutter 
                        gemischt hatten, um so ihre Gewinne zu maximieren. 
                        <br />
                        <br />
                        Auch in der Milch &ndash; bevorzugt im Milchfett &ndash; reichern sich gerne Dioxine 
                        an, und lt. Umweltbundesamt (BfR) nimmt der Mensch durchschnittlich täglich 
                        mit der getrunkenen Milch 17 Pikogramm Dioxin auf. Diese Menge erscheint nur 
                        gering &ndash; vor allem vor dem Hintergund, dass die Weltgesundheitsorganisation 
                        (WHO) die tägliche Aufnahme von 4 Pikogramm Dioxin pro kg Körpergewicht 
                        über die Nahrung für unbedenklich hält (bei einem Durchschnittsgewicht 
                        von 75 kg wären dies also 300 Pikogramm pro Tag). Aber wir nehmen ja zum 
                        einen nicht nur über die Milch Dioxine auf, sondern über viele andere 
                        Nahrungsmittel auch, so dass allein dadurch schon eine erkläckliche Menge 
                        zusammen kommt. Und zum anderen wissen wir ja leider auch, dass die einzelnen 
                        Gifte nicht isoliert betrachtet werden dürfen &ndash; wie der Cocktail aus 
                        vielen verschiedenen Giften wirkt, wird ja leider nicht erforscht und bewertet.
                        <br />
                        <br />
                        Dioxine allein betrachtet sind äußerst gefährliche Gifte, die schon 
                        in allerkleinsten Mengen sehr gefährlich sein können. Spätestens 
                        seit dem Chemieunfall im italienischen Seveso (1976) ist bekannt, dass sich 
                        Dioxin in Milch anreichern kann &ndash; Müttern hier in Deutschland wurde 
                        noch einige Jahre danach die Möglichkeit gegeben, ihre Muttermilch auf 
                        den Gehalt des Giftes untersuchen zu lassen. Es geht nicht nur sofort in die 
                        Milch über, sondern lagert sich jahre- und jahrzehntelang im Fettgewebe 
                        (u.a. der Brust bzw. des Euters) ab, und wird dann in der Laktationsphase an 
                        die Milch abgegeben.
                        <br />
                        <br />
                        Aber auch ohne Skandale ist die Qualität von Tierfutter nicht die beste: 
                        Selbst wenn die Bauern nur ihr eigenes Heu verfüttern und das Wasser aus 
                        einem eigenen Brunnen zapfen, so befindet sich inzwischen weltweit eine mehr 
                        oder weniger hohe Konzentration von Dioxinen auf den Weiden &ndash; eine absolut 
                        dioxinfreie Milch gibt es auch bei sorgfältigster Produktion nicht (noch nicht 
                        einmal Biomilch ist völlig dioxinfrei). 
                        Und darüber hinaus haben die Bauern meist zuvor 
                        nitrathaltige Gülle aus den Ställen auf ihre Wiesen gefahren und 
                        auf den danebenliegenden Äckern &#187;Pflanzenschutzmittel&#171; (Pestizide 
                        und Herbizide) ausgestreut, die mit dem Regen ins Grundwasser gelangen &ndash; 
                        der Kreislauf schließt sich.
                        <br />
                        <br />
                        Hinzu kommen selbstverständlich noch die Schadstoffe, die bei der Verarbeitung 
                        der Milch in den Molkereien in die Produkte gelangen. Wie oben beschrieben, ist 
                        die Milch, die wir im Supermarkt kaufen, ja leider nun wirklich nicht mehr das 
                        Naturprodukt, als das sie uns gerne in der Werbung angepriesen wird: In der 
                        Molkerei werden reihenweise Zusatzstoffe zur Milch hinzugegeben &ndash; und 
                        wenn ein Gesetz gegen den Zusatz eines Stoffes zur Milch spricht, so bleibt 
                        häufig noch die Möglichkeit, ihn als Bestandteil von beispielsweise 
                        Fruchtzusätzen in Joghurt etc. doch unterzubringen &ndash; Hintertürchen 
                        gibt es diverse.
                        <br />
                        <br />
                        Natürlich müssen in der Molkerei alle Produktionsanlagen peinlichst 
                        sauber gehalten werden, denn Milch ist ein hervorragender Nährboden für 
                        Bakterien. Und verdorbene Milchprodukte schmälern den Gewinn des Herstellers.
                        Deshalb werden reichlich Reinigungsmittel eingesetzt &ndash; schon die Tanklaster, 
                        mit denen die Milchmengen von den Bauern eingesammelt und über Land transportiert 
                        werden, dürfen keinerlei Verunreinigungen enthalten. Auch hier gibt es 
                        diverse Möglichkeiten, dass eingesetzte Chemikalien, die nicht gänzlich 
                        aus den Tanks gewaschen werden, in der Milch zurückbleiben &ndash; es sind 
                        einige Rückholaktionen bekannt, die aufgrund solcher entdeckten Rückstände
                        durchgeführt werden mussten.
                        <br />
                        <br />
                        Und last but not least können Verpackungen Schadstoffe an die Milch abgeben, denn die Zeiten, 
                        in denen wir mit der Milchkanne zum Bauern gingen, um unsere tägliche Milchration 
                        zu kaufen, sind seit Großmutters (oder bald Urgroßmutters) Zeiten 
                        vorbei. Heute werden Milch und Milchprodukte großteilig in Kunststoffbehältnissen 
                        abverkauft, die aus Materialien bestehen, deren Unbedenklichkeit immer wieder 
                        &ndash; natürlich erst im Nachhinein &ndash; durch neue Erkenntnisse 
                        erschüttert wird.
                        <br />
                        <br />
                        Leider erhalten die Verbraucher nur bei öffentlichen Skandalen und dann 
                        auch nur widerwillig und tröpfchenweise Informationen über Schadstoffe 
                        in Nahrungsmitteln &ndash; was alles unter dem Teppich gehalten wird, mag ich 
                        mir gar nicht vorzustellen.
                        <br />
                        <a id="milchundmedikamente">&nbsp;</a>
                        <hr />
                        <h5>Medikamenteneinnahme mit Milch</h5>
                        <hr />
                        Bei den meisten Medikamenten wäre es höchstwahrscheinlich unproblematisch, 
                        sie mit Milch einzunehmen. Es gibt jedoch Wirkstoffgruppen, die sich nicht mit 
                        den Bestandteilen der Milch vertragen und deren Wirksamkeit in Zusammenhang mit 
                        Milch beeinträchtigt werden kann.
                        <br />
                        <br />
                        Hierzu zählt beispielsweise Tetracyclin, ein Antibiotikum, das mit dem 
                        Kalzium aus der Milch eine Verbindung eingehen kann, die nicht mehr durch die 
                        Darmwand aufgenommen werden kann. Somit wäre die Wirksamkeit des Mittels 
                        nicht mehr (oder nicht mehr in vollem Umfang) gewährleistet. Bei Einnahme 
                        von Antibiotika aus der Tetracyclin-Gruppe muss deshalb ein zeitlicher Abstand 
                        zwischen der Einnahme des Medikaments und dem Verzehr von Milch(produkten) von 
                        mindestens 2 Stunden eingehalten werden. Die gleiche Wirkung haben natürlich 
                        auch mit Kalzium angereicherte Fruchtsäfte.
                        <br />
                        <br />
                        Auch bei der Einnahme von MAO-Hemmern, enthalten in so genannten Psychopharmaka 
                        gegen Depressionen und Angststörungen, sollte auf den gleichzeitigen Verzehr 
                        von Milch und Milchprodukten verzichtet werden (ebenso wie generell auf sehr 
                        eiweißhaltige und auch geräucherte Nahrungsmittel wie Fleisch, Fisch 
                        (insbesondere Fischkonserven) und Räucherwurst). Der in diesen Nahrungsmitteln enthaltene Stoff 
                        Tyramin kann bei Einnahme von MAO-Hemmern nicht mehr ausreichend abgebaut werden 
                        und reichert sich im Körper an, was u.U. schwerwiegende Folgen  wie beispielsweise 
                        Bluthochdruck bis hin zu Hirnblutungen nach sich ziehen kann.
                        <br />
                        <br />
                        Auch der aufgeklärteste Patient kann oftmals nicht wirklich entscheiden, 
                        ob ein Medikament ohne Probleme mit Milch zusammen eingenommen werden kann, zumal 
                        ständig neue Wirkstoffe auf den Markt kommen. Es wird zwar in den Waschzetteln 
                        meist erwähnt, wenn das Präparat nicht mit Milch eingenommen werden soll, 
                        aber viele Neben- und Wechselwirkungen werden dort leider nicht erwähnt. 
                        <br />
                        <br />
                        Wenn Sie auf der sicheren Seite bleiben wollen, empfehle ich Ihnen, grundsätzlich 
                        keine Medikamente mit Milch einzunehmen, sondern immer nur Wasser zu verwenden, 
                        da es durchaus auch Probleme mit anderen Getränken wie beispielsweise 
                        Grapefruitsaft und selbstredend natürlich auch alkoholischen Getränken 
                        geben kann.
                        <br />
                        <hr />
                        <b>Lesen Sie auch folgende Beträge:</b>
                        <br />
                        <a href="wasistli">Was ist Laktose-Intoleranz?</a>
                        <br />
                        <a href="diagnose">Diagnose-Methoden zur Ermittlung einer Laktose-Intoleranz</a>
                        <br />
                        <a href="behandlung">&#187;Behandlung&#171; der Laktose-Intoleranz</a>
                        <br />
                        <a href="laktase">Informationen zu Laktase-Präparaten</a>
                        <br />
                        <a href="kaese">Käse &ndash; alles Käse?</a>
                        <br />
                        <br />
                        <a href="javascript: scrollMainToTop();" class="nachoben">nach oben</a>
                    </div>
                </div>
            </div>    
            <br>
            <br> 
            <div class="bodyspacer"></div> 
        </div>