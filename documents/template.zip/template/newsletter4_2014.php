        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br /> 
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>
                <h1 class="header center orange-text">DorisPaas-Newsletter</h1>      
            </div>  
        </div> 
        <div class="container">    
            <div class="section">   
                <div class="row margintoprow">        
                    <div class="col s12 m12">
                        <img src="<?php echo IMG_PATH; ?>dorispaas-de-titelfoto-newsletter.png" alt="" border="0" hspace="0" vspace="0" style="float: left; margin-left: 0px; margin-right: 20px; padding-bottom: 0px;" /></a><br />
                        <br />
                        <br />
                        <br />
                        <br />
                        <br />
                        <br />
                        <br />
                        <br />
                        <b>Ausgabe 4/2014 (Juli 2014)</b>
                        <br />
                        <br />
                        _______________________________________________________________________________________________
                        <br />
                        <br />
                        <br />
                        
                        Liebe Leserin, lieber Leser.
                        <p>
                        Wissenschaftliche Erkenntnisse entwickeln sich immer rasanter, und insbesondere 
                        die Forschung in Sachen Verdauung und Darmflora ist eine sehr spannende Angelegenheit. 
                        Deshalb verwende ich immer einen gro&#223;en Teil meiner Zeit, um mich intensiv fortzubilden.
                        Keine Beratung &ndash; und schon gar nicht eine Beratung im Ern&auml;hrungs- oder 
                        Gesundheitsbereich &ndash; kann effektiv und kompetent sein, wenn der Berater 
                        nicht auf dem Laufenden ist. Vorrangig liegen die 
                        Schwerpunkte meiner Studien in den Sachgebieten, in 
                        denen ich Sie seit vielen Jahren begleite und berate: Gesunde Ern&auml;hrung, 
                        gesunde Verdauung und die Darmflora und alles rund um Nahrungsmittel-Unvertr&auml;glichkeiten 
                        und die damit zusammenh&auml;ngenden Themen. Sie k&ouml;nnen sicher sein, 
                        dass ich Ihnen nicht nur die neuesten Erkenntnisse auf diesen Gebieten zur Verf&uuml;gung 
                        stellen kann, sondern auch genau abw&auml;ge, was davon ganz individuell f&uuml;r Sie gut 
                        und richtig ist. Nicht immer muss ja alles Neue auch gut f&uuml;r Sie sein, manchmal hat das 
                        Altbew&auml;hrte durchaus sein Gutes. Auf <a href="http://www.dorispaas.de" target="_blank">www.DorisPaas.de</a>
                        sind alle Beitr&auml;ge immer ganz aktuell, und bei den Beratungen in meiner <a href="http://www.ganzheitliche-gesundheitsberatung.de" target="_blank">Praxis 
                        f&uuml;r Ganzheitliche Gesundheitsberatung und Pr&auml;vention</a> k&ouml;nnen Sie 
                        auf diese aktuellen Erkenntnisse vertrauen.
                        <br />
                        <hr>
                        <img src="<?php echo IMG_PATH; ?>enders-klein.png" alt="" border="0" hspace="0" vspace="0" style="float: left; margin-left: 0px; margin-right: 20px; padding-bottom: 0px;" /></a>
                        <br />
                        <b>&#149;	<a href="http://www.dorispaas.de/index.php?page=fremdliteratur" target="_blank">B&uuml;cher anderer Autoren</a></b>
                        <br />
                        F&uuml;r meine Weiterqualifizierung lese ich nicht nur Fachliteratur, sondern 
                        auch B&uuml;cher, die f&uuml;r jeden interessant sein k&ouml;nnten. Neben den 
                        <a href="http://www.dorispaas.de/index.php?page=books" target="_blank">B&uuml;chern</a>, 
                        die ich selbst zu den Themen Nahrungsmittel-Intoleranzen, 
                        gesunde Ern&auml;hrung und gesunde Verdauung f&uuml;r Sie geschrieben habe, finden Sie unter der neuen Rubrik 
                        &#187;B&uuml;cher anderer Autoren&#171; solche, deren Lekt&uuml;re sich f&uuml;r Sie 
                        lohnen k&ouml;nnte. Es gibt aber auch Werke, deren Kauf man sich aus 
                        meiner Sicht getrost sparen kann. Auf der Seite gibt es jeweils eine (pers&ouml;nliche) Bewertung,
                        die Sie, wenn Sie m&ouml;chten, zur Kauf- und Leseentscheidung heranziehen k&ouml;nnen.
                        Ganz besonders m&ouml;chte ich Ihnen heute das Buch &#187;<a href="http://www.dorispaas.de/index.php?page=fremdliteratur#enders-charmedarm" target="_blank">Darm 
                        mit Charme</a>&#171; von Giulia Enders empfehlen &ndash; trotz des an sich fachlichen 
                        Themas w&auml;re es es eine sehr vergn&uuml;gliche Lekt&uuml;re z.B. f&uuml;r Ihren Urlaub.
                        <br />
                        <br />
                        <hr>
                        <br />
                        <b>&#149;	<a href="http://www.dorispaas.de/index.php?page=fma-depressionen" target="_blank">Fruktose-Malabsorption und Depressionen</a></b>
                        <br />
                        Wussten Sie das? Der Verzehr von Fruchtzucker kann zu Depressionen f&uuml;hren? 
                        Der Zucker, mit dem Nahrungsmittel-Produzenten vielen Lebensmitteln ein 
                        ges&uuml;nderes Image verpassen wollen? 
                        Es muss nicht gleich eine ausgewachsene Depression sein, aber man kann sich durchaus 
                        scheinbar ohne Grund niedergeschlagen f&uuml;hlen oder unerkl&auml;rliche 
                        Schlafst&ouml;rungen haben, wenn man den &#187;gesunden&#171; Fruchtzucker isst. 
                        Und man muss auch nicht unbedingt an einer Fruktose-Malabsorption (Fruktose-Intoleranz) 
                        leiden, um psychische Probleme nach dem Verzehr von Fruchtzucker zu bekommen. Es ist 
                        tats&auml;chlich so, dass es jedem von uns regelrecht auf das Gem&uuml;t schlagen 
                        kann, wenn wir zu viel Fruchtzucker verzehren. Aber leider sind auch ausgewachsene 
                        Depressionen m&ouml;glich. &Uuml;ber die Zusammenh&auml;nge von Depressionen und 
                        Fruktose informiert Sie ein neuer Beitrag auf www.DorisPaas.de.
                        <br />
                        In diesem Zusammenhang ist eine fruktosearme Ern&auml;hrung ganz besonders wichtig
                        &ndash; nicht nur f&uuml;r Menschen mit Fruktose-Malabsorption! 
                        Schauen Sie sich doch einmal die Informationen oder das kleine Video zur 
                        &#187;<a href="http://www.dorispaas.de/index.php?page=lebensmittel-datenbank-info" target="_blank">DorisPaas.de &#150; Lebensmittel-Datenbank</a>&#171; 
                        an. Diese Datenbank enth&auml;lt inzwischen mehr als 900 Lebensmittel, die auf ihre 
                        Bek&ouml;mmlichkeit bei den verschiedensten Nahrungsmittel-Unvertr&auml;glichkeiten 
                        &ndash; und nat&uuml;rlich auch auf die Fruktose &ndash; abgepr&uuml;ft worden sind.
                        Testen Sie die Datenbank doch einmal aus, um zu sehen, wie viele Lebensmittel Ihnen 
                        auch bei einer fruktosekontrollierten Ern&auml;hrung zur Verf&uuml;gung stehen!
                        <br />
                        <br />
                        <hr>
                        <br />
                        <img src="<?php echo IMG_PATH; ?>kaeselaib.png" alt="" border="0" hspace="0" vspace="0" style="float: left; margin-left: 0px; margin-right: 20px; padding-bottom: 0px;" /></a>
                        <br />
                        <b>&#149;	<a href="http://www.dorispaas.de/index.php?page=kaese" target="_blank">K&auml;se &ndash; alles K&auml;se?</a></b>
                        <br />
                        Darf ich Sie zu einem Besuch in einer K&auml;serei einladen? Im Juni habe ich einen 
                        Betrieb besichtigt, in dem die K&auml;seherstellung noch als richtiges Handwerk 
                        verstanden wird und in dem die mit viel Liebe erzeugten Schnittk&auml;sesorten 
                        als regionale Ware vermarktet werden. In dem bebilderten Beitrag lernen Sie 
                        nicht nur, wie K&auml;se &uuml;berhaupt hergestellt wird. Sie erfahren auch, ob 
                        und welcher K&auml;se f&uuml;r Sie bek&ouml;mmlich ist, selbst wenn Sie an 
                        Nahrungsmittel-Unvertr&auml;glichkeiten leiden. Und last, but not least 
                        m&ouml;chte ich Ihnen auch zeigen, dass es trotz der ganzen Lebensmittel-Skandale 
                        tats&auml;chlich noch Hersteller gibt, deren Produkte man mit gutem Gewissen kaufen 
                        und genie&#223;en kann.
                        <br />
                        <br />
                        <hr>
                        <br />
                        Liebe Leserin, lieber Leser, habe ich Ihnen ein wenig Appetit gemacht? Appetit auf 
                        leckeren, regional hergestellten K&auml;se? Appetit auf gesunde und bek&ouml;mmliche Ern&auml;hrung 
                        ohne (zu) viel Fruktose? Auf eine Ern&auml;hrung, die Ihnen die gute Laune nicht verdirbt?
                        Oder auf Lesefutter? Ich w&uuml;nsche Ihnen auf jeden Fall &#187;Guten Appetit&#171;
                         und eine wundersch&ouml;ne, erholsame Sommerzeit!
                        <br />
                        <br />
                        In diesem Sinne sende ich Ihnen bis zum n&auml;chsten Newsletter, den Sie in zwei 
                        Monaten, also etwa Mitte September 2014 erhalten, ganz herzliche Gr&uuml;&#223;e aus dem Rheinland 
                        <br />
                        Ihre
                        <br />
                        Doris Paas
                        </p>
                        <i>P.S. Gerne k&ouml;nnen Sie diesen Newsletter auch an Freunde und Bekannte weiterleiten!</i>
                        <p>
                        <hr>
                        <hr>
                        <img src="<?php echo IMG_PATH; ?>termine-klein.png" alt="" border="0" hspace="0" vspace="0" style="float: left; margin-left: 0px; margin-right: 20px; padding-bottom: 0px;" /></a>
                        <br />
                        &#149;	Beachten Sie bitte auch die Hinweise zu den <a href="http://www.dorispaas.de/index.php?page=termine" target="_blank">Terminen 
                        f&uuml;r die Veranstaltungen</a>, zu denen ich Sie herzlich einlade.  
                        <br />
                        &#149;	S&auml;mtliche neuen Beitr&auml;ge finden Sie immer unter dem Button 
                        &#187;<a href="http://www.dorispaas.de/index.php?page=news" target="_blank">neueste Betr&auml;ge</a>&#171; 
                        in der Seiten-Navigation.
                        <br />
                        &#149;	Den besten &Uuml;berblick &uuml;ber die kompletten Inhalte auf www.DorisPaas.de 
                        finden Sie in der <a href="http://www.dorispaas.de/sitemap-html" target="_blank">Sitemap</a> 
                        in der Seiten-Navigation.
                        <br />
                        <br />
                        <hr>
                        <br />
                        Sie k&ouml;nnen den Erhalt des Newsletters jederzeit abbestellen.
                        Bitte klicken Sie auf <a href="http://www.dorispaas.de/index.php?page=unsubscribe_newsletter&amp;ticket=%UNSUBSCRIBE_TICKET%" target="_blank">diesen Link</a>.
                        <br />
                        Ihre Mailadresse wird im Verteiler gel&ouml;scht, und Sie erhalten keine Mails mehr.
                        </p>
                    </div>
                </div>
            </div>    
            <br>
            <br> 
            <div class="bodyspacer"></div> 
        </div>