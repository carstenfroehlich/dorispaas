        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br /> 
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>
                <h1 class="header center orange-text">FODMAP-Diät</h1>      
            </div>  
        </div> 
        <div class="container">    
            <div class="section">   
                <div class="row margintoprow">        
                    <div class="col s12 m4">
                        <ul class="nav">
                            <li>
                                <b>Abschnitte dieser Seite:</b>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>fodmaps#kohlenhydrate">Komplexe Kohlenhydrate</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>fodmaps#boehnchen">Jedes Böhnchen gibt ein Tönchen</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>fodmaps#laktose">Laktose</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>fodmaps#fruktose">Fruktose, Sorbit & Co.</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>fodmaps#fodmapdiaet">FODMAP-Diät</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>fodmaps#intoleranzen">FODMAP-Diät und Nahrungsmittel-Unverträglichkeiten</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>fodmaps#lebensmittel">Lebensmittel-Auswahl</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>fodmaps#dauer">Dauer</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>fodmaps#datenbank">DorisPaas.de &ndash; Lebensmittel-Datenbank</a>
                            </li>
                            <li>
                                <a href="<?= URL_ROOT ?>fodmaps#beratung">Individuelle Beratung</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="row margintoprow">        
                    <div class="col s12 m12">
                        <img src="<?php echo IMG_PATH; ?>fodmaps.png" alt="" class="right" />
                        Bei manchen Menschen mit Nahrungsmittel-Unverträglichkeiten, Reizdarm-Syndrom und/oder 
                        einer Dünndarmfehlbesiedelung zeigen die &#187;üblichen&#171; Diäten nicht den gewünschten Erfolg.
                        Auch wenn die einzelnen unbekömmlichen Stoffe gemieden werden, gehen in diesen Fällen Beschwerden wie 
                        Bauchschmerzen, Blähungen, Durchfälle und/oder Verstopfung und 
                        viele andere nicht auf ein akzeptables Maß zurück.
                        <br />
                        <br />
                        Hilfreich kann dann neben der erforderlichen Reduzierung der unverträglichen 
                        Stoffe zusätzlich die Einhaltung einer Diät mit einem geringeren 
                        Anteil an bestimmten Kohlenhydraten sinnvoll sein. Diese Ernährung ist leichter verdaulich, 
                        und schädlichen Darmbakterien wird mit dem geringeren Ballaststoffanteil die 
                        Lebensgrundlage entzogen. 
                        <br />
                        <a id="kohlenhydrate"></a>
                        <hr>
                        <h5>Komplexe Kohlenhydrate</h5>
                        <hr>
                        Wenn Beschwerden nach dem Verzehr von 
                        komplexeren Kohlenhydraten stark zunehmen, ist es empfehlenswert, einen Versuch 
                        mit einer Ernährung zu wagen, die vorübergehend weniger Ballaststoffe, kurzkettige 
                        Kohlenhydrate und Zuckeralkohole enthält. Nicht gemeint ist selbstverständlich 
                        hiermit, dass Sie jetzt nur Weißbrot und Zucker verzehren sollen. Minimiert werden 
                        sollte jedoch insgesamt der Verzehr von Getreide, d.h. von allen Nahrungsmitteln, 
                        die Weizen, Roggen, Gerste oder Hafer (und allen Abkömmlingen wie z.B. Dinkel oder 
                        Grünkern etc.) enthalten. Zusätzlich muss der Konsum der 
                        sogenannten Pseudogetreide wie Reis, Amaranth, Quinoa, Buchweizen etc. gesenkt 
                        werden. 
                        <br />
                        <br />
                        Vor allem sollten Getreide und auch Pseudogetreide vorübergehend nicht 
                        mehr als vollwertige Produkte verzehrt werden, sondern für die (kleinen!) Beilagenmengen 
                        die &#187;weiße&#171; (geschälte) Variante gewählt werden. Bevorzugt werden sollten 
                        Kohlenhydrate aus Gemüse und zu einem geringen Anteil auch aus Obst. Zusätzlich 
                        sollten weitestgehend alles Zuckrige und künstlich gesüßte Nahrungsmittel gemieden 
                        werden.
                        <br />
                        <a id="boehnchen">&nbsp;</a>
                        <hr>
                        <h5>Jedes Böhnchen gibt ein Tönchen</h5>
                        <hr>
                        Weitere Nahrungsmittel, die Sie meiden sollten, sind die üblichen Verdächtigen in 
                        Bezug auf Blähungen. Dies sind alle Kohlsorten, Lauch- und Zwiebelgemüse und 
                        Hülsenfrüchte. Alle diese Lebensmittel enthalten schwerverdauliche Bestandteile 
                        wie Fruktane, Galaktane, Galakto- und Frukto-Oligosaccharide, die viel zu lange 
                        im Dünndarm liegen bleiben und dort von den Bakterien vergoren werden können. 
                        <br />
                        <a id="laktose">&nbsp;</a>
                        <hr>
                        <h5>Laktose und Fruktose</h5>
                        <hr>
                        Auch wenn Sie nicht laktoseintolerant sind, ist es vorteilhaft, auf Laktose (Milchzucker) 
                        zu verzichten. Die Verdauung des Milchzuckers findet in Gänze erst im Verlauf der 
                        gesamten Länge des Dünndarms statt. Siedeln nun &#187;gefräßige&#171; Dickdarmbackterien 
                        im Dünndarm, freuen diese sich über die leckere Mahlzeit. Werden jedoch laktosefreie
                        Produkte verzehrt, entziehen Sie diesen Bakterien diese Nahrung. 
                        <br />
                        <a id="fruktose">&nbsp;</a>
                        <hr>
                        <h5>Fruktose, Sorbit & Co.</h5>
                        <hr>
                        Auch fruktosereiche Lebensmittel sind tabu. Bei jedem Menschen ist &ndash; selbst wenn keine 
                        Fruktose-Malabsorption vorliegt &ndash; die Aufnahmekapazität des Darms in Bezug auf 
                        Fruktose beschränkt. Isst man nun zu große Mengen dieses Einfachzuckers, gelangt er zur
                        Freude der schädlichen Darmbakterien genauso wie die Laktose in untere Darmabschnitte, 
                        die dann vermehrt beschwerdeverursachende Säuren und Gase produzieren.
                        <br />
                        <br />
                        Das gleiche Transportsystem, das die Fruktose benötigt, um ins Blut geschleust 
                        zu werden, benutzen auch Zuckeralkohole (Polyole). Und diese Stoffe sind 
                        &#187;egoistisch&#171;, d.h. sie besetzen die Transporter vorrangig, weshalb dann 
                        noch weniger dieser Transporter für die Fruktose zur Verfügung steht. Da es kaum
                        möglich ist, sich gänzlich fruktosefrei zu ernähren, ohne Mangelerscheinungen in 
                        Bezug auf Vitamine und Mineralstoffe zu zeigen, sollte man die geringen Transportkapazitäten
                        unbedingt freihalten. Dies bedeutet, dass es ratsam ist, auf alle Zuckeralkohole 
                        zu verzichten. Dies ist relativ einfach, denn zumindest muss ein künstlicher Zusatz
                        zu industriell bearbeiteten Nahrungsmitteln auf den Zutatenlisten deklariert werden.
                        Die Zuckeralkohole heißen Sorbit/Sorbitol (E 420), Mannit/Mannitol (E 421), Xylit/Xylitol 
                        (E 967), und Erythrit/Erythritol (E 968).
                        Zusätzlich müssen natürlich auch alle Nahrungsmittel gemieden werden, die natürlicherweise 
                        Zuckeralkohole enthalten.
                        <br />
                        <a id="fodmapdiaet">&nbsp;</a>
                        <hr>
                        <h5>FODMAP-Diät</h5>
                        <hr>
                        Am besten geeignet für eine solche Diät ist die sogenannte FODMAP-Diät. Die 
                        Buchstaben stehen für die englischen Begriffe &#187;<b>F</b>ermentable <b>O</b>ligo-, 
                        <b>D</b>i- <b>M</b>onosaccharides <b>A</b>nd <b>P</b>olyols&#171; (vergärbare Mehrfach-, 
                        Zweifach- und Einfachzucker und Zuckeralkohole). 
                        <br />
                        <br />
                        Die FODMAP-Diät deckt die meisten möglichen Verursacher von Unverträglichen ab. 
                        Die Nahrungsmittel werden darauf überprüft und bewertet, wie hoch der Anteil 
                        dieser Inhaltsstoffe <b>in der Summe</b> ist. Danach werden sie klassifiziert und in die 
                        Kategorie &#187;hoher FODMAP-Gehalt&#171; oder &#187;niedriger FODMAP-Gehalt&#171;
                        einsortiert. Genauere Listen oder Datenbanken weisen zusätzlich auch einen 
                        mittleren FODMAP-Gehalt aus.
                        <br />
                        <br />
                        Bei der FODMAP-Diät werden zunächst alle Lebensmittel gemieden, die einen hohen 
                        FODMAP-Gehalt aufweisen. So kann die Aufnahme der FODMAPs so weit reduziert werden, 
                        dass die Mahlzeiten zum einen möglichst wenige mögliche Beschwerdeverursacher enthalten 
                        und zum anderen nur noch leichter verdauliche Kohlenhydrate verzehrt werden, die 
                        dann frühzeitig im Darm verdaut werden können. So gelangen dann kaum noch Kohlenhydrate 
                        in tiefere Abschnitte des Dünndarms, und die dort fälschlicherweise siedelnden 
                        Bakterien bekommen keine Nahrung mehr.
                        <br />
                        <a id="intoleranzen">&nbsp;</a>
                        <hr>
                        <h5>FODMAP-Diät bei Nahrungsmittel-Unverträglichkeiten</h5>
                        <hr>
                        Das Problem bei der reinen FODMAP-Diät ist, dass sie &#187;nur&#171; <b>die Summe</b> 
                        der problematischen Inhaltsstoffe betrachtet und bewertet. Es kann durchaus sein, 
                        dass beispielsweise ein Lebensmittel, das zwar keine Laktose und nur wenige Oligosacharide 
                        und Zuckeralkohole, aber relativ viel Fruktose enthält, mit dem Etikett &#187;niedriger 
                        FODMAP-Gehalt&#171; ausgezeichnet wird. An diesem Beispiel wird deutlich, dass es 
                        bei der FODMAP-Diät bei bekannten oder vermuteten Unverträglichkeiten <b>zusätzlich</b>
                        wichtig ist, die ggf. für Sie unbekömmlichen Stoffe im Auge behalten. Selbstverständlich 
                        gilt dies auch für eventuelle Allergien.
                        <br />
                        <a id="lebensmittel">&nbsp;</a>
                        <hr>
                        <h5>Lebensmittel-Auswahl</h5>
                        <hr>
                        Bei der FODMAP-Diät &ndash; werden alle Lebensmittel gemieden, deren Menge u.a. 
                        an Laktose, Fruktose, Oligosacchariden und Zuckeralkoholen in der Summe eine bestimmte Grenze überschreitet.
                        Meidet man diese mit &#187;hoher FODMAP-Gehalt&#171; bewerteten Lebensmittel und 
                        verzehrt nur solche mit dem Prädikat &#187;niedriger FODMAP-Gehalt&#171;, wird 
                        sich die Menge der insgesamt verzehrten FODMAPS in Grenzen halten. Eine FODMAP-freie 
                        Diät einzuhalten, ist unmöglich, aber es reicht in den allermeisten Fällen die 
                        konsequent gezielte Auswahl der Lebensmittel mit einem niedrigen FODMAP-Gehalt.
                        <br />
                        <br />
                        Zusätzlich muss man unbedingt auf die individuellen Unverträglichkeiten achten. Auch
                        wenn die Lebensmittel mit einem niedrigen FODMAP-Gehalt meist nur geringe Mengen 
                        der einzelnen unbekömmlichen Stoffe enthalten, beruht ihre Bewertung ja immer auf 
                        <b>einer Summe</b> von Faktoren. Deshalb ist es wichtig, auch immer noch genau auf die 
                        eigenen Unverträglichkeiten zu achten. In einigen Fällen sind es dann noch zusätzliche 
                        Lebensmittel, die gemieden werden müssen, um wirklich beschwerdefrei zu werden.
                        <br />
                        <br />
                        Nicht enthalten in den FODMAP-Listen sind Allergene. Da die verschiedensten 
                        Lebensmittel Allergien auslösen können, können diese Möglichkeiten nicht alle mit 
                        berücksichtigt werden. Bitte achten Sie deshalb auch immer konsequent 
                        auf Ihre persönlichen Allergene.
                        <br />
                        <a id="dauer">&nbsp;</a>
                        <hr>
                        <h5>Dauer</h5>
                        <hr>
                        Die FODMAP-Diät sollte in ihrer strengen Ausprägung  
                        immer eine vorübergehende Diät sein. In den meisten Fällen zeigt sich unter der 
                        konsequenten Meidung aller möglichen Beschwerdeverursacher eine rasche Besserung. 
                        Um wieder zu einer größtmöglichen Vielfalt an Nahrungsmitteln zurückzukehren, 
                        werden nach etwa 4 &ndash; 6 Wochen sehr vorsichtig und in kleinen Mengen mehr und mehr 
                        Lebensmittel hinzugenommen werden &ndash; immer unter Beobachtung der individuellen 
                        Bekömmlichkeit. Sobald wieder Beschwerden auftreten, müssen die entsprechenden 
                        Komponenten wieder weggelassen bzw. reduziert werden.
                        <br />
                        <a id="datenbank">&nbsp;</a>
                        <hr>
                        <h5>DorisPaas.de &ndash; Lebensmittel-Datenbank</h5>
                        <hr>
                        Eine gute Hilfe bei der Ermittlung geeigneter Lebensmittel sowohl in Bezug auf den 
                        FODMAP-Gehalt als auch auf viele Nahrungsmittel-Unverträglichkeiten ist die
                        <br />
                        &#187;<a href="lebensmittel-datenbank-info">DorisPaas.de &ndash; Lebensmittel-Datenbank</a>&#171;
                        <br /> 
                        Sie finden hier weit über Tausend Lebensmittel, die Sie in Bezug auf den FODMAP-Gehalt 
                        und gleichzeitig auf verschiedene Unverträglichkeiten filtern können.
                        <br />
                        <br />
                        <br />
                        <img src="<?php echo IMG_PATH; ?>ampelnhochniedrig.png" alt="" class="left" />
                        <br />
                        <br />
                        <br />
                        <br />
                        <br />
                        Für die FODMAP-Gehalte &#187;niedrig&#171;, &#187;vorsichtig testen&#171; und &#187;hoch&#171;
                        wurden für jedes einzelne Lebensmittel die Signalfarben grün, gelb bzw. rot gewählt.
                        <br />
                        <br />
                        <br />
                        <img src="<?php echo IMG_PATH; ?>ampelngruengelbrot.png" alt="" class="left" />
                        <br />
                        <br />
                        <br />
                        <br />
                        <br />
                        Gleichzeitig berücksichtigt die Lebensmittel-Datenbank folgende Nahrungsmittel-Intoleranzen, 
                        für die als Kennzeichen ebenfalls die Ampelfarben grün, gelb und rot verwendet werden:
                        <br />
                        <b>&#149;</b> Laktose-Intoleranz
                        <br />
                        <b>&#149;</b> Fruktose-Intoleranz
                        <br />
                        <b>&#149;</b> Sorbit-Intoleranz
                        <br />
                        <b>&#149;</b> Histamin-Intoleranz
                        <br />
                        <b>&#149;</b> Oligosaccharid-Intoleranz
                        <br />
                        <b>&#149;</b> Zöliakie/Gluten-Sensitivität
                        <br />
                        <b>&#149;</b> Salicylat-Intoleranz
                        <br />
                        <b>&#149;</b> Allergenes Potenzial
                        <br />
                        <br />
                        <hr>
                        <a id="beratung">&nbsp;</a>
                        <div class="row">
                        <div class="col s12 m2">
                        <h5>Beratung</h5>
                        <br />
                            <a href="http://www.ganzheitliche-gesundheitsberatung.de" target="_blank">
                                <img src="<?php echo IMG_PATH; ?>praxiswebsite.png" alt="" class="inline" /></a>
                        </div>
                        </div>
                        <div class="row">
                        <div class="col s12 m12">
                            Gerne biete ich Ihnen eine individuelle Beratung an &ndash; 
                            auf Wunsch auch telefonisch oder per Skype.
                            <br />
                            Bitte informieren Sie sich auf meiner Praxis-Website <a href="http://www.ganzheitliche-gesundheitsberatung.de" target="_blank">&#187;www.Ganzheitliche-Gesundheitsberatung.de&#171;</a>
                        </div>
                        </div>
                        <hr>
                        <br />
                        <a href="guterrat" target="_blank"><img src="<?php echo IMG_PATH; ?>hilfreich.png" alt="" class="left" /></a>
                        <br />
                        <br />                        
                        <hr />
                        <a href="javascript: scrollMainToTop();" class="nachoben">nach oben</a>
                    </div>
                </div>
            </div>    
            <br>
            <br> 
            <div class="bodyspacer"></div> 
        </div>