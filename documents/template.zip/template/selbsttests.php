        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br /> 
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>
                <h1 class="header center orange-text">Selbsttests bei Nahrungsmittel-Unverträglichkeiten &ndash;</h1>      
                <div class="row center">        
                    <h5 class="header col s12 light">wann sind sie sinnvoll?</h5>      
                </div>  
            </div>  
        </div> 
        <div class="container">    
            <div class="section">   
                <div class="row margintoprow">        
                    <div class="col s12 m4">
                        <ul class="nav">
                            <li>
                                <b>Abschnitte dieser Seite:</b>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>selbsttests#medizinischetests">Selbsttests im medizinischen Bereich sind nicht neu</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>selbsttests#selbsttests">Selbsttests auf Nahrungsmittel-Unverträglichkeiten</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>selbsttests#auswahl">Auswahl eines geeigneten Tests</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>selbsttests#durchfuehrung">Probleme bei der Durchführung</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>selbsttests#nachsorge">Beratung und Betreuung des Patienten nach dem Test</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>selbsttests#gluten">Extrembeispiel &#187;Gluten-Test&#171;</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>selbsttests#arzttests">Ist beim Arzt eine korrekte Durchführung gewährleistet?</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>selbsttests#selbstinitiative">Selbstinitiative des Patienten erwünscht</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>selbsttests#fazit">Fazit</a>
                            </li> 
                        </ul>
                    </div>
                    <div class="col s12 m8">
                        <img src="<?php echo IMG_PATH; ?>testset.png" alt="" class="right" />
                    </div>
                </div>
                <div class="row margintoprow">        
                    <div class="col s12 m12">
                        Ich habe Verdauungsbeschwerden. Bin ich krank? Wenn ja, an welcher Krankheit leide 
                        ich? Ist es eine Nahrungsmittel-Unverträglichkeit? Und welche Nahrungsmittel könnten 
                        verantwortlich sein? Diese Fragen möchte ich wie jeder, der über längere Zeit an 
                        bestimmten Symptomen leidet, möglichst schnell mit einem geeigneten Test beantwortet 
                        haben. 
                        <br />
                        <br />
                        Immer wieder klagen Betroffene darüber, dass es offensichtlich in solchen Fällen 
                        oftmals lange Wartezeiten bei den Ärzten zu geben scheint und es nicht einfach ist, 
                        wirklich schnell eine zuverlässige Diagnose zu bekommen. Deshalb sprechen sie mit 
                        Freunden und Bekannten &ndash; jeder kennt ja einen, der auch solche Beschwerden 
                        hat. Und im Internet gibt es neben mannigfaltigen Informationen auch eine Reihe 
                        von Fragebögen, die einen Verdacht in eine bestimmte Richtung zu erhärten scheinen. 
                        Wie zuverlässig und belastbar diese Informationen sind, ist für den Laien schwer 
                        zu beurteilen, denn er kann sie nur schwer auf Seriosität und Kompetenz zu überprüfen.
                        <br />
                        <br />
                        Diese Fragestellungen und Problematik sind wohl ganz offensichtlich Ursache für 
                        eine Entwicklung, die Pharmahersteller und medizinische Labore veranlasst haben, 
                        Tests auf Nahrungsmittel-Unverträglichkeiten für den Hausgebrauch zu entwickeln 
                        und zu vertreiben, denn diese Produkte erobern seit einigen Monaten in großer Zahl 
                        den Markt. Der Betroffene greift dies als vermeintlich gute Alternative auf, denn 
                        die Firmen veröffentlichen auf ihren Websites Gebrauchsanleitungen, die dem Käufer 
                        suggerieren, dass gar nichts schief gehen kann. Auch sind die Preise moderat, und 
                        die Zusicherung, das Testergebnis schon nach wenigen Tagen per Post zugesandt zu 
                        bekommen, ist vielversprechend.
                        <br />
                        <a id="medizinischetests"></a>
                        <hr>
                        <h5>Selbsttests im medizinischen Bereich sind nicht neu</h5>
                        <hr>
                        Schon seit Jahrzehnten gibt es Schwangerschaft-Selbsttests, Blutdruck-Messgeräte 
                        für zu Hause, Urin-Teststreifen und digitale Messgeräte zur Ermittlung des 
                        Blutzuckers und viele andere mehr. Immer erhält der Patient sofort ein Ergebnis, 
                        das er auf Applikatoren, Teststreifen oder einer digitalen Anzeige ablesen kann. 
                        Diese Testmethoden sind auf jeden Fall sinnvoll: Sie können die Zusammenarbeit mit 
                        dem Arzt unterstützen und ergänzen, der die vom Patienten ermittelten Werte in 
                        seine Diagnose und Therapieempfehlungen mit einbeziehen kann. Nie jedoch wird ein 
                        Arzt sich bei verdächtigen Befunden allein auf solche Werte beschränken, sondern 
                        selbst eine Diagnostik durchführen, die er ggf. durch die zusätzlichen Daten ergänzt. 
                        Der unbestreitbare Vorteil solcher Selbsttest kann aber vor allem auch darin liegen, 
                        dass die Patienten durch die Mitbeteiligung zu einem gesundheitsbewussteren Verhalten 
                        animiert werden können, wenn sie durch krankhafte Werte die Konsequenzen einer 
                        ungesunden Lebensweise zeitnah vor Augen geführt bekommen. 
                        <br />
                        <br />
                        <a id="selbsttests"></a>
                        <hr>
                        <h5>Selbsttests auf Nahrungsmittel-Unverträglichkeiten</h5>
                        <hr>
                        Zusätzlich zu diesen etablierten Tests werden nun seit einigen Monaten vor allem 
                        über das Internet Selbsttests auf Nahrungsmittel-Unverträglichkeiten angeboten 
                        &ndash; sicherlich nicht zuletzt auch als Ergebnis einer immer intensiver geführten 
                        Diskussion über die Verbreitung dieser Intoleranzen und der entsprechenden, vermehrt 
                        in den Supermärkten angebotenen laktose-, fruktose- und glutenfreien Lebensmittel 
                        und vielen anderen Diätprodukten. Die passende Möglichkeit zur Selbstdiagnose gibt 
                        es nun in Form von Wasserstoff-Atemtests auf Laktose-, Fruktose- und Sorbit-Intoleranz, 
                        sowie einen Glukose-Atemtest auf Dünndarmfehlbesiedelung, weiterhin Stuhltests für 
                        Kohlenhydrat-Malabsorptionen und die Ermittlung der Qualität der Mikrobiota (Darmflora) 
                        &ndash; alle zur Durchführung zu Hause. Ganz neu sind &#187;Gluten-Tests&#171;, 
                        mit denen man bestimmte Antikörper im Kapillarblut oder Stuhl aufspüren und so 
                        ermitteln kann, ob eine Zöliakie vorliegt.
                        <br />
                        <br />
                        Diese Tests basieren allesamt auf gleichen oder ähnlichen Prinzipien, nach denen 
                        auch in der ärztlichen Praxis oder im medizinischen Labor die Untersuchungsergebnisse 
                        ermittelt werden. Bisher ist mir auch noch kein unseriöses Unternehmen bekannt, 
                        das sich hier nicht ehrlich um belastbare Befunde bemühen würde. Nicht ganz 
                        auszuschließen oder sogar zu befürchten ist allerdings, dass bald auch schwarze 
                        Schafe ein Stück von diesem großen Kuchen abhaben werden wollen. Und hier die Spreu 
                        vom Weizen zu trennen, dürfte für den Patienten selbst sicherlich so gut wie unmöglich 
                        sein.
                        <br />
                        <br />
                        <a id="auswahl"></a>
                        <hr>
                        <h5>Auswahl eines geeigneten Tests</h5>
                        <hr>
                        Zu allererst ist vor der Auswahl eines geeigneten Tests zu bedenken, dass häufig 
                        nicht nur eine, sondern gleich mehrere Intoleranzen für Verdauungsprobleme 
                        verantwortlich sein können und dass die verschiedenen Unverträglichkeiten großteilig 
                        die gleichen oder zumindest sehr ähnliche Symptome hervorrufen. Dies kann dazu 
                        führen, dass mehrere Tests nacheinander durchgeführt werden müssen. Die Hersteller 
                        und auch die meisten Internet-Informationen klären den Probanden aber nicht 
                        ausreichend darüber auf, dass ein Test auf eine bestimmte Nahrungsmittel-Unverträglichkeit 
                        erst Sinn macht, wenn durch andere Methoden wie z.B. ein Ernährungs- und Symptomtagebuch 
                        ein tatsächlich begründeter Verdacht auf genau diese Intoleranz(en) besteht. So 
                        kann schnell ein erkleckliches Sümmchen zusammen kommen, wenn man zwei oder gar 
                        mehrere verschiedene Tests kaufen muss &ndash; Kosten, die die Krankenkasse übernehmen 
                        würde, wenn die erforderlichen Tests beim Arzt durchgeführt werden.
                        <br />
                        <br />
                        <a id="durchfuehrung"></a>
                        <hr>
                        <h5>Probleme bei der Durchführung</h5>
                        <hr>
                        Mit dem Testset erhält der Proband eine Gebrauchsanleitung, die versucht, den Leser 
                        sowohl über eine korrekte Vorbereitung als auch über eine fehlerfreie Durchführung 
                        des Tests zu informieren. Als großes Problem hierbei sehe ich jedoch, dass diese 
                        Informationen zum einen nicht immer ausreichend und teilweise leider auch nicht 
                        ganz korrekt sind (z.B. bei den Empfehlungen für die zeitlichen Abstände zu einer 
                        Antibiose oder zwischen Atemtests mit verschiedenen Kohlenhydraten oder Stuhltests). 
                        Zum anderen kann nicht wirklich sichergestellt werden, dass der Proband auch alles 
                        richtig verstanden und befolgt hat. Schon kleine Abweichungen bei der Vorbereitung 
                        und bei der Durchführung können entscheidende Änderungen der erzielten Werte bewirken.
                        Somit ist die Belastbarkeit der Diagnose zumindest zweifelhaft. 
                        <br />
                        <br />
                        Bei Atemtests kann sich ein weiteres Problem ergeben, wenn sich bei der ersten 
                        Atemprobe ein zu hoher Basiswert (Nüchternwert) ergibt. Nur wenn der Basiswert 
                        unterhalb einer bestimmten Grenze liegt, kann die Fortsetzung des Atemtests zu 
                        einer korrekten Diagnose führen. Der Proband kann diesen Basiswert aber nicht selbst 
                        erkennen, bevor nicht der komplette Test durchgeführt und vom Labor ausgewertet 
                        wurde. Nicht nur die Kosten waren dann umsonst und der gesamte Test wertlos, vor 
                        allem auch die (dann unnötige) Belastung durch das Trinken einer eventuell 
                        unverträglichen Zuckerlösung war vergebens. Um ein aussagekräftiges Ergebnis zu 
                        erhalten, muss der komplette Test in einem solchen Fall wiederholt werden &ndash; 
                        und dies kann frühestens nach einer Wartezeit von 2 Wochen geschehen, da sich die 
                        Darmflora erst von den durch die Testlösung hervorgerufenen Irritationen erholen 
                        muss. Bei einem Test in einer spezialisierten Praxis wäre ein erhöhter Basiswert 
                        sofort erkannt worden, so dass die Testlösung erst gar nicht verabreicht worden 
                        wäre und der Test bereits nach wenigen Tagen erneut durchgeführt werden könnte.
                        <br />
                        <br />
                        Bei keinem der mir bekannten Atem- und vor allem Stuhltests werden übrigens vorherige 
                        Ernährungsgewohnheiten (z.B. eher eiweißbetont oder vegan oder kohlenhydratreich) 
                        abgefragt und in die Bewertung mit einbezogen, obwohl diese verschiedenen Vorlieben 
                        durchaus die Zusammensetzung der Darmflora und damit ein Messergebnis beeinflussen 
                        können, ohne gleich krankhaft zu sein.
                        <br />
                        <br />
                        Selbst wenn ein Test korrekt durchgeführt wurde, können Ergebnisse durch den 
                        Rückversand der Proben beeinflusst werden: Die Hersteller weisen in der 
                        Gebrauchsanleitung zwar darauf hin, dass die Probenrücksendung nicht an Wochenenden 
                        und nicht vor Feiertagen erfolgen soll. So soll eine lange Verweildauer auf dem 
                        Postweg vermieden werden. Auszuschließen ist es aber nicht, dass ein Paket doch 
                        über einige Tage und in den entsprechenden Jahreszeiten bei extremen Temperaturen 
                        im Postversand hängen geblieben ist und die Proben durch diese Bedingungen unbrauchbar 
                        geworden sind. Selbstverständlich wäre dieses Problem bei Arztpraxen, die Proben 
                        auf dem Postweg an Labore versenden, ebenfalls gegeben. Größere Spezialpraxen, die 
                        häufig solche Tests durchführen, verfügen jedoch in den meisten Fällen entweder 
                        über eigene Messgeräte oder arbeiten mit Kurierdiensten zusammen, die Proben auf 
                        direktem Wege zu einem angeschlossenen Labor transportieren.
                        <br />
                        <br />
                        <a id="nachsorge"></a>
                        <hr>
                        <h5>Beratung und Betreuung des Patienten nach dem Test</h5>
                        <hr>
                        Nicht vergessen werden darf natürlich auch, dass mit der Auswertung eines Selbsttests 
                        die anschließende Aufklärung des Patienten, wie er nun mit dieser Diagnose umzugehen 
                        hat, lediglich als ein allgemeiner Ratschlag in Form von Textbausteinen gegeben wird. 
                        Die individuellen Umstände des Patienten mit in diese Ratschläge einzubeziehen, wie 
                        dies (im Idealfall) in einem persönlichen Abschlussgespräch mit einem Arzt geschehen 
                        sollte, kann ein Labor nicht leisten. Ein Patient kann durch ein Messergebnis und 
                        die daraus schlussgefolgerte Diagnose u.U. psychisch belastet oder mit den Konsequenzen 
                        überfordert sein. In einer Praxis besteht die Möglichkeit, dass entweder der Arzt 
                        oder aber eine Mitarbeiterin dies bemerken und geeignete Maßnahmen erkennen, 
                        einleiten oder empfehlen.
                        <br />
                        <br />
                        <a id="gluten"></a>
                        <hr>
                        <h5>Extrembeispiel &#187;Gluten-Test&#171;</h5>
                        <hr>
                        In diesem Zusammenhang möchte ich hier auch das (für mich) extreme Beispiel der 
                        &#187;Gluten-Tests&#171; hervorheben: Erstens verwenden die mir bekannten &#187;Gluten-Tests&#171; 
                        (Stuhl- und Bluttests) in ihrer Beschreibung den irreführenden Namen &#187;Gluten-Unverträglichkeit&#171;, 
                        obwohl sie das Vorliegen einer Zöliakie abprüfen wollen. Leider gelingt hier die 
                        Abgrenzung zur Gluten-Sensitivität, die ja ebenfalls eine Gluten-Unverträglichkeit 
                        ist, nicht ausreichend, so dass ein Patient also durchaus Probleme mit Gluten haben 
                        könnte, auch wenn das Testergebnis negativ ist und keine Zöliakie vorliegt.
                        <br />
                        <br />
                        Weiterhin muss unbedingt beachtet werden, dass es sich bei der Zöliakie um eine 
                        schwere Erkrankung handelt, bei der sehr enge Ernährungsrichtlinien eingehalten 
                        werden müssen, um ernste und dauerhafte Schädigungen zu vermeiden. Deshalb darf 
                        bei der Diagnostik keinesfalls vergessen werden, welch große psychische Belastungen 
                        auf einen Patienten bei einem solchen Befund zukommen. Wer fängt einen Patienten 
                        auf, der über eine solche Diagnose per Post informiert wird? Wer begleitet ihn? 
                        Wer leitet ihn an, wie seine Diät in Zukunft auszusehen hat? Wer hilft ihm zu 
                        unterscheiden, welche Nahrungsmittel er meiden muss? Wer zeigt ihm Perspektiven auf, 
                        welch umfangreiche Palette ihm trotz allem noch zur Verfügung steht? Vor allem aber, 
                        wer sagt ihm, dass neben der Ermittlung von einem oder zwei Antikörperwerten erstens 
                        noch weitere Antikörper ermittelt und zweitens eine Dünndarmspieglung mit Biopsie 
                        durchgeführt werden müssen, bevor eine Zöliakie-Diagnose tatsächlich belastbar ist? 
                        Und wer sagt ihm zu guter Letzt, dass er jetzt keinesfalls auf eigene Faust mit 
                        einer glutenfreien Ernährung beginnen darf, weil sonst die weitere Diagnostik nicht 
                        mehr greift? Bei einem dieser Produkte, für das ein &#187;Musterbefund&#171; im Netz 
                        aufrufbar ist, wird eine solche &#187;vorübergehende glutenfreie Kost&#171; sogar 
                        ausdrücklich &#187;zur Erhärtung der Diagnose&#171; empfohlen! Dies ist ein 
                        eklatanter Fehler, der dazu führt, dass vor jeder weiteren Diagnostik wertvolle 
                        Zeit für den Patienten verstreicht, weil er erst wieder über einige Wochen 
                        glutenhaltige Kost verzehren muss, bevor die anderen Parameter wieder aussagekräftig 
                        sein können. Unabhängig vom am Schluss dieses Artikels gezogenen Gesamtfazit möchte 
                        ich bereits an dieser Stelle betonen, dass aus allen diesen Gründen ein Selbsttest 
                        für Gluten aus meiner Sicht keinesfalls empfehlenswert ist.
                        <br />
                        <br />
                        <a id="arzttests"></a>
                        <hr>
                        <h5>Ist beim Arzt eine korrekte Durchführung gewährleistet? </h5>
                        <hr>
                        Ich wage nicht zu behaupten, dass wirklich ausnahmslos alle Ärzte, die Patienten 
                        in ihren Praxen auf Nahrungsmittel-Unverträglichkeiten testen, die Vorbereitung, 
                        Durchführung und Nachsorge tatsächlich korrekt umsetzen &ndash; ob die Fehler aus 
                        Mangel an Zeit oder auch aus Mangel an Wissen geschehen, ist für das Ergebnis 
                        unerheblich. In meiner Praxis haben mich schon viele Klienten kontaktiert, bei 
                        denen der Hausarzt bei einem Test auf eine Nahrungsmittel-Unverträglichkeit leider 
                        eklatante Fehler begangen hat (falsche Menge des Testzuckers, falsche Atemtechnik, 
                        Nichtbeachtung eines zu hohen Nüchternwertes, zu frühes Abbrechen des Tests nach 
                        nur zwei Atemproben, fehlerhafte Interpretation der Testergebnisse, etc.). Dadurch 
                        wurde dann die Belastbarkeit der aus dem Test gefolgerten Diagnose unnötig beeinträchtigt. 
                        <br />
                        <br />
                        Wenn Sie sich für einen Test beim Arzt entscheiden, wählen Sie bitte unbedingt 
                        einen Spezialisten. Die Aufgabe eines Hausarztes (Allgemeinmediziner, Praktischer 
                        Arzt) ist es, mit einem breit gefächerten Erfahrungsspektrum Probleme zu erkennen 
                        &ndash; die Tiefenkenntnisse liegen bei den Spezialisten für die einzelnen Fachgebiete, 
                        zu denen der Hausarzt den Patienten dann ggf. überweist. Es ist zwar nicht auszuschließen, 
                        dass gerade Ihr Hausarzt sich intensiv mit Nahrungsmittel-Unverträglichkeiten und 
                        deren Diagnosemethoden befasst hat und einen geeigneten Test qualifiziert durchführen 
                        und interpretieren kann &ndash; nur ist dies wahrscheinlich schwer für Sie zu erkennen. 
                        Am besten aufgehoben sind Sie deshalb bei einem Gastroenterologen. Hier ist die 
                        Chance auf eine fehlerfreiere Durchführung und anschließende korrektere Interpretation 
                        der Testergebnisse am höchsten. 
                        <br />
                        <br />
                        <a id="selbstinitiative"></a>
                        <hr>
                        <h5>Selbstinitiative des Patienten erwünscht</h5>
                        <hr>
                        Von eigenverantwortlicher Selbstinitiative soll Patienten mit Verdauungsbeschwerden 
                        trotzdem in keinster Weise generell abgeraten werden &ndash; im Gegenteil: Informieren 
                        Sie sich im Vorfeld, gerne auch über das Internet. So erweitern Sie ihr Wissen und 
                        können Sie sich mit Ihrem Arzt auf Augenhöhe unterhalten. Sie können verstehen, 
                        welche Maßnahmen er Ihnen vorschlägt und können über Ihre Gesundheit mitentscheiden. 
                        Vor allem aber befähigt es Sie, sich ggf. einen geeigneten Facharzt zu suchen und 
                        von Ihrem Hausarzt dorthin überweisen zu lassen. Und sollten Sie hier länger auf 
                        einen Termin warten müssen, können Sie u.U. über Ihren Hausarzt oder auch mit 
                        Unterstützung Ihrer Krankenkasse einen Termin in kürzerer Zeit erhalten. 
                        <br />
                        <br />
                        In der Wartezeit empfiehlt es sich dringend, ein Ernährungs- und Symptomtagebuch 
                        zu führen, in dem Sie alles, was Sie essen und trinken, genauestens protokollieren. 
                        Ebenso tragen Sie die Symptome mit Zeitpunkt und Intensität ein. Diese Informationen 
                        sind für den Arzt eine wertvolle Ergänzung und Entscheidungshilfe für einen 
                        geeigneten Test.
                        <br />
                        <br />
                        <a id="fazit"></a>
                        <hr>
                        <h5>Fazit</h5>
                        <hr>
                        Für die in der Überschrift gestellte Frage nach der Sinnhaftigkeit von Selbsttests 
                        zur Diagnose von Nahrungsmittel-Unverträglichkeiten kann somit folgendes Fazit 
                        gezogen werden: Wichtig und ratsam ist es immer, sich vor einem Test &ndash; egal, 
                        ob Sie ihn in einer Arztpraxis oder zu Hause durchführen wollen &ndash; über die 
                        Art der Beschwerden zu informieren und einen dafür geeigneten Test auszusuchen. 
                        Unerlässlich ist es im Vorfeld, ein Ernährungs- und Symptomtagebuch zu führen, um 
                        so die wahrscheinlichste Unverträglichkeit zu ermitteln. Erst dann kann der 
                        richtige Test ausgewählt werden.
                        <br />
                        <br />
                        Sie sollten vor einer Entscheidung für oder gegen einen Selbsttest die Vor- und 
                        Nachteile gegenüber einem Test in einer qualifizierten Praxis kennen und abwägen 
                        (Schnelligkeit, Belastung, Genauigkeit, Preis). Weiterhin ist es erforderlich, dass 
                        Sie sich im Vorfeld über eine korrekte Vorbereitung und Durchführung des Tests 
                        informieren &ndash; auch hier in jedem Falle, also unabhängig davon, ob Sie selbst 
                        oder der Arzt testen. Bei einer Entscheidung für einen Selbsttest muss neben Ihrer 
                        umfassenden Vorbereitung ein schneller Rückversand zum Labor bei angemessenen 
                        Temperaturen sichergestellt sein, damit insgesamt eine belastbare Diagnose gestellt 
                        werden kann. Bei der Entscheidung für einen Test durch den Arzt ist meist dem 
                        Spezialisten der Vorzug vor dem Allgemeinmediziner zu geben, um die größtmögliche 
                        Chance auf einen fehlerfrei durchgeführten Test zu gewährleisten. Ein fehlerhaft 
                        durchgeführter Test durch einen nicht ausreichend informierten Arzt bringt gegenüber 
                        einem korrekt durchgeführten Selbsttest eher Nachteile.
                        <br />
                        <br />
                        Ggf. kann es sinnvoll sein, wenn Sie aufgrund Ihrer Vorinformationen mit Maßnahmen 
                        oder der geplanten Durchführung von Tests durch Ihren Arzt nicht einverstanden 
                        sind, einen auf Nahrungsmittel-Unverträglichkeiten und Diagnosemethoden spezialisieren 
                        Heilpraktiker oder Gesundheitsberater zu konsultieren und mit diesem die korrekte 
                        Durchführung eines geeigneten Tests zu besprechen. So können Fehler bereits im 
                        Vorfeld vermieden werden. 
                        <br />
                        <hr>
                        <div class="row">
                        <div class="col s12 m2">
                            <a href="http://www.ganzheitliche-gesundheitsberatung.de" target="_blank">
                                <img src="<?php echo IMG_PATH; ?>praxiswebsite.png" alt="" class="inline" /></a>
                        </div>
                        </div>
                        <div class="row">
                        <div class="col s12 m12">
                            Gerne biete ich Ihnen eine individuelle Beratung an &ndash; 
                            auf Wunsch auch telefonisch oder per Skype.
                            <br />
                            Bitte informieren Sie sich auf meiner Praxis-Website <a href="http://www.ganzheitliche-gesundheitsberatung.de" target="_blank">&#187;www.Ganzheitliche-Gesundheitsberatung.de&#171;</a>
                        <hr>
                        Nach einer solchen qualifizierten Vorbereitung könnte es möglich sein, taugliche 
                        Tests dann tatsächlich auch zu Hause durchzuführen, wenn Sie mit Ihrem Berater 
                        zum einen ein geeignetes Produkt ausgewählt haben und wenn er Sie zum anderen 
                        ausführlich über die erforderlichen Vorbereitungen, über die korrekte Durchführung 
                        und die anschließenden Konsequenzen aufgeklärt hat.
                        <br />
                        <br />
                        Und natürlich sollten Sie sich der Tatsache bewusst sein, dass Sie sich im Falle 
                        eines positiven Testergebnisses bei seriösen Quellen (Arzt, Ernährungs- und/oder 
                        Gesundheitsberater, vertrauenswürdige Internetseiten, Selbsthilfegruppen) über 
                        die sich daraus ergebende Ernährungsweise informieren müssen, um die richtigen 
                        Konsequenzen aus dieser Diagnose herleiten und wieder beschwerdefrei leben zu können. 
                        Nur wenn Sie alle diese Gesichtspunkte gut überlegt und abgewogen haben, kann die 
                        Entscheidung für einen Selbsttest unter Umständen für Sie Sinn machen. 
                        <br />
                        <br />
                        Bitte lesen Sie hierzu auch den Fachbeitrag, der in der Zeitschrift 
                        <a href="<?php echo FILES_PATH; ?>2014_09_01_aid_selbsttests.pdf" target="_blank">&#187;Ernährung im Fokus&#171;</a>, 
                        Ausgabe 9/2014 erschienen ist.
                        <br />
                        <br />
                        Zusätzlich finden Sie im Downloadbereich einen &#187;Selbsttest zur Ermittlung 
                        von Nahrungsmittel-Unverträglichkeiten, eines Reizdarm-Syndroms und/oder einer 
                        Dünndarmfehlbesiedelung (SIBO)&#171;
                        <br />
                        <hr />
                        <a href="javascript: scrollMainToTop();" class="nachoben">nach oben</a>

                    </div>
                </div>
            </div>  
            <br />
            <br />
            <br />  
            <div class="bodyspacer"></div> 
        </div>