        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br /> 
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>
                <h1 class="header center orange-text">DorisPaas-Newsletter</h1>      
                    <div class="row center">        
                    <h5 class="header col s12 light">Nichts mehr verpassen</h5>      
                    </div>     
            </div>  
        </div> 
        <div class="container">    
            <div class="section">   
                <div class="row margintoprow">        
                    <div class="col s12 m12">
                        Die Website &#187;www.dorispaas.de&#171; wird immer umfangreicher, und es gibt 
                        ständig Neuigkeiten in Sachen &#187;Nahrungsmittel-Intoleranzen&#171;, 
                        &#187;Gesunde Ernährung&#171;, &#187;Gesunde Verdauung&#171; und alle verwandten 
                        Bereiche. Da kann es schon schwer sein, nicht den Überblick zu verlieren und 
                        nichts zu verpassen.
                        <br />
                    </div>
                </div>
                <div class="row">        
                    <div class="col s12 m12">
                        <hr />
                        </div>
                        </div>
                <div class="row">        
                    <div class="col s12 m1">
                        <a id="newsletterabo"></a>
                        <a href="subscribe_newsletter"><img src="<?php echo IMG_PATH; ?>newsletter.png" alt="Newsletter bestellen" class="left" /></a>
                        </div>
                    <div class="col s12 m11">
                        <a href="subscribe_newsletter"><h5><br />Newsletter abonnieren</h5></a>
                        <br />
                        Warum lassen Sie sich nicht über alle erschienenen 
                        Neuigkeiten bequem und <b>kostenlos</b> per E-Mail informieren?
                        <br />
                        <br />
                        Fordern Sie ganz einfach den <a href="subscribe_newsletter">Newsletter</a>
                        an, der in zweimonatigen Abständen 
                        erscheint und Sie über alles informiert, was sich hier Neues tut.
                        Bitte klicken Sie auf den nebenstehenden Briefkasten, 
                        um den Newsletter als E-Mail zu abonnieren. Lesen Sie hierzu auch die 
                        <a href="datenschutz">Datenschutzerklärung</a>.
                        <br />
                        <br />
                        Sie erhalten nach der Bestellung die nächste Ausgabe des Newsletters. 
                        Sie erscheint 
                        
                        <!-- hier das neue Erscheinungsdatum einsetzen -->

                        <b>Mitte Mai 2018</b>. 
                        
                        Im <b><a href="<?= URL_ROOT ?>newsletter#archiv">Archiv</a></b>
                        können Sie sich die letzten Ausgaben des Newsletters anschauen. 
                        <br />
                        <br />
                        <br />
                        </div>
                        </div>
                <div class="row">        
                    <div class="col s12 m1">
                        <a id="newsletterstop"></a>
                        <a href="unsubscribe_newsletter_step1"><img src="<?php echo IMG_PATH; ?>newsletter-stoppen.png" alt="Newsletter stornieren" class="left" /></a>
                        </div>
                    <div class="col s12 m11">
                        <a href="unsubscribe_newsletter_step1"><h5><br />Newsletter abbestellen</h5></a>
                        <br />
                        Selbstverständlich können Sie den Newsletter jederzeit 
                        abbestellen &ndash; ein Klick genügt.
                    </div>
                </div>
                <div class="row margintoprow">        
                    <div class="col s12 m12">
                        <a id="archiv"></a>
                        <hr class="double" />
                        <h5>Newsletter-Archiv</h5>
                        <hr class="double" />
                        <br />
                        <img src="<?php echo IMG_PATH; ?>dorispaas-de-titelfoto-newsletter-w.png" alt="" class="left" /></a>
                        <br />
                        <br />
                        <br />
                        <br />
                        <br />
                        <br />
                        <br />
                        <br />
                        <br />
                        <br />
                        <hr />
                        <!-- aktueller Newsletter -->

                        <h5>Aktueller DorisPaas-Newsletter &#150; Ausgabe 39 (März 2018)</h5>
                        <hr />
                        <a href="http://www.dorispaas.de/" target="_blank"><img src="<?php echo IMG_PATH; ?>nl-2018-02-titel.png" alt="Titelbild" border="0" hspace="0" vspace="0" style="float: left; margin-left: 0px; margin-right: 20px; padding-bottom: 20px;" /></a>
                        Liebe Leserin, lieber Leser.
                        <br />
                        <br />
                        am 15. M&auml;rz findet weltweit der &#187;Internationale Weltverbrauchertag&#171; 
                        statt. Dies ist ein Aktionstag, den wir dem ehemaligen amerikanischen Pr&auml;sidenten John 
                        F. Kennedey verdanken, der am 13.3.1962, also vor sage und schreibe 56 Jahren, 
                        vor dem Kongress drei auch heute noch 
                        brandaktuelle Grundrechte f&uuml;r Verbraucher proklamierte. Dies sind erstens das 
                        Recht auf <b>Schutz vor betr&uuml;gerischer und irref&uuml;hrender Kennzeichnung von 
                        Waren oder Werbung f&uuml;r Produkte</b>, zweitens das Recht, <b>vor unwirksamen oder sogar 
                        gef&auml;hrlichen Medikamenten gesch&uuml;tzt zu werden</b> und drittens das Recht, 
                        unsere <b>Produkte aus einer breiten Palette mit marktgerechten Preisen ausw&auml;hlen 
                        zu k&ouml;nnen</b>. Unsere deutsche Regierung mit den Ministern f&uuml;r Verbraucherschutz, 
                        Landwirtschaft und Gesundheit haben mich mit ihren Entscheidungen bisher leider 
                        (noch) nicht davon &uuml;berzeugt, dass wir uns durch diese sehr sinnvollen 
                        Grunds&auml;tze gesch&uuml;tzt sehen k&ouml;nnten. Aber auch die Amerikaner und 
                        eigentlich alle anderen L&auml;nder der Welt haben in dieser Richtung noch einen 
                        weiten Weg vor sich. Umso wichtiger ist es, dass wir bei bzw. vor allen unseren 
                        Entscheidungen f&uuml;r oder gegen einen Kauf oder Verbrauch <b>die Augen aufmerksam 
                        offen halten</b>, um nicht Gefahr zu laufen, dass unsere Gesundheit 
                        ernsthaften Schaden nehmen kann. Zwei Beispiele (unter leider viel zu vielen) habe 
                        ich in den beiden Beitr&auml;gen dieses Newsletters f&uuml;r Sie zusammengestellt. 
                        Solange keine ausreichenden gesetzlichen Regelungen 
                        zum wirksamen Schutz der Verbraucher geschaffen werden, m&uuml;ssen wir die Hersteller 
                        mit unseren Kaufentscheidungen (be)zwingen und sch&auml;dliche Produkte so weit 
                        wie m&ouml;glich in den Regalen liegen lassen oder zumindest durch st&auml;ndiges, 
                        hartn&auml;ckiges Einfordern von unbedenklichen Lebensmitteln, Waren und Leistungen unsere 
                        Bed&uuml;rfnisse im Sinne der &uuml;ber 50 Jahre alten Verbraucherrechte lauthals 
                        kundtun &ndash; und zwar nicht nur am Internationalen Weltverbrauchertag, sondern 
                        an jedem Tag des Jahres.

                        <br />
                        <br />
                        <br />
                        <hr>
                        <br />
                        <a href="http://www.dorispaas.de/index.php?page=trinkwasser" target="_blank"><img src="http://www.dorispaas.de/assets/images/nl-2018-02-wasserfilter.png" alt="Bild Fasten" border="0" hspace="0" vspace="0" style="float: left; margin-left: 0px; margin-right: 20px; padding-bottom: 0px;" /></a>
                        <b>&#149;	<a href="http://www.dorispaas.de/index.php?page=trinkwasser" target="_blank">Schwerpunktthema &#187;Chlor im Trinkwasser&#171;</a></b>
                        <br />
                        Unser Trinkwasser ist nicht nur unser wichtigstes, sondern auch eines der am besten 
                        kontrollierten Lebensmittel. Obwohl die Qualit&auml;t durch die Trinkwasserverordnung 
                        gesetzlich garantiert sein sollte, hei&#223;t dies aber nicht, dass es zwangsl&auml;ufig 
                        auch immer f&ouml;rderlich f&uuml;r unsere Gesundheit ist. Es kann durch 
                        verschiedene Umst&auml;nde nicht nur Schadstoffe wie u.a. Nitrat oder Schwermetalle 
                        enthalten, sondern auch mit Keimen belastet sein. Die Wasserwerke m&uuml;ssen aber aufgrund 
                        der gesetzlichen Vorschriften unbedenkliches Trinkwasser liefern und da eine 
                        biologische Entkeimung teuer ist, greift man dort lieber zur chemischen Keule 
                        in Form von Chlor. 
                        <br />
                        <br />
                        Auch in unserer Darmflora befinden sich Keime &ndash; teils sch&auml;dliche, 
                        in einer gesunden Mikrobiota aber wesentlich mehr n&uuml;tzliche Keime. Diese haben 
                        vielf&auml;ltige Aufgaben wie vor allem die St&auml;rkung des Immunsystems. Die 
                        Darmkeime unterst&uuml;tzen uns aber auch bei der Verarbeitung eigentlich unverdaulicher 
                        Stoffe oder produzieren bestimmte Vitamine, die unser eigener K&ouml;rper nicht 
                        herstellen kann. Ohne unsere Darmflora h&auml;tten wir keine normale Verdauung, 
                        ja wir w&auml;ren &uuml;berhaupt nicht lebensf&auml;hig! Wenn wir nun mit dem 
                        Trinkwasser gr&ouml;&#223;ere Mengen Chlor aufnehmen, wirkt sich dies nat&uuml;rlich 
                        auch auf die Zusammensetzung unserer Darmflora aus. Es findet eine dauerhafte 
                        Belastung der Keimbalance durch das Trinken chlorhaltigen Wassers statt, und im 
                        Laufe der Zeit verschlechtert sich die Qualit&auml;t der f&uuml;r unsere Gesundheit 
                        so wichtigen Mikrobiota immer mehr. 
                        <br />
                        <br />
                        <hr>
                        <br />
                        <a href="http://www.dorispaas.de/index.php?page=blog#blog-2018-02-25" target="_blank"><img src="http://www.dorispaas.de/assets/images/nl-2018-02-schoellkraut.png" alt="" border="0" hspace="0" vspace="0" style="float: left; margin-left: 0px; margin-right: 20px; padding-bottom: 0px;" /></a>
                        <b>&#149;	<a href="http://www.dorispaas.de/index.php?page=blog#blog-2018-02-25" target="_blank">Ein wichtiger Hinweis zum Pr&auml;parat &#187;Iberogast&reg;&#171;</a></b>
                        <br />
                        Im Zusammenhang mit den oben erw&auml;hnten Verbraucherrechten m&ouml;chte ich 
                        auf ein Pr&auml;parat &ndash; das Iberogast&reg; &ndash; hinweisen, das in bestimmten 
                        F&auml;llen gerne von vielen Menschen bei Magen-/Darmproblemen verwendet wird. 
                        Dieses Mittel enth&auml;lt u.a. 
                        Sch&ouml;llkraut, das schon seit einiger Zeit im Verdacht steht, bei 
                        h&ouml;herer Dosierung und l&auml;ngerer Einnahmedauer Lebersch&auml;den verursachen 
                        zu k&ouml;nnen. Und &ndash; wen wundert es &ndash; dieser Verdacht wird
                        vom Hersteller Bayer in Leverkusen nicht nur nicht an die gro&#223;e Glocke geh&auml;ngt, sondern 
                        auch bis zum heutigen Tage im Beipackzettel verschwiegen. Aus diesem Grunde habe ich einen Beitrag zu 
                        diesem Thema in meinem Blog geschrieben und m&ouml;chte Ihnen empfehlen, sich diesen 
                        aufmerksam durchzulesen. Auch wenn ich mit meinen Beratungen grunds&auml;tzlich 
                        versuche, Probleme urs&auml;chlich und ganzheitlich zu betrachten und zu verbessern, 
                        kann es manchmal hilfreich sein, zun&auml;chst Symptome zu lindern und dies 
                        gelegentlich auch mit geeigneten Mitteln zu unterst&uuml;tzen. Iberogast&reg;
                        ist trotz des Gehalts an Sch&ouml;llkraut nicht grunds&auml;tzlich schlecht, aber 
                        es ist wichtig zu wissen, dass es sich hier nur um ein Akutmittel f&uuml;r eng umrissene 
                        Anwendungsgebiete handelt und keineswegs um ein Pr&auml;parat, das &uuml;ber l&auml;ngere 
                        Zeitr&auml;ume eingenommen werden kann oder soll. Schade, dass der Hersteller den 
                        Verbraucher hier nicht ausreichend informiert! 
                        
                        <br />
                        <br />
                        <hr>
                        <br />
                        Liebe Leserinnen und Leser, es ist schwierig, aus der Flut von Informationen, die 
                        uns &uuml;ber die verschiedenen Medien erreichen, die f&uuml;r uns wichtigen und &ndash; 
                        vor allem &ndash; die &#187;richtigen&#171; herauszufiltern. Was entspricht wirklich 
                        den Tatsachen und wann werden wir im wahrsten Sinne des Wortes an der Nase herumgef&uuml;hrt?
                        Wie oben erw&auml;hnt, scheint es noch ein sehr weiter Weg zu sein, bis es ein wirklich 
                        verl&auml;ssliches Verbraucherschutzgesetz gibt, das seinen Namen auch verdient.
                        Ich bitte Sie herzlich, mit allen Ihnen zur Verf&uuml;gung stehenden Mitteln daran 
                        mitzuarbeiten, dass wir uns irgendwann einmal darauf verlassen k&ouml;nnen, von 
                        den Herstellern und Produzenten &uuml;ber die Produkte umfassend informiert zu werden.
                        Der derzeit wirksamste Weg scheint mir zu sein, dass wir &#187;mit den F&uuml;&#223;en 
                        abstimmen&#171; &ndash; sprich, dass wir allein schon im eigenen Interesse keine Produkte kaufen, 
                        deren Auszeichnung unbefriedigend ist und nur solche Waren ausw&auml;hlen, die ehrlich 
                        deklariert sind. Ich wei&#223;, das ist nicht einfach und zumindest am Anfang 
                        etwas umst&auml;ndlich, aber ich hoffe, dass steter Tropfen den Stein h&ouml;hlt.
                        <br />
                        <br />
                        In diesem Sinne sende ich Ihnen bis zum n&auml;chsten Newsletter, den Sie in zwei Monaten, also 
                        etwa Mitte Mai 2018 erhalten, ganz herzliche Gr&uuml;&#223;e aus dem Rheinland 
                        <br />
                        Ihre                        
                        <br />
                        <img src="http://www.dorispaas.de/assets/images/nl-unterschrift-dopa.png" alt="" border="0" hspace="0" vspace="0" style="float: left; margin-left: 0px; margin-right: 10px; padding-bottom: 0px;" />
                        </p>
                        <br />
                        <br />
                        <br />
                        <i>P.S. Gerne k&ouml;nnen Sie diesen Newsletter auch an Freunde und Bekannte weiterleiten!</i>
                        <p>
                        <hr class="double" />
                        
                        
                        
                        <br />
                        <hr >
                        <h5>2018</h5>
                        <hr>
                        <br />
                        <a href="newsletter2_2018" target="_blank">DorisPaas-Newsletter &ndash; Ausgabe 39 (März 2018) &ndash; Schwerpunktthema: Chlor im Trinkwasser</a>
                        <br />
                        <br />
                        <a href="newsletter1_2018" target="_blank">DorisPaas-Newsletter &ndash; Ausgabe 38 (Januar 2018) &ndash; Schwerpunktthema: Fasten</a>
                        <br />
                        <br />
                        <hr >
                        <br />
                        <hr >
                        <h5>2017</h5>
                        <hr>
                        <br />
                        <a href="newsletter6_2017" target="_blank">DorisPaas-Newsletter &ndash; Ausgabe 37 (November 2017) &ndash; Schwerpunktthema: Glyphosat und unser Mikrobiom</a>
                        <br />
                        <br />
                        <a href="newsletter5_2017" target="_blank">DorisPaas-Newsletter &ndash; Ausgabe 36 (September 2017) &ndash; Schwerpunktthema: Atemgastests</a>
                        <br />
                        <br />
                        <a href="newsletter4_2017" target="_blank">DorisPaas-Newsletter &ndash; Ausgabe 35 (Juli 2017) &ndash; Schwerpunktthema: Sodbrennen und Reflux</a>
                        <br />
                        <br />
                        <a href="newsletter3_2017" target="_blank">DorisPaas-Newsletter &ndash; Ausgabe 34 (Mai 2017) &ndash; Schwerpunktthema: Was kann das Internet für Ihre Gesundheit leisten und was nicht?</a>
                        <br />
                        <br />
                        <a href="newsletter2_2017" target="_blank">DorisPaas-Newsletter &ndash; Ausgabe 33 (März 2017)</a>
                        <br />
                        <br />
                        <a href="newsletter1_2017" target="_blank">DorisPaas-Newsletter &ndash; Ausgabe 32 (Januar 2017)</a>
                        <br />
                        <br />
                        <hr >
                        <h5>2016</h5>
                        <hr />
                        <br />
                        <a href="newsletter6_2016" target="_blank">DorisPaas-Newsletter &ndash; Ausgabe 31 (November 2016)</a>
                        <br />
                        <br />
                        <a href="newsletter5_2016" target="_blank">DorisPaas-Newsletter &ndash; Ausgabe 30 (September 2016)</a>
                        <br />
                        <br />
                        <a href="newsletter4_2016" target="_blank">DorisPaas-Newsletter &ndash; Ausgabe 29 (Juli 2016)</a>
                        <br />
                        <br />
                        <a href="newsletter3_2016" target="_blank">DorisPaas-Newsletter &ndash; Ausgabe 28 (Mai 2016)</a>
                        <br />
                        <br />
                        <a href="newsletter2_2016" target="_blank">DorisPaas-Newsletter &ndash; Ausgabe 27 (März 2016)</a>
                        <br />
                        <br />
                        <a href="newsletter1_2016" target="_blank">DorisPaas-Newsletter &ndash; Ausgabe 26 (Januar 2016)</a>
                        <br />
                        <br />
                        <hr >
                        <h5>2015</h5>
                        <hr>
                        <br />
                        <a href="newsletter6_2015" target="_blank">DorisPaas-Newsletter &ndash; Ausgabe 25 (November 2015)</a>
                        <br />
                        <br />
                        <a href="newsletter5_2015" target="_blank">DorisPaas-Newsletter &ndash; Ausgabe 24 (September 2015)</a>
                        <br />
                        <br />
                        <a href="newsletter4_2015" target="_blank">DorisPaas-Newsletter &ndash; Ausgabe 23 (Juli 2015)</a>
                        <br />
                        <br />
                        <a href="newsletter3_2015" target="_blank">DorisPaas-Newsletter &ndash; Ausgabe 22 (Mai 2015)</a>
                        <br />
                        <br />
                        <a href="newsletter2_2015" target="_blank">DorisPaas-Newsletter &ndash; Ausgabe 21 (März 2015)</a>
                        <br />
                        <br />
                        <a href="newsletter1_2015" target="_blank">DorisPaas-Newsletter &ndash; Ausgabe 20 (Januar 2015)</a>
                        <br />
                        <br />
                        <hr >
                        <h5>2014</h5>
                        <hr>
                        <br />
                        <a href="newsletter6_2014" target="_blank">DorisPaas-Newsletter &ndash; Ausgabe 19 (November 2014)</a>
                        <br />
                        <br />
                        <a href="newsletter5_2014" target="_blank">DorisPaas-Newsletter &ndash; Ausgabe 18 (September 2014)</a>
                        <br />
                        <br />
                        <a href="newsletter4_2014" target="_blank">DorisPaas-Newsletter &ndash; Ausgabe 17 (Juli 2014)</a>
                        <br />
                        <br />
                        <a href="newsletter3_2014" target="_blank">DorisPaas-Newsletter &ndash; Ausgabe 16 (Mai 2014)</a>
                        <br />
                        <br />
                        <a href="newsletter2_2014" target="_blank">DorisPaas-Newsletter &ndash; Ausgabe 15 (März 2014)</a>
                        <br />
                        <br />
                        <a href="newsletter1_2014" target="_blank">DorisPaas-Newsletter &ndash; Ausgabe 14 (Januar 2014)</a>
                        <br />
                        <br />
                        <hr >
                        <h5>2013</h5>
                        <hr>
                        <br />
                        <a href="newsletter6_2013" target="_blank">DorisPaas-Newsletter &ndash; Ausgabe 13 (November 2013)</a>
                        <br />
                        <br />
                        <a href="newsletter5_2013" target="_blank">DorisPaas-Newsletter &ndash; Ausgabe 12 (September 2013)</a>
                        <br />
                        <br />
                        <a href="newsletter4_2013" target="_blank">DorisPaas-Newsletter &ndash; Ausgabe 11 (Juli 2013)</a>
                        <br />
                        <br />
                        <a href="newsletter3_2013" target="_blank">DorisPaas-Newsletter &ndash; Ausgabe 10 (Mai 2013)</a>
                        <br />
                        <br />
                        <a href="newsletter2_2013" target="_blank">DorisPaas-Newsletter &ndash; Ausgabe 9 (März 2013)</a>
                        <br />
                        <br />
                        <a href="newsletter1_2013" target="_blank">DorisPaas-Newsletter &ndash; Ausgabe 8 (Januar 2013)</a>
                        <br />
                        <br />
                        <hr >
                        <h5>2012</h5>
                        <hr>
                        <br />
                        <a href="newsletter6_2012" target="_blank">DorisPaas-Newsletter &ndash; Ausgabe 7 (November 2012)</a>
                        <br />
                        <br />
                        <a href="newsletter5_2012" target="_blank">DorisPaas-Newsletter &ndash; Ausgabe 6 (September 2012)</a>
                        <br />
                        <br />
                        <a href="newsletter4_2012" target="_blank">DorisPaas-Newsletter &ndash; Ausgabe 5 (Juli 2012)</a>
                        <br />
                        <br />
                        <a href="newsletter3_2012" target="_blank">DorisPaas-Newsletter &ndash; Ausgabe 4 (Mai 2012)</a>
                        <br />
                        <br />
                        <a href="newsletter2_2012" target="_blank">DorisPaas-Newsletter &ndash; Ausgabe 3 (März 2012)</a>
                        <br />
                        <br />
                        <a href="newsletter1_2012" target="_blank">DorisPaas-Newsletter &ndash; Ausgabe 2 (Januar 2012)</a>
                        <br />
                        <hr />
                        <a href="javascript: scrollMainToTop();" class="nachoben">nach oben</a>
                    </div>
                </div>
            </div>    
            <br>
            <br> 
            <div class="bodyspacer"></div> 
        </div>