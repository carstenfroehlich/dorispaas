        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br /> 
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>
                <h1 class="header center orange-text">DorisPaas-Newsletter</h1>      
            </div>  
        </div> 
        <div class="container">    
            <div class="section">   
                <div class="row margintoprow">        
                    <div class="col s12 m12">
                        <b>Ausgabe 6-2012 (November 2012)</b>
                        <br />
                        -------------------------------------------------------
                        <br />
                        <br />
                        Liebe Leserin, lieber Leser.
                        <p>
                        <b>&#149;   <a href="http://www.ganzheitliche-gesundheitsberatung.de" target="_blank">www.Ganzheitliche-Gesundheitsberatung.de</a></b>
                        <br />
                        Seit &uuml;ber 5 Jahren berate ich nun Menschen vor allem mit 
                        Nahrungsmittel-Unvertr&auml;glichkeiten, und es wurden nat&uuml;rlich auch Anfragen 
                        zu vielen weiteren Problemen im Gesundheitsbereich an mich 
                        gestellt. Nach und nach konnte ich meine Ratschl&auml;ge auf ein immer breiteres 
                        Fundament stellen und meine Beratungs-Schwerpunkte immer mehr erweitern. 
                        <br />
                        Trotz meiner Ausbildung als Ganzheitliche Gesundheitsberaterin, die es mir erlauben 
                        w&uuml;rde, Sie tats&auml;chlich zu jedem Gesundheitsproblem beraten zu 
                        d&uuml;rfen, halte ich es nach wie vor f&uuml;r sinnvoll und verantwortungsbewusster, 
                        f&uuml;r mich selbst als Beraterin Schwerpunkte zu setzen. Niemand kann solch ein 
                        breites Themenfeld so abdecken, dass er tats&auml;chlich zu jedem dieser zahlreichen 
                        Bereiche so viel Wissen aufbaut, um <b>alle</b> Klienten mit <b>jedem</b> 
                        Gesundheitsproblem kompetent beraten zu k&ouml;nnen. 
                        Es ist nicht nur Ihr gutes Recht als Ratsuchende(r), sondern auch mein eigener 
                        Anspruch an mich selbst, dass ich zu den Problemen, f&uuml;r die ich Ihnen meine 
                        Beratung anbiete, wirklich fundierte, in die Tiefe gehende Kenntnisse aufweisen kann. 
                        Dies geht nur durch Spezialisierung. 
                        Nat&uuml;rlich ist es nicht nur wichtig, sondern auch unerl&auml;sslich, alle 
                        angrenzenden Gebiete so weit wie m&ouml;glich im Blick zu haben, um Zusammenh&auml;nge 
                        zu erkennen und sich dadurch ein Gesamtbild machen zu k&ouml;nnen. Es wird jedoch immer 
                        Bereiche geben m&uuml;ssen, in denen man seine Schwerpunkte setzt. Dies ist nicht 
                        nur bei (Fach-)&Auml;rzten gang und g&auml;be, auch jeder seri&ouml;s 
                        arbeitende Gesundheitsberater kann sich nur in einem begrenzten Themenbereich 
                        wirklich bis in die Tiefe einarbeiten.
                        <br />
                        Damit Sie sich neben den vielen Sachthemen, die 
                        <a href="http://www.dorispaas.de" target="_blank">DorisPaas.de</a> zur Verf&uuml;gung 
                        stellt, nun auch ausf&uuml;hrlich &uuml;ber mein umfassendes Beratungsangebot, 
                        aber auch &uuml;ber meine dar&uuml;ber hinaus gehenden Serviceangebote informieren 
                        k&ouml;nnen, gibt es jetzt neben DorisPaas.de die neue Webadresse 
                        &#187;<a href="http://www.ganzheitliche-gesundheitsberatung.de" target="_blank">www.Ganzheitliche-Gesundheitsberatung.de</a>&#171;.
                        <br />
                        Schauen Sie doch auch hier einmal vorbei &#150; ich freue mich auf Ihren Besuch.
                        <br />
                        <br />
                        <b>&#149;   <a href="http://www.dorispaas.de/index.php?page=ganz-kochmedizin" target="_blank">Medizin aus dem Kochtopf</a></b>
                        <br />
                        Der Aufbau dieser neuen Website hat in den letzten Wochen nat&uuml;rlich 
                        einen Gro&#223;teil meiner Zeit in Anspruch genommen. Trotzdem gibt es auch auf
                        <a href="http://www.dorispaas.de" target="_blank">DorisPaas.de</a> zwei neue 
                        Seiten, die ich Ihnen ans Herz legen m&ouml;chte.
                        Zum einen ist dies die Seite &#187;Medizin aus dem Kochtopf&#171;,
                        auf der ich schildere, wie man ganz einfach mit einer vern&uuml;nftigen und 
                        &uuml;berlegten Auswahl der t&auml;glichen Nahrungsmittel entscheidend zur 
                        eigenen Gesunderhaltung beitragen kann.
                        <br />
                        Lesen Sie hier mehr dar&uuml;ber: <a href="http://www.dorispaas.de/index.php?page=ganz-kochmedizin" target="_blank">Medizin aus dem Kochtopf</a>
                        <br />
                        <br />
                        <b>&#149;   <a href="http://www.dorispaas.de/index.php?page=ganz-zuckerempfehlung" target="_blank">Welches 
                        S&uuml;&#223;ungsmittel ist empfehlenswert?</a></b>
                        <br />
                        Und rechtzeitig zur Advents- und Weihnachtszeit, in der wir alle 
                        ja gerne auch das eine oder andere Mal etwas S&uuml;&#223;es naschen wollen, habe ich 
                        auf der Seite &#187;Welches S&uuml;&#223;ungsmittel ist empfehlenswert?&#171;
                        versucht, Ihnen eine Hilfestellung zu geben, wie Sie vor dem Hintergrund der Warnungen 
                        vor S&uuml;&#223;em doch einen Weg finden k&ouml;nnen, Ihr winterliches Verlangen 
                        zu stillen.
                        <br />
                        Lesen Sie hier mehr dar&uuml;ber: <a href="http://www.dorispaas.de/index.php?page=ganz-zuckerempfehlung" target="_blank">Welches 
                        S&uuml;&#223;ungsmittel ist empfehlenswert?</a>
                        <br />
                        <br />
                        Nun bleibt mir nur noch, Ihnen f&uuml;r dieses ausklingende Jahr eine geruhsame 
                        und vor allem beschwerdefreie Advents- und Weihnachtszeit und dann viel Gesundheit 
                        f&uuml;r das neue Jahr 2013 zu w&uuml;nschen.
                        <br />
                        Und nat&uuml;rlich bedanke ich mich ganz herzlich bei Ihnen für Ihr Interesse und 
                        freue mich auf ein Wiederlesen auf meinen Websites oder auch auf ein (Wieder)sehen 
                        in meinem Beratungsb&uuml;ro in Troisdorf.
                        <br />
                        <br />
                        Bis zum n&auml;chsten Newsletter, den Sie wie gewohnt in zwei Monaten, also etwa 
                        Mitte Januar 2013 erhalten, sende ich Ihnen herbstliche Gr&uuml;&#223;e aus dem Rheinland
                        <br />
                        <br />
                        Ihre
                        <br />
                        Doris Paas
                        </p>
                        Gerne k&ouml;nnen Sie diesen Newsletter auch an Freunde und Bekannte weiterleiten!
                        <p>
                        -------------------------------------------------------------------------------------------------------------
                        <br />
                        Sie k&ouml;nnen den Erhalt des Newsletters jederzeit abbestellen.
                        Bitte klicken Sie auf <a href="http://www.dorispaas.de/index.php?page=unsubscribe_newsletter&amp;ticket=%UNSUBSCRIBE_TICKET%" target="_blank">diesen Link</a>.
                        <br />
                        Ihre Mailadresse wird im Verteiler gel&ouml;scht, und Sie erhalten keine Mails mehr.
                        </p>
                    </div>
                </div>
            </div>    
            <br>
            <br> 
            <div class="bodyspacer"></div> 
        </div>