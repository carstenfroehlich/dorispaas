        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br /> 
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>
                <h1 class="header center orange-text">Das Internet &ndash;</h1>      
                    <div class="row center">        
                    <h5 class="header col s12 light">was kann es für Ihre Gesundheit leisten und was nicht?</h5>      
                    </div>     
            </div>  
        </div> 
        <div class="container">    
            <div class="section">   
                <div class="row margintoprow">        
                    <div class="col s12 m4">
                        <ul class="nav">
                            <li>
                                <b>Abschnitte dieser Seite:</b>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>internetrat#informationsquelle">Informationsquelle überprüfen</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>internetrat#diversitaet">Vielfältigkeit der Informationen</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>internetrat#kompetenz">Kompetenten Rat einholen</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>internetrat#zweitemeinung">Ggf. eine zweite Meinung einholen</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>internetrat#umsonst">Hilfe für &#187;umsonst&#171;?</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>internetrat#zeit">Zeit für Sie</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>internetrat#abklaerung">Kompetenz im Voraus abklären</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>internetrat#meineberatung">Meine Beratung</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>internetrat#fazit">Fazit</a>
                            </li> 
                        </ul>
                    </div>
                    <div class="col s12 m8">
                        <img src="<?php echo IMG_PATH; ?>internetinfos.png" alt="" class="right" />
                        </div>
                        </div>
                <div class="row">        
                    <div class="col s12 m12">
                        Immer häufiger suchen Menschen mit gesundheitlichen Problemen Rat im Internet. 
                        Anhand der verschiedenen Symptome kann mit Suchmaschinen geschaut werden, welche 
                        Informationen hierzu im Netz zu finden sind. 
                        <br />
                        <br />
                        Das ist zuerst einmal eine gute Sache. Nur ist es natürlich schwer, zu unterscheiden, 
                        welche Informationen seriös sind und welche nicht. Denn leider posten viele Menschen 
                        auch Informationen, die entweder nur auf deren ganz individuelle Situation zutreffen 
                        oder aber solche, die schlichtweg falsch sind.
                        <br />
                        <br />
                        Wie also kann ein Suchender, der im Zweifelsfalle immer ein Laie in Bezug auf 
                        dieses Thema ist, unterscheiden, welche Informationen wirklich hilfreich sind?
                    </div>
                </div>
                <div class="row margintoprow">        
                    <div class="col s12 m12">
                        <a id="informationsquelle"></a>
                        <hr />
                        <h5>Informationsquelle überprüfen</h5>
                        <hr />
                        Zuerst einmal sollte man die Quelle der Informationen auf ihre Glaubwürdigkeit 
                        überprüfen. Verschiedene Institute, aber auch Arztpraxen, Heilpraktiker, 
                        Ernährungs- und Ganzheitliche Gesundheitsberater präsentieren im Internet nicht 
                        nur ihre Leistungen, sondern stellen gleichzeitig auch grundlegende Informationen 
                        zu ihren Schwerpunkten auf ihrer Homepage zur Verfügung. Solche Quellen rangieren 
                        auf der Glaubwürdigkeitsskala recht weit oben.
                        <br />
                        <br />
                        Dann gibt es verschiedene Foren für Ärzte, Apotheker und Patienten (unter vielen anderen 
                        z.B. <a href="http://www.doccheck.com/de/" target="_blank">DocCheck</a>) 
                        oder auch die Homepages von medizinischen Fachverlagen, die viele &ndash; im den 
                        meisten Fällen &ndash; gut belastbare Informationen liefern.
                        <br />
                        <br />
                        Auch Selbsthilfegruppen, die sich auf bestimmte Erkrankungen spezialisiert haben 
                        und ihr Wissen auf einer Homepage veröffentlichen, sind auf jeden Fall ernst zu nehmen.
                        <br />
                        <br />
                        Wikipedia, die Plattform, auf der jedermann sein Wissen der Allgemeinheit zur 
                        Verfügung stellen kann, ist zwar in den überwiegenden Fällen seriös &ndash; schon 
                        allein deshalb, weil die Beiträge auch von vielen weiteren Personen ergänzt, 
                        überarbeitet und berichtigt werden können &ndash; aber es kann auch hier durchaus 
                        vorkommen, dass definitiv falsche Behauptungen unzensiert und unkommentiert stehen 
                        bleiben. Oftmals finden hier regelrechte Kleinkriege statt zwischen den Urhebern der 
                        Beiträge und Menschen, die diese Artikel verändern wollen, weil die Autoren auf 
                        ihrer Meinung beharren. Sie löschen dann flugs die Korrekturen, um ihre Informationen 
                        weiterhin dort unzensiert stehen zu lassen und konterkarieren mit diesem Verhalten die eigentliche 
                        Funktionalität dieser Gemeinschaftsplattform. Erkennbar ist so etwas (oben rechts) 
                        an der Versionsgeschichte eines jeden Beitrags. Vorsicht und besondere Aufmerksamkeit 
                        ist hier also auf jeden Fall geboten, bevor man einen solchen Beitrag für bare Münze nehmen sollte.
                        <br />
                        <br />
                        Problematisch können in meinen Augen Internetforen sein, in denen &ndash; meist 
                        zu ganz bestimmten Themen &ndash; Betroffene selbst Fragen stellen können, die 
                        dann von der Community des Forums beantwortet werden. Mit Sicherheit werden hier 
                        oft auch gute Ratschläge gegeben. Genauso oft aber sind die Ratschläge nur auf 
                        die ganz individuelle Situation des Ratgebenden zugeschnitten und können eben nicht 
                        1:1 auf jeden anderen Betroffenen übertragen werden. Und last but not least gibt 
                        es in diesen Foren auch immer wieder Empfehlungen, die absolut falsch sind. Es 
                        kann hier also sein, dass Sie einen guten Rat bekommen, aber genauso kann es sein, 
                        dass Ratschläge nicht nur falsch, sondern auch richtig gefährlich sein können. Es 
                        werden hier zwar sehr häufig genau diese gefährlichen Empfehlungen dann auch von 
                        anderen Forenteilnehmern kommentiert, aber nicht immer sind diese Kontrollinstanzen 
                        selbst kompetent &ndash; oder die Korrekturen kommen verspätet, so dass der Fragende 
                        sie gar nicht mehr liest. Ein Fragesteller, der selbst Ahnung von der Materie hat, 
                        könnte hier die Spreu vom Weizen trennen. Aber es liegt ja gerade in der Natur der 
                        Sache, dass die Fragenden eben diese Ahnung nicht oder nicht in ausreichendem Umfang 
                        haben. So ist die Gefahr groß, dass man sich auf Fehlinformationen verlässt und 
                        im Ernstfalle seiner Gesundheit eher schadet als nützt.
                        <br />
                        <a id="diversitaet">&nbsp;</a>
                        <br />
                        <hr />
                        <h5>Vielfältigkeit der Informationen</h5>
                        <hr />
                        Ich möchte keineswegs so verstanden werden, dass ich generell davon abraten möchte, 
                        sich im Internet über gesundheitliche Probleme schlau zu machen! Ganz im Gegenteil: 
                        Ich halte es für einen großen Fortschritt, dass man mit wenigen Mausklicks und zu jeder Zeit viele 
                        Informationen über ein bestimmtes Thema finden kann. Ich möchte aber dringend 
                        darauf hinweisen, dass man zumindest versuchen sollte, aus möglichst vielen Quellen 
                        die verschiedensten Meinungen zu sammeln und dann zuerst einmal selbst zu versuchen, 
                        anhand der Seriosität der Quellen zu schauen, was glaubhaft sein könnte und was nicht.
                        <br />
                        <br />
                        Einige Menschen erwarten auch, dass sie mit einer einzigen Frage, die sie in bestimmten 
                        Frage- und Antwortforen (unter vielen anderen z.B. 
                        <a href="http://www.gutefrage.net/" target="_blank">gutefrage.net</a>) stellen, ihre Antwort gleich maßgeschneidert 
                        und quasi auf dem Silbertablett serviert bekommen. Dies ist ein besonders verhängnisvolles 
                        Vorgehen! Natürlich kann es auch hier sein, dass zufällig ein Fachmann diese Frage 
                        liest und fundiert beantwortet. In den überwiegenden Fällen jedoch liest man hier 
                        völlig inkompetente Antworten &ndash; gegeben meist von den Heerscharen der sich 
                        hinter ihren Pseudomymen versteckenden Menschen &ndash; die der Fragesteller dann vielleicht für bare Münze 
                        nimmt. Er wird dann ggf. keine weiteren Auskünfte mehr einholen und so die Gelegenheit 
                        versäumen, eventuell im Netz auf richtigere und nützlichere Informationen zu treffen. 
                        Unter Umständen werden dann sogar wichtige Maßnahmen versäumt, die zur Wiederherstellung 
                        der Gesundheit unerlässlich sind.
                        <br />
                        <a id="kompetenz">&nbsp;</a>
                        <br />
                        <hr />
                        <h5>Kompetenten Rat einholen</h5>
                        <hr />
                        Wie gesagt: Ich halte es für richtig, sich im Internet schlau zu machen. Dann aber 
                        ist es gerade im Gesundheitsbereich wichtig, sich mit einem nachweislich kompetenten Berater &ndash; also je 
                        nach Art der Probleme und Symptome mit einem Arzt, Heilpraktiker, 
                        Ernährungs- oder spezialisierten Ganzheitlichen Gesundheitsberater &ndash; 
                        zusammenzusetzen und zu beraten, welche Erkrankung überhaupt vorliegt, welche 
                        diagnostischen Maßnahmen sinnvoll und welche Behandlungsformen geeignet sind.
                        <br />
                        <br />
                        Mit diesem Berater können Sie nun auf Augenhöhe sprechen, denn Sie sind nicht der 
                        uninformierte Patient oder Klient, der sich ohne Vorwissen blind auf die Ratschläge 
                        des Gesprächspartners verlassen muss, sondern Sie haben sich (im besten Falle) 
                        bereits über die verschiedenen Möglichkeiten schlau gemacht. Eine wertvolle Hilfe 
                        aber ist es, dass Ihr Berater, der ja über die Materie Bescheid weiß (oder wissen 
                        sollte), für Sie oder mit Ihnen trennen kann, was richtig und was falsch oder 
                        (für Sie) ungeeignet ist.
                        <br />
                        <a id="zweitemeinung">&nbsp;</a>
                        <br />
                        <hr />
                        <h5>Ggf. eine zweite Meinung einholen</h5>
                        <hr />
                        Entweder vertrauen Sie diesem Menschen, oder aber Sie holen sich eine zweite Meinung 
                        ein. Selbst unsere gesetzlichen Krankenkassen, die ja nicht unbedingt für Freigiebigkeit 
                        bekannt sind, räumen Ihnen die Möglichkeit ein, sich bei anderen Ärzten eine zweite 
                        Meinung einholen zu können (bitte lesen Sie hierzu auch den Beitrag 
                        &#187;<a href="http://localhost/dorispaas.de/arztsuche" "target="_blank">Wie finde ich einen qualifizierten Arzt?</a>&#171;). 
                        <br />
                        <br />
                        Bei Heilpraktikern, Ernährungs- und Ganzheitlichen 
                        Gesundheitsberatern müssen Sie leider die Kosten selbst tragen, es lohnt sich aber 
                        auf jeden Fall zu entscheiden, ob Sie dem Ratschlag folgen oder einen weiteren 
                        einholen wollen. 
                        <br />
                        <br />
                        Grundsätzlich sollte es jeder Berater begrüßen, einen &#187;aufgeklärten Patienten&#171; 
                        vor sich zu haben. Früher, als sich ein Arzt noch als der &#187;Halbgott in Weiß&#171; 
                        fühlte, waren Patienten eher als mehr oder weniger dankbare Befehlsempfänger geduldet. 
                        Die meisten Ärzte heute finden es gut, einen informierten Gesprächspartner vor sich 
                        zu haben. Leider jedoch ist &ndash; insbesondere bei Kassenpatienten &ndash; die 
                        Zeit der Ärzte begrenzter, so dass auch heute noch ab und an Mediziner zu finden 
                        sind, die zu wenig Geduld haben, alle Fragen zu beantworten, die durch die vielen 
                        zuvor eingeholten Informationen aufgetaucht sind. Versuchen Sie bitte trotzdem darauf zu 
                        bestehen, alle Ihre Fragen ausführlich und verständlich beantwortet zu bekommen. 
                        <br />
                        <br />
                        Fair wäre es allerdings, bereits vorab für sich selbst möglichst logisch und stimmig 
                        abzuklären, was für Sie richtig und vertretbar sein könnte. Ziehen Sie hier ggf. 
                        auch neben den Informationen aus dem Internet weiterführende Literatur zurate, bei 
                        der dann doch meist eine größere Wahrscheinlichkeit der Seriosität besteht. 
                        Je breiter Sie Ihre Recherche anlegen, desto ernster werden Sie von Ihrem Arzt genommen.
                        <br />
                        <a id="umsonst">&nbsp;</a>
                        <br />
                        <hr />
                        <h5>Hilfe für &#187;umsonst&#171;? </h5>
                        <hr />
                        Ratschläge im Internet sind in der Regel umsonst. Dies ist neben der Vielfältigkeit 
                        und vor allem neben der ständigen Verfügbarkeit einer der Hauptgründe, warum Menschen 
                        sich über gesundheitliche Probleme im Internet informieren.
                        <br />
                        <br />
                        Natürlich sind auch die Ratschläge bei Ihrem Arzt &#187;umsonst&#171; &ndash; 
                        zumindest scheinbar, denn Sie zahlen ja vorab Ihre Beiträge in die gesetzliche 
                        oder auch private Krankenversicherung ein. Der Arztbesuch selbst kostet dann 
                        (meist) nichts.
                        <br />
                        <br />
                        Beratungen bei Heilpraktikern, Ernährungs-  und Ganzheitlichen Gesundheitsberatern 
                        sind in der Regel nicht umsonst, selten werden die Kosten &ndash; und dann auch 
                        nur anteilig &ndash; von den Krankenkassen übernommen. 
                        <br />
                        <a id="zeit">&nbsp;</a>
                        <br />
                        <hr />
                        <h5>Zeit für Sie</h5>
                        <hr />
                        Im anderen Sinne des Wortes allerdings ist eine 
                        solche Beratung nicht umsonst: Unter der Voraussetzung, dass Sie einen 
                        auf Ihre Probleme spezialisierten Berater gefunden haben, kann ein solches Gespräch 
                        teilweise sehr viel mehr bringen als eine der o.a. kostenlosen Möglichkeiten, denn 
                        diese Berater nehmen sich zum einen viel Zeit für Sie und schneiden ihre Ratschläge 
                        insbesondere im Gegensatz zum anonymen Internet ganz auf Ihre individuellen Probleme zu.
                        <br />
                        <br />
                        Die Zeit eines Arztes wird  in den meisten Fällen leider begrenzt sein &ndash; gerade, 
                        wenn Sie ein Kassenpatient sind. Vor dem Hintergrund einer in meinen Augen mangelhaften 
                        Vergütungspraxis der Krankenkassen sollten Sie dafür allerdings Verständnis haben, 
                        denn der Arzt muss sein Personal und die Miete für seine Räume bezahlen und bekommt 
                        trotz allem für jeden Patienten nur eine Pauschale &ndash; egal, wie lange er diesen 
                        berät.
                        <br />
                        <br />
                        Mehr Zeit werden Heilpraktiker, Ernährungs- und Ganzheitliche Gesundheitsberater  
                        haben. Aber leider werden Sie die Leistungen dieser Fachkräfte in den allermeisten 
                        Fällen selbst bezahlen müssen. Eine solche Investition kann sich aber durchaus 
                        lohnen, denn diese Berater können sehr viel intensiver auf Sie eingehen. Wichtig 
                        ist aber ganz besonders hier, dass Sie Berater finden, die auf Ihr Problem spezialisiert 
                        sind, denn die Kosten für eine Beratung von jemandem, der sich bei Ihrer Erkrankung 
                        nicht auskennt, wären &#187;rausgeschmissenes Geld&#171;. 
                        <br />
                        <a id="abklaerung">&nbsp;</a>
                        <br />
                        <hr />
                        <h5>Kompetenz im Voraus abklären</h5>
                        <hr />
                        Deshalb sollten Sie immer im Voraus abklären, ob der von Ihnen ins Auge gefasste 
                        Berater &ndash; sei es ein Arzt, ein Heilpraktiker, Ernährungs- oder Ganzheitlicher 
                        Gesundheitsberater &ndash; die Kompetenz besitzt, Sie in Ihrem ganz speziellen Fall 
                        zu beraten. Und hier werden Ihnen in vielen Fällen die Informationen, die Sie über 
                        das Internet sammeln konnten, weiterhelfen. Sie werden hier sicherlich zumindest 
                        rudimentäre Grundlagen evtl. Wichtiges zu diagnostischen Maßnahmen erfahren haben, 
                        so dass Sie am Telefon mit den richtigen Fragen ermitteln können, ob Ihr Gesprächspartner 
                        zum einen überhaupt auf diese Erkrankung spezialisiert ist und welche Diagnostik 
                        er anwendet.
                        <br />
                        <br />
                        Falls Sie kein gutes Gefühl haben, suchen Sie sich einen anderen Berater. Oftmals 
                        muss man lange auf Termine warten. Wenn Sie dann an jemanden geraten, dessen Ratschlag 
                        Ihnen nicht weiterhilft, wäre dies ärgerlich, denn Sie haben wertvolle Zeit verloren. 
                        Wenden Sie deshalb bereits im Vorfeld bei der Suche nach einem geeigneten Berater 
                        größte Sorgfalt an.
                        <br />
                        <br />
                        Wer nicht bereit ist, vorab am Telefon Auskunft darüber zu erteilen, über welche Kompetenzen 
                        er verfügt und welche Möglichkeiten zur Diagnose und Behandlung er anbietet &ndash; 
                        oder aber diese Informationen für alle zugänglich auf einer Hompage veröffentlicht, 
                        wäre zumindest für mich kein geeigneter Kandidat.
                        <br />
                        <hr>
                        <a id="meineberatung">&nbsp;</a>
                        <div class="row">
                        <div class="col s12 m2">
                            <a href="http://www.ganzheitliche-gesundheitsberatung.de" target="_blank">
                                <img src="<?php echo IMG_PATH; ?>praxiswebsite.png" alt="" class="inline" /></a>
                        </div>
                        </div>
                        <div class="row">
                        <div class="col s12 m12">
                        <h5>Meine Beratung</h5>
                        <br />
                        Ich selbst informiere Sie auf meiner Praxis-Hompage 
                        <a href="http://www.ganzheitliche-gesundheitsberatung.de" target="_blank">www.Ganzheitliche-Gesundheitsberatung.de</a> 
                        über meine Schwerpunkte, so dass Sie erkennen können, ob ich für Ihre Probleme die 
                        richtige Ansprechpartnerin sein könnte. Und wahrscheinlich haben Sie auch hier schon auf 
                        <a href="http://www.dorispaas.de"www.dorispaas.de" target="_blank">www.dorispaas.de</a> 
                        viele Informationen finden können, so dass Sie sich ein Bild von meiner Qualifikation 
                        machen können. Schauen Sie sich bitte auch gerne meine <a href="vita" target="_blank">Vita</a> an, so dass Sie sehen 
                        können, auf welche Vor-, Aus- und Fortbildungen sich meine Qualifikation stützt.                        
                        <br />
                        <br />
                        Falls wir bei einer ersten Kontaktaufnahme per Telefon oder eMail feststellen, 
                        dass ich für Sie nicht die richtige Ansprechpartnerin bin, versuche ich möglichst, 
                        Ihnen Kolleginnen oder Kollegen zu empfehlen.
                        <br />
                        <br />
                        Wenn Sie aber meinen, dass Sie sich von mir beraten lassen möchten, freue ich mich 
                        sehr, wenn Sie viele Informationen mitbringen, die ich dann gerne mit Ihnen zusammen 
                        ordne. Ich begrüße es sehr, Klienten beraten zu dürfen, die sich schon so weit es 
                        geht schlau gemacht haben. Unser gemeinsames Ziel ist es dann, dass Sie vorhandene 
                        Beschwerden möglichst rasch loswerden oder solche gar nicht erst entstehen lassen. 
                        Meine Beratungen sind &ndash; anders, als es auch die besten Informationen Internet 
                        sein können &ndash; immer individuell und ganz persönlich auf Sie zugeschnitten.
                        </div>
                        </div>
                        <a id="fazit">&nbsp;</a>
                        <hr />
                        <h5>Fazit</h5>
                        <hr />
                        Informationen aus dem Internet können hilfreich sein. Sie haben den Vorteil zu 
                        jeder Zeit verfügbar zu sein und sind in großer Vielfalt zu finden. Sie können 
                        sich also &ndash; bei ausreichender Geduld &ndash; sehr breit informieren und 
                        verschiedene Meinungen und Möglichkeiten erfahren und ggf. gegeneinander abwägen.
                        <br />
                        <br />
                        Nachteil dieser Informationsflut ist allerdings, dass man entscheiden muss, was 
                        fundiert, was richtig und was falsch und &ndash; vor allem &ndash; was passend für 
                        die eigenen Probleme ist.
                        <br />
                        <br />
                        Gerade im Gesundheitsbereich ist es unerlässlich, das für die eigene Situation 
                        Geeignete herauszufiltern. Und dafür braucht es Vorwissen. Ohne ein solches 
                        Vorwissen wäre man schutzlos den vielen Falschinformationen unter den &#187;richtigen&#171;
                        Informationen ausgeliefert!
                        <br />
                        <br />
                        Informieren Sie sich also bitte gerne, aber lassen Sie sich dann dabei helfen, 
                        die für Sie richtige Diagnostik und Behandlung zu finden. Ansonsten spielen Sie 
                        leichtfertig mit dem Wertvollsten, was Sie besitzen: mit Ihrer Gesundheit!
                        <br />
                        <br />
                        Ich wünsche Ihnen alles erdenklich Gute!
                        <br />
                        <hr />
                        <a href="javascript: scrollMainToTop();" class="nachoben">nach oben</a>
                    </div>
                </div>
            </div>    
            <br>
            <br> 
            <div class="bodyspacer"></div> 
        </div>