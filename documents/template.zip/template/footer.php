        <footer class="page-footer doris-paas lighten-1">    
            <div class="container">      
                <div class="row">        
                    <div class="col l4 s12 footer-menu-elements">
                        <div class="row">
                            <div class="col l3 s12">
                                <a class="white-text" href="<?php echo URL_ROOT; ?>sitemap-html">Sitemap</a>
                            </div>
                            <div class="col l9 s12">
                                <a class="white-text" href="<?php echo URL_ROOT; ?>impressum">Impressum</a>
                            </div>
                        
                        
                            <!--
                            <li>
                            <a class="white-text" href="#!">neueste Beiträge</a>
                            </li>            
                            <li>
                            <a class="white-text" href="#!">Beratung / Praxis</a>
                            </li>            
                            <li>
                            <a class="white-text" href="#!">Kontakt</a>
                            </li>
                            --> 
                    </div>  
                    <div class="col l8 s12">      
                           
                    </div>           
                </div>    
            </div>    
        </footer>  
        <!--  Scripts-->
        <script src="//ajax.googleapis.com/ajax/libs/jquery/3.0.0/jquery.min.js" crossorigin="anonymous"></script>
        <script src="<?php echo JS_PATH; ?>bootstrap.min.js?fingerprint=20170806154500"></script>  
        <script src="<?php echo JS_PATH; ?>materialize.js?fingerprint=20170806154500"></script>
        <?php if($ACTION[0] == 'lebensmittel-datenbank') { ?>  
            <script src="<?php echo JS_PATH; ?>browser.js?fingerprint=201708133800"></script>
            <script src="<?php echo JS_PATH; ?>common.js?fingerprint=201708133800"></script>
        <?php } ?>
        <script src="<?php echo JS_PATH; ?>init.js?fingerprint=201708133800"></script>
        <script src="<?php echo JS_PATH; ?>functions.js?fingerprint=20171120215200"></script>
        <script src="<?php echo JS_PATH; ?>jquery.fancybox.min.js"></script>
        <?php if($ACTION[0] == 'lebensmittel-datenbank') { ?>  
            <script type="text/javascript">
                $(document).ready(function() {
         			onLmdbBodyScroll();
                    onLmdbWidthChange();
                });
                (function($) {
                	$(document).ready(function() {
                		$(window).bind('scroll', function() {
                			onLmdbBodyScroll();
                		});
                        $(window).bind('resize', function() {
                			onLmdbWidthChange();
                		});
                    });
                })(jQuery);
            </script>
        <?php } ?>
    </body>
</html>