        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br /> 
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>
                <h1 class="header center orange-text">Genießen?</h1> 
                    <div class="row center">        
                    <h5 class="header col s12 light">Ja, auch bei Nahrungsmittel-Unverträglichkeiten!</h5>      
                    </div>     
            </div>  
        </div> 
        <div class="container">    
            <div class="section">   
                <div class="row margintoprow">        
                    <div class="col s12 m4">
                        <ul class="nav">
                            <li>
                                <b>Abschnitte dieser Seite:</b>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-genuss#diagnose">Diagnose eventueller Unverträglichkeiten</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-genuss#beratung">Beratung</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-genuss#psyche">Zusammenhang zwischen psychischer Verfassung und Darmgesundheit</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-genuss#auswahl">Auswahl der verträglichen Nahrungsmittel</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-genuss#auswaertsessen">Auswärts essen</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-genuss#suenden">Bewusste &#187;Sünden&#171;</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-genuss#genussmittel">Genussmittel</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-genuss#schluss">Noch eine Bemerkung zum Schluss ...</a>
                            </li> 
                            <li>
                                <a href="guterrat" target="_blank">War dieser Beitrag hilfreich für Sie?</a>
                            </li>
                        </ul>
                    </div>
                    <div class="col s12 m8">
                        <img src="<?php echo IMG_PATH; ?>genuss-salatteller.png" alt="faq" class="right" />
                    </div>
                </div>
                <div class="row margintoprow">        
                    <div class="col s12 m12">
                        Oftmals betrachten Menschen, die an Unverträglichkeiten leiden, viele oder die 
                        meisten Nahrungsmittel als Feind, und jedes Essen wird zu einem Kampf &ndash; 
                        einem Kampf, den man nie gewinnen kann. Unter solchen negativen Bedingungen kann 
                        man natürlich kaum eine Mahlzeit mehr genießen &ndash; alles, was man isst, wird 
                        als wahrscheinlicher Beschwerdeverursacher angesehen.
                        <br />
                        <br />
                        Der Betroffene beäugt die Zutaten, die er bei der Zubereitung seiner Mahlzeit 
                        angstvoll im Hinblick auf mögliche, ja sogar wahrscheinliche Beschwerden ausgewählt 
                        hat, bereits mit einem unguten Gefühl: &#187;Sicherlich werde ich bald wieder 
                        Probleme wie Bauchschmerzen, Blähungen oder Durchfälle bekommen.&#171; Und tatsächlich 
                        folgen dann nach dem Gesetz der &#187;sich selbsterfüllenden Prophezeiung&#171; 
                        (self fulfilling prophecy) die gefürchteten Symptome meist auf dem Fuße. Erst recht 
                        geschieht dies beim Auswärtsessen, bei dem man noch weniger Einfluss auf die 
                        verwendeten Zutaten hat, als beim Selberkochen. Selbst, wenn man mit dem Koch 
                        geeignete Gerichte im Hinblick auf die eigenen Bedürfnisse ausgewählt hat, bleibt 
                        oftmals ein Misstrauen erhalten, ob die &#187;verbotenen&#171; Zutaten tatsächlich 
                        weggelassen wurden &ndash; und das nächste Bauchgrummeln, das ja Menschen ohne 
                        Unverträglichkeiten durchaus auch nach einem leckeren Essen haben, wird sofort 
                        als Vorbote schlimmerer Beschwerden interpretiert.
                        <br />
                        <br />
                        Einmal in diesem Teufelskreis gefangen, ist es kaum noch möglich, eine Mahlzeit 
                        genießen zu können &ndash; auch wenn diese die unverträglichen Bestandteile gar 
                        nicht enthält. Aber <b>trotz</b> Nahrungsmittel-Unverträglichkeit(en) oder eben 
                        gerade <b>mit</b> Nahrungsmittel-Unverträglichkeit(en) kann und sollte man seine 
                        Mahlzeiten genießen! Sich freuen, Duft und Geschmack registrieren, genüsslich kauen,
                        das Ambiente bewusst wahrnehmen ...
                        <br />
                        <a id="diagnose"></a>
                        <hr>
                        <h5>Diagnose eventueller Unverträglichkeiten</h5>
                        <hr>
                        Es ist richtig: Wenn man Nahrungsmittel-Unverträglichkeiten hat, ist es nicht ratsam, 
                        Bestandteile zu verzehren, die man nicht verträgt. Unangenehme Symptome wären dann 
                        tatsächlich vorprogrammiert. Wenn man hingegen Zutaten auswählt, die verträglich 
                        sind, sind Probleme eher unwahrscheinlich. Sollte man allerdings tatsächlich das 
                        Gefühl haben, überhaupt keine Nahrungsmittel ohne Probleme zu vertragen, ist der 
                        erste Schritt, die Beschwerdeverursacher herauszufinden. Dies geschieht am besten 
                        mit einem <a href="downloads#tagebuch" target="_blank">Verzehr- und Symptomtagebuch</a>, 
                        in dem alle verzehrten Nahrungsmittel und 
                        Getränke aufgeschrieben und zusätzlich die darauf folgenden Symptome protokolliert 
                        werden. Bei der Auswertung lässt man sich sinnvollerweise von einer auf diese 
                        Problematik spezialisierte Fachkraft begleiten und helfen, die ggf. zur Untermauerung 
                        der Befunde geeigneten Tests empfiehlt.
                        <br />
                        <br />
                        <hr>
                        <a id="beratung">&nbsp;</a>
                        <div class="row">
                        <div class="col s12 m2">
                            <a href="http://www.ganzheitliche-gesundheitsberatung.de" target="_blank">
                                <img src="<?php echo IMG_PATH; ?>praxiswebsite.png" alt="" class="inline" /></a>
                        </div>
                        </div>
                        <div class="row">
                        <div class="col s12 m12">
                        <h5>Beratung</h5>
                        <br />
                            Gerne biete ich Ihnen eine individuelle Beratung an &ndash; 
                            auf Wunsch auch telefonisch oder per Skype.
                            <br />
                            Bitte informieren Sie sich auf meiner Praxis-Website <a href="http://www.ganzheitliche-gesundheitsberatung.de" target="_blank">&#187;www.Ganzheitliche-Gesundheitsberatung.de&#171;</a>
                        </div>
                        </div>
                        <a id="psyche">&nbsp;</a>
                        <hr>
                        <h5>Zusammenhang zwischen psychischer Verfassung und Darmgesundheit</h5>
                        <hr>
                        Nach der Diagnose die Ohren hängen zu lassen &ndash; &#187;oh je, so viel darf 
                        ich nun nicht mehr essen&#171; &ndash; ist ein zwar verständlicher, aber 
                        nichtsdetotrotz falscher Weg, der unweigerlich zu 
                        Traurigkeit, im schlimmsten Falle sogar zu Depressionen, führen kann. Das Gegenteil 
                        führt zum Ziel: eine solche Diagnose ist der Beginn einer besseren, beschwerdefreien 
                        Zeit, denn nun wissen Sie, was Ihnen nicht bekommt, und Sie können es weglassen.
                        <br />
                        <br />
                        Es gibt einen engen Zusammenhang zwischen der seelischen Verfassung und der 
                        Darmgesundheit bzw. einer guten Verdauung: Zum einen kommunizieren das sogenannte 
                        Bauchhirn &ndash; also das empfindliche Nervengeflecht rund um den Darm &ndash; 
                        und das Gehirn im Kopf ständig miteinander. Gibt es Probleme im Darm, meldet das 
                        Bauchhirn dieses sofort an den Kopf, und Sie fühlen sich schlecht. Anders herum 
                        meldet auch der Kopf an den Bauch, wenn Sie sich nicht wohlfühlen oder niedergeschlagen 
                        sind &ndash; und sofort fährt auch der Darm seine gesunden Funktionen herunter.
                        <br />
                        <br />
                        Zum anderen reagiert nach neuesten wissenschaftlichen Erkenntnissen auch unsere 
                        Darmflora (Mikrobiom) mit den Billionen von Bakterien auf seelische Veränderungen: 
                        Fühlen Sie sich gut, geht es auch den Darmbakterien gut, und es stellt sich eine 
                        gesündere Balance ein. Niedergeschlagenheit oder sogar Depressionen wirken sich 
                        im Gegenzug negativ auf die Zusammensetzung des Mirkrobioms aus. Eine gesunde 
                        Darmflora sendet Impulse an das Kopfhirn, die bewirken, dass Sie sich gut fühlen. 
                        Eine schlechtere Beschaffenheit der Darmflora bewirkt negativere Gefühle 
                        (Darm-Hirn-Achse/Gut-Brain-Axis).
                        <br />
                        <a id="auswahl">&nbsp;</a>
                        <br />
                        <hr>
                        <h5>Auswahl der verträglichen Nahrungsmittel</h5>
                        <hr>
                        Sobald Sie als Betroffene/r genau wissen, welche Lebensmittel oder Nahrungsbestandteile 
                        unverträglich sind und diese künftig meiden, besteht die Wahrscheinlichkeit, dass 
                        Mahlzeiten, die diese Zutaten nicht enthalten, keine Probleme mehr nach sich ziehen. 
                        Es spricht also nichts <b>gegen</b>, sondern alles <b>für</b> ein ausgiebiges 
                        Genießen von Mahlzeiten.
                        <br />
                        <br />
                        Der nächste Schritt ist das Zusammenstellen einer Liste, in der Sie alle unbekömmlichen 
                        Nahrungsmittel auf der einen Seite aufführen. Auf der anderen Seite, die meistens 
                        sehr viel länger wird, schreiben Sie möglichst viele Lebensmittel auf, die bekömmlich 
                        sind. Allein schon diese Aufstellung zeigt deutlich, dass Sie doch sehr viel mehr 
                        Dinge essen dürfen als Dinge, die &#187;verboten&#171; sind. Das macht Mut!
                        <br />
                        <br />
                            <div class="left">
                                <a href="lebensmittel-datenbank-info">
                                    <img src="<?php echo IMG_PATH; ?>lebensmitteldatenbank.png" alt="home video small" class="inline" />
                                </a>
                            </div>
                            <p class="right">
                                Wenn Ihnen hier nicht genügend Lebensmittel einfallen, empfehle ich Ihnen die 
                                &#187;<a href="lebensmittel-datenbank-info" target="_blank">DorisPaas.de &ndash; 
                                Lebensmittel-Datenbank</a>&#171;, in der Sie Filter für Ihre individuelle(n) 
                                Unverträglichkeit(en) setzen können und sich so alle verträglichen Lebensmittel 
                                anzeigen lassen können. Sie werden staunen, wie viele dies sind!
                                <br />
                            </p>
                        </div> 
                        <br />
                        <br />
                        <br />
                        <br />
                        <br />
                        <br />
                        Anschließend suchen Sie sich aus der Liste der verträglichen Lebensmittel diejenigen 
                        heraus, die Sie besonders gerne mögen und bereiten sich aus diesen Zutaten eine 
                        leckere Mahlzeit zu. Ggf. finden Sie auch in Ratgebern für die entsprechenden 
                        Nahrungsmittel-Unverträglichkeiten geeignete Rezepte, können aber auch Vorschläge 
                        aus ganz normalen Rezeptbüchern aufgreifen, bei denen Sie eventuell nicht 
                        verträgliche Bestandteile durch bekömmliche ersetzen.
                        <br />
                        <br />
                        Die meisten Menschen, die schon länger mit ihren Unverträglichkeiten leben, werden 
                        Ihnen bestätigen können, dass sie nicht nur sehr einfallsreich beim Ersetzen 
                        geworden sind, sondern dass sie ihre Mahlzeiten jetzt sehr viel bewusster zusammenstellen 
                        und genießen.
                        <br />
                        <br />
                        Ja, tatsächlich: man kann <b>und soll</b> auch mit Nahrungsmittel-Unverträglichkeiten 
                        seine Mahlzeiten genießen. Oder soll es wirklich mit dem Zeitpunkt der Diagnose 
                        nicht mehr erlaubt sein, sich sein Essen so richtig schmecken zu lassen? Wenn Sie 
                        die unverträglichen Zutaten weglassen, sind doch aller Voraussicht nach keine 
                        Beschwerden mehr zu befürchten! Jetzt das Essen wieder so richtig mit Genuss zu 
                        verspeisen, hebt die Laune und macht ein rundum gutes Gefühl.
                        <br />
                        <a id="auswaertsessen">&nbsp;</a>
                        <br />
                        <hr>
                        <h5>Auswärts essen</h5>
                        <hr>
                        Was aber ist, wenn Sie Ihr Essen nicht selbst zubereiten, mit anderen zusammen in 
                        ein Restaurant essen gehen oder eingeladen sind und Ihre Unverträglichkeit nicht 
                        mit Nahrungsergänzungsmitteln (z.B. den entsprechenden Enzymen) kompensieren zu 
                        können? Wenn Sie also meinen, es nicht 
                        in der Hand zu haben, welche Zutaten in den Gerichten verarbeitet wurden? In solchen 
                        Fällen müssen Sie versuchen, so viel Einfluss wie möglich auf die Vermeidung 
                        unverträglicher Zutaten zu nehmen. 
                        <br />
                        <br />
                        Im Restaurant ist hier immer das Gespräch mit dem Koch erforderlich. Eventuell 
                        können Sie mit den Freunden (ggf. sogar bei Geschäftsessen) im Vorhinein vereinbaren, 
                        welches Lokal angesteuert werden soll. Ein Anruf dort am Vortag kann klären, 
                        inwieweit der Küchenchef über Ihre Unverträglichkeit und die damit zusammenhängenden 
                        Erfordernisse informiert ist. Oftmals finden Sie auch im Internet die Speisekarte 
                        und können anhand derer mit dem Personal klären, welche Gerichte für Sie geeignet 
                        sind oder welche Zutaten man weglassen oder ersetzen kann. Nach meinen Erfahrungen 
                        sind die Verantwortlichen in den Restaurants grundsätzlich sehr bemüht und finden 
                        gemeinsam mit Ihnen immer verträgliche Varianten, die sie meist besonders liebevoll 
                        und lecker anrichten. Und so ungewöhnlich, wie Sie vielleicht meinen, sind doch 
                        Extrawünsche gar nicht. In einer Runde von 3 &ndash; 4 Tischgästen ist doch eigentlich 
                        immer zumindest einer, der eine Abwandlung des auf der Speisekarte aufgeführten 
                        Menüs erbittet: &#187;Mein Gericht bitte nicht mit Pommes Frites sondern mit 
                        Salzkartoffeln …&#171;
                        <br />
                        <br />
                        Bei Einladungen zu Freunden ist es auf jeden Fall unerlässlich, mit einem ausreichenden 
                        Zeitvorlauf Bescheid zu sagen, welche Lebensmittel oder Zutaten problematisch sind. 
                        Wenn der Gastgeber bereits weiß, welche Gerichte er anbieten möchte, kann man 
                        gemeinsam überlegen, welche Möglichkeiten bestehen, diese Gerichte so zuzubereiten, 
                        dass unbekömmliche Zutaten entweder durch bekömmliche ersetzt werden oder die 
                        unverträglichen zum späteren Hinzugeben neben dem Gericht gereicht werden (z.B. 
                        Salatsoße in einem Kännchen und alternativ Essig und Öl neben den Salat stellen). Bei manchen Einladungen 
                        können Sie ja auch selber etwas beisteuern &ndash; einen leckeren Salat oder einen 
                        selbstgebackenen Kuchen. Den können Sie auf jeden Fall besonders lecker und eben 
                        für sich verträglich zubereiten. So werden zwar wahrscheinlich nicht alle 
                        Gerichte für Sie essbar sein, aber wenigstens das eine oder andere, so dass auch 
                        Sie an der netten Einladung Ihren Spaß haben werden.
                        <br />
                        <br />
                        Ohne diese Vorbereitung wäre es nicht schön für Sie, wenn Sie dann missgelaunt an 
                        einem trockenen Brot oder Radieschen kauen würden, weil Sie zum einen nichts 
                        anderes essen können und zum anderen zuschauen müssten, was die anderen alles 
                        Leckeres zur Auswahl haben. Und es wäre auch unfair gegenüber dem Gastgeber, der 
                        sich viel Mühe bereitet hat und nun sehen muss, dass es Ihnen damit gar nicht gut 
                        geht.
                        <br />
                        <br />
                        Eine gute Organisation im Vorfeld ist bei Nahrungsmittel-Unverträglichkeiten also 
                        nicht nur beim Auswärtsessen erforderlich. Auch beim selber Zubereiten von 
                        Mahlzeiten trägt eine gute Vorbereitung mit der sorgfältigen Auswahl der verträglichen 
                        &ndash; und vor allem leckeren &ndash; Lebensmittel dazu bei, dass Sie Ihr Essen 
                        so richtig genießen können!
                        <br />
                        <a id="suenden">&nbsp;</a>
                        <br />
                        <hr>
                        <h5>Bewusste &#187;Sünden&#171;</h5>
                        <hr>
                        Und wenn Sie tatsächlich einmal ein scheinbar unbezwingbares Bedürfnis überkommt, 
                        ein &#187;verbotenes&#171; Nahrungsmittel essen zu wollen, dürfen Sie in den 
                        meisten Fällen durchaus auch einmal &#187;sündigen&#171;. Es muss Ihnen dann klar sein, dass 
                        auf diese Sünde dann Beschwerden folgen &ndash; aber wägen Sie ab, ob sich das 
                        &#187;Preis-Leistungs-Verhältnis&#171; &ndash; sprich das Verhältnis von Genuss 
                        und anschließenden Beschwerden &ndash; lohnt. Wenn Sie meinen, dass Sie die 
                        Bauchschmerzen, die vielleicht einen Tag lang anhalten, es wert sind, eine Mahlzeit mit 
                        einem unverträglichen Lebensmittel zu verzehren, dann essen Sie dieses Lebensmittel. 
                        <br />
                        <br />
                        <img src="<?php echo IMG_PATH; ?>bewertung-gut.png" alt="" class="left" />
                        <b>Vergessen Sie dann aber nicht, diese Mahlzeit dann auch so richtig zu genießen 
                        &ndash; damit sich diese bewusste Sünde dann auch wenigstens gelohnt hat!</b>
                        <br />
                        <br />
                        Danach ist Zeit, wieder konsequent zu sein. Aber die Erinnerung an diesen Genuss dürfen 
                        Sie dann noch lange auskosten &ndash; zu einem erneuten Sündigen werden Sie 
                        wahrscheinlich so bald gar nicht wieder das Bedürfnis verspüren. 
                        <br />
                        <br />
                        Und wenn doch? Dann schauen Sie, dass Sie es nicht allzu oft tun und überprüfen 
                        gegebenenfalls, ob Sie nicht auch aus verträglichen Zutaten genussvollere Mahlzeiten 
                        zaubern können. Wie wäre es, ein Gericht auch optisch aufzuwerten &ndash; es 
                        beispielsweise mit essbaren Blüten zu verzieren oder im guten Geschirr von der 
                        Oma anzurichten &ndash; es gibt so viele Möglichkeiten, den Genuss zu erhöhen. 
                        <br />
                        <a id="genussmittel">&nbsp;</a>
                        <br />
                        <hr>
                        <h5>Genussmittel</h5>
                        <hr>
                        Ein anderes Thema sind (nicht nur) bei Nahrungsmittel-Unverträglichkeiten die 
                        sogenannten &#187;Genussmittel&#171; wie Kaffee, Tee, Schokolade, Zigaretten und 
                        Alkohol. In einem <a href="ganz-genussmittel" target="_blank">gesonderten Beitrag</a> 
                        können Sie die spezifischen Wirkungen dieser Stoffe auf das Verdauungssystem lesen 
                        und entscheiden, ob und ggf. in welchen Mengen Sie Genussmittel in Ihr Leben 
                        integrieren möchten und mit welchen Konsequenzen Sie dadurch zu rechnen haben.
                        <br />
                        <a id="schluss">&nbsp;</a>
                        <br />
                        <hr>
                        <h5>Noch eine Bemerkung zum Schluss ...</h5>
                        <hr>
                        Die wichtigste Voraussetzung, ob Ihnen etwas schmeckt und ob sie es genießen können, 
                        spielt sich in Ihrem Kopf ab: Nicht das &#187;Verbotene&#171; beweinen, sondern 
                        sich auf das &#187;Erlaubte&#171; freuen. Neben den auch vorher schon geliebten 
                        und nach wie vor erlaubten Lebensmitteln gibt es wahrscheinlich viele, die bisher (noch) 
                        nicht zu Ihrem Favoriten gezählt haben. Diese können bei näherer Betrachtung und 
                        abgeänderter Zubereitungsweise auch richtig lecker sein. Und zusätzlich gibt es mit 
                        Sicherheit zahlreiche Lebensmittel, die Sie (bisher) noch gar nicht kannten. Seien 
                        Sie neugierig und probieren Sie Unbekanntes aus. Viele Zutaten werden Sie sicherlich 
                        bald lieben und genießen lernen, wenn Sie diesen eine Chance geben.
                        <br />
                        <br />
                        Ich wünsche Ihnen einen guten Appetit!
                        <br />
                        <br />
                        <hr>
                        <br />
                        <b>Lesen Sie hierzu auch folgenden Beitrag auf dieser Website: </b>
                        <br />
                        <a href="ganz-genussmittel" target="_blank">&#149; Genussmittel bei Darmempfindlichkeit</a>
                        <br />
                        <br />
                        <hr>
                        <br />
                        <a href="guterrat" target="_blank"><img src="<?php echo IMG_PATH; ?>hilfreich.png" alt="" class="left" /></a>
                        <br />
                        <br />
                        <hr />
                        <a href="javascript: scrollMainToTop();" class="nachoben">nach oben</a>
                    </div>
                </div>
            </div>    
            <br>
            <br> 
            <div class="bodyspacer"></div> 
        </div>