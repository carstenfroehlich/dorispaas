        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br /> 
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>
                <h1 class="header center orange-text">Zöliakie und Gluten-Unverträglichkeit (Gluten-Sensitivität)</h1>      
            </div>  
        </div> 
        <div class="container">    
            <div class="section">   
                <div class="row margintoprow">        
                    <div class="col s12 m12">
                        <a href="paas-heftchen-gluten" target="_blank"><img src="<?php echo IMG_PATH; ?>buchzumthema-gluten.png" alt="" class="right" /></a>
                        <a href="paas-heftchen-kinderzoeliakie" target="_blank"><img src="<?php echo IMG_PATH; ?>buchzumthema-kinderzoeli.png" alt="" class="right" /></a>
                        Sowohl die Zöliakie als auch die Gluten-Unverträglichkeit sind Formen einer Unverträglichkeit 
                        gegenüber dem Getreideeiweiß Gluten (sprich Glutehn, mit Betonung auf der 
                        zweiten Silbe). 
                        <br />
                        <br />
                        Gluten ist in den Getreidesorten Weizen, Roggen und Gerste und deren Abkömmlingen 
                        Dinkel, Grünkern, Emmer, Einkorn und Kamut enthalten. Hafer enthält 
                        eigentlich kein Gluten, sondern &#187;nur&#171; ein etwas weniger agressives Protein 
                        (Avenin), durch Verunreinigungen mit anderen Körnern können jedoch 
                        auch in Haferprodukten nennenswerte Glutenmengen enthalten sein. Somit ist auch Hafer 
                        (zumindest aus deutscher Produktion) für Zöliakie-Betroffene nicht geeignet. 
                        Gluten ist auch unter dem Beinamen &#187;Klebereiweiß&#171; bekannt, weil es 
                        beim Backen klebende Eigenschaften hat und u.a. Brotteig zusammenhält und dadurch 
                        beim Backen schön aufgehen lässt. Gebäck aus Getreidearten, die frei von Gluten 
                        sind, ist eher bröckelig und schwerer zu verbacken.
                        <br />
                        <br />
                        Da vor allem Weizen, aber auch Roggen und Gerste aufgrund dieser günstigen 
                        Eigenschaften als Brot- und Backgetreide, und darüber hinaus auch für 
                        Nudeln und andere Teigwaren vermehrt eingesetzt werden, ist unsere Nahrung sehr 
                        stark glutenhaltig. 
                        <br />
                        <br />
                        Insbesondere der Weizen wurde in den letzten 50 Jahren u.a. mehr 
                        und mehr auf einen hohen Glutengehalt gezüchtet, eben weil das Gluten von der 
                        Nahrungsmittelindustrie die oben beschriebenen, erwünschten Eigenschaften hat. 
                        Ungeachtet der Tatsache, dass der Verzehr großer Gluten-Mengen 
                        für kein menschliches Verdauungssystem vorteilhaft ist &ndash; egal, ob man Zöliakie oder 
                        eine Gluten-Sensitivität hat oder nicht &ndash; wird dieses hochgezüchtete Getreide ohne 
                        Rücksicht auf die Folgen für die Verbraucher von der Industrie in allen möglichen 
                        Nahrungsmitteln eingesetzt. 
                        <br />
                        <br />
                        Aufgrund der Bindefreudigkeit wird Gluten auch 
                        als technischer Hilfsstoff in allen möglichen Nahrungsmitteln wie Wurst- und 
                        Fleischwaren, Milchprodukten und Käse, aber auch in Gewürzen und Tee 
                        und sogar in Medikamenten verwendet &ndash; es gibt keine industriell bearbeitete 
                        Nahrungsmittelgruppe, in der nicht Gluten Verwendung finden könnte und die 
                        garantiert immer frei von Gluten ist. 
                        <br />
                        <br />
                        Gemeinsam haben Zöliakie und Gluten-Sensitivität, dass in beiden Fällen Gluten 
                        unverträglich ist und der Verzehr zu verschiedenen Beschwerden führt. Oftmals sind 
                        es Verdauungsbeschwerden wie Blähungen, häufige Stühle, Durchfälle und/oder 
                        Verstopfung. Aber auch die verschiedendsten diffusen Beschwerden, die man zuerst 
                        gar nicht mit der Ernährung in Verbindung bringt, können durch Glutenverzehr 
                        verursacht werden.
                        <br />
                        <br />
                        Gluten-Sensitivität ist &#187;nur&#171; eine Nahrungsmittel-Intoleranz
                        mit allen Merkmalen einer Unverträglichkeit. Insbesondere ist sie mengenabhängig, 
                        d.h. beispielsweise, dass die Intensität der Symptome von der Verzehrmenge abhängig ist. Dies 
                        bedeutet, dass Spuren grundsätzlich und meist auch kleinere Mengen Gluten ohne Probleme 
                        toleriert werden und keine Beschwerden machen. Andere Bezeichnungen für die Gluten-Sensitivität
                        sind u.a. &#187;nicht-Zöliakie-Weizensensivität&#171;,  &#187;non celiac gluten sensitivity&#171; 
                        oder &#187;non celiac gluten sensitive enteropathy&#171;.
                        <br />
                        <br />
                        Eine Zöliakie hingegen ist eine Autoimmunerkrankung, bei der bereits kleinste 
                        Spuren von verzehrtem Gluten dazu führen, dass sich das Immunsystem gegen die 
                        eigenen Körperzellen &ndash; in diesem Falle gegen die Zellen der Dünndarmschleimhaut &ndash;
                        richtet und diese nach und nach zerstört. 
                        <br />
                        <br />
                        Zusammengefasst bedeutet dies: Bei beiden Erkrankungen muss Gluten gemieden werden, 
                        um beschwerdefrei zu bleiben &ndash; bei der Zöliakie absolut konsequent, es werden 
                        keine noch so kleinen Glutenmengen vertragen, ohne dass schwere Folgen auftreten.
                        Bei der Gluten-Sensitivität ist eine weitestgehende Meidung erforderlich, 
                        Gluten-Spuren oder eine der individuellen Toleranzschwelle entsprechende, kleinere 
                        Menge werden jedoch ohne Folgen vertragen.
                        <br />
                        <br />
                        <hr>
                        <a id="beratung">&nbsp;</a>
                        <div class="row">
                        <div class="col s12 m2">
                            <a href="http://www.ganzheitliche-gesundheitsberatung.de" target="_blank">
                                <img src="<?php echo IMG_PATH; ?>praxiswebsite.png" alt="" class="inline" /></a>
                        </div>
                        </div>
                        <div class="row">
                        <div class="col s12 m12">
                        <h5>Beratung</h5>
                        <br />
                            Gerne biete ich Ihnen eine individuelle Beratung an &ndash; 
                            auf Wunsch auch telefonisch oder per Skype.
                            <br />
                            Bitte informieren Sie sich auf meiner Praxis-Website <a href="http://www.ganzheitliche-gesundheitsberatung.de" target="_blank">&#187;www.Ganzheitliche-Gesundheitsberatung.de&#171;</a>
                        </div>
                        </div>
                        <hr>
                        <br />
                        <a href="guterrat" target="_blank"><img src="<?php echo IMG_PATH; ?>hilfreich.png" alt="" class="left" /></a>
                        <br />
                        <br />
                        <br />
                        <b>Lesen Sie bitte weiterhin folgende Beiträge:</b>
                        <br />
                        <a href="zoeliakie">Zöliakie &ndash; was ist das?</a>
                        <br />
                        <a href="zoeliakie-diagnose">Diagnose der Zöliakie</a>
                        <br />
                        <a href="glutensensitivitaet">Gluten-Sensitivität &ndash; was ist das?</a>
                        <br />
                        <a href="glutensensitivitaet-diagnose">Diagnose der Gluten-Sensitivität</a>
                        <br />
                        <a href="zoeliakie-behandlung">Behandlung der Zöliakie und der Gluten-Sensitivität</a>
                        <br />
                        <br />
                        <b>Empfehlenswerte Literatur:</b>
                        <br />
                        <a href="paas-heftchen-gluten" target="_blank">Zöliakie und Gluten-Sensitivität</a>
                        <br />
                        <br />
                        <hr />
                        <b>Empfehlung:</b>
                        <br />
                        Eine unverzichtbare Hilfe bei der Ermittlung geeigneter Lebensmittel ist die
                        <br />
                        &#187;<b>DorisPaas.de &ndash; Lebensmittel-Datenbank</b>&#171;. 
                        Informieren Sie sich <a href="lebensmittel-datenbank-info" "traget=_blank">hier</a>.
                        <hr />
                        <br />
                        <br />
                        <a href="javascript: scrollMainToTop();" class="nachoben">nach oben</a>
                    </div>
                </div>
            </div>    
            <br>
            <br> 
            <div class="bodyspacer"></div> 
        </div>