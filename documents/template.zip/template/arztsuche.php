        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br /> 
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>
                <h1 class="header center orange-text">Mein Arzt &ndash;</h1>      
                    <div class="row center">        
                    <h5 class="header col s12 light">wie finde ich den richtigen Arzt für mein Problem?</h5>      
                    </div>     
            </div>  
        </div> 
        <div class="container">    
            <div class="section">   
                <div class="row margintoprow">        
                    <div class="col s12 m4">
                        <ul class="nav">
                            <li>
                                <b>Abschnitte dieser Seite:</b>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>arztsuche#augenhoehe">Mit dem Arzt auf Augenhöhe</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>arztsuche#fehlervermeidung">Fehler vermeiden</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>arztsuche#unnoetigetests">Unnötige Tests vermeiden</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>arztsuche#kontrolle">Die Kontrolle behalten</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>arztsuche#ernaehrungsberatung">Ernährungsberatung</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>arztsuche#magendarmzentren">Magen-Darm-Zentren</a>
                            </li> 
                        </ul>
                    </div>
                    <div class="col s12 m8">
                        <img src="<?php echo IMG_PATH; ?>stethoskop.png" alt="Stethoskop" class="right" />
                    </div>
                </div>
                </div>
                <div class="row margintoprow">        
                    <div class="col s12 m12">
                        Wenn Sie immer wieder Probleme mit der Verdauung haben, werden Sie versuchen, 
                        der oder den Ursachen auf den Grund zu gehen. Wahrscheinlich haben Sie selber 
                        irgendwann bestimmte Lebensmittel im Verdacht, diese Beschwerden zu verursachen.
                        <br />
                        <br />
                        Früher oder später werden Sie Ihren Arzt aufsuchen, um eine eventuelle 
                        Nahrungsmittel-Unverträglichkeit zu diagnostizieren oder aber auch auszuschließen.
                        <br />
                        <a id="augenhoehe"></a>
                        <br />
                        <hr />
                        <h5>Mit dem Arzt auf Augenhöhe</h5>
                        <hr />
                        Es ist auf jeden Fall von Vorteil, wenn Sie sich schon vor diesem Arztbesuch 
                        möglichst umfassend schlau gemacht haben. Nur so können Sie mit Ihrem Arzt <b>auf 
                        Augenhöhe</b> sprechen. Glücklicherweise sind die Zeiten so gut wie vorbei, als 
                        die Ärzte sich noch als die &#187;Halbgötter in Weiß&#171; fühlten und meinten, 
                        dass der Patient ohnehin keine Ahnung von der Materie hat und ihm und seinen 
                        Vorschriften zu folgen hat. Die älteren Ärzte, die am ehesten noch so gedacht haben, 
                        verschwinden altersgemäß nach und nach von der Bildfläche, und jüngere Mediziner 
                        nehmen deren Stellen ein. Erschreckenderweise habe ich allerdings erst kürzlich 
                        im Rahmen eines Selbsthilfetreffens, an dem auch Medizinstudenten teilgenommen haben, 
                        um sich über die entsprechende Problematik zu informieren, auch bei einigen dieser 
                        jungen zukünftigen Ärzte noch eine antiquierte und ziemlich überhebliche Einstellung 
                        zum Arzt-Patienten-Verhältnis bemerkt.
                        <br />
                        <br />
                        Größtenteils jedoch ist es von den Ärzten heute sogar erwünscht, dass sie in ihrem 
                        Gegenüber einen informierten Patienten haben, denn so sparen sie sich lange Erklärungen. 
                        <br />
                        <br />
                        Und für Sie als Patient(in) hat dies den Vorteil, dass Sie sich auf Augenhöhe mit 
                        Ihrem Behandler unterhalten und ihm Fragen stellen können, die Ihnen anderenfalls 
                        gar nicht eingefallen wären. Somit bedeutet eine umfassende Information vor dem 
                        Arztgespräch, dass Sie sehr viel mehr über sich und eine eventuelle Krankheit erfahren 
                        und auch mitbestimmen können, welche diagnostischen Maßnahmen und später auch 
                        Therapien durchgeführt werden.
                        <br />
                        <a id="fehlervermeidung"></a>
                        <br />
                        <hr />
                        <h5>Fehler vermeiden</h5>
                        <hr />
                        Es bedeutet darüber hinaus, dass Sie die Kontrolle behalten darüber, ob bestimmte 
                        Maßnahmen auch korrekt ausgeführt werden. Leider erlebe ich immer wieder, dass 
                        gerade die Wasserstoff-Atemtests, die heute als Goldstandard zur Ermittlung von 
                        Nahrungsmittel-Unverträglichkeiten und Dünndarmfehlbesiedelungen gelten, in den 
                        Arztpraxen nicht immer ganz richtig verlaufen. Dies liegt zum Teil daran, dass 
                        eventuell das Praxispersonal nicht exakt eingewiesen wurde, teils, dass leider 
                        auch einigen Ärzten die Bedeutung auch kleinster Details nicht wichtig genug 
                        erscheint. Ein weiterer Grund kann aber auch die unzureichende Information des 
                        Verhaltens des Patienten im Vorfeld der Tests sein. So kann es zu ungenauen oder 
                        auch sogar falschen Ergebnissen kommen, und das ist schade.
                        <br />
                        <a id="unnoetigetests"></a>
                        <br />
                        <hr />
                        <h5>Unnötige Tests vermeiden</h5>
                        <hr />
                        Bei sorgfältigerer Durchführung wäre es oft sogar möglich, mit einem Atemtest 
                        nicht nur die Unverträglichkeit gegenüber der Testlösung abzuprüfen, sondern es 
                        könnte gleichzeitig auch eine Dünndarmfehlbesiedelung diagnostiziert oder 
                        ausgeschlossen werden. Diese Tatsache ist aber sowohl vielen Ärzten als erst recht 
                        auch den Patienten nicht bekannt, und so müssen bei anhaltenden Beschwerden weitere 
                        Tests durchgeführt werden. Diese Belastung durch die zusätzlichen Tests könnte bei 
                        vorheriger Information vermieden werden.
                        <br />
                        <a id="kontrolle"></a>
                        <br />
                        <hr />
                        <h5>Die Kontrolle behalten</h5>
                        <hr />
                        Als Patient können wir schlecht abschätzen, ob unser Arzt über diese Vorkenntnisse 
                        und auch über die entsprechende Ausrüstung in seiner Praxis verfügt. Wir können 
                        uns aber selber schlau machen und im Vorgespräch dafür sorgen, dass die Tests nach 
                        unseren Vorstellungen verlaufen. Sollte der Arzt dann nicht bereit sein, die Tests 
                        präziser durchzuführen, bleibt uns die Möglichkeit, ungenaue Tests zu vermeiden 
                        und uns rechtzeitig einen qualifizierteren Arzt zu suchen.
                        <br />
                        <br />
                        Diese Website soll Ihnen die erforderlichen allgemeinen Informationen liefern, 
                        um sich weitestgehend zu vorzubereiten. Sollten Sie individuellen Informationsbedarf 
                        haben, biete ich Ihnen auch gerne eine Beratung an, in der wir Ihre persönlichen 
                        Probleme besprechen und schauen können, welche Tests ggf. erforderlich sind und 
                        wie diese genau durchgeführt werden sollten.
                        <br />
                        <br />
                        Je besser Sie informiert in ein Arztgespräch gehen, desto vorteilhafter wird dies 
                        für den Untersuchungsverlauf und auch für eine eventuelle spätere Therapie sein. 
                        Scheuen Sie sich nicht, dem Arzt auf Augenhöhe gegenüberzutreten &ndash; wenn er 
                        dies nicht mag, ist er wahrscheinlich nicht der kompetente Ratgeber für Sie, den 
                        Sie sich wünschen.
                        <br />
                        <a id="ernaehrungsberatung"></a>
                        <br />
                        <hr />
                        <h5>Ernährungsberatung</h5>
                        <hr />
                        Und wenn Sie dann eine qualifizierte Diagnose erhalten haben, dürfen Sie nicht von 
                        Ihrem Arzt &ndash; sei er auch noch so kompetent &ndash; erwarten, dass er Sie 
                        solange mit Ernährungstipps begleitet, bis Sie sich mit einer eventuell 
                        erforderlichen Diät selbst zurecht finden. Dies kann bei allem Wohlwollen ein Arzt 
                        nicht leisten. Zum einen ist er hier tatsächlich nicht der richtige Ansprechpartner, 
                        und zum anderen kann er dies aus wirtschaftlichen Gründen auch gar nicht anbieten. 
                        Hierfür sind Ernährungs- und/oder Gesundheitsfachkräfte zuständig. Suchen Sie sich 
                        auch hier auf Ihre Problematik spezialisierte Fachkräfte, die ggf. auch bereit 
                        sind mit Ihrem  Arzt zusammen zu arbeiten. 
                        <br />
                        <br />
                        <hr>
                        <div class="row">
                        <div class="col s12 m2">
                            <a href="http://www.ganzheitliche-gesundheitsberatung.de" target="_blank">
                                <img src="<?php echo IMG_PATH; ?>praxiswebsite.png" alt="" class="inline" /></a>
                        </div>
                        </div>
                        <div class="row">
                        <div class="col s12 m12">
                            Gerne biete ich Ihnen eine individuelle Beratung an &ndash; 
                            auf Wunsch auch telefonisch oder per Skype.
                            <br />
                            Bitte informieren Sie sich auf meiner Praxis-Website <a href="http://www.ganzheitliche-gesundheitsberatung.de" target="_blank">&#187;www.Ganzheitliche-Gesundheitsberatung.de&#171;</a>
                        </div>
                        </div>
                        <div class="row">
                        <div class="col s12 m12">
                        <hr>
                        <a id="magendarmzentren"></a>
                        <br />
                        <h5>Magen-Darm-Zentren</h5>
                        <hr />
                        Häufig empfehlenswert sind die besonders in Großstädten zu findenden sogenannten
                        &#187;Magen-Darm-Zentren&#171; die sich auf die Diagnostik und Behandlung von Menschen 
                        mit Problemen im Magen-Darm-Trakt spezialisiert haben. In diesen Zentren arbeiten 
                        mehrere Ärzte zusammen &ndash; meist Gastroenterologen, Proktologen und Internisten.
                        Durch diese enge Kooperation kann auf dem kürzesten Wege ein Erfahrungsaustausch
                        stattfinden, so dass sich die Kompetenzen mehrerer Fachärzte addieren. Darüber hinaus 
                        lernen die Kollegen voneinander und können in Konferenzen gemeinsam überlegen, 
                        welche diagnostischen oder Behandlungsmöglichkeiten am geeignetsten sind. Oftmals
                        kooperieren diese Zentren auch mit Ernährungs- und/oder Gesundheitsfachkräften, 
                        so dass die Patienten hier in den meisten Fällen sehr gut betreut werden.
                        <br />
                        <br />
                        <hr>
                        <br />
                        <a href="guterrat" target="_blank"><img src="<?php echo IMG_PATH; ?>hilfreich.png" alt="" class="left" /></a>
                        <br />
                        <br />
                        <br />
                        <b>Lesen Sie auch folgende Betr&auml;ge</b>:
                        <br />
                        <a href="arztqualifikation">Wie erkenne ich die Qualifikation eines Arztes?</a>
                        <br />
                        <a href="selbsttests">Selbsttests bei Nahrungsmittel-Unverträglichkeiten &ndash; wann sind sie sinnvoll?</a>
                        <br />
                        <a href="diagnose">Diagnose-Methoden zur Ermittlung einer Laktose-Intoleranz</a>
                        <br />
                        <a href="fmadiagnose">Diagnose-Methoden zur Ermittlung einer Fruktose-Intoleranz</a>
                        <br />
                        <a href="oligosaccharide-diagnose">Diagnose-Methoden zur Ermittlung einer Oligosaccharid-Intoleranz</a>
                        <br />
                        <a href="zoeliakie-diagnose">Diagnose der Zöliakie</a>
                        <br />
                        <a href="glutensensitivitaet-diagnose">Diagnose der Gluten-Sensitivität</a>
                        <br />
                        <a href="rds-diagnose">Diagnose des Reizdarm-Syndroms</a>
                        <br />
                        <hr />
                        <a href="javascript: scrollMainToTop();" class="nachoben">nach oben</a>
                    </div>
                    </div>
                </div>
            </div>    
            <br>
            <br> 
            <div class="bodyspacer"></div> 
        </div>