        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br /> 
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>
                <h1 class="header center orange-text">Behandlung</h1> 
                    <div class="row center">        
                    <h5 class="header col s12 light">der Fruktose-Intoleranz (Fruktosemalabsorption)</h5>      
                    </div>     
            </div>  
        </div> 
        <div class="container">    
            <div class="section">   
                <div class="row margintoprow">        
                    <div class="col s12 m4">
                        <ul class="nav">
                            <li>
                                <b>Abschnitte dieser Seite:</b>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>fmabehandlung#fma">Fruktose-Malabsorption &ndash; eine Krankheit?</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>fmabehandlung#medikamente">Medikamente</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>fmabehandlung#darmflora">Pflege von Darmflora und Darm</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>fmabehandlung#probiotika">Unterstützung der Darmflora mit Pro- und Präbiotika</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>fmabehandlung#bewegung">Bewegung und Sport</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>fmabehandlung#entspannung">Entspannung</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>fmabehandlung#beratung">Beratung</a>
                            </li> 
                            <li>
                                <a href="guterrat" target="_blank">War dieser Beitrag hilfreich für Sie?</a>
                            </li> 
                        </ul>
                    </div>
                    <div class="col s12 m8">
                        <a href="paas-heftchen-fu" target="_blank"><img src="<?php echo IMG_PATH; ?>buchzumthema-fi.png" alt="" class="right" /></a>
                    </div>
                </div>
                <div class="row margintoprow">        
                    <div class="col s12 m12">
                        <a id="fma"></a>
                        <hr />
                        <h5>Fruktose-Malabsorption &ndash; eine Krankheit?</h5>
                        <hr />
                        Eine Fruktose-Malabsorption kann &ndash; im Gegensatz zu einer Laktose-Intoleranz 
                        &ndash; als Krankheit angesehen werden, vorausgesetzt, die Malabsorption tritt nicht 
                        auf, weil mit der Nahrung viel zuviel Fruchtzucker aufgenommen wird (bitte lesen Sie hierzu 
                        auch die Seite &#187;<a href="wasistfma" target="_blank">Was ist 
                        Fruktose-Intoleranz?</a>&#171;).
                        <br />
                        <br />
                        Heilbar ist die FMA nicht, es kann jedoch mit einer angepassten, fruktosearmen 
                        Ernährung eine weitestgehende Beschwerdefreiheit erreicht werden.
                        <br />
                        <br />
                        Auch eine Ernährung, die möglichst frei von Haushaltszucker ist, ist bei 
                        einer FMA angeraten &ndash; zumindest in der Anfangsphase, bis man herausgefunden hat, 
                        welche Nahrungsmittel einem besser oder schlechter bekommen.
                        <br />
                        <a id="medikamente">&nbsp;</a>
                        <hr />
                        <h5>Medikamente</h5>
                        <hr />
                        Da das fehlende oder nicht ausreichende Transportprotein GLUT5 nicht künstlich 
                        hergestellt und als Medikament verabreicht werden kann, ist es leider nicht möglich, 
                        es &ndash; wie beispielsweise das Laktase-Enzym bei einer Laktose-Intoleranz &ndash; 
                        in Tablettenform zu substituieren (ersetzen/ergänzen).
                        <br />
                        <br />
                        Jedoch ist auffällig, dass bei einer FMA oftmals die Konzentrationen der Aminosäure 
                        Tryptophan, dem Vitamin B9 (Folsäure) und dem Spurenelement Zink im Blut erniedrigt 
                        sind. Durch die Ergänzung dieser Stoffe kann &ndash; bei gleichzeitiger, möglichst 
                        fruktosearmer Ernährung &ndash; unter Umständen eine Beschwerdebesserung 
                        herbeigeführt werden.
                        <br />
                        <a id="darmflora">&nbsp;</a>
                        <hr />
                        <h5>Pflege von Darmflora und Darm</h5>
                        <hr />
                        Zusätzlich zu einer angepassten Ernährung helfen die Pflege der Darmflora 
                        und des Darmes. Hierbei sollte auf eine möglichst naturbelassene Ernährung 
                        geachtet werden. Zwar sind Vollkornprodukte fruktosehaltiger als Produkte aus weißem 
                        Mehl, es ist aber durchaus hilfreich, hier eine gesunde Balance zu finden, denn 
                        die Ballaststoffe in den Vollkornprodukten pflegen die Darmschleimhaut: Wie bei 
                        einem Peeling schmirgeln die harten Schalen die abgestorbenen Zellen der Darmschleimhaut 
                        ab und ermöglichen es so den jungen Zellen, ihre Funktionen optimal zu erfüllen. 
                        <br />
                        <br />
                        In einer so gepflegten Darmschleimhaut können sich nützliche Darmbakterien 
                        bestmöglich vermehren und so krankmachenden Keimen wenig Platz und Nährboden 
                        bieten. Somit bildet sich eine gesund ausbalancierte Darmflora, die zu Ihrem 
                        Wohlbefinden beiträgt.
                        <br />
                        <br />
                        Der oben erwähnte Hinweis auf einen möglichst geringen Verzehr von Haushaltszucker 
                        ist deshalb wichtig, weil sich schädliche Darmbakterien vorrangig von Zucker 
                        ernähren &ndash; und dieser Nährboden sollten ihnen entzogen werden. 
                        Somit haben günstiger wirkende Bakterien die Möglichkeit, sich zu vermehren 
                        und eine gesündere Zusammensetzung der Darmflora zu bewirken.
                        <br />
                        <a id="probiotika">&nbsp;</a>
                        <hr />
                        <h5>Unterstützung der Darmflora mit Pro- und Präbiotika</h5>
                        <hr />
                        Als Probiotika bezeichnet man Darmbakterien, die für den Menschen günstige 
                        Wirkungen entfalten. Hier sind insbesondere Milchsäurebakterien zu nennen, 
                        die neben einer günstigen Wirkung in Bezug auf den Milchzucker insgesamt ein 
                        optimales Milieu im Darm erzeugen. Deshalb eignet sich der verstärkte Verzehr 
                        von milchsauer eingelegtem Gemüse wie Sauerkraut, Roter Beete, Mixed Pickles u.Ä.
                        <br />
                        <br />
                        Als Präbiotika werden Stoffe bezeichnet, die eigentlich für den Menschen 
                        unverdaubar sind, jedoch als &#187;Futter&#171; für die vorteilhaften Darmbakterien 
                        dienen können. Mit dem Verzehr von präbiotischen Nahrungsbestandteilen 
                        wird die Vermehrung der günstigen Darmbakterien unterstützt &ndash; die 
                        Darmflora wird somit mit diesen für den Menschen vorteilhaften Bakterienarten 
                        angereichert, die ungünstiger wirkenden oder gar krank machenden werden 
                        zurückgedrängt. 
                        <br />
                        <br />
                        Viele pflanzliche Nahrungsmittel wie z.B. Chicoree, Schwarzwurzeln oder auch die 
                        Topinamburknolle enthalten einen hohen Anteil an präbiotischen Inhaltsstoffen. 
                        Präbiotika werden auch als Präparate zum Einnehmen in Apotheken oder Reformhäusern 
                        angeboten. Hier ist insbesondere das Inulin zu nennen, das eine günstige, 
                        verstärkende Wirkung auf Probiotika haben kann (nicht zu verwechseln mit dem 
                        Insulin, das für die Zuckerverwertung besonders den Diabetikern bekannt ist). 
                        Oftmals werden Kombipräparate aus Pro- und Präbiotika angeboten. 
                        <b>Für empfindliche Menschen insbesondere solche mit einer Fruktose-Intoleranz 
                        sei jedoch der Hinweis angebracht, dass Präbiotika u.U. selber Unverträglichkeitsreaktionen 
                        hervorrufen können. Eine vorsichtige Dosierung ist also unbedingt angeraten. </b> 
                        <br />
                        <a id="bewegung">&nbsp;</a>
                        <hr />
                        <h5>Bewegung und Sport</h5>
                        <hr />
                        Zu einem gesunden Darm gehört auch ausreichende Bewegung, denn die Darmperistaltik 
                        (Darmbewegungen) normalisiert sich durch eine ausreichende, gesunde Bewegung der 
                        Bauchmuskulatur. Bewegen Sie sich deshalb täglich mit Freude und Spaß 
                        am besten an der frischen Luft, denn nicht nur die Bewegung an sich tunt Ihrem Darm gut, 
                        auch die Anreicherung des Blutes mit Sauerstoff trägt zu Ihrer Gesundheit und 
                        Ihrem Wohlbefinden bei. Wählen Sie eine Sportart, die Ihnen gefällt und 
                        beginnen Sie 6'150; insbesondere als &#187;Anfänger&#171; langsam und 
                        überfordern Sie sich nicht.
                        <br />
                        <a id="entspannung">&nbsp;</a>
                        <hr />
                        <h5>Entspannung</h5>
                        <hr />
                        Häufig wird eine Nahrungsmittel-Intoleranz auch begleitet von einem Reizdarm-Syndrom. 
                        Dieses kann günstig beeinflusst werden durch eine vernünftige Balance 
                        zwischen Anregung und Entspannung. Sollten Ihre Beschwerden sich also trotz konsequenter, 
                        fruktosearmer Ernährung nicht zu Ihrer Zufriedenheit reduzieren, so versuchen Sie (
                        auch in Rücksprache mit Ihrem Arzt), verschiedene Entspannungstechniken zu 
                        erlernen (autogenes Training, progressive Muskelentspannung nach Jacobson, Quigong). 
                        Oftmals sind Entspannungsübungen sehr hilfreich, um Beschwerden bei Fruktose-Intoleranz 
                        günstig zu beeinflussen.
                        <br />
                        <br />
                        <hr>
                        <a id="beratung">&nbsp;</a>
                        <div class="row">
                        <div class="col s12 m2">
                            <a href="http://www.ganzheitliche-gesundheitsberatung.de" target="_blank">
                                <img src="<?php echo IMG_PATH; ?>praxiswebsite.png" alt="" class="inline" /></a>
                        </div>
                        </div>
                        <div class="row">
                        <div class="col s12 m12">
                        <h5>Beratung</h5>
                        <br />
                            Gerne biete ich Ihnen eine individuelle Beratung an &ndash; 
                            auf Wunsch auch telefonisch oder per Skype.
                            <br />
                            Bitte informieren Sie sich auf meiner Praxis-Website <a href="http://www.ganzheitliche-gesundheitsberatung.de" target="_blank">&#187;www.Ganzheitliche-Gesundheitsberatung.de&#171;</a>
                        </div>
                        </div>
                        <hr>
                        <br />
                        <a href="guterrat" target="_blank"><img src="<?php echo IMG_PATH; ?>hilfreich.png" alt="" class="left" /></a>
                        <br />
                        <br />
                        <hr />
                        <img src="<?php echo IMG_PATH; ?>lebensmitteldatenbank.png" alt="home video small" class="left" />
                        <b>Empfehlung:</b>
                        <br />
                        Eine zusätzliche Hilfe bei der Ermittlung geeigneter Lebensmittel stellt die
                        <br />
                        &#187;<b>DorisPaas.de &ndash; Lebensmittel-Datenbank</b>&#171; dar. 
                        <a href="lebensmittel-datenbank-info" target="_blank">Informieren Sie sich hier</a>.
                        <br />
                        <br />
                        <br />
                        <hr />
                        <b>Lesen Sie auch folgende Beträge</b>:
                        <br />
                        <a href="wasistfma">Was ist Fruktose-Intoleranz?</a>
                        <br />
                        <a href="fmadiagnose">Diagnose-Methoden zur Ermittlung einer Fruktose-Intoleranz</a>
                        <br />
                        <a href="fmaernaehrung">Ernährung bei Fruktose-Intoleranz</a>
                        <br />
                        <a href="nmu-behandlung">Behandlungsgrundsätze bei Nahrungsmittel-Unverträglichkeiten</a>
                        <br />
                        <a href="nmu-karenz">Karenz</a>
                        <br />
                        <a href="fma-depressionen">Fruktose-Malabsorption und Depressionen</a>
                        <br />
                        <a href="fruktose">Fragen und Antworten zum Thema Fruktose von Dr. H.-J. Thon</a>
                        <br />
                        <br />
                        <b>Empfehlenswerte Literatur</b>:
                        <br />
                        <a href="paas-heftchen-fu">Kurz und klar: Fruchtzucker-Unverträglichkeit </a>
                        <br />
                        <br />
                        <a href="javascript: scrollMainToTop();" class="nachoben">nach oben</a>
                    </div>
                </div>
            </div>    
            <br>
            <br> 
            <div class="bodyspacer"></div> 
        </div>