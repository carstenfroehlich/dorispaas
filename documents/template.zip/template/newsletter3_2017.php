        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br /> 
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>
                <h1 class="header center orange-text">DorisPaas-Newsletter</h1>      
            </div>  
        </div> 
        <div class="container">    
            <div class="section">   
                <div class="row margintoprow">        
                    <div class="col s12 m12">
                        <img src="<?php echo IMG_PATH; ?>dorispaas-de-titelfoto-newsletter-w.png" alt="" border="0" hspace="0" vspace="0" style="float: left; margin-left: 0px; margin-right: 20px; padding-bottom: 0px;" /></a><br />
                        <br />
                        <br />
                        <br />
                        <br />
                        <br />
                        <br />
                        <br />
                        <br />
                        <b>Ausgabe 34 (Mai 2017)</b>
                        <br />
                        <br />
                        _________________________________________________________________________
                        <br />
                        <br />
                        <br />
                        <br />
                        
                        
                        <a href="http://www.dorispaas.de/" target="_blank"><img src="<?php echo IMG_PATH; ?>nl-2017-03-titel.png" alt="" border="0" hspace="0" vspace="0" style="float: left; margin-left: 0px; margin-right: 20px; padding-bottom: 20px;" /></a>
                        Liebe Leserin, lieber Leser.
                        <br />
                        Zur&uuml;ckgekehrt aus einem traumhaften Urlaub durch Nordirland melde ich mich 
                        mit diesem Newsletter bei Ihnen. Nachdem wir bereits im letzten Jahr in S&uuml;dirland 
                        das tollste Wetter hatten, war es auch auf dieser Reise durchgehend angenehm warm. 
                        Ohne einen einzigen Regentag konnten wir nun auch die n&ouml;rdlichen Provinzen 
                        in ihrer ganzen Sch&ouml;nheit genie&#223;en. W&auml;hrend auf unserer letztj&auml;hrigen 
                        Fahrt im September die orangen Montbretien die Wege s&auml;umten, war es in diesem 
                        Mai der tiefgelbe Stechginster &ndash; ein genauso &uuml;berw&auml;ltigender Anblick! 
                        Dieses Land ist auf jeden Fall eine Reise wert! Es mag sein, dass nicht jeder so 
                        viel Gl&uuml;ck mit dem Wetter haben wird, aber da &#187;schlechtes&#171; Wetter 
                        vom stetigen Wind meist schnell weggepustet wird und somit vor&uuml;bergehend ist,
                        braucht man eigentlich nur die richtige Kleidung, um Land, Leute, Natur und Kultur 
                        so richtig genie&#223;en zu k&ouml;nnen. Wenn Sie m&ouml;gen, lesen Sie doch einmal 
                        die beiden Berichte
                        <a href="http://www.dorispaas.de/index.php?page=reiseberichte#irland" target="_blank">&uuml;ber den S&uuml;den und den Norden Irlands</a>.
                        
                        <br />
                        <br />
                        <br />
                        <br />
                        <hr>
                        <br />
                        <a href="http://www.dorispaas.de/index.php?page=internetrat" target="_blank"><img src="<?php echo IMG_PATH; ?>nl-2017-03-internetrat.png" alt="" border="0" hspace="0" vspace="0" style="float: left; margin-left: 0px; margin-right: 20px; padding-bottom: 0px;" /></a>
                        <b>&#149;	<a href="http://www.dorispaas.de/index.php?page=internetrat" target="_blank">Schwerpunktthema: Was kann das Internet f&uuml;r Ihre Gesundheit leisten und was nicht?</a></b>
                        <br />
                        Immer h&auml;ufiger suchen Menschen mit gesundheitlichen Problemen Rat im Internet. 
                        Anhand der verschiedenen Symptome kann mit Suchmaschinen geschaut werden, welche 
                        Informationen hierzu im Netz zu finden sind. Das ist zuerst einmal eine gute Sache. 
                        Nur ist es nat&uuml;rlich schwer, zu unterscheiden, welche Informationen seri&ouml;s 
                        sind und welche nicht. Denn leider posten viele Menschen auch Informationen, die 
                        entweder nur auf deren ganz individuelle Situation zutreffen oder aber auch solche, 
                        die schlichtweg falsch sind. Wie also kann ein Suchender, der im Zweifelsfalle 
                        immer ein Laie in Bezug auf dieses Thema ist, unterscheiden, welche Informationen 
                        wirklich hilfreich sind? Zuerst einmal sollte man die Quelle der Informationen 
                        auf ihre Glaubw&uuml;rdigkeit &uuml;berpr&uuml;fen. Verschiedene Institute, aber 
                        auch Arztpraxen, Heilpraktiker, Ern&auml;hrungs- und Ganzheitliche Gesundheitsberater 
                        pr&auml;sentieren im Internet nicht nur ihre Leistungen, sondern stellen gleichzeitig 
                        auch grundlegende Informationen zu ihren Schwerpunkten auf ihrer Homepage zur 
                        Verf&uuml;gung. Solche Quellen rangieren auf der Glaubw&uuml;rdigkeitsskala recht 
                        weit oben. Andere hingegen leider sehr viel weniger.
                        <br />
                        <br />
                        Auch wenn Sie meinen, im Internet Informationen gefunden zu haben, die Ihnen bei 
                        Ihren Beschwerden interessant erscheinen, sollte Sie diese auf jeden Fall &#187;mit 
                        &auml;u&#223;erster Vorsicht genie&#223;en&#171;! Es ist immer ratsam, 
                        sich bei qualifizierten &Auml;rzten, Heilpraktikern, Ern&auml;hrungs- und/oder 
                        spezialisierten Ganzheitlichen Gesundheitsberatern r&uuml;ckzuversichern, ob die 
                        ins Auge gefassten M&ouml;glichkeiten tats&auml;chlich infrage kommen. Aber es 
                        kann oftmals fast genauso schwierig sein, einen kompetenten Berater zu finden und hier 
                        auch einen zeitnahen Termin zu bekommen. Lesen Sie hierzu die aktualisierten Berichte 
                        zu den Themen: &#187;<a href="http://www.dorispaas.de/index.php?page=arztsuche" target="_blank">Wie 
                        finde ich einen qualifizierten Arzt</a>&#171; und &#187;<a href="http://www.dorispaas.de/index.php?page=arztqualifikation" target="_blank">Wie 
                        erkenne ich die Qualifikation eines Arztes?</a>&#171;. 
                        <br />
                        <br />
                        <br />
                        <br />
                        <hr>
                        <br />
                        <a href="http://www.ganzheitliche-gesundheitsberatung.de/" target="_blank"><img src="<?php echo IMG_PATH; ?>nl-2017-03-praxis.png" alt="" border="0" hspace="0" vspace="0" style="float: left; margin-left: 0px; margin-right: 20px; padding-bottom: 0px;" /></a>
                        <b>&#149;	<a href="http://www.ganzheitliche-gesundheitsberatung.de/" target="_blank">Qualifizierte Beratung</a></b>
                        <br />
                        Selbstverst&auml;ndlich biete auch Ich Ihnen gerne meine Beratung an. Als 
                        &#187;Beraterin f&uuml;r Ganzheitliche Gesundheit (IHK)&#171; bin ich ausgebildet, 
                        Sie ganz umfassend in s&auml;mtlichen Bereichen zu beraten, in denen Sie Einfluss 
                        auf Ihre Gesundheit nehmen, sie sch&uuml;tzen, st&auml;rken und ggf. wieder herstellen 
                        k&ouml;nnen. Dabei helfen mir meine Erfahrungen als Lehrerin, sie p&auml;dagogisch 
                        anzuleiten und zu begleiten. Auch wenn ich so eine &#187;Rundum-Beratung&#171; anbieten 
                        kann, halte ich es trotzdem f&uuml;r sinnvoll und verantwortungsbewusster, f&uuml;r 
                        sich selbst als Berater Schwerpunkte zu setzen. Niemand kann solch ein breites 
                        Themenfeld so abdecken, dass er tats&auml;chlich zu jedem dieser zahlreichen Bereiche 
                        so viel Wissen aufbaut, um alle Klienten mit jedem Gesundheitsproblem kompetent 
                        beraten zu k&ouml;nnen. Es ist nicht nur Ihr gutes Recht als Ratsuchende(r), sondern 
                        auch mein eigener Anspruch an mich selbst, dass ich zu den Problemen, f&uuml;r die 
                        ich Ihnen meine Beratung anbiete, wirklich fundierte, in die Tiefe gehende Kenntnisse 
                        aufweisen kann. Dies geht nur durch Spezialisierung. Gerne k&ouml;nnen Sie sich 
                        auf meiner Praxis-Website <a href="http://www.ganzheitliche-gesundheitsberatung.de/index.php" target="_blank">www.Ganzheitliche-Gesundheitsberatung.de</a> 
                        &uuml;ber meine <a href="http://www.ganzheitliche-gesundheitsberatung.de/profil.php" target="_blank">Qualifikationen</a> 
                        und <a href="http://www.ganzheitliche-gesundheitsberatung.de/preise.php?" target="_blank">Angebote</a> 
                        schlau machen. Und wenn Sie mich dann gerne kennelernen m&ouml;chten, rufen Sie 
                        mich doch einfach einmal an &ndash; ich freue mich auf Sie!
                        <br />
                        <br />
                        <br />
                        <br />
                        <hr>
                        <br />
                        Liebe Leserin, lieber Leser, Sie haben es gesehen: dieser Newsletter enth&auml;lt 
                        heute ein &#187;<b>Schwerpunktthema</b>&#171;. Das soll in Zukunft immer so sein. Auf 
                        der Website www.dorispaas.de gibt es mittlerweile so viele verschiedene Themen, 
                        dass ich Sie in den Newslettern jeweils auf einen speziellen Bereich aufmerksam 
                        machen m&ouml;chte. Dies k&ouml;nnen ganz neue Themen und Seiten sein, aber auch 
                        bereits bestehende Seiten, die zu diesem jeweiligen Schwerpunkt passen und aktualisiert 
                        worden sind. So k&ouml;nnen Sie sich noch intensiver mit diesen Themen vertraut 
                        machen. Im Archiv finden Sie alle alten Newsletter und k&ouml;nnen dort bei Bedarf
                        auch all die anderen Artikel nachlesen.
                        <br />
                        <br />
                        Bis zum n&auml;chsten Newsletter, den Sie in zwei Monaten, also 
                        etwa Mitte Juli 2017 erhalten, sende ich Ihnen ganz herzliche Gr&uuml;&#223;e aus dem Rheinland 
                        <br />
                        Ihre
                        <br />
                        <img src="<?php echo IMG_PATH; ?>nl-unterschrift-dopa.png" alt="" border="0" hspace="0" vspace="0" style="float: left; margin-left: 0px; margin-right: 10px; padding-bottom: 0px;" />
                        </p>
                        <br />
                        <br />
                        <br />
                        <i>P.S. Gerne k&ouml;nnen Sie diesen Newsletter auch an Freunde und Bekannte weiterleiten!</i>
                        <p>
                        <hr>
                        <hr>
                        <a href="http://www.dorispaas.de/index.php?page=termine" target="_blank"><img src="<?php echo IMG_PATH; ?>newsletter-zettel.png" alt="" border="0" hspace="0" vspace="0" style="float: left; margin-left: 0px; margin-right: 20px; padding-bottom: 0px;" /></a>
                        <br />
                        &#149;	Beachten Sie bitte auch die Hinweise zu den <a href="http://www.dorispaas.de/index.php?page=termine" target="_blank">Terminen</a> 
                        f&uuml;r die Veranstaltungen, zu denen ich Sie herzlich einlade.  
                        <br />
                        &#149;	S&auml;mtliche neuen Beitr&auml;ge finden Sie immer unter dem Button 
                        &#187;<a href="http://www.dorispaas.de/index.php?page=news" target="_blank">neueste Betr&auml;ge</a>&#171; 
                        in der Seiten-Navigation.
                        <br />
                        &#149;	Den besten &Uuml;berblick &uuml;ber die kompletten Inhalte auf www.DorisPaas.de 
                        finden Sie in der <a href="http://www.dorispaas.de/sitemap-html" target="_blank">Sitemap</a> 
                        in der Seiten-Navigation.
                        <br />
                        &#149;	www.dorispaas.de &ndash; garantiert <a href="http://www.dorispaas.de/guterrat" target="_blank">werbefreie 
                        und unabh&auml;ngige Informationen</a>. 
                        
                        <br />
                        <br />
                        <hr>
                        <br />
                        Sie k&ouml;nnen den Erhalt des Newsletters jederzeit abbestellen.
                        Bitte klicken Sie auf <a href="http://www.dorispaas.de/index.php?page=unsubscribe_newsletter&amp;ticket=%UNSUBSCRIBE_TICKET%" target="_blank">diesen Link</a>.
                        <br />
                        Ihre Mailadresse wird im Verteiler gel&ouml;scht, und Sie erhalten keine Mails mehr.
                        </p>
                    </div>
                </div>
            </div>    
            <br>
            <br> 
            <div class="bodyspacer"></div> 
        </div>