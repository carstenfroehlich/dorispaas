        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br /> 
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>     
                <h1 class="header center orange-text">Hilfe</h1>   
            </div>  
        </div>
        <div class="container">    
            <div class="section">  
                <div class="row">        
                    <div class="col s12 m12">          
                        <h5>Etwas funktioniert nicht?</h5>
                        <br />
                        Diese Website und alle ihre Funktionen wurden sorgfältig unter verschiedenen 
                        Betriebssystemen und Browsern optimiert und getestet, so dass eigentlich alles 
                        korrekt angezeigt werden sollte. Grundsätzlich ist sie mobilfähig. 
                        Da es jedoch unzählige Hersteller für Android- und Apple-Smartphones 
                        gibt, kann eine störungsfreie Funktionalität nicht garantiert werden. 
                        Ggf. greifen Sie über einen Laptop oder Desktop-Computer auf die Website zu.
                        <br />
                        <br />
                        <b>Falls Sie Probleme haben, leeren Sie zunächst den Cache, löschen alte Cookies und starten den Browser neu &ndash; meist lösen bereits diese Maßnahmen viele Probleme.</b>
                        <br />
                        <br />
                        Bei andauernden Schwierigkeiten schauen Sie 
                        bitte, welches Betriebssystem Ihr Computer hat und welchen Browser Sie benutzen und beherzigen Sie die unten stehenden Tipps.
                        <br />
                        <br />
                        <b>&#149;</b> Beim Aufruf einer Seite?
                        <br />
                        <b>&#149;</b> Bei der Anzeige einer Seite?
                        <br />
                        <b>&#149;</b> Bei einer Bestellung?
                        <br />
                        <b>&#149;</b> Beim Einloggen in die &#187;DorisPaas.de &ndash; Lebensmittel-Datenbank?
                        <br />
                        <b>&#149;</b> Bei einem Download?
                        <br />
                        <b>&#149;</b> Oder bei einer sonstigen Aktion auf dieser Website?
                        <br />
                        <br />
                        <hr class="visual" />
                        <br />
                        
                        <a id="system">&nbsp;</a>
                        <div class="oneline">
                            <img src="<?php echo IMG_PATH; ?>betriebssystem.png" alt="Firefox" class="inline" />
                        </div>
                        <br />
                        <a style="color: red;"><h5>&#149; Betriebssysteme und Browser:</h5></a>
                        <br /> 
                        <hr />
                        <b>Betriebssystem Windows</b>: 
                        Windows XP, Windows 7 und Windows 10. 
                        <br />
                        <br />
                        <b>Browser</b>: Internet Explorer (ab Version 9), Firefox, Chrome. 
                        <br />
                        <br />
                        Hinweis für Nutzer von Windows XP: Der Zugriff auf die DorisPaas.de &ndash; Lebensmittel-Datenbank 
                        ist unter XP nicht mit dem Internet Explorer möglich, da dieses Betriebssystem den 
                        Internet Explorer nur bis Version 8 unterstützt. XP-Nutzer müssen einen anderen 
                        Browser installieren (z.B. Firefox oder Chrome).
                        <br />
                        <br />
                        <hr />
                        <b>Betriebssystem MacOS</b>: 
                        MacOS 10
                        <br />
                        <br />
                        <b>Browser</b>: Google Chrome
                        <br />
                        <hr class="visual" />
                        <b><i>Andere Betriebssytem-Versionen und/oder Browser sind möglich, jedoch nicht getestet.</i></b>
                        <hr class="visual" />
                        <br />
                        <br />
                        <div class="oneline">
                            <a href="http://www.mozilla.org/de/firefox" target="_blank">
                                <img src="<?php echo IMG_PATH; ?>firefox.png" alt="Firefox" class="inline" />
                            </a>
                            Hier können Sie den Browser &#187;Mozilla Firefox&#171; für Ihr Betriebssystem kostenlos downloaden:
                            <br />
                            <br />
                            <a href="https://www.mozilla.org/en-US/firefox/all/" target="_blank">https://www.mozilla.org/en-US/firefox/all/</a>
                            <br class="cb" />
                        </div>
                        <br />
                            <div class="oneline">
                            <a href="https://www.google.de/chrome/browser/desktop/index.html" target="_blank">
                                <img src="<?php echo IMG_PATH; ?>chrome.png" alt="Firefox" class="inline" />
                            </a>
                            Hier können Sie den Browser &#187;Google Chrome&#171; für Ihr Betriebssystem kostenlos downloaden:
                            <br />
                            <br />
                            <a href="https://www.google.de/chrome/browser/desktop/index.html" target="_blank">https://www.google.de/chrome/browser/desktop/index.html</a>
                            <br class="cb" />
                        </div>
                        <br />
                        <p class="quellen"><i>(die Abbildungen zeigen die geschützten Warenzeichen von Windows 7, Mozilla Firefox und Google Chrome)</i></p>
                        <hr class="visual" />
                        <br />
                        <div class="oneline">
                            <img src="<?php echo IMG_PATH; ?>anmeldung.png" alt="Firefox" class="inline" />
                            <br />
                            <br />
                            <a style="color: red;"><h5>&#149; Probleme bei der Anmeldung an der &#187;DorisPaas.de &ndash; Lebensmittel-Datenbank&#171;:</h5></a>
                            <br />
                            <b>&#149; Erstanmeldung</b> 
                            <br />
                            Sie haben bei der Erstanmeldung an der DorisPaas.de &ndash; Lebensmittel-Datenbank Probleme mit dem Passwort?
                            <br />
                            Bitte versuchen Sie zuerst, das Ihnen übersandte Passwort zu <b>kopieren und einzusetzen</b>.
                            Bei andauernden Schwierigkeiten können Sie mich danach gerne per Mail erreichen. 
                            Zur Ermittlung eventueller Fehlerquellen geben Sie bitte Betriebssystem, 
                            Browser und Versionen an.
                            <br />
                            <br />
                            <b>&#149; Erneute Anmeldung</b> 
                            <br />
                            Sie haben bei der erneuten Anmeldung Probleme mit dem Passwort? 
                            <br />
                            Bitte nutzen Sie die Funktion <a href="lebensmittel-datenbank-new-pw">Passwort zurücksetzen</a>.
                            Sie erhalten dann ein neues Passwort per eMail zugesandt.
                            <br />
                            <br />
                            <b>&#149; Sporadische Probleme bei der Anmeldung</b>
                            <br />
                            Wenn Sie immer wieder Probleme bei der Anmeldung haben, schauen Sie bitte, 
                            ob Ihr Browser das Setzen von Cookies zulässt. Cookies sind kleine Dateien, 
                            die auf Ihrem System platziert werden müssen, um eine erfolgreiche Anmeldung 
                            zu ermöglichen. Es werden dadurch <b>keine</b> Daten von Ihnen ausgelesen 
                            oder weiterverwendet und schon gar nicht an Dritte weitergegeben.
                            <br />
                            <br />
                            Bei wiederholten Problemen schauen Sie bitte in den Einstellungen Ihres 
                            Browsers, ob hier Cookies zugelassen werden. Im Firefox können Sie 
                            unter dem Menüpunkt &#187;Einstellungen&#171; die entsprechenden Konfigurationen 
                            vornehmen (siehe Abbildung), in anderen Browsern analog. Beachten Sie bitte, 
                            dass auch unter &#187;Ausnahmen&#171; die Website &#187;www.dorispaas.de&#171; 
                            nicht blockiert sein darf.
                            <br />
                            <br />
                            <img src="<?php echo IMG_PATH; ?>cookies-firefox.png" alt="" border="0" hspace="0" vspace="0" style="margin-left: 0px; padding-bottom: 0px;" />
                            <br class="cb" />
                        </div>
                        <br />
                        <hr class="visual" />
                        <br />
                        <div class="oneline">
                            <a href="mailto:kontakt@dorispaas.de" class="link">
                                <img src="<?php echo IMG_PATH; ?>email.png" alt="eMail" border="0" hspace="0" vspace="0" style="float: left; margin-right: 15px; padding-bottom: 0px;" /></a>
                            </a>
                            <br />
                            <br />
                            <a style="color: red;"><h5>&#149; Nachricht per eMail:</h5></a>
                            <br />
                            <br />
                            Wenn auch nach der Installation eines der oben angeführten Browser weiterhin Probleme bei der Nutzung der &#187;DorisPaas.de &ndash; Lebensmittel-Datenbank&#171;
                            bestehen, senden Sie mir bitte ein eMail an <a href="mailto:kontakt@dorispaas.de" class="link">kontakt@dorispaas.de</a>.
                            <br />
                            <br />
                            <b>Wichtig</b> sind dabei bitte folgende Angaben, damit ich Ihnen schnellstmöglich helfen kann:
                            <br />
                            &#149; Was funktioniert nicht?
                            <br />
                            &#149; Welches Betriebssystem und welche Version benutzen Sie?
                            <br />
                            &#149; Welchen Browser und welche Version benutzen Sie?
                            <br class="cb" />
                        </div>
                        <br />
                        <hr class="visual" />
                        <br />
                        <b>Bitte beachten Sie, dass ich Ihnen nur bei Problemen mit der &#187;DorisPaas.de &ndash; Lebensmittel-Datenbank&#171; weiterhelfen kann.
                        Alle kostenlosen Services werden nicht supportet.</b>
                        <br />
                        <br />
                        Herzliche Grüße aus dem Rheinland
                        <br />
                        Doris Paas
                    </div>
                </div>
            </div>    
            <br>
            <br> 
            <div class="bodyspacer"></div> 
        </div>