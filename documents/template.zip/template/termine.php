        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br /> 
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>
                <h1 class="header center orange-text">Doris Paas</h1>      
                <div class="row center">        
                    <h5 class="header col s12 light">Veranstaltungstermine</h5>      
                </div>
            </div>  
        </div> 
        <div class="container">    
            <div class="section">   
                <div class="row margintoprow">        
                    <div class="col s12 m8">
                        <ul class="nav">
                            <li>
                                <b>Termine im Überblick:</b>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>termine#swr2">Sendung im SWR2: <br /><b>Gesund dank Mikroben-Vielfalt &ndash; Die Bakterien-WG im Darm </b></a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>termine#vhs-koeln-2018-04-18">18.4.2018, Köln, Studienhaus am Neumarkt &ndash; Vortrag: <br /><b>Unklare Verdauungsbeschwerden &ndash; was könnten die Ursachen sein?</b></a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>termine#vhs-koeln-2018-09-19">19.9.2018, Köln, Studienhaus am Neumarkt &ndash; Vortrag: <br /><b>Unklare Verdauungsbeschwerden &ndash; was könnten die Ursachen sein?</b></a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>termine#shg">alle zwei Monate in Troisdorf: <br /><b>Selbsthilfegruppe für Laktose-Intoleranz</b></a>
                            </li> 
                        </ul>
                    </div>
                    <div class="col s12 m4">
                        <img src="<?php echo IMG_PATH; ?>termine.png" alt="" class="right" />
                        Wenn Sie Interesse daran haben, auf einer Ihrer Veranstaltungen einen Vortrag mit den Themen 
                        Laktose-Intoleranz&#171; oder generell &#187;Nahrungsmittel-Unverträglichkeiten&#171;, 
                        &#187;Gesunde Ernährung&#171;, &#187;Gesunde Verdauung&#171; oder &#187;Ganzheitliche Gesundheit&#171; zu buchen, 
                        freue ich mich auf Ihre <a href="mailto:kontakt@dorispaas.de" class="link">eMail-Nachricht</a>.
                    </div>       
                </div>
                <div class="row margintoprow">        
                    <div class="col s12 m12">
                        <hr />
                        <a id="swr2"></a>
                        <h4 style="margin-top: 0px;">
                            Radiosendung
                        </h4>
                        
                        <table>
                        <tr>
                        <td>
                        <table>
                            <tr>
                                <td style="vertical-align: top; padding-right: 5px;">
                                    <b>Thema:</b>
                                </td>
                                
                                <td style="vertical-align: top;">
                                    <b>Gesund dank Mikroben-Vielfalt &ndash;
                                    <br />Die Bakterien-WG im Darm </b>
                                    <br />
                                    <br />
                                </td>
                            </tr>
                                
                            <tr>
                                <td style="vertical-align: top; padding-right: 5px;">
                                    Datum:
                                </td>
                                <td style="vertical-align: top;">
                                    Mittwoch, 6.12.2017
                                </td>
                            </tr>
                            
                            <tr>
                                <td style="vertical-align: top; padding-right: 5px;">
                                    Uhrzeit:
                                </td>
                                
                                <td style="vertical-align: top;">
                                    8:30 Uhr
                                </td>
                            </tr>
                                
                            
                        </table>
                        </td>
                        
                        </tr>
                        </table>
                        
                        <div>
                        <table>
                        <tr>
                        <td>
                            <tr>
                                <td style="vertical-align: top; padding-right: 5px;">
                                    Beschreibung:
                                </td>
                                
                                <td style="vertical-align: top;">
                                    Der Wissenschaftsjournalist Hellmuth Nordwig führt Interviews <br />
                                    mit verschiedenen Spezialisten zum Thema.
                                    <br />
                                    <br />
                                </td>
                            </tr>
                        </tr>
                        </td>
                        </table>
                        <table>
                        <tr>
                        <td>
                            <tr>
                                <td style="vertical-align: top; padding-right: 5px;">
                                    Termin verpasst?
                                </td>
                                
                                <td style="vertical-align: top;">
                                    <a href="https://www.swr.de/swr2/programm/sendungen/wissen/bakterien-wg-im-darm-gesund-dank-mikroben/-/id=660374/did=20746020/nid=660374/168nquv/index.html" target="_blank">Hier können Sie sich die Aufzeichnung anhören</a>
                                    <br />
                                    <br />
                                </td>
                            </tr>
                        </tr>
                        </td>
                        </table>
                        </div>

                        
                        <br />
                        <hr />
                        <br />
                        <br />
                        <a id="vhs-koeln-2018-04-18"></a>
                        <h4 style="margin-top: 0px;">
                            VORTRAG
                        </h4>
                        
                        <table>
                        <tr>
                        <td>
                        <table>
                            <tr>
                                <td style="vertical-align: top; padding-right: 5px;">
                                    <b>Thema:</b>
                                </td>
                                
                                <td style="vertical-align: top;">
                                    <b>Unklare Verdauungsbeschwerden &ndash;  
                                    <br />was könnten die Ursachen sein?</b>
                                    <br />
                                    <br />
                                </td>
                            </tr>
                                
                            <tr>
                                <td style="vertical-align: top; padding-right: 5px;">
                                    Datum:
                                </td>
                                <td style="vertical-align: top;">
                                    Mittwoch, 18.4.2018
                                </td>
                            </tr>
                            
                            <tr>
                                <td style="vertical-align: top; padding-right: 5px;">
                                    Uhrzeit:
                                </td>
                                
                                <td style="vertical-align: top;">
                                    18:00 &ndash; 19:30 Uhr
                                </td>
                            </tr>
                            
                            <tr>
                                <td style="vertical-align: top; padding-right: 5px;">
                                    Ort:
                                </td>
                                
                                <td style="vertical-align: top;">
                                    VHS Köln, Neumarkt
                                    <br />
                                    Studienhaus, Cäcilienstraße 35
                                    <br />
                                    50667 Köln
                                    <br />
                                    Raum 0.06
                                </td>
                            </tr>
                            <tr>
                                <td style="vertical-align: top; padding-right: 5px;">
                                    Teilnehmer-
                                    <br />
                                    entgeld:
                                </td>
                                
                                <td style="vertical-align: top;">
                                    5,- Euro
                                </td>
                            </tr>
                            
                            
                        </table>
                        </td>
                        
                        </tr>
                        </table>


                        
                        <br />
                        <hr />
                        <br />
                        <br />
                        <a id="vhs-koeln-2018-09-19"></a>
                        <h4 style="margin-top: 0px;">
                            VORTRAG
                        </h4>
                        
                        <table>
                        <tr>
                        <td>
                        <table>
                            <tr>
                                <td style="vertical-align: top; padding-right: 5px;">
                                    <b>Thema:</b>
                                </td>
                                
                                <td style="vertical-align: top;">
                                    <b>Unklare Verdauungsbeschwerden &ndash;  
                                    <br />was könnten die Ursachen sein?</b>
                                    <br />
                                    <br />
                                </td>
                            </tr>
                                
                            <tr>
                                <td style="vertical-align: top; padding-right: 5px;">
                                    Datum:
                                </td>
                                <td style="vertical-align: top;">
                                    Mittwoch, 19.9.2018
                                </td>
                            </tr>
                            
                            <tr>
                                <td style="vertical-align: top; padding-right: 5px;">
                                    Uhrzeit:
                                </td>
                                
                                <td style="vertical-align: top;">
                                    18:00 &ndash; 19:30 Uhr
                                </td>
                            </tr>
                            
                            <tr>
                                <td style="vertical-align: top; padding-right: 5px;">
                                    Ort:
                                </td>
                                
                                <td style="vertical-align: top;">
                                    VHS Köln, Neumarkt
                                    <br />
                                    Studienhaus, Cäcilienstraße 35
                                    <br />
                                    50667 Köln
                                    <br />
                                    Raum 0.06
                                </td>
                            </tr>
                            <tr>
                                <td style="vertical-align: top; padding-right: 5px;">
                                    Teilnehmer-
                                    <br />
                                    entgeld:
                                </td>
                                
                                <td style="vertical-align: top;">
                                    5,- Euro
                                </td>
                            </tr>
                            
                            
                        </table>
                        </td>
                        
                        </tr>
                        </table>
                       
                        
                        <br />
                        <hr />
                        <br />
                        <br />
                        <a id="shg"></a>
                        <h5>Selbsthilfegruppe für Laktose-Intoleranz</h5>
                        <table>
                            <tr>
                                <td style="vertical-align: top; padding-right: 5px;">
                                    Beschreibung:
                                </td>
                                
                                <td style="vertical-align: top;">
                                    Viele Menschen haben Verdauungsbeschwerden &ndash; angefangen von 
                                    Bauchgrummeln und Blähungen, über Verstopfung und Durchfall bis hin 
                                    zu Schmerzen und Krämpfen. Was könnte dahinter stecken? Es gibt 
                                    Magen-Darminfektionen mit Bakterien oder auch Parasiten, 
                                    Nahrungsmittel-Unverträglichkeiten oder -Allergien, bakterielle 
                                    Fehlbesiedelungen des Dünn- und Dickdarms und &ndash; glücklicherweise 
                                    selten &ndash; schlimmere Erkrankungen. Bereits anhand der Symptome 
                                    und vor allem mit einem Ernährungs- und Symptomtagebuch kann man oft 
                                    selbst schon ein wenig eingrenzen, wo der Hase im Pfeffer liegen könnte.
                                    <br />
                                    Selbstverständlich ist bei andauernden Beschwerden ein Arztbesuch 
                                    unerlässlich, aber es kann sehr hilfreich sein, sich selbst über mögliche 
                                    Ursachen zu informieren.
                                    <br />
                                    Die Ernährungs- und Gesundheitspädagogin Doris Paas, die sich auf genau 
                                    diese Bereiche spezialisiert hat, gibt einen Überblick über die 
                                    verschiedenen Erkrankungen, deren typische Symptome und informiert 
                                    über diagnostische Maßnahmen, aber auch Möglichkeiten, mit geeigneten 
                                    Methoden die Beschwerden zu lindern. 
                                    <br />
                                    <br />
                                </td>
                            </tr>
                            <tr>
                                <td style="vertical-align: top; padding-right: 5px;">
                                    Informationen
                                    <br />
                                    und Anmeldung:
                                </td>
                                
                                <td style="vertical-align: top;">
                                    <br />
                                    bei der VHS Köln 
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>    
            <br>
            <br> 
            <div class="bodyspacer"></div> 
        </div>