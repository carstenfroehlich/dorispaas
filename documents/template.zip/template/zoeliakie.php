        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br /> 
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>
                <h1 class="header center orange-text">Zöliakie</h1> 
                    <div class="row center">        
                    <h5 class="header col s12 light">&ndash; was ist das?</h5>      
                    </div>     
            </div>  
        </div> 
        <div class="container">    
            <div class="section">   
                <div class="row margintoprow">        
                    <div class="col s12 m12">
                        <hr>
                        <b>Zum besseren Verständnis sollten Sie zuvor folgenden Beitrag gelesen haben:</b> 
                        <a href="gluten" target="_blank">Zöliakie und Gluten-Sensitivität</a>
                        <hr>
                        <b>Sehen Sie auch das Video zum Thema</b>
                        <br />
                        <br />
                        <a href="videos#zoeliakie" target="_blank"><img src="<?php echo IMG_PATH; ?>videobutton.png" alt="Videos" class="left" />
                        <br />Zöliakie &ndash; was ist das?</a>
                        <br />
                        <br />
                        <br />
                        <br />
                        <hr />
                        <br />
                        Die Zöliakie ist eine Form von <a href="glutensensitivitaet" target="_blank">Gluten-Unverträglichkeit</a>, 
                        bei der zusätzlich und vor allem zu der Intoleranz von Gluten noch eine autoimmune 
                        Reaktionen des Körpers hinzukommt. Neben den für jede Nahrungsmittel-Unverträglichkeit 
                        typischen Verdauungsbeschwerden wie Bauchschmerzen, Blähungen, Durchfällen und/oder Verstopfung, 
                        treten hier autoimmune (selbstzerstörerische)  
                        Reaktionen auf, d.h. das Immunsystem erkennt unter der Einwirkung von Gluten die 
                        Dünndarmschleimhaut als Fremdkörper und bekämpft und zerstört deren Zellen. 
                        <br />
                        <br />
                        <img src="<?php echo IMG_PATH; ?>zoeliakie-darmschleimhaut.png" alt="" class="left" /></a>
                        <br />
                        <br />
                        Wie in der Abbildung schematisch dargestellt, ist die Darmschleimhaut des Dünndarms
                        in die Schleimhautzotten (1) aufgefaltet, und diese Zotten weiter in die so genannten 
                        Mikrovilli (2), um eine größtmögliche Fläche zur Aufnahme der Nährstoffe zu errreichen.
                        Wenn bei einer Zöliakie-Erkrankung weiterhin Gluten aufgenommen wird, flachen zuerst 
                        die Mikrovilli ab (3), und später sind sowohl die Mikrovilli (4) als auch die 
                        Schleimhautzotten je nach Ausprägung der Erkrankung so gut wie gänzlich zerstört (5).
                        <br />
                        <br />
                        Ist die Schleimhaut dermaßen geschädigt, treten 
                        logischerweise Defizite bei der Ernährung auf, der Patient nimmt meist stark an 
                        Gewicht ab, und auch die Versorgung mit Vitaminen und Mineralstoffen ist mangelhaft. 
                        Hieraus resultieren diverse Symptome und teilweise auch schwere Folgeerkrankungen.
                        <br />
                        <br />
                        Da zum einen Gluten in so gut wie allen Nahrungsmittelgruppen enthalten 
                        sein kann und zum anderen die auftretenden Symptome neben den Verdauungsproblemen
                        sehr diffus sein können, ist der Zusammenhang von Beschwerden mit einem bestimmten Verursacher 
                        oftmals schwer herzustellen. Meistens haben die Betroffenen einen recht langen 
                        Leidensweg hinter sich, bevor die Diagnose &#187;Zöliakie&#171; gestellt wird. 
                        Durchschnittlich wird eine Zöliakie erst nach mehr als 10 Jahren diagnostiziert 
                        &ndash; teilweise können auch wesentlich längere Zeiträume erinnert werden.
                        <br />
                        <br />
                        Im Zuge einer unbehandelten Zöliakie treten sehr häufig auch andere 
                        Unverträglichkeiten wie Laktose- und/oder Fruktose- und Sorbit-Intoleranzen 
                        auf, weil die geschädigten Darmschleimhautzellen die für die Verdauung 
                        dieser Kohlenhydrate erforderlichen Enzyme oder Transportproteine nicht mehr oder 
                        nicht mehr ausreichend herstellen können. Hier liegt dann jeweils die 
                        sekundäre Erkrankungsform vor, die jedoch häufig reversibel ist, sobald 
                        sich die Darmschleimhautzellen regeneriert haben.
                        <br />
                        <br />
                        Zöliakie-Patienten leiden häufig auch an anderen Autoimmunerkrankungen. Hier sind u.a. 
                        die Hashimoto-Thyreoiditis oder Morbus Basedow (entzündliche Autoimmunerkrankungen Schilddrüse), 
                        Rheuma, Diabetes oder die Hauterkrankung Morbus herpetiformis duhring zu nennen. 
                        Aus diesem Grund ist es immer vorteilhaft, sich bei einer Zöliakie-Erkrankung 
                        beigleitend gründlich untersuchen zu lassen.
                        <br />
                        <br />
                        Fachausdrücke für Zöliakie  sind auch &#187;Glutensensitive 
                        Enteropathie&#171; oder &#187;Einheimische Sprue&#171;, wobei der Ausdruck &#187;Sprue&#171; 
                        (sprich Spruh) früher nur für Erwachsene benutzt wurde. Heute wird jedoch 
                        die Bezeichnung Zöliakie sowohl für Kinder als auch für erwachsene 
                        Erkrankte einheitlich benutzt. Neben dem Auslöser Gluten ist die Ursache der 
                        Erkrankung genetisch bedingt und kann bis heute noch nicht ursächlich behandelt, d.h. 
                        geheilt werden. Die einzig wirksame Behandlung der Zöliakie besteht in der konsequenten 
                        Meidung von jeglichem Glutenverzehr. 
                        <br />
                        <br />
                        Die Anzahl der Betroffenen kann nur sehr schwer benannt 
                        werden, denn es gibt aufgrund der verzögerten Diagnosestellung und dem oftmals 
                        besonders bei Erwachsenen schleichenden Beginn der Erkrankung eine sehr 
                        große Dunkelziffer &ndash; geschätzt wird, dass in Europa etwa einer 
                        von 100-500 Bürgern von Zöliakie betroffen ist.
                        <br />
                        <br />
                        <hr>
                        <a id="beratung">&nbsp;</a>
                        <div class="row">
                        <div class="col s12 m2">
                            <a href="http://www.ganzheitliche-gesundheitsberatung.de" target="_blank">
                                <img src="<?php echo IMG_PATH; ?>praxiswebsite.png" alt="" class="inline" /></a>
                        </div>
                        </div>
                        <div class="row">
                        <div class="col s12 m12">
                        <h5>Beratung</h5>
                        <br />
                            Gerne biete ich Ihnen eine individuelle Beratung an &ndash; 
                            auf Wunsch auch telefonisch oder per Skype.
                            <br />
                            Bitte informieren Sie sich auf meiner Praxis-Website <a href="http://www.ganzheitliche-gesundheitsberatung.de" target="_blank">&#187;www.Ganzheitliche-Gesundheitsberatung.de&#171;</a>
                        </div>
                        </div>
                        <hr>
                        <br />
                        <a href="guterrat" target="_blank"><img src="<?php echo IMG_PATH; ?>hilfreich.png" alt="" class="left" /></a>
                        <br />
                        <br />
                        <hr>
                        <b>Bitte lesen Sie weiterhin folgende Beiträge:</b>
                        <br />
                        <a href="zoeliakie-diagnose">Diagnose der Zöliakie</a>
                        <br />
                        <a href="glutensensitivitaet">Gluten-Sensitivität &ndash; was ist das?</a>
                        <br />
                        <a href="glutensensitivitaet-diagnose">Diagnose der Gluten-Sensitivität</a>
                        <br />
                        <a href="zoeliakie-behandlung">Behandlung der Zöliakie und der Gluten-Sensitivität</a>
                        <br />
                        <a href="weizenallergie" target="_blank">Weizenallergie</a>
                        <br />
                        <hr />
                        <b>Empfehlenswerte Literatur:</b>  
                        <br />                      
                        <br />
                    <div class="col s12 m12">
                        <a href="paas-heftchen-gluten" target="_blank"><img src="<?php echo IMG_PATH; ?>buchzumthema-gluten.png" alt="" class="left" /></a>
                        <a href="paas-heftchen-kinderzoeliakie" target="_blank"><img src="<?php echo IMG_PATH; ?>buchzumthema-kinderzoeli.png" alt="" class="left" /></a>
                    </div>
                    <div class="col s12 m12">
                    <br />
                    <hr />
                        <div class="oneline">
                            <div class="left">

                                <a href="lebensmittel-datenbank-info">
                                    <img src="<?php echo IMG_PATH; ?>lebensmitteldatenbank.png" alt="home video small" class="inline" />
                                </a>
                            </div>
                            <p class="left">
                                <b>Empfehlung:</b>
                                <br />
                                Eine zusätzliche Hilfe bei der Ermittlung geeigneter Lebensmittel stellt die
                                <br />
                                &#187;<b>DorisPaas.de &ndash; Lebensmittel-Datenbank</b>&#171; dar. 
                                Informieren Sie sich <a href="lebensmittel-datenbank-info" target="_blank">hier</a>.
                            </p>
                        </div>
                        </div> 
                        <br style="clear: left;" />
                            <hr />
                        <br />
                        <a href="javascript: scrollMainToTop();" class="nachoben">nach oben</a>
                    </div>
                </div>
            </div>    
            <br>
            <br> 
            <div class="bodyspacer"></div> 
        </div>