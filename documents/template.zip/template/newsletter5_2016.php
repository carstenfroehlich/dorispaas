        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br /> 
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>
                <h1 class="header center orange-text">DorisPaas-Newsletter</h1>      
            </div>  
        </div> 
        <div class="container">    
            <div class="section">   
                <div class="row margintoprow">        
                    <div class="col s12 m12">
                        <img src="<?php echo IMG_PATH; ?>dorispaas-de-titelfoto-newsletter-w.png" alt="" border="0" hspace="0" vspace="0" style="float: left; margin-left: 0px; margin-right: 20px; padding-bottom: 0px;" /></a><br />
                        <br />
                        <br />
                        <br />
                        <br />
                        <br />
                        <br />
                        <br />
                        <br />
                        <b>Ausgabe 30 (September 2016)</b>
                        <br />
                        <br />
                        
                        _____________________________________________________________________________________________
                        <br />
                        <br />
                        <br />
                        
                        <a href="http://www.dorispaas.de/" target="_blank"><img src="<?php echo IMG_PATH; ?>nl-2016-04-titel.png" alt="" border="0" hspace="0" vspace="0" style="float: left; margin-left: 0px; margin-right: 20px; padding-bottom: 10px;" /></a>
                        Liebe Leserin, lieber Leser.
                        <br />
                        Ein wider Erwarten sehr sch&ouml;ner Sommer neigt sich dem Ende zu und ich hoffe, 
                        Sie konnten diese Zeit genie&#223;en, Kraft tanken und sich und Ihrer Gesundheit 
                        Gutes tun. Nun kommt bald der Herbst &ndash; und damit beginnt die K&uuml;rbiszeit.
                        K&uuml;rbisse sind bei jeder Nahrungsmittel-Unvertr&auml;glichkeit bek&ouml;mmlich, 
                        und sie haben einen sehr geringen FODMAP-Gehalt. Damit eignen sie sich f&uuml;r 
                        zahlreiche leckere Gerichte, vor allem Eint&ouml;pfe und Suppen. Aber auch 
                        s&uuml;&#223;-sauer eingelegt stellen Sie eine absolute K&ouml;stlichkeit dar.
                        Ihrem Einfallsreichtum sind mit diesem Gem&uuml;se keine Grenzen gesetzt. 
                        Besonders gut harmoniert der K&uuml;rbis mit Kartoffeln und M&ouml;hren, aber auch 
                        Maronen k&ouml;nnen K&uuml;rbisgerichte hervorragend erg&auml;nzen. &Uuml;brigens: 
                        Der Hokkaido-K&uuml;rbis l&auml;sst sich besonders leicht verarbeiten, weil Sie 
                        ihn nicht sch&auml;len m&uuml;ssen. Einfach die Kerne entfernen, mit dem Messer 
                        kleinschneiden und ab in den Topf.
                        Probieren Sie verschiedene Rezepte und lassen Sie es sich &ndash; auch (oder gerade) wenn es 
                        drau&#223;en regnet oder st&uuml;rmt &ndash; gut schmecken.
                        <br />
                        <br />
                        <br />
                        <hr>
                        <br />
                        <a href="http://www.dorispaas.de/index.php?page=reiseberichte#irland" target="_blank"><img src="<?php echo IMG_PATH; ?>nl-2016-05-reisebericht.png" alt="" border="0" hspace="0" vspace="0" style="float: left; margin-left: 0px; margin-right: 20px; padding-bottom: 10px;" /></a>
                        <b>&#149;	<a href="http://www.dorispaas.de/index.php?page=reiseberichte#irland" target="_blank">Irland &ndash; ein Reisebericht</a></b>
                        <br />
                        Eine Woche bei sch&ouml;nstem Wetter durch Irland! Das muss doch geflunktert sein, 
                        denken jetzt bestimmt die eingefleischten Irland-Kenner. Aber es ist wahr: Mit 
                        dem Wetter hatten wir wirklich unheimliches Gl&uuml;ck, wobei das &#187;sch&ouml;nste&#171; 
                        Wetter durchaus nicht immer nur strahlender Sonnenschein war, sondern teilweise 
                        auch mal ein kurzer, warmer, weicher Nieselregen oder wabernder Nebel, der 
                        die Bergspitzen geheimnisvoll verh&uuml;llte, um nach kurzer Zeit den Blick wieder 
                        freizugeben. So konnten wir auf unserer einw&ouml;chigen Tour durch den S&uuml;den 
                        der Irischen Republik nachvollziehen, wie die zahlreichen Legenden um die vielen 
                        guten und b&ouml;sen Feen und Geister entstanden sind. Auch, wenn die Gr&uuml;ne 
                        Insel in Bezug auf die Landschaften, die Flora und Fauna ein absoluter Traum ist, 
                        scheint die Ern&auml;hrung (auch bei bei Nahrungsmittel-Unvertr&auml;glichkeiten) nicht so 
                        ganz einfach, und die typisch-irische Landesk&uuml;che war zumindest f&uuml;r mich 
                        gew&ouml;hnungsbed&uuml;rftig. Das Fr&uuml;hst&uuml;ck beispielsweise ist &ndash; 
                        &auml;hnlich wie in England und Schottland &ndash; sehr deftig-kr&auml;ftige Kost 
                        und der Begriff &#187;laktosefrei&#171; scheint dort im Gegensatz zu Gluten eher 
                        unbekannt zu sein.
                        <br />
                        <br />
                        <br />
                        <hr>
                        <br />
                        <a href="http://www.dorispaas.de/index.php?page=blog-2016-09-03" target="_blank"><img src="<?php echo IMG_PATH; ?>nl-2016-05-mdh.png" alt="" border="0" hspace="0" vspace="0" style="float: left; margin-left: 0px; margin-right: 20px; padding-bottom: 0px;" /></a>
                        <b>&#149;	<a href="http://www.dorispaas.de/index.php?page=blog-2016-09-03" target="_blank">Zukunftsmusik? Intelligente Verpackungs-Etiketten</a></b>
                        <br />
                        Jeder kennt das: Im Supermarktregal schauen wir, das frischeste Produkt auszuw&auml;hlen.
                        Wir erwarten &ndash; und das im Allgemeinen nicht zu Unrecht &ndash; dass wir 
                        dann ein m&ouml;glichst lange haltbares Lebensmittel mit nach Hause nehmen, das wir ggf. 
                        noch einige Zeit im K&uuml;hlschrank lagern k&ouml;nnen. 
                        Noch viel mehr sind Menschen mit einer Histamin-Intoleranz grunds&auml;tzlich auf 
                        gr&ouml;&#223;tm&ouml;gliche Frische angewiesen, denn je 
                        l&auml;nger ein Lebensmittel gelagert hat und je h&ouml;her die Temperatur in 
                        dieser Zeit, desto h&ouml;her ist grunds&auml;tzlich der Histamin-Gehalt selbst 
                        bei eigentlich unproblematischen Lebensmitteln. 
                        Die sogenannten &#187;intelligenten Etiketten&#171; k&ouml;nnen helfen, den Frischegrad 
                        zuverl&auml;ssig zu erkennen.
                        <br />
                        <br />
                        <br />
                        <hr>
                        <br />
                        <a href="http://www.dorispaas.de/index.php?page=siboschulung" target="_blank"><img src="<?php echo IMG_PATH; ?>nl-2016-05-arztschulung.png" alt="" border="0" hspace="0" vspace="0" style="float: left; margin-left: 0px; margin-right: 20px; padding-bottom: 20px;" /></a>
                        <b>&#149;	<a href="http://www.dorispaas.de/index.php?page=siboschulung" target="_blank">Schulungen zum Thema &#187;D&uuml;nndarmfehlbesiedelung&#171; f&uuml;r &Auml;rzte und &Auml;rztinnen, Heilpraktiker/innen und Ern&auml;hrungs- und Gesundheitsberater/innen</a></b>
                        <br />
                        Noch vor etwa 10 &ndash; 15 Jahren war die Laktose-Intoleranz auch unter den 
                        Schulmedizinern ein wenig bekanntes Thema, und die Betroffenen durchliefen oft 
                        eine Odyssee, bis der Grund f&uuml;r Ihre Beschwerden endlich erkannt wurde. 
                        Das hat sich im Laufe der Zeit gl&uuml;cklicherweise ge&auml;ndert. Das Wissen um weitere 
                        Nahrungsmittel-Unvertr&auml;glichkeiten, aber auch die Z&ouml;liakie konnte sich danach schon 
                        schneller etablieren. Somit bekommen Betroffene heute in diesen F&auml;llen sehr viel 
                        schneller eine qualifizierte Diagnose. 
                        Das Wissen &uuml;ber die bakterielle Fehlbesiedelung des D&uuml;nndarms ist jedoch noch 
                        nicht sehr verbreitet bzw. noch nicht ausreichend vertieft, und eine Weiterbildung 
                        aller Fachkr&auml;fte in diagnostischen, behandelnden und beratenden Berufen w&uuml;rde 
                        allen Beteiligten helfen: Patienten w&uuml;rden unn&ouml;tige Untersuchungen erspart, Kassen&auml;rzte 
                        k&ouml;nnten sogar ihr Budget schonen und &ndash; vor allem &ndash; k&ouml;nnte eine verl&auml;sslichere 
                        Diagnose und damit auch eine wirksamere Behandlung den Patienten einen langen Leidensweg ersparen.
                        Machen Sie Ihren Arzt, Heilpraktiker und/oder Ern&auml;hrungs- und Gesundheitsberater 
                        doch auf die M&ouml;glichkeit einer speziellen Schulung aufmerksam &ndash; letztendlich wird das auch Ihnen zugute kommen.
                        <br />
                        <br />
                        <br />
                        <hr>
                        <br />
                        Liebe Leserin, lieber Leser, wussten Sie, dass gesch&auml;tzte 80&#37; der von 
                        Reizdarmbeschwerden Betroffenen eigentlich an einer D&uuml;nndarmfehlbesiedelung 
                        leiden, und sind Sie beim letzten Absatz auf dieses Thema  
                        neugierig geworden? Auf meiner Website finden Sie eine Reihe von Beitr&auml;gen 
                        zu dieser Problematik. Wenn Sie sich in den dort beschriebenen Symptomen wiedererkennen,
                        empfehle ich Ihnen das im April neu erschienene Buch 
                        &#187;<a href="http://www.dorispaas.de/index.php?page=book-ddfb" target=_blank">D&uuml;nndarmfehlbesiedelung 
                        &ndash; erkennen, verstehen, erfolgreich behandeln</a>&#171;. Es ist eine durchaus 
                        interessante Lekt&uuml;re f&uuml;r gem&uuml;tliche Herbstabende.
                        <br />
                        <br />
                        Bis zum n&auml;chsten Newsletter, den Sie in zwei Monaten, also 
                        etwa Mitte November 2016 erhalten, sende ich Ihnen ganz herzliche Gr&uuml;&#223;e aus dem Rheinland 
                        <br />
                        Ihre
                        <br />
                        <img src="<?php echo IMG_PATH; ?>nl-unterschrift-dopa.png" alt="" border="0" hspace="0" vspace="0" style="float: left; margin-left: 0px; margin-right: 10px; padding-bottom: 0px;" />
                        </p>
                        <br />
                        <br />
                        <br />
                        <i>P.S. Gerne k&ouml;nnen Sie diesen Newsletter auch an Freunde und Bekannte weiterleiten!</i>
                        <p>
                        <hr>
                        <hr>
                        <a href="http://www.dorispaas.de/index.php?page=termine" target="_blank"><img src="<?php echo IMG_PATH; ?>newsletter-zettel.png" alt="" border="0" hspace="0" vspace="0" style="float: left; margin-left: 0px; margin-right: 20px; padding-bottom: 0px;" /></a>
                        <br />
                        &#149;	Beachten Sie bitte auch die Hinweise zu den <a href="http://www.dorispaas.de/index.php?page=termine" target="_blank">Terminen</a> 
                        f&uuml;r die Veranstaltungen, zu denen ich Sie herzlich einlade.  
                        <br />
                        &#149;	S&auml;mtliche neuen Beitr&auml;ge finden Sie immer unter dem Button 
                        &#187;<a href="http://www.dorispaas.de/index.php?page=news" target="_blank">neueste Betr&auml;ge</a>&#171; 
                        in der Seiten-Navigation.
                        <br />
                        &#149;	Den besten &Uuml;berblick &uuml;ber die kompletten Inhalte auf www.DorisPaas.de 
                        finden Sie in der <a href="http://www.dorispaas.de/sitemap-html" target="_blank">Sitemap</a> 
                        in der Seiten-Navigation.
                        <br />
                        &#149;	www.dorispaas.de &ndash; garantiert <a href="http://www.dorispaas.de/guterrat" target="_blank">werbefreie 
                        und unabh&auml;ngige Informationen</a>. 
                        
                        <br />
                        <br />
                        <hr>
                        <br />
                        Sie k&ouml;nnen den Erhalt des Newsletters jederzeit abbestellen.
                        Bitte klicken Sie auf <a href="http://www.dorispaas.de/index.php?page=unsubscribe_newsletter&amp;ticket=%UNSUBSCRIBE_TICKET%" target="_blank">diesen Link</a>.
                        <br />
                        Ihre Mailadresse wird im Verteiler gel&ouml;scht, und Sie erhalten keine Mails mehr.
                        </p>
                    </div>
                </div>
            </div>    
            <br>
            <br> 
            <div class="bodyspacer"></div> 
        </div>