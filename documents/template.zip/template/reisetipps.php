        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br /> 
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>
                <h1 class="header center orange-text">Reisen</h1>      
                    <div class="row center">        
                    <h5 class="header col s12 light">und der Umgang mit Nahrungsmittel-Unverträglichkeiten</h5>      
                    </div>     
            </div>  
        </div> 
        <div class="container">    
            <div class="section">   
                <div class="row margintoprow">        
                    <div class="col s12 m4">
                        <ul class="nav">
                            <li>
                                <b>Abschnitte dieser Seite:</b>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>reisetipps#urlaubsgestaltung">Urlaubsgestaltung</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>reisetipps#vorbereitung">Vorbereitung von An- und Abreise</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>reisetipps#zeitplanung">Zeitplanung für den Stuhlgang</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>reisetipps#genussmittel">Genussmittel im Urlaub</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>reisetipps#reiseapotheke">Reiseapotheke</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>reisetipps#beratung">Beratung</a>
                            </li> 
                        </ul>
                    </div>
                    <div class="col s12 m8">
                        <img src="<?php echo IMG_PATH; ?>reiseauto-neu.png" alt="" class="right" />
                    </div>
                </div>
                <div class="row margintoprow">        
                    <div class="col s12 m12">
                        Zu Hause haben Sie Ihre Nahrungsmittel-Unverträglichkeiten im Griff &ndash; Sie wissen, 
                        welche Lebensmittel Sie vertragen und welche Sie besser meiden sollten. Sie haben 
                        Ihre Einkaufsquellen, wo Sie die Produkte bekommen, die Ihnen gut bekommen.
                        Auch wenn Sie zur Arbeit gehen, haben Sie einen Weg gefunden, sich mit verträglichen 
                        Speisen zu versorgen, und selbst der eine oder andere Restaurantbesuch bereitet 
                        Ihnen keine Probleme. So weit so gut!
                        <br />
                        <br />
                        Was aber, wenn Sie verreisen wollen? Für viele Menschen beginnen hier die Probleme.
                        Habe ich hier die Möglichkeit, mich so zu ernähren, dass ich keine Verdauungsprobleme 
                        bekomme und mir einen Teil der wertvollen Urlaubstage verderbe?
                        <br />
                        <a id="urlaubsgestaltung"></a>
                        <hr />
                        <h5>Urlaubsgestaltung</h5>
                        <hr />
                        Es gibt verschiedene Arten der Urlaubsgestaltung: Am einfachsten ist es, wenn Sie 
                        in Länder verreisen, in denen Sie die Sprache beherrschen und sich auch weitestgehend 
                        selbst versorgen können &ndash; beispielsweise in einem Ferienhaus oder einer
                        Ferienwohnung mit Kochgelegenheit. Verschiedene Lebensmittel können Sie mitbringen, 
                        oder Sie schauen im Internet, ob Erfahrungen von anderen Betroffenen vorliegen, 
                        welche Möglichkeiten zum Einkauf geeigneter Lebensmittel es in der Gegend gibt.
                        Lesen Sie hierzu auch den Beitrag &#187;<a href="reiseberichte" target="_blank">Reiseberichte</a>&#171;.
                        <br />
                        <br />
                        Ebenfalls relativ einfach ist ein Urlaub in einem Hotel &ndash; hier kann man im 
                        Vorfeld Kontakt aufnehmen und anfragen, ob und wie weit man dort auf Ihre 
                        Bedürfnisse eingerichtet ist oder sich einrichten kann.
                        <br />
                        <br />
                        Auch ein Urlaub mit einer all-inclusive-Versorgung ist meist unproblematisch, weil 
                        hier die Verköstigung in der Regel in Büffetform angeboten wird. Als erfahrener 
                        Betroffener haben Sie sicherlich einen Blick dafür, welche Speisen &#187;unverdächtig&#171; 
                        sind und welche Sie besser meiden sollten. Bei Schwierigkeiten steht aber auch 
                        hier so gut wie immer Personal zur Verfügung, und man kann im Zweifelsfalle nachfragen.
                        <br />
                        <hr />
                        <h5>Hinweis:</h5>
                        <hr />
                        Auch wenn es zumindest in Deutschland seit 2014 vorgeschrieben ist, auch bei offenen, 
                        sprich unverpackten Lebensmitteln die Allergene inkl. Laktose zu deklarieren, ist 
                        dies in anderen Ländern und erst recht nicht in Urlaubshochburgen an der Tagesordnung.
                        Im Zweifelsfalle sollten Sie lieber auf die eine oder andere Speise verzichten, 
                        die Auswahl ist jedoch nach meinen Erfahrungen immer so gigantisch, dass man auch 
                        so keinen Mangel leiden müsste.
                        <br />
                        <br />
                        Ein wenig komplizierter wird es, wenn man einen Urlaub mit Rundumverpflegung gebucht 
                        hat &ndash; beispielsweise auf einer Kreuzfahrt &ndash; und keine Ausweichmöglichkeiten 
                        hat. Aber auch hier kann man sich mit den Köchen und Küchenchefs gleich am Anfang 
                        der Reise kurzschließen und besprechen, welche Regeln eingehalten werden müssen.
                        Je freundlicher Sie diesen Menschen begegnen, desto mehr Ehrgeiz legen sie an den 
                        Tag, um auch Ihnen die Mahlzeiten so bekömmlich und auch so lecker wie möglich 
                        zuzubereiten. Und zum Abschluss der Reise freuen sie sich dann ganz besonders 
                        über ein verdientes Trinkgeld. 
                        <br />
                        <br />
                        Auf meiner Grönland-Kreuzfahrt im Jahr 2011 hatte man die Möglichkeit, am ersten Reistag an einem 
                        &#187;Allergie-Treffen&#171; teilzunehmen, an dem alle Betroffenen ihre Wünsche 
                        äußerten, die dann in den Folgetagen grundsätzlich bei den Mahlzeiten berücksichtigt 
                        wurden. Ich fand, das war ein toller Service.
                        <br />
                        <br />
                        Auf jeden Fall ist es immer gut, wenn Sie bereits im Vorfeld bei der Buchung Ihrer Reise
                        nachfragen, ob man auf besondere Wünsche eingehen kann. Besonders wichtig ist 
                        dies natürlich bei Allergien und/oder einer Zölikakie, bei der auch gelegentliche 
                        &#187;Sünden&#171; absolut tabu sind.
                        <br />
                        <a id="vorbereitung">&nbsp;</a>
                        <hr />
                        <h5>Vorbereitung von An- und Abreise</h5>
                        <hr />
                        Auch die An- und Abreise müssen Sie gut vorbereiten: Denken Sie bereits bei der 
                        Buchung von Langstreckenflügen daran, geeignete Verpflegung mitzubuchen. Erst am 
                        Flughafen Bescheid zu sagen, reicht nicht, denn die Speisen werden von langer Hand 
                        von den Catering-Unternehmen zusammengestellt und sind bereits Stunden vor Ihrem 
                        Einchecken vorbereitet. Trotzdem kann natürlich immer etwas schief gehen. Denken
                        Sie deshalb daran, am besten ein paar verträgliche Snacks mitzuführen. Vergessen 
                        Sie dabei aber nicht die Sicherheitsvorschriften, damit Sie nicht 
                        etwa Ihre mitgebrachten Lebensmittel wegwerfen müssen, bevor Sie in den Flieger 
                        einsteigen dürfen.
                        <br />
                        <a id="zeitplanung">&nbsp;</a>
                        <hr />
                        <h5>Zeitplanung für den Stuhlgang</h5>
                        <hr />
                        Ein weiterer Punkt zum Gelingen Ihrer Reise ist die Zeitplanung für Ihren Stuhlgang: 
                        Fast jeder, der von Nahrungsmittel-Unverträglichkeiten
                        oder -Allergien betroffen ist, hat &#187;einen empfindlichen Darm&#171; oder 
                        sogar ein Reizdarm-Syndrom. Dies geht meistens damit einher, dass man dazu neigt, 
                        sich immer darüber Gedanken zu machen, ob eine Toilette erreichbar ist. 
                        <br />
                        <br />
                        Bei längeren Tagestouren in einer Reisegruppe werden zwar in mehr oder weniger 
                        regelmäßigen Abständen &#187;Pinkelpausen&#171; eingelegt, deren Abstand einem Betroffenen 
                        aber schon mal den Schweiß auf die Stirn treiben können.
                        <br />
                        <br />
                        Hilfreich ist es hier, sich am Morgen möglichst viel Zeit zu lassen. Stehen Sie 
                        ggf. eine Stunde früher auf nehmen Sie Ihr Frühstück in Ruhe ein. Wenn Sie danach 
                        noch ein wenig Zeit bis zum allgemeinen Aufbruch haben oder sogar eine Runde 
                        spazieren gehen, bewirkt der sogenannte &#187;gastrokolische Reflex&#171;, dass 
                        sich Ihr Darm bereits vor dem Ausflug entleert, und Sie der Stuhlgang nicht unterwegs drängt
                        (siehe auch <a href="http://dorispaas.de/faq#frage87" target="_blank">FAQ</a> und 
                        <a href="http://dorispaas.de/verdauung" target="_blank">Gesunde Verdauung</a>).
                        <br />
                        <a id="genussmittel">&nbsp;</a>
                        <hr />
                        <h5>Genussmittel im Urlaub</h5>
                        <hr />
                        Im Urlaub wollen Sie es sich so richtig gut gehen lassen &ndash; und dazu gehören 
                        für die meisten auch Genussmittel. Tagsüber ist besonders in den warmen Ländern 
                        der Besuch der Eisdiele obligatorisch, am Straßenrand locken diverse Verkäufer mit Süßigkeiten 
                        und abends lässt man sich vielleicht gerne ein Glas Wein oder Bier schmecken 
                        &ndash; jeder hat so seine ganz persönlichen Vorlieben. Das ist völlig in Ordnung. 
                        Aber denken Sie bitte daran, dass alle Genussmittel auch einen Einfluss auf die 
                        Verdauung haben &ndash; leider meist negative. Manche Genussmittel führen zu 
                        weicherem, dünneren Stuhl, andere stopfen. Informieren Sie sich über diese Wirkungen. 
                        Es ist klug, möglichst nicht über die Stränge zu schlagen, um sich den Urlaub 
                        nicht durch unerwünschte Verdauungsstörungen zu verderben. Lesen Sie hierzu auch 
                        den Beitrag &#187;<a href="ganz-genussmittel" target="_blank">Genussmittel bei Darmempfindlichkeit</a>&#171;.
                        <br />
                        <a id="reiseapotheke">&nbsp;</a>
                        <hr />
                        <h5>Reiseapotheke</h5>
                        <hr />
                        ... und noch ein Hinweis für die Reiseapotheke: Bedenken Sie bitte, dass Sie 
                        (neben den für Sie erforderlichen und für alle üblichen Notfallmedikamenten) zwar 
                        für wirkliche Notfälle durchaus ein Mittel mit 
                        dem Wirkstoff Loperamid (z.B. Imodium) in Ihrer Reiseapotheke dabei haben können, 
                        dass diese Mittel aber den Darm hemmen und keine Dauermedikation darstellen sollten.
                        Besser ist es, auch auf der Reise darauf zu achten, neben ausschließlich verträglichen 
                        Lebensmitteln auch genügend Ballaststoffe 
                        zu sich zu nehmen und vor allem auch ausreichend zu trinken. Weiterhin sorgt 
                        Bewegung für regelmäßigen Stuhlgang. Bei vielen Touren mit Bussen oder anderen 
                        Transportmitteln kommt die Bewegung oft zu kurz. Der Darm aber braucht diese Anregung
                        von außen, um normal funktionieren zu können. Nutzen Sie deshalb jede Pause  
                        zu einem genüsslichen Recken und Strecken, zu tiefem Durchatmen und kleinen 
                        gymnastischen Übungen &ndash; neben der Durchblutung Ihrer Beine wird es Ihnen auch 
                        Ihre Verdauung danken, und einen beschwerdefreien Urlaub steht nichts mehr 
                        im Wege.
                        <br />
                        <br />
                        <hr>
                        <a id="beratung">&nbsp;</a>
                        <div class="row">
                        <div class="col s12 m2">
                            <a href="http://www.ganzheitliche-gesundheitsberatung.de" target="_blank">
                                <img src="<?php echo IMG_PATH; ?>praxiswebsite.png" alt="" class="inline" /></a>
                        </div>
                        </div>
                        <div class="row">
                        <div class="col s12 m12">
                        <h5>Beratung</h5>
                        <br />
                            Gerne biete ich Ihnen eine individuelle Beratung an &ndash; 
                            auf Wunsch auch telefonisch oder per Skype.
                            <br />
                            Bitte informieren Sie sich auf meiner Praxis-Website <a href="http://www.ganzheitliche-gesundheitsberatung.de" target="_blank">&#187;www.Ganzheitliche-Gesundheitsberatung.de&#171;</a>
                        </div>
                        </div>
                        <hr>
                        <br />
                        <a href="guterrat" target="_blank"><img src="<?php echo IMG_PATH; ?>hilfreich-4.png" alt="" class="left" /></a>
                        <br />
                        <br />
                        <hr />
                        <b>Lesen Sie auch folgende Betr&auml;ge</b>:
                        <br />
                        <a href="reiseberichte">&#149; Reiseberichte</a>
                        <br />
                        <a href="ganz-reisedurchfall">&#149; Reisedurchfall (Reisediarrhoe)</a>
                        <br />
                        <br />
                        <hr />
                        <div class="oneline">
                            <div class="left">
                                <a href="lebensmittel-datenbank-info">
                                    <img src="<?php echo IMG_PATH; ?>lebensmitteldatenbank.png" alt="home video small" class="inline" />
                                </a>
                            </div>
                            <p class="left">
                                <b>Empfehlung:</b>
                                <br />
                                Eine zusätzliche Hilfe bei der Ermittlung geeigneter Lebensmittel stellt die
                                <br />
                                &#187;<b>DorisPaas.de &ndash; Lebensmittel-Datenbank</b>&#171; dar. 
                                Informieren Sie sich <a href="lebensmittel-datenbank-info" target="_blank">hier</a>.
                            </p>
                        </div>
                        <br style="clear: left;" />
                        <hr />
                        <a href="javascript: scrollMainToTop();" class="nachoben">nach oben</a>
                    </div>
                </div>
            </div>    
            <br>
            <br> 
            <div class="bodyspacer"></div> 
        </div>