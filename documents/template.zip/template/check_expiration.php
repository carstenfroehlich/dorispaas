<?php
    $sql  = "SELECT gdu.* FROM groceries_db_users gdu left join user_order uo ON gdu.id = uo.user_id ";
    $sql .= "left join order_items oi ON oi.order_id = uo.id WHERE oi.article_id IN (9, 10, 11, 12) ";
    $sql .= "AND (gdu.actual_order_expiration_date = '".mysql_real_escape_string( date("Y-m-d", strtotime(date('Y-m-d', strtotime(date('Y-m-d'))) . " +14 day")) );
    $sql .= "' OR gdu.actual_order_expiration_date = '".mysql_real_escape_string( date('Y-m-d') )."') GROUP BY gdu.id";
    
    $users = getUserFromQuery($sql);
    $datenbank_verlaengerung = loadArticle(12);

    try {
        foreach($users AS $user) {
            $today = false;
            if(date('Y-m-d') == $user->actual_order_expiration_date) { $today = true; }
            $anrede  = "Sehr geehrte/r Frau/Herr ".$user->firstname." ".$user->lastname."\n\n";
            $mailtext  = "in den vergangenen Monaten konnten Sie\n- von den komfortablen Funktionen der DorisPaas.de - ";
            $mailtext .= "Lebensmittel-Datenbank und vielen Informationen profitieren\n";
            $mailtext .= "- Ihre Beschwerden minimieren und\n- Ihren Speiseplan um zahlreiche verträgliche Lebenmittel erweitern.\n\n";
            if($today) {
                $mailtext .= "Heute läuft nun Ihr gebuchtes Abonnement der DorisPaas.de - Lebensmittel-Datenbank ab.\n\n";
            } else {
                $mailtext .= "In 14 Tagen läuft nun Ihr gebuchtes Abonnement der DorisPaas.de - Lebensmittel-Datenbank ab.\n\n";
            }
            $mailtext .= "Gerne biete ich Ihnen die Möglichkeit, Ihr Abo kostengüstig für nur ".number_format($datenbank_verlaengerung->price, 2, ',', '')." Euro um weitere 6 Monate zu verlängern.\n";
            $mailtext .= "- Sie können dann die komfortablen Funktionen der DorisPaas.de - Lebensmittel-Datenbank für nur ".number_format($datenbank_verlaengerung->price / 6, 2, ',', '')." Euro pro Monat weiterhin nutzen.\n";
            $mailtext .= "- Lassen Sie sich die für Ihre Nahrungsmittel-Intoleranzen verträglichen Lebensmittel anzeigen.\n";
            $mailtext .= "- Nutzen Sie die Chance, Ihren Speiseplan nach und nach um viele weitere, möglicherweise verträgliche Lebensmittel zu erweitern.\n";
            $mailtext .= "- Vermeiden Sie auch in Zukunft unangenehme Symptome durch für Sie unbekömmliche Lebensmittel.\n\n";
            $mailtext .= "Buchen Sie Ihre Abo-Verlängerung einfach und komfortabel über den Shop auf meiner Website: http://www.dorispaas.de/shop#aboverlaengerung\n\n";
            $mailtext .= "Geben Sie bitte bei der Bestellung Ihre Kundennummer ein, damit wir Ihren Zugang korrekt zuordnen können. Diese lautet:\n";
            $mailtext .= $user->customer_id."\n\n";
            $mailtext .= "Ich freue mich auf Ihre Bestellung.\n\nWeiterhin alles Gute und ganz herzliche Grüße aus dem Rheinland\nDoris Paas";

            $mail = new Rmail();
            $mail->setFrom('bestellung@dorispaas.de');
            $mail->setSubject('Ihr Zugang zur Lebensmitteldatenbank läuft bald ab');
            $mail->setText($anrede.$mailtext);
            $result  = $mail->send(array($user->email));

            $text = '';
            if($today) {
                $text .= "Erinnerungsmail an ".$user->firstname." ".$user->lastname." versandt, dass der Zugang heute abläuft.";
            } else {
                $text .= "Erinnerungsmail an ".$user->firstname." ".$user->lastname." versandt, dass der Zugang in 14 Tagen abläuft.";
            }

            $mail2 = new Rmail();
            $mail2->setFrom('bestellung@dorispaas.de');
            $mail2->setSubject('Erinnerungsmail an '.$user->firstname." ".$user->lastname.' versandt');
            $mail2->setText($text);
            $result  = $mail2->send(array('bestellung@dorispaas.de'));
        }
    } catch ( Exception $e ) { 
            // Do nothing!!
        }
