        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br />   
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>   
                <h1 class="header center orange-text">BLOG</h1>
            </div>  
        </div>
        <div class="container">    
            <div class="section">
                <div class="row">        
                    <div class="col s12 m12">
                        <img src="<?php echo IMG_PATH; ?>blog.png" alt="Blog" class="left" />
                        Seit einiger Zeit habe auch ich mich entschlossen zu bloggen. Aber keine Bange: Sie werden 
                        hier keine Trivialitäten finden, was ich wann getan, gesagt oder gegessen habe.
                        <br />
                        Ich könnte mir aber vorstellen, dass einige öffentlich gemachte  Äußerungen von 
                        mir auch für Sie interessant sein könnten. 
                        <br />
                        <br />
                        Immer mehr Zeitschriften, Organisationen oder auch online-Medien veröffentlichen 
                        Beiträge zu Gesundheits- und Ernährungsthemen. Und manchmal &ndash; wenn ich meine, 
                        etwas dazu beitragen zu können &ndash; kommentiere ich diese. Sei es, weil ich 
                        die Beiträge gut finde und die Inhalte bestärken oder ergänzen, oder aber auch, 
                        weil ich das Geschriebene einfach nicht unkommentiert stehen lassen möchte.
                        <br />
                        <br />
                        Aber auch Veröffentlichungen von Institutionen wie beispielsweise der 
                        Verbraucherzentrale sind in meinen Augen häufig so verfasst, dass ich hierzu &ndash; 
                        teilweise in Zusammenarbeit mit Interessengruppen &ndash; mit offenen Briefen oder 
                        Pressemitteilungen mit Ergänzungen oder aber auch Berichtigungen reagiere.
                        <br />
                        <br />
                        Im Folgenden finden Sie Links zu aktuellen Beiträgen und den zugehörigen 
                        Leserbriefen, Kommentaren, Pressemitteilungen bzw. offenen Briefen &ndash; chronologisch von unten nach oben geordnet.
                        <br />
                    </div>
                </div>



                    <a id="blog-2018-02-25"></a>
                    <hr />
                    <br />
                    <a href="https://www.facebook.com/www.dorispaas.de?ref=hl" target="_blank">Facebookeintrag vom 25.2.2018</a>
                    <br />
                    <br />
                    <div class="oneline">
                        <div class="left" style="width: 148px">
                        <a href="https://www.facebook.com/www.dorispaas.de?ref=hl" target="_blank"></a>
                    </div>
                    </div>
                    
                    <b>Ein wichtiger Hinweis zu Iberogast®</b>
                    <br />
                    <br />
                    Auch die eigenen Empfehlungen, die man in der eigenen Praxis 
                    seit langem wegen bisheriger guter Erfahrungen mit Mitteln und 
                    Präparaten an betroffene Patienten und Klienten weitergibt, 
                    müssen zum Teil bei aktuellen Anlässen immer wieder überdacht 
                    werden. So ist dies derzeit auch mit dem Präparat &#187;Iberogast®&#171;. 
                    <br />
                    <br />
                    Auch wenn ich mit meinen Beratungen grundsätzlich versuche, 
                    Probleme ursächlich und ganzheitlich zu betrachten und zu 
                    verbessern, kann es manchmal hilfreich sein, zunächst Symptome 
                    zu lindern und dies gelegentlich auch mit der Empfehlung 
                    geeigneter Mittel zu unterstützen. Bei Problemen mit dem 
                    Transport der Nahrung durch das Verdauungssystem habe ich, 
                    sofern andere Methoden versagten, das Präparat &#187;Iberogast®&#171; 
                    des Pharmaunternehmens Bayer in Leverkusen vorgeschlagen, 
                    das mit verschiedenen pflanzlichen Inhaltsstoffen bei funktionellen 
                    und motilitätsbedingten Beschwerden eingesetzt werden kann.
                    <br />
                    <br />
                    Offensichtlich steht einer dieser pflanzlichen Inhaltsstoffe, 
                    das <b>Schöllkraut</b>, schon seit einiger Zeit im Verdacht, bei 
                    höherer Dosierung und längerer Einnahmedauer <b>Leberschäden</b> verursachen 
                    zu können. Und &ndash; wen wundert es &ndash; wird dieser Verdacht 
                    von Bayer nicht nur nicht an die große Glocke gehängt, sondern 
                    auch im Beipackzettel verschwiegen. Insbesondere in Bezug auf 
                    die hochsensible Schwangerschafts- und Stillzeit wird im Beipackzettel 
                    (Stand Januar 2016) versichert, dass sich &#187;aus den vorliegenden 
                    Daten […] keine Hinweise für Bedenken hinsichtlich der Anwendung 
                    während der Schwangerschaft und Stillzeit ableiten&#171; lassen. 
                    Gerade hier müssten meiner Meinung nach noch nicht abschließend 
                    erforschte Unsicherheiten zumindest darauf hingewiesen werden, 
                    so dass die Frauen sich bewusst entscheiden können, ob sie 
                    dieses Präparat einnehmen möchten ober nicht. Der lapidare Zusatz 
                    &#187;Gleichwohl soll Iberogast® während der Schwangerschaft 
                    und Stillzeit nur nach Rücksprache mit einem Arzt eingenommen 
                    werden&#171; ist hier in meinen Augen viel zu wenig &ndash; 
                    vor allem, da das Mittel frei verkäuflich ist und es kein Arzt 
                    verschreiben muss.
                    <br />
                    <br />
                    Aber auch unabhängig von einer Schwangerschaft scheint es &ndash; 
                    vor allem bei längerer Einnahmedauer &ndash; nicht ganz unproblematisch 
                    zu sein, dieses Mittel einzunehmen, und die Schweizer Arzneimittelbehörde 
                    hat kürzlich die <a href="https://compendium.ch/mpro/mnr/25618/html/de?Platform=Desktop" target="_blank">Informationen 
                    zu diesem Präparat</a> angepasst und mit folgendem Hinweis ergänzt: 
                    &#187;Schöllkraut (Chelidonium)-Präparate wurden in sehr seltenen 
                    Fällen mit Leberschädigungen in Verbindung gebracht&#171;. 
                    In Deutschland jedoch steht der 
                    <a href="https://www.iberogast.de/static/documents/4100B_Iberogast_10.1.pdf" target="_blank">Beipackzettel</a> 
                    ohne einen solchen Hinweis bis zum heutigen Tage auf der 
                    Internetseite von Iberogast® zum Download zur Verfügung.
                    <br />
                    <br />
                    Es ist gut, dass durch die Aufmerksamkeit verschiedener Fachleute 
                    wie jetzt der grünen Gesundheitspolitikerin Kordula Schulz-Asche 
                    nun offensichtlich doch Bewegung in die Sache kommt und eventuelle 
                    Gefahren durch ein Präparat aufgezeigt und hinterfragt werden. 
                    Ich möchte Ihnen hierzu gerne den 
                    <a href="https://www.deutsche-apotheker-zeitung.de/news/artikel/2018/02/23/schulz-asche-attackiert-iberogast-hersteller-bayer" target="_blank">Beitrag 
                    der Deutschen Apotheker Zeitung Daz.online</a> ans Herz legen, 
                    damit Sie sich ein eigenes Bild machen können.
                    <br />
                    <br />
                    Selbst wenn ein Mittel nur &#187;rein pflanzliche Inhaltsstoffe&#171; 
                    enthält, sollte grundsätzlich jedem bewusst sein, dass diese 
                    Zutaten nicht zwangsläufig unproblematisch sein müssen. Auch 
                    Pflanzen können hochpotente Wirkungen haben &ndash; deshalb 
                    werden sie ja auch seit Jahrtausenden von Heilkundigen erfolgreich 
                    bei Erkrankungen eingesetzt. Dass hier unter Umständen auch 
                    unerwünschte Nebenwirkungen auftreten können, ist dabei nie 
                    völlig auszuschließen und hängt u.a. auch immer von zahlreichen 
                    zusätzlichen Faktoren ab.
                    <br />
                    <br />
                    Deshalb empfehle ich, auch frei verkäufliche Präparate &ndash; 
                    auch die, die &#187;nur&#171; pflanzliche Stoffe enthalten &ndash; 
                    nur nach sorgfältiger Information einzunehmen und dies auch 
                    nur über einen möglichst kurzen Zeitraum. Sollte die Studienlage 
                    zu einem Mittel nicht eindeutig sein, möchte ich Sie ermutigen, 
                    über andere Alternativen nachzudenken. In meinen Beratungen 
                    werde ich meine Klienten auf jeden Fall auf die Problematik 
                    um das Iberogast® hinweisen und andere Möglichkeiten aufzeigen.




                <div class="row margintoprow">        
                    <div class="col s12 m12 blog">
                    <hr />
                    <a id="blog-2018-01-2018"></a>
                    22.1.2018
                    <br />
                    <b>Rezeptvorschlag für ein gluten-, laktose-, weizen- und zuckerfreies Brot</b> 
                    <br />
                    <br />
                    Heute schickte mir eine Klientin folgenden Rezeptvorschlag, 
                    den ich hier an dieser Stelle gerne an Sie weitergebe:
                    <br />
                    <br />
                    <b>Zutaten</b>
                    <br />
                    <b>&#149;</b> 660 g Mehlmischung (ca. 50% Vollkorn-Buchweizenmehl, 30% Erdmandelmehl, 20% geschrotete Leinsamen)
                    <br />
                    <b>&#149;</b> 1/2 Päckchen Weinstein-Backpulver o.Ä.
                    <br />
                    <b>&#149;</b> 660 ml Pflanzenmilch (Reismilch schmeckt besonders gut, weil leicht süßlich)
                    <br />
                    <b>&#149;</b> 2 TL Salz
                    <br />
                    <br />
                    <b>Zubereitung</b>
                    <br />
                    <b>&#149;</b> Mehlmischung erstellen und das Backpulver untermischen
                    <br />
                    <b>&#149;</b> Kastenbackform gut mit Pflanzenöl (z.B. Rapsöl) einfetten (danach löst sich das Brot besonders leicht aus der Form)
                    <br />
                    <b>&#149;</b> Ofen auf 180°C vorheizen, am besten Umluft
                    <br />
                    <b>&#149;</b> Schrittweise Mehlmischung und Milch mit den Knethaken des Handrührgeräts verrühren
                    <br />
                    <b>&#149;</b> Danach noch einmal kurz mit dem Handquirl oder Kochlöffel rühren
                    <br />
                    <b>&#149;</b> Masse in die Kastenform füllen, glattstreichen und in die mittlere Schiene des Ofens stellen
                    <br />
                    <b>&#149;</b> Ca. 30 min. backen
                    <br />
                    <br />
                    <b>Tipps</b>
                    <br />
                    <b>&#149;</b> Zwischendurch immer mal wieder die Kruste überprüfen (sie soll nicht 
                    schwarz werden, daher besser auch keine Ober-/Unterhitze einstellen) 
                    und mit einen Holzstäbchen einstechen und testen, 
                    wie feucht das Brot noch von innen ist.
                    <br />
                    <b>&#149;</b> Nicht wundern, das Brot geht nicht sehr auf, das ist ok.
                    <br />
                    <b>&#149;</b> Das Tolle ist, dass man diese Zutaten lagern kann. Man kann 
                    also spontan ein Brot backen und muss nicht frische Hefe, 
                    Eier etc. haben. Also auch etwas für stark Eingespannte sowie 
                    für Leute mit &#187;Knet-Phobie&#171;.
                    <br />
                    <br />
                    Liebe Frau M., ganz herzlichen Dank für dieses tolle Rezept!
                    <br />
                    <hr />





                    <a id="blog-2017-11-02"></a>
                    <a href="https://www.facebook.com/www.dorispaas.de?ref=hl" target="_blank">Facebookeintrag vom 2.11.2017</a>
                    <br />
                    <br />
                    <div class="oneline">
                        <div class="left" style="width: 148px">
                        <a href="https://www.facebook.com/www.dorispaas.de?ref=hl" target="_blank">
                                <img src="<?php echo IMG_PATH; ?>nl-2017-06-titel.png" alt="Glyphosat" class="inline" />
                            </a>
                    </div>
                    </div>
                    
                    Voraussichtlich am 9. November wird die EU-Kommission darüber abstimmen, ob und 
                    ggf. für welche Zeitspanne die Zulassung für das Unkrautvernichtungsmittel Glyphosat 
                    verlängert wird &ndash; oder auch nicht.
                    <br />
                    <br />
                    Glyphosat ist einer von mehreren Inhaltsstoffen des unter dem Namen &#187;Roundup&#171; 
                    vertriebenen Unkrautvernichtungsmittels des amerikanischen Agrarkonzerns Monsanto, 
                    der wahrscheinlich in Kürze von dem deutschen Chemie- und Pharmakonzern Bayer AG 
                    aufgekauft werden wird. Neben Herbiziden produziert die Firma mit Hauptsitz in St. 
                    Louis im Bundesstaat Missouri und Niederlassungen in zahlreichen anderen Ländern 
                    auch Saatgut. Wie alle Herbizide und Pestizide benötigt auch Roundup, das sowohl 
                    in der kommerziellen Landwirtschaft wie auch in privaten Obst- und Gemüsegärten 
                    Verwendung findet, in der EU eine Zulassung, die erteilt wird, sofern die EU-Kommission 
                    der Meinung ist, diese Mittel seien für Mensch, Tier und Umwelt unbedenklich. Nur 
                    zugelassene Mittel dürfen verkauft und eingesetzt werden, ohne eine Zulassung sind 
                    der Vertrieb und die Ausbringung in der gesamten EU verboten. Liegt eine Zulassung 
                    vor, ist es den einzelnen Mitgliedsstaaten allerdings immer noch unbenommen, per 
                    Sonderregelung den Einsatz im eigenen Land zu untersagen. Umgekehrt ist es jedoch 
                    nicht möglich, eine fehlende EU-Zulassung in einzelnen Ländern aufzuheben. Die 
                    derzeitige Frist für die Zulassung von Glyphosat erlischt am 15. Dezember 2017 &ndash; 
                    sofern nicht rechtzeitig eine Folgezulassung erteilt wird.
                    <br />
                    <br />
                    Mehr über Glyphosat und die Wirkung dieses Stoffes findet ihr auf meiner 
                    <a href="http://www.dorispaas.de/glyphosat" target="_blank">Website</a>
                    <br />
                    <br />
                    Auf der Website des <a href="https://aktion.bund.net/europ%C3%A4ische-b%C3%BCrgerinitiative-gegen-glyphosat" target="_blank">BUND</a>
                    findet ihr eine Petition gegen die Verlängerung der Zulassungserlaubnis für Glyphosat. 
                    Da eine solche Stimmabgabe eine der wenigen Möglichkeiten ist, unserer Bundesregierung 
                    zu signalisieren, wie viele Menschen keine Verlängerung der Zulassung wünschen, 
                    bitte ich euch ganz herzlich darum, eure eigene Stimme abzugeben und zusätzlich 
                    diesen Beitrag auf euren Accounts zu verlinken. Je mehr Menschen ihren Willen in 
                    diesem Sinne kundtun, desto größer wird die Chance, dass auch die schwerfälligste 
                    Regierung dies hoffentlich endlich zur Kenntnis nimmt und in der EU-Kommission 
                    zumindest für Deutschland gegen ein Mittel stimmt, dessen Unbedenklichkeit mitnichten 
                    zweifelsfrei bewiesen ist. 
                    <br />
                    <br />
                    Herzlichen Dank und liebe Grüße
                    <br />
                    Doris Paas
                    <br />
                    <hr />
                    
                    
                    
                    
                    <a id="blog-2017-09-19">&nbsp;</a>
                    <p>
                        <a href="http://www.amazon.de/gp/cdp/member-reviews/A5MX7PXD1ZYMY/ref=cm_cr_pr_auth_rev?ie=UTF8&sort_by=MostRecentReview" target="_blank">Buchrezension bei Amazon.de vom 19.9.2017</a>
                    </p>
                    <br />
                    <div class="oneline">
                    
                        <div class="left" style="width: 148px">
                            <a href="http://www.amazon.de/gp/product/3442392578/ref=as_li_tl?ie=UTF8&camp=1638&creative=6742&creativeASIN=3442392578&linkCode=as2&tag=daslaktintobu-21&linkId=4XDHG4ETJV2RVVCF" target="_blank">
                                <img src="<?php echo IMG_PATH; ?>aggarwal.png" alt="Aggarwal" class="inline" />
                            </a>
                        </div>
                        <div class="left" style="width: 502px;">
                            <p>
                                <a href="http://www.amazon.de/gp/cdp/member-reviews/A5MX7PXD1ZYMY/ref=cm_cr_pr_auth_rev?ie=UTF8&sort_by=MostRecentReview" target="_blank">Buchrezension bei Amazon.de vom 19.9.2017</a>
                            </p>
                            <p>
                                Dr. Bharat B. Aggarwahl (mit Debora Yost): 
                                <br />
                                <b>Heilende Gewürze</b>
                                <br />
                                Wie 50 heimische und exotische Gewürze Gesundheit erhalten <br />und Krankheiten heilen können
                                <br />
                                <br />
                                Meine persönliche Bewertung: 
                                <br />
                                <img src="<?php echo IMG_PATH; ?>bewertungssternchen-5.png" alt="" border="0" hspace="0" vspace="0" style="float: left; margin-right: 0px; padding-bottom: 0px;" />
                                <br />
                                <br />
                                <i>Wenn man nicht schon bisher ein Fan von Gewürzen gewesen ist, <br />macht spätestens dieses Buch gesunden Appetit darauf</i>
                            </p>
                        </div>
                        <br class="cb" />
                    </div>
                    <br style="clear: left;" />
                    <b>Wenn man nicht schon bisher ein Fan von Gewürzen gewesen ist, macht spätestens dieses Buch gesunden Appetit darauf </b>
                    <br />
                    <br />
                    Wie einfach es doch sein kann, etwas für seine Gesundheit zu tun &ndash; und dies 
                    nicht mit Mittelchen und Pülverchen (und deren Nebenwirkungen) aus der Apotheke, 
                    sondern lecker einfach nur beim Essen.
                    <br />
                    <br />
                    Aggarwal weiß ganz offensichtlich, wovon er spricht. Nicht nur aufgrund seiner 
                    ethnischen Herkunft, die seine natürliche Affinität zum reichlichen Gebrauch von 
                    Gewürzen erklärt, sondern auch durch seine Tätigkeit als Wissenschaftler darf man 
                    als Leser sicher sein, hier wirklich fundiertes Fachwissen serviert zu bekommen. 
                    Und die Zusammenarbeit mit Debora Yost hat hier ganz offensichtlich wunderbare 
                    Früchte getragen.
                    <br />
                    <br />
                    Dass mit mehr als nur Salz und Pfeffer gewürzte Speisen ein echter Gaumenschmaus 
                    sein können, weiß jeder. Das Wissen darum, dass sie auch einen heilenden Effekt 
                    haben können, ist leider großteilig in unserer westlichen, ach so &#187;fortschrittlichen&#171; 
                    Zivilisation verloren gegangen. Aggarwal und Yost bringen diese althergebrachten 
                    Schätze wieder in unser Bewusstsein zurück, und zwar nicht nur einfach behauptet, 
                    sondern auch für den kritischsten Leser wissenschaftlich belegt untermauert. <br />
                    <p>
                    <a href="blog-2017-09-19">Weiterlesen</a>
                    </p>
                    <br />
                    <hr />
                    <br />
                    
                    
                    
                    
                    
                    
                    <a id="blog-2016-09-03">&nbsp;</a>
                    <div class="oneline">
                    <div class="left" style="width: 148px">
                    <img src="<?php echo IMG_PATH; ?>mdh.png" alt="Mindesthaltbarkeit" class="inline" />
                    </div>
                    </div>
                    Zukunftsmusik?
                    <br />
                    <br />
                    <b>&#187;Das intelligente Verpackungs-Etikett&#171;</b>
                    <br />
                    <br />
                    Jeder kennt das: Im Supermarktregal schauen wir, das frischeste Produkt auszuwählen.
                    Wir erwarten &ndash; und das im Allgemeinen nicht zu Unrecht &ndash; dass wir 
                    dann ein möglichst lange haltbares Lebensmittel mit nach Hause nehmen, das wir ggf. 
                    noch einige Zeit im Kühlschrank lagern können. Dies ist legitim.
                    <br />
                    <br />
                    Für den Händler bedeutet dieses Verhalten jedoch, dass er oftmals Nahrungsmittel, 
                    bei denen der Ablauf des Mindesthaltbarkeitsdatums kurz bevor steht, entweder 
                    entsorgen oder aber zu einem verbilligten Preis verkaufen muss. Für den Händler 
                    ist dies eine Umsatzeinbuße und &ndash; im Falle der Entsorgung &ndash; eine 
                    Verschwendung von Ressourcen. Und das muss nicht so sein.
                    <br />
                    <br />
                    Das Mindesthaltbarkeitsdatum ist kein Verfallsdatum. Letzteres finden wir z.B. bei 
                    Medikamenten, die nicht mehr nach Ablauf dieser Frist verwendet werden dürfen, 
                    weil dann entweder die Wirksamkeit nicht mehr gewährleistet werden kann oder die 
                    Wirkstoffe sogar verdorben sein können.
                    <br />
                    <br />
                    Das Mindesthaltbarkeitsdatum bei Lebensmitteln bedeutet, dass diese bei korrekter 
                    Lagerung garantiert noch bis zu diesem Tag zum Verzehr geeignet sind. Aber auch 
                    danach können Sie noch genießbar sein, und im Allgemeinen ist dies auch je nach 
                    Art des Lebensmittels noch einige Tage der Fall. Lediglich Fleisch &ndash; vor 
                    allem Hackfleisch &ndash; trägt ein Verbrauchsdatum, bis zu dem das Produkt verzehrt 
                    werden soll, da hier der Verderb schneller einsetzt.
                    <br />
                    <p>
                    <a href="blog-2016-09-03">Weiterlesen</a>
                    </p>
                    <br />
                    <hr />
                    
                    
                    
                    
                    
                    
                    <a id="blog-2016-07-04">&nbsp;</a>
                    
                    <p style="text-align:right">4.7.2016</p>
                    <div class="oneline">
                        <div class="left" style="width: 148px">
                        <a href="https://www.tuebiom.de" target="_blank">
                                <img src="<?php echo IMG_PATH; ?>tuebiom.png" alt="Tübiom" class="inline" />
                            </a>
                    </div>
                    </div>
                    
                    <a href="http://www.tuebiom.de" target="_blank"><b>Tübiom</b> </a>
                    <br />
                    <br />
                    Ausnahmsweise einmal nicht in eigener Sache möchte ich Sie auf ein sehr interessantes 
                    Projekt aufmerksam machen: das Tübiom Projekt.
                    <br />
                    <br />
                    In Zusammenarbeit mit der Universitätsklinik und der Universität Tübingen will 
                    die CeMeT GmbH im Rahmen dieses Projektes ermitteln, welches Mikrobiom im menschlichen 
                    Darm &#187;normal&#171; ist. Hierzu soll zuerst einmal anhand von Stuhlproben 
                    von 10.000 freiwilligen Probanden ermittelt werden, welche Mikroorganismen im Darm vorhanden 
                    sind und welche Lebens- und Essgewohnheiten mit den verschiedenen Besiedelungen 
                    in Verbindung gebracht werden können. Die Studie soll also helfen, Zusammenhänge 
                    zwischen der Zusammensetzung des Darm-Mikrobioms, Gesundheit und Lebensstil 
                    besser zu verstehen und eine Referenzdatenbank aufzubauen.
                    <br />
                    <br />
                    In weiteren Schritten kann dann erforscht werden, ob es möglich sein kann, anhand einer 
                    Stuhlprobe über bestehende Krankheiten (z.B. Darmkrebs) oder aber auch über mögliche 
                    Erkrankungsrisiken Aussagen machen zu können. Ein sehr ambitioniertes und &ndash; wie 
                    ich meine &ndash; unterstützenswertes Vorhaben!
                    <br />
                    <br />
                    Das Projekt hat dazu aufgerufen, dass Menschen Stuhlproben einschicken und Fragebögen 
                    zu den relevanten Fakten ausfüllen. Völlig kostenlos für Sie können Sie ein Testset 
                    anfordern und bekommen nach dem Einsenden und der Auswertung nicht nur Auskunft 
                    über Ihr eigenes Mikrobiom. Sie können auf der Website auch interaktiv Ihre 
                    Ihre Ergebnisse mit der durchschnittlichen Zusammensetzung anderer Teilnehmergruppen 
                    vergleichen. 
                    <br />
                    <br />
                    Gerne möchte ich ein solches Programm unterstützen und beteilige mich natürlich 
                    selbst daran. Auch Sie möchte ich ganz herzlich bitten, sich auf der 
                    <a href="http://www.tuebiom.de" target="_blank">Website </a> zu registrieren und 
                    an dem Projekt teilzunehmen.
                    <br />
                    <br />
                    Herzlichen Dank
                    <br />
                    <br />
                    <hr />
                    <br />
                    
                    
                    <a id="blog-2015-06-08">&nbsp;</a>
                    
                    <a href="https://www.xing.com/communities/posts/lebensmittel-ohne-zusatzstoffe-1009756535" target="_blank">Eintrag auf Xing vom 8.6.2015</a>
                    <br />
                    <br />
                    <div class="oneline">
                        <div class="left" style="width: 148px">
                        <a href="https://www.xing.com/communities/posts/lebensmittel-ohne-zusatzstoffe-1009756535" target="_blank">
                                <img src="<?php echo IMG_PATH; ?>erdnusscreme.png" alt="Erdnusscreme" class="inline" />
                            </a>
                    </div>
                    </div>
                    
                    
                    <b>Gratwanderung Einkauf</b>
                    <br />
                    <br />
                    <br />
                    <br />
                    <br />
                    <br />
                    Wenn man von Nahrungsmittel-Unverträglichkeiten, -Allergien oder auch einer Zöliakie 
                    betroffen ist, kann der Lebensmitteleinkauf schon ziemlich beschwerlich werden: 
                    Jede Zutatenliste muss man intensiv studieren, um nicht versehentlich doch das 
                    eine oder andere unverträgliche Produkt in den Einkaufswagen zu legen.
                    <br />
                    <br />
                    Zwar hat man bald eine gewisse Auswahl an verträglichen Standard-Produkten zusammengestellt, 
                    aus denen man seine verträglichen Mahlzeiten zubereitet, und im vertrauten Supermarkt 
                    findet man diese meist sofort. Trotzdem kommt es häufig vor, dass eben dieser 
                    Supermarkt nicht nur die Anordnung der Lebensmittelgruppen auf den Kopf stellt und 
                    man wieder suchen muss, und leider gar nicht so selten ändern auch die Hersteller 
                    die Rezepturen ihrer Produkte. Ab und an ist also nicht nur ein neues Suchen, 
                    sondern auch ein Blick auf die Zutatenlisten der üblichen Produkte fällig &ndash; 
                    aber das kennen wir ja schon und sind daran gewöhnt.
                    <br />
                    <p>
                    <a href="blog-2015-06-08">Weiterlesen</a>
                    </p>
                    <br />
                    <hr />
                    
                    
                    
                    
                    <a id="blog-2015-05-04">&nbsp;</a>
                    
                    <a href="https://www.facebook.com/www.dorispaas.de?ref=hl" target="_blank">Facebookeintrag vom 25.8.2014</a>
                    <br />
                    <br />
                    <br />
                    <div class="oneline">
                        <div class="left" style="width: 148px">
                        <a href="https://www.facebook.com/www.dorispaas.de?ref=hl" target="_blank">
                                <img src="<?php echo IMG_PATH; ?>kubli.png" alt="Kubli" class="inline" />
                            </a>
                    </div>
                    </div>
                    <br style="clear: left;" />
                    Kommentar zum Beitrag 
                    <a href="http://www.codecheck.info/news/Laktose-und-glutenfreie-Produkte-bis-9mal-teurer-80163" target="_blank">Laktose- 
                    und glutenfreie Produkte bis 9mal teurer &ndash; Abzocke mit der Gesundheit</a>
                    <br />

                    Der Beitrag auf der Website codecheck.info enthält zwar viele richtige Tatsachen, 
                    er erweckt aber leider insgesamt doch ein verzerrtes Bild. 
                    <br />
                    <br />
                    Allein schon die Überschrift zeigt, dass hier nicht richtig differenziert wird: 
                    laktose- und glutenfreie Produkte in einen Topf zu werfen und die Preise für alle 
                    gleichzeitig zu vergleichen, kann zumindest irreführend sein.
                    <p>
                    <a href="blog-2015-05-04">Weiterlesen</a>
                    </p>
                    <br />
                    <hr />
                    
                    
                    
                    
                    <a id="blog-2015-01-10">&nbsp;</a>
                    
                    <div class="oneline">
                    
                    <p style="text-align:right">10.1.2015</p>
                    
                        <div class="left" style="width: 502px;">
                             
                            Leserbrief zum Beitrag 
                            <br />
                            &#187;<b>Strichcode kann Infos zur Gentechnik liefern</b>&#171; 
                                <br /> im Kölner Stadt-Anzeiger vom 7.1.2015
                                <br />
                            </p>
                        </div>
                        <br class="cb" />
                    </div>
                    <br style="clear: left;" />
                    Vielen Dank für den Beitrag &#187;Strichcode kann Infos zur Gentechnik liefern&#171;. 
                    Er zeigt informativ auf, wie die derzeitige Gesetzeslage und die Gedanken unseres 
                    Gesundheitsministers sind, im Zusammenhang mit der Problematik um TTIP umzugehen. 
                    Er macht auch deutlich, auf welche &#187;Gegenliebe&#171; die wirklichkeitsfremden 
                    Pläne stoßen, Inhaltsstoffe über einen Barcode zu deklarieren. 
                    <br />
                    <br />
                    Sehr geehrter Herr 
                    Schmidt, ich persönlich zeige Ihnen die Rote Karte für das weitere Schlupfloch, 
                    mir unerwünschte Zutaten unterschieben zu können! Lesen Sie beim Einkauf den Barcode 
                    eines jeden Nahrungsmittels, das Sie kaufen, mit Ihrem Handy aus? Nehmen sich die 
                    Zeit, dann die langen Zutatenlisten zu studieren? Hat Ihr Smartphone ganz hinten 
                    in Ihrem Supermarkt noch einen Netzempfang, um diese Aktion durchführen zu können? 
                    <br />
                    <br />
                    Bekennen Sie bitte endlich Farbe und kommen Ihrer Aufgabe nach, ein Minister für 
                    uns Verbraucher zu sein und uns vor Schäden durch industrielle Machenschaften 
                    wirksam zu schützen. Seien Sie sicher: es kommt auch Ihrer Gesundheit zugute und 
                    würde Ihnen &ndash; ganz nebenbei &ndash; auch Wählerstimmen sichern. <br />
                    <br />
                    <br />
                    <hr />
                    <br />
                    
                    
                    
                    
                    
                    <a id="blog-2014-11-10">&nbsp;</a>
                    
                    <div class="oneline">
                    
                        <div class="left" style="width: 148px">
                        <a href="http://www.amazon.de/gp/product/3442392578/ref=as_li_tl?ie=UTF8&camp=1638&creative=6742&creativeASIN=3442392578&linkCode=as2&tag=daslaktintobu-21&linkId=4XDHG4ETJV2RVVCF" target="_blank">
                                <img src="<?php echo IMG_PATH; ?>perlmutter.png" alt="Perlmutter" class="inline" />
                            </a>
                        </div>
                        <div class="left" style="width: 502px;">
                            <p>
                                <a href="http://www.amazon.de/gp/cdp/member-reviews/A5MX7PXD1ZYMY/ref=cm_cr_pr_auth_rev?ie=UTF8&sort_by=MostRecentReview" target="_blank">Buchrezension bei Amazon.de vom 10.11.2014</a>
                            </p>
                            <p>
                                Dr. David Perlmutter mit Kristin Loberg: 
                                <br />
                                <b>Dumm wie Brot</b>
                                <br />
                                Wie Weizen schleichend Ihr Gehirn zerstört
                                <br />
                                <br />
                                Meine persönliche Bewertung: 
                                <br />
                                <img src="<?php echo IMG_PATH; ?>bewertungssternchen-3.png" alt="" border="0" hspace="0" vspace="0" style="float: left; margin-right: 0px; padding-bottom: 0px;" />
                                <br />
                                <br />
                                <i>Eher für den bereits sachlich umfassend informierten Leser als für den &#187;einfach nur Neugierigen&#171;</i>
                            </p>
                        </div>
                        <br class="cb" />
                    </div>
                    <br style="clear: left;" />
                    Den Tenor seines Buches lässt uns Dr. David Perlmutter bereits im Untertitel wissen: 
                    &#187;Wie Weizen schleichend Ihr Gehirn zerstört&#171; und versucht aufzuzeigen, 
                    dass Weizen dafür verantwortlich ist, dass neurologisch-degenerative Erkrankungen 
                    wie u.a. Demenz und Alzheimer (wobei er diese beiden Erkrankungen leider in einen 
                    Topf wirft) durch Glutenverzehr verursacht werden. 
                    <br />
                    <br />
                    So zeigt er auf, dass Arteriosklerose nicht nur die landläufig bekannten Folgeerkrankungen 
                    wie u.a. Herzinfarkte nach sich zieht, sondern auch die Blutgefäße im Gehirn 
                    beeinträchtigt, was neben Schlaganfällen auch zu Demenz und Alzheimer führt. 
                    Dies ist eine Schlussfolgerung, der ich ohne weiteres folgen kann &ndash; denn 
                    warum sollte eine Mangeldurchblutung nur in den Körperregionen Folgen haben, im 
                    Gehirn aber nicht?
                    <br />
                    <br />
                    <p>
                    <a href="blog-2014-11-10">Weiterlesen</a>
                    </p>
                    <br />
                    <hr />
                    <br />
                    
                    
                    
                    
                    
                    
                    
                    <a id="blog-2014-08-25">&nbsp;</a>
                    <p style="text-align:right">25.8.2014</p>
                    <p>
                        <a href="https://www.facebook.com/www.dorispaas.de?ref=hl" target="_blank">Facebookeintrag vom 25.8.2014</a>
                    </p>
                    Glosse
                    <h2>
                        Mein Versuch, laktosefreie Brötchen zu kaufen
                    </h2>
                    kürzlich erlebt auf einer Berlinreise
                    <br />
                    <br />
                    <br />
                    Ort: ein Bäckereigeschäft im Vorraum eines Supermarktes
                    <br />
                    <br />
                    Mitwirkende: eine Bäckereifachverkäuferin (wobei ich natürlich keine Garantie für 
                    die Ausbildung der Dame übernehmen kann und will), weiterhin ich als Kundin 
                    (wobei ich mir über meine Rolle als wirkliche Kundin nicht sicher bin &ndash; 
                    vielleicht war ich auch einfach nur ein Störenfried)
                    <br />
                    <br />
                    Ich: &#187;Guten Tag, können Sie mir bitte sagen, ob die Laugenstangen und die 
                    Mehrkornfrischlinge Laktose enthalten?&#171;
                    <br />
                    <br />
                    Verkäuferin: &#187;Da müüsn se dahinten guckn, da hängt ne Liste.&#171;
                    <br />
                    <br />
                    <a href="blog-2014-08-25">Weiterlesen ... </a>
                    <br />
                    <br />
                    <br />
                    <hr />
                    
                    
                    
                    
                    
                    
                    <a id="blog-2014-07-03">&nbsp;</a>
                    
                    <div class="oneline">
                    
                        <div class="left" style="width: 148px">
                            <a href="http://www.amazon.de/gp/product/392740005X/ref=as_li_qf_sp_asin_tl?ie=UTF8&camp=1638&creative=6742&creativeASIN=392740005X&linkCode=as2&tag=daslaktintobu-21" target="_blank">
                                <img src="<?php echo IMG_PATH; ?>bannenberg.png" alt="Korn" class="inline" />
                            </a>
                        </div>
                        <div class="left" style="width: 502px;">
                            <p>
                                <a href="http://www.amazon.de/gp/cdp/member-reviews/A5MX7PXD1ZYMY/ref=cm_cr_pr_auth_rev?ie=UTF8&sort_by=MostRecentReview" target="_blank">Buchrezension bei Amazon.de vom 3.7.2014</a>
                            </p>
                            <p>
                                <b>Thomas Bannenberg: 
                                <br />
                                Der Leitfaden</b>
                                <br />
                                für freie unterrichtende, beratende und therapeutische Berufe
                                <br />
                                <br />
                                Meine persönliche Bewertung: 
                                <br />
                                <img src="<?php echo IMG_PATH; ?>bewertungssternchen-5.png" alt="" border="0" hspace="0" vspace="0" style="float: left; margin-right: 0px; padding-bottom: 0px;" />
                                <br />
                                <br />
                                <i>Wertvolle Hinweise für Gesundheits- oder Ernährungsberater, Heilpraktiker, Entspannungstherapeuten, Coaches etc.</i>
                            </p>
                        </div>
                        <br class="cb" />
                    </div>
                    <br style="clear: left;" />
                    Sie sind bereits als Gesundheits- oder Ernährungsberater, Heilpraktiker, 
                    Entspannungstherapeut, Coach oder als Spezialist in einem verwandten Berufsfeld 
                    selbstständig? Oder Sie nutzen Ihre Ausbildung bisher &#187;nur&#171; für sich 
                    selbst und liebäugeln mit einer selbstständigen Tätigkeit in Ihrem Berufsfeld? 
                    Oder Sie wollen erst demnächst eine solche Ausbildung beginnen?
                    <br />
                    <br />
                    Egal, ob Sie (noch) gar nicht an eine Selbstständigkeit denken oder aber in 
                    absehbarer Zeit ein neues (kleines) Unternehmen gründen wollen oder ob Sie schon 
                    richtig im Geschäft sind &ndash;  für alle ist das Buch &#187;Der Leitfaden&#171; 
                    von Thomas Bannenberg eine wahre Fundgrube von Tipps!
                    <br />
                    <br />
                    <p>
                    <a href="blog-2014-07-03">Weiterlesen</a>
                    </p>
                    <br />
                    <hr />
                    <br />
                    
                    
                    
                    
                    <a id="blog-2014-02-21">&nbsp;</a>
                    
                    <div class="oneline">
                    
                        <div class="left" style="width: 148px">
                            <a href="http://www.amazon.de/gp/product/3527708928/ref=as_li_qf_sp_asin_tl?ie=UTF8&camp=1638&creative=6742&creativeASIN=3527708928&linkCode=as2&tag=daslaktintobu-21" target="_blank">
                                <img src="<?php echo IMG_PATH; ?>zoeliakie-dummies.png" alt="Korn" class="inline" />
                            </a>
                        </div>
                        <div class="left" style="width: 502px;">
                            <p>
                                <a href="http://www.amazon.de/gp/cdp/member-reviews/A5MX7PXD1ZYMY/ref=cm_cr_pr_auth_rev?ie=UTF8&amp;sort_by=MostRecentReview" target="_blank">Buchrezension bei Amazon.de vom 21.2.2014</a>
                            </p>
                            <p>
                                <b>Danna Korn: Glutenfrei leben für Dummies</b><br />
                                 Vor allem mit den ersten Kapiteln ein hervorragender Ratgeber
                            </p>
                        </div>
                        <br class="cb" />
                    </div>
                    <br style="clear: left;" />
                    Vor allem mit den ersten Kapiteln ist dieses Buch ein hervorragender Ratgeber für 
                    Menschen mit Zöliakie und Gluten-Sensitivität. Es gibt zahlreiche Informationen 
                    zu Hintergründen und Zusammenhängen, die es dem Leser ermöglichen, zu verstehen, 
                    was es mit dem Gluten auf sich hat. Vor allem sollten sich hier sicherlich Menschen 
                    mit einer frischen Diagnose angesprochen fühlen.
                    <p>
                    <a href="blog-2014-02-21">Weiterlesen</a>
                    </p>
                    <br />
                    <hr />
                    <br />
                    
                    
                    
                    
                    <a id="blog-2014-02-17">&nbsp;</a>
                    
                    <div class="oneline">
                        <div class="left" style="width: 148px">
                            <a href="http://www.amazon.de/gp/product/3442173582/ref=as_li_qf_sp_asin_tl?ie=UTF8&camp=1638&creative=6742&creativeASIN=3442173582&linkCode=as2&tag=daslaktintobu-21" target="_blank">
                                <img src="<?php echo IMG_PATH; ?>weizenwampe.png" alt="Weizenwampe" class="inline" />
                            </a>
                        </div>
                        <div class="left" style="width: 502px;">
                            <p>
                                <a href="http://www.amazon.de/gp/cdp/member-reviews/A5MX7PXD1ZYMY/ref=cm_cr_pr_auth_rev?ie=UTF8&amp;sort_by=MostRecentReview" target="_blank">Buchrezension bei Amazon.de vom 17.2.2014</a>
                            </p>
                            <p>
                                <b>Dr. med. William Davis: Weizenwampe</b><br />
                                Bitte mit Vorsicht genießen
                            </p>
                        </div>
                        <br class="cb" />
                    </div>
                    <br style="clear: left;" />
                    Das Buch &#187;Weizenwampe&#171; von Dr. med. William Davis zeigt eine völlig andere 
                    Betrachtungsweise des Themas &#187;Weizen&#171; und vor allem auch &#187;Vollkorn&#171; 
                    als allgemein üblich. Es wirft die bisherige Ansicht, Vollkorn sei gesund, über 
                    den Haufen und sagt &ndash; auf einen Nenner gebracht &ndash; dass nicht nur 
                    Auszugsmehle und deren Produkte, sondern auch das Vollkorn aus Weizen und allen 
                    anderen glutenhaltigen Getreiden ungesund seien.</p>
                    <p>
                    <a href="blog-2014-02-17">Weiterlesen</a>
                    </p>
                    
                    <br />
                    
                    <hr />
                    
                    
                    
                    
                    
                    
                    
                    
                    <a id="blog-2014-02-12">&nbsp;</a>
                    <p style="text-align:right">12.2.2014</p>
                    <p>
                        <a href="http://www.facebook.com/www.dorispaas.de" target="_blank">Facebookeintrag vom 12.2.2014</a>
                    </p>
                    <h2>
                        Genmais 1507 &ndash; Chance zum Farbe bekennen verpasst
                    </h2>
                    <p>
                    Brüssel hat abgestimmt &ndash;  über die Erlaubnis, den gentechnisch veränderten 
                    Mais 1507 in der EU anbauen zu dürfen. Das Ergebnis dieser Abstimmung: 1507 darf 
                    in Zukunft angebaut werden. 
                    <br />
                    <br />
                    Deutschland hat sich bei dieser Abstimmung enthalten. In den Medien bedauern die 
                    meisten Politiker unserer Regierung diese Stimmenthaltung: &#187;Man selber wäre 
                    selbstverständlich &ndash;  wie ja auch die große Mehrheit der Bevölkerung (!) &ndash;  
                    gegen eine solche Anbaugenehmigung. Aber leider leider wäre es üblich, sich im Falle 
                    von Uneinigkeit enthalten ZU MÜSSEN&#171;.
                    <br />
                    <br />
                    Zugegeben: Die 29 Stimmen der Bundesrepublik hätten &#187;den Kohl auch nicht fett gemacht&#171;, 
                    und das Ergebnis wäre auch mit einer Ablehnung von Deutschland nicht anders ausgefallen. 
                    Trotzdem ist wieder einmal die Gelegenheit verpasst worden, dass die von uns gewählten 
                    Vertreter so für uns gesprochen hätten, wie sie die Stimmen aus dem Volke laut und 
                    deutlich vernehmen.
                    <br />
                    <br />
                    <a href="blog-2014-02-12">Weiterlesen ... </a>
                    <br />
                    <br />
                    <hr />
                    
                    
                    
                    
                    <a id="blog-2014-01-10">&nbsp;</a>
                    <p style="text-align:right">10.1.2014</p>
                    <p>
                        <a href="http://www.facebook.com/www.dorispaas.de" target="_blank">Facebookeintrag vom 10.1.2014</a>
                    </p>
                    <h2>
                        &#187;Neue Bestimmungen zur Deklarationspflicht von Allergenen in Lebensmitteln ab 13.12.2014&#171;
                    </h2>
                    <p>
                    Eine gute Nachricht für uns veröffentlichte Das Bundesministerium für Ernährung, 
                    Landwirtschaft und Verbraucherschutz in einer Pressemitteilung am 13.12.2013 
                    (ich zitiere aus http://www.bmelv.de/SharedDocs/Pressemitteilungen/2013/304-Was-sich-2014-aendert.html):
                    &#187;Mehr Transparenz durch die neue Lebensmittel-Kennzeichnung
                    <br />
                    <br />
                    Ab dem 13. Dezember 2014 gelten in der EU neue Vorschriften zur Lebensmittelkennzeichnung. 
                    Pflichtinformationen auf Lebensmittelverpackungen müssen eine Mindestschriftgröße haben, 
                    damit sie gut lesbar sind. Lebensmittel-Imitate müssen speziell gekennzeichnet werden. 
                    Bei ihrer Verwendung muss der ersatzweise verwendete Stoff in unmittelbarer Nähe des 
                    Produktnamens angegeben werden. Bestimmte Stoffe, die Allergien oder Unverträglichkeiten 
                    auslösen können, müssen im Zutatenverzeichnis hervorgehoben werden. Auch bei nicht 
                    verpackten Lebensmitteln, sogenannter »loser Ware«, ist die genaue Kennzeichnung 
                    dieser Stoffe künftig verpflichtend. Das sind nur einige Beispiele weitere Details 
                    der Regelungen gibt es unter: www.bmelv.de/lebensmittelkennzeichnung&#171;
                    <br />
                    <br />
                    Schade ist es natürlich, dass den Herstellern für die verpflichtende Umsetzung 
                    dieser Richtlinie ein ganzes Jahr Zeit gegeben wird – ein Jahr, in dem die Verbraucher 
                    leider noch mit den alten, auch vom BMELV als unzureichend erkannten Regelungen 
                    vorlieb nehmen müssen. 
                    <br />
                    <br />
                    <a href="bestimmungen#regel-1a">Weiterlesen ... </a>
                    
                    
                    
                    <br />
                    <br />
                    <hr />
                    <a id="blog-2013-12-12">&nbsp;</a>
                    <p>
                    </p>
                    <p style="text-align:right">12.12.2013</p>
                    <h2>
                        Achtung: Aspartam!
                    </h2>
                    <p>
                    
                    
                    
                    Im meiner gestrigen Tageszeitung war die Meldung auf Seite 11 gerade mal 5 cm hoch 
                    &ndash; aber für mich trotzdem sehr brisant: Die EU-Lebensmittelbehörde EFSA 
                    behauptet nun ganz offiziell, dass nach einer von ihr durchgeführten Studie der 
                    künstliche Süßstoff &#187;Aspartam&#171; für die Verbraucher ungefährlich sei! 
                    Die erlaubten und &#187;von der Industrie eingesetzten&#171; Mengen seien 
                    unbedenklich &ndash; lediglich für Menschen mit der Stoffwechselerkrankung PKU 
                    (Phenylketonurie) würde eine Verzehrwarnung gegeben.
                    <br />
                    <br />
                    Irgendwie habe ich bei solcher Art Meldungen immer wieder ein Déjà vu &ndash; war 
                    da vor 60 Jahren nicht schon einmal etwas, wo lange Zeit und in mehr als 
                    verhängnisvoller Weise abgestritten wurde, dass ein Schlafmittel für die &#187;bedauerlichen, 
                    aber nur vereinzelt auftretenden Missbildungen von Babies&#171; verantwortlich 
                    sein könnte?
                    <br />
                    <br />
                    Zugegeben, hier gibt es selbstverständlich gravierende Unterschiede im Schweregrad! 
                    Aber ist es nicht immer wieder das gleiche System, wenn einen Verdacht, eine 
                    Substanz könne eventuell die Gesundheit von Verbrauchern beeinträchtigen, immer 
                    wieder zu Gunsten der Hersteller so lange unter den Teppich gekehrt wird, bis 
                    tatsächlich niemand mehr daran vorbei kommt zugeben zu müssen, dass eben doch ein 
                    Zusammenhang nicht mehr von der Hand zu weisen ist?
                    <br />
                    <p> 
                    <a href="blog-2013-12-12" target="_blank">weiterlesen</a>
                    </p>
                    
                    
                    
                    <br />
                    <hr />
                    <a id="blog-2013-11-19">&nbsp;</a>
                    
                    <div class="oneline">
                        <div class="left" style="width: 120px;">
                            <img src="<?php echo IMG_PATH; ?>lebensmitteldatenbank.png" alt="DorisPaas &ndash; Lebensmittel-Datenbank" class="inline" />
                        </div>
                        <div class="left" style="width: 502px;">
                            <p>
                            </p>
                            <p>
                            19.11.2013
                            </p>
                            <h2>
                                DorisPaas.de &ndash; Lebensmittel-Datenbank
                            </h2>
                            <p>
                            Die &#187;DorisPaas.de &ndash; Lebensmittel-Datenbank&#171; ist online!
                            <br />
                            Bitte informieren Sie sich hier: <a href="lebensmittel-datenbank-info" target="_blank">Lebensmittel-Datenbank-Info</a>
                            <br />
                        </div>
                        <br class="cb" />
                    </div>
                    <br style="clear: left;" />
                    
                    
                    
                    
                    <br />
                    <hr />
                    <a id="blog-2013-11-19">&nbsp;</a>
                    <p>
                    <a href="https://www.xing.com/net/pric8b3c9x/nahrungs-intoleranzen/ideen-vorschlage-feedback-322013/mehrere-nahrungsmittel-unvertraglichkeiten-gleichzeitig-was-kann-ich-eigentlich-noch-essen-45526651/45526651/#45526651" target="_blank">Zum Xing-Beitrag vom 19.11.2013</a>
                    </p>
                    <h2>
                        Mehrere Nahrungsmittel-Unverträglichkeiten gleichzeitig &ndash; was kann ich eigentlich noch essen?
                    </h2>
                    <p>
                    
                    Diesen Satz hört und liest man immer häufiger! Denn bei Nahrungsmittel-Unverträglichkeiten 
                    ist es immer das Mittel der Wahl, die unbekömmlichen Lebensmittel weitestgehend zu meiden.
                    <br />
                    <br />
                    Wenn man eine Nahrungsmittel-Unverträglichkeit hat, ist es &#187;relativ einfach&#171;, 
                    sich anhand einer Liste zu orientieren, welche Lebensmittel verträglich sind oder 
                    welche Lebensmittel Probleme verursachen und besser gemieden werden sollten. Es 
                    bleiben immer noch genügend Lebensmittel zur Auswahl, um einen abwechslungsreichen 
                    Speisezettel zusammenstellen zu können.
                    <br />
                    <br />
                    Schwieriger wird es bei zwei Intoleranzen &ndash; und wahrscheinlich gänzlich 
                    unübersichtlich wird es, wenn man an mehreren Unverträglichkeiten leidet. Und 
                    deshalb fragen sich die Betroffenen eben häufig, was denn überhaupt noch möglich 
                    ist, sind wahrscheinlich übervorsichtig und trauen sich kaum noch, irgendetwas 
                    zu essen. Da kann die Auswahl recht schnell eintönig werden, und Demoralisierung 
                    und letztendlich sogar Mangelerscheinungen können die Folge sein.
                    <br />
                    <br />
                    So weit muss es nicht kommen! Ich möchte Ihnen an dieser Stelle die &#187;DorisPaas.de &ndash; 
                    Lebensmittel-Datenbank&#171; vorstellen ...
                    <br />
                    
                    
                    <p> 
                    <a href="blog-2013-11-19" target="_blank">weiterlesen</a>
                    </p>
                    
                    
                    
                    
                    
                    
                    <br />
                    <hr />
                    <a id="blog-2013-10-23">&nbsp;</a>
                    <p>
                        <a href="https://www.xing.com/net/pri969c08x/gesundheitspublizistik/artikel-210138/es-mag-sein-45342576/45342576/#45342576" target="_blank">Xing-Beitrag vom 23.10.2013</a>
                    </p>
                    <h2>
                        &#187;Es mag sein ...&#171;
                    </h2>
                    <p>
                    Es mag sein …
                    <br />
                    <br />
                    Es mag sein, dass der Spiegel in seinem Beitrag über das &#187;Industrieprodukt 
                    Schwein&#171; die Begriffe &#187;Schweinesystem&#171;, &#187;Schlacht-Plan&#171; 
                    und &#187;große Sauerei&#171; ungewollt zweideutig benutzt wurden &ndash; allein, 
                    mir fehlt dazu der Glaube! Diesen sehr empfehlenswerten Artikel in der Ausgabe 43/2013 
                    sollten Sie auf jeden Fall lesen.
                    <br />
                    <br />
                    Es mag sein, dass es ja nach solch drastischen Vergleichen doch den einen oder 
                    anderen eingeFleischten Schweineesser gibt, der danach endlich ans Überlegen kommt 
                    &ndash; das wäre schön!
                    <br />
                    <br />
                    Es mag sein, dass wir Menschen unsere Vorstellungen von einem erfüllten Sexualleben 
                    nicht auf die Tiere übertragen dürfen, die vielleicht künstliche (Zwangs-)Befruchtungen 
                    nicht so empfinden wie wir. Und es mag sein, dass der Zuchteber, der den ganzen 
                    Tag ein so genanntes &#187;Phantom&#171; besteigen darf (muss), sein Leben ganz 
                    toll findet ...
                    </p>
                    
                    <p> 
                    <a href="blog-2013-10-23" target="_blank">weiterlesen</a>
                    </p>
                    
                    
                    
                    <br />
                    
                    <hr />
                    
                    <a id="blog-2013-09-26">&nbsp;</a>
                    
                    <p>
                        <a href="http://www.facebook.com/www.dorispaas.de" target="_blank">Facebookeintrag vom 26.9.2013</a>
                    </p>
                    <h2>
                        &#187;Die Akte Aluminium ... &#171;
                    </h2>
                    <p>
                    Dieser gestern in 3Sat gesendete Film ist absolut empfehlenswert!
                    <br />
                    Wir alle benutzen dieses eigentlich in keinem lebenden Organismus vorkommende Metall 
                    &ndash; sei es in der Küche als Kochgeschirr oder als Verpackungsmaterial. Kaum 
                    ein Joghurt ohne Aludeckel und nicht zu vergessen die Getränkedosen! Es führt so 
                    gut wie kein Weg mehr an diesem Stoff vorbei. Auch als Baumaterial ist Aluminium 
                    überall anzutreffen, bei Gebäuden, Autos, Fahrrädern und vielem mehr. 
                    <br />
                    Aber wussten Sie, dass es auch in Medikamenten, in Cremes, Sonnenschutzpräparaten, 
                    sogar in Deos und diversen weiteren Kosmetika zu finden ist? 
                    <br />
                    Ist doch gut &ndash; oder? Alu hat viele tolle Eigenschaften, und seit der Beimengung 
                    von Aluminium hält das Deo sogar 48 Stunden frisch! Was also ist daran auszusetzen?
                    <br />
                    Forscher haben schon seit längerem herausgefunden, dass Aluminium schädlich im 
                    Organismus wirkt: Fische im Umkreis von Aluminiumwerken sterben, wenn Abwässer in 
                    die Flüsse gelangen, weil das Aluminium die Kiemen blockiert. Die Alzheimer Krankheit 
                    tritt gehäuft bei Menschen auf, die beispielsweise mit Magensäureblockern Aluminium 
                    in erhöhter Menge aufnehmen. Mit Aluminium in Impfstoffen gelangen weitere Alumengen 
                    in den Organismus. Allergien werden gefördert und im Deo sorgt Aluminium für Brustkrebs, 
                    der dann auch noch aggressiver ist und leichter streut, als man es sonst erwarten würde. 
                    <br />
                    Ich möchte Ihnen diesen Film, den man noch in der Mediathek des Senders anschauen 
                    kann, wärmstens empfehlen. Hier erfährt man nicht nur, wie Aluminium gewonnen wird 
                    (und was schon dabei alles passieren kann), sondern auch, welchen Gefahren wir 
                    uns mit dem unüberlegten Gebrauch von Aluminium aussetzen. Selbstverständlich 
                    kommen auch die all das negierenden Lobbyisten zu Worte &ndash; aber das sollte 
                    uns letztendlich &ndash; wie immer &ndash; nur noch mehr bestärken, gut auf uns 
                    selbst auszupassen und zu schauen, welche Möglichkeiten uns zum aufmerksamen und 
                    weitestgehenden Vermeiden bleiben.
                    <br />
                    Meine Deos jedenfalls sind heute Vormittag alle im Müll gelandet und durch alufreie 
                    Alternativen ersetzt worden. Und meinen Joghurt werde ich wieder selbst herstellen 
                    und in Gläsern aufbewahren.
                    <br />
                    Bitte schauen Sie sich diesen Film (52 Min.) an und bilden Sie sich selbst ein Urteil.
                    <br />
                    <br />
                    Herzliche Grüße
                    <br />
                    Doris
                    <br />
                    <br />
                    <a href="http://www.3sat.de/mediathek/?mode=play&obj=38485" target="_blank">zum Film in der 3Sat-Mediathek</a>
                    </p>
                    Da 3Sat den Film leider in der Mediathek nicht mehr anbietet, hier noch ein weiterer Link:
                    <br />
                    <a href="http://trutube.tv/video/3118/Die-Akte-Aluminium" target="_blank">http://trutube.tv/video/3118/Die-Akte-Aluminium</a>
                    <br />
                    <br />
                    
                    
                    
                    
                    <br />
                    
                    <hr />
                    
                    <a id="blog-2013-08-05">&nbsp;</a>
                    
                    <p>
                        <a href="https://www.xing.com/net/pri3b0283x/naturwurst/gesunde-ernahrung-gesundheit-wohlbefinden-305775/mahlzeit-44791026/" target="_blank">Xing-Beitrag vom 5.8.2013</a>
                    </p>
                    <h2>
                        &#187;Mahlzeit!&#171;
                    </h2>
                    <p>
                    ... so titelt der Spiegel in seiner Ausgabe vom 29.7.2013 &ndash; und weiter: 
                    &#187;Die Lebensmittelproduktion ist zu einem globalisierten, hochindustrialisierten 
                    Wirtschaftszweig geworden. Sie bietet kostenoptimierte Waren an, die nur noch 
                    entfernt an Essen erinnern. Die Verbraucher ahnen nichts.&#171;<br />
                    Dieser empfehlenswerte Beitrag führt uns Lesern vor Augen, wie die scheinbar 
                    ach so gesunden, ach so natürlichen &#187;Lebens&#171;mittel in Wirklichkeit 
                    hergestellt werden: Nichts mit handgerührtem Joghurt, dem die buntbeschürzte 
                    und rotwangig-gesunde Bäuerin noch rasch eine Handvoll Erdbeeren hinzufügt. 
                    Und nichts mit den gesunden Kühen, die vor malerischer Kulisse auf der Weise 
                    in unserer schönen Heimat grasen, um uns dann ihre wertvolle Milch zu geben.<br />
                    Alles Lug und Trug, sowohl mit den Erdbeeren als auch mit der Heimat und mit so 
                    vielem anderen!<br />
                    Aus welchen Ländern in der ganzen Welt die meisten Rohstoffe für die 
                    Dinge kommen, die wir als Nahrungs- oder sogar als Lebensmittel im Supermarkt als 
                    regionale Produkte angeboten bekommen und was es mit den Zusatzstoffen mit den 
                    E-Nummern auf sich hat, verrät der Spiegel-Beitrag. Auch, welche wenigen 
                    Firmen den Kuchen unter sich aufteilen und warum eben diese Firmen lieber vorsichtig 
                    mit Informationen über ihre Produktion umgehen und uns Verbraucher über 
                    so vieles im Unklaren lassen.<br />
                    Wir lesen auch, wie es um die Ausstattung mit Lebensmittelkontrolleuren in unserem 
                    Lande aussieht und welche &#187;Sicherheit&#171; uns diese Kontrollen geben können. 
                    Aber glücklicherweise gibt es auch Hinweise für den nicht alles duldenden 
                    Verbraucher, auf welchen Websites er sich über Warnungen und Skandale informieren 
                    kann.<br />
                    übrigens: Eine Sonderseite macht &#187;Appetit&#171; auf die in vielleicht 
                    gar nicht mehr so ferner Zeit in unserer Pfanne bruzzelnden &#187;Burger aus der 
                    Petrischale&#171; &ndash; und wie weit die Forschung in dieser Richtung schon gediehen ist.<br />
                    Insgesamt ist dies  &ndash; wieder einmal &ndash; ein lesenswerter Beitrag, den ich 
                    Ihnen wärmstens empfehlen möchte.
                    </p>
                    <p>
                    Herzliche Grüße<br />
                    Doris Paas
                    </p>
                    
                    <p> 
                    <a href="https://www.xing.com/net/pri3b0283x/naturwurst/gesunde-ernahrung-gesundheit-wohlbefinden-305775/mahlzeit-44791026/" target="_blank">Zum Xing-Beitrag vom 5.8.2013</a>
                    </p>
                    
                    <br />
                    
                    <hr />
                    
                    <a id="blog-2013-07-18">&nbsp;</a>
                    
                    <p>
                        <a href="http://www.facebook.com/www.dorispaas.de" target="_blank">Facebookeintrag vom 18.7.2013</a>
                    </p>
                    <h2>
                        &#187;Unser täglich Gift&#171;
                    </h2>
                    <p>
                    Ein sehr empfehlenswerter Film, der vorgestern in arte ausgestrahlt wurde! Alle 
                    die ihn nicht gesehen haben, können ihn unter diesem Link anschauen: 
                    <a href="http://www.arte.tv/guide/de/sendungen/JT-010705/unser-taglich-gift" target="_blank">Unser täglich Gift</a><br />
                    Das Thema: Wie wirken Chemierückstände aus Pestiziden, Herbiziden und 
                    Fungiziden in unseren Nahrungsmitteln? Wie wirken die diversen Zusatzstoffe, die 
                    in der EU als unbedenklich zugelassen sind? Mit dem ADI-Wert, der die (angeblich) 
                    täglich unbedenkliche Menge EINES Stoffes angibt, ist ja noch keine Aussage 
                    getroffen, denn was macht der Cocktail aller Stoffe zusammen, die wir täglich 
                    zu uns nehmen, mit unserem Körper und unserem Geist?<br />
                    Und welche Stoffe gehen aus den Verpackungen, den Plastikbeschern und -flaschen 
                    in die enthaltenen Nahrungsmittel über, die wir dann aufnehmen?<br />
                    Gibt es einen Zusammenhang dieser Stoffe mit chronischen Krankheiten wie Krebs, 
                    Entzündungen oder Schädigungen des Nervensystems?<br />
                    Wie viel Sorgfalt wird bei der Zulassung der verschiedenen Substanzen aufgewendet, 
                    welche Gesichtspunkte spielen dabei eine Rolle? Wie ist die Verflechtung der Interessen 
                    der Mitglieder der Zulassungsgremien &ndash; dienen diese Wissenschaftler tatsächlich 
                    nur der Wissenschaft oder vielleicht auch der Industrie? Wie transparent sind die 
                    Zulassungsverfahren für die öffentlichkeit?<br />
                    Wie sieht der Zusammenhang zwischen landestypischer Ernähung und Krankheiten in 
                    anderen Ländern (z.B. Indien) aus?<br />
                    Durch diesen sehenswerten Film wurde (wieder einmal) ganz deutlich, dass nur wir 
                    alleine für unsere Gesundheit sorgen können &ndash; weder die Hersteller 
                    noch gar die Nahrungsmittel-Industrie sind an der Gesundheit der Verbraucher interessiert
                    &ndash; einzig allein die eigene Gewinnmaximierung treibt sie an.<br />
                    Machen Sie sich Ihr eigenes Bild &ndash; die knappen 2 Stunden sind eine gut investierte Zeit.
                    </p>
                    
                    <p>
                    Viele Grüße<br />
                    Doris Paas
                    </p>
                    <p>
                        <a href="http://www.facebook.com/www.dorispaas.de" target="_blank">Zum Facebookeintrag vom 18.1.2013</a>
                    </p>
                    
                    <br />
                    
                    <hr />
                    
                    <a id="blog-2013-03-24">&nbsp;</a>
                    
                    <p>
                        24.3.2013
                    </p>
                    <p>
                    ... und wieder ein Beitrag über laktosefreie Produkte &ndash; diesmal auf &#187;<a href="http://www.spiegel.de/gesundheit/ernaehrung/laktosefreie-nahrungsmittel-sind-auch-bei-intoleranz-oft-ueberfluessig-a-886427.html#sp.goto.blogcomment=4104" target="_blank">spiegel-online.de&#171;:</a>
                    </p>
                    <h2 class="upper">
                        <h5>Laktoseunverträglichkeit: Kampf mit dem Milchzucker</h5>
                    </h2>
                    <p>
                    Dieser Beitrag auf spiegel-online enthält viele falsche Behauptungen, die ich nicht so einfach 
                    stehen lassen wollte. Bitte lesen Sie meinen aus Gründen 
                    der Zeichenbeschränkung in zwei Teile gesplitteten Kommentar  
                    &#187;<a href="http://www.spiegel.de/gesundheit/ernaehrung/laktosefreie-nahrungsmittel-sind-auch-bei-intoleranz-oft-ueberfluessig-a-886427.html#sp.goto.blogcomment=4104" target="_blank">Schade &ndash; wieder nichts wirklich Neues</a>&#171;
                    auf spiegel-online (Kommentare Nr. 76 und 77) oder direkt hier:
                    </p>
                    <p>
                    &#187;Es ist schade, dass hier offensichtlich immer wieder einer vom anderen abschreibt, 
                    ohne wirklich einmal selbst korrekt zu recherchieren, bzw. ohne die wirklich 
                    relevanten Tatsachen herauszustellen und den weniger wichtigen den ihnen zustehenden 
                    Stellenwert zuzuweisen. Gerade vom Spiegel hätte ich mir hier Sorgfalt gewünscht.
                    </p>
                    <p>
                    Ja, es ist richtig, dass die meisten Menschen auf der Welt laktoseintolerant sind 
                    und wir hier bei uns &#187;nur&#171; aufgrund einer Genveränderung den Milchzucker 
                    (Laktose) auch noch im Erwachsenenalter vertragen. Somit ist schon einmal 
                    klargestellt, dass weder das eine (Laktosetoleranz) noch das andere (Laktoseintoleranz) 
                    besser oder schlechter ist oder gar einen Krankheitswert hat. Es beschreibt 
                    lediglich eine Eigenschaft &ndash; so wie beispielsweise die braune oder blaue Augenfarbe. 
                    <p>
                    <p>
                        <a href="blog-2013-03-24">Weiterlesen</a>
                    </p>
                    
                    <br />
                    
                    <hr />
                    
                    <a id="blog-2013-03-22">&nbsp;</a>
                    
                    <p>
                        22.3.2013
                    </p>
                    <h2>
                        Heute ist der Weltwassertag
                    </h2>
                    <p>
                    Eigentlich ist es sehr wenig Wasser, was wir täglich zum Trinken und zum Kochen 
                    benötigen: nur etwa 5 Liter. Dazurechnen müssen wir hier bei uns in 
                    Deutschland noch etwa 120 Liter für die persönliche Hygiene, für 
                    die Toilettenspülung und zum Wäschewaschen und Geschirrspülen &ndash; 
                    insgesamt also rund 125 Liter, die wir täglich verbrauchen &ndash; jeder von 
                    uns! Diese Menge wäre eigentlich nicht wirklich kritisch, aber ...
                    </p>
                    <p>
                    Es kommen zu dieser (aus unserer Sicht) kleinen Menge noch Unmengen an Litern 
                    dazu u.a. für die Landwirtschaft, für die Industrie und für unseren 
                    sonstigen Luxus. 
                    </p>
                    <p>
                    Nur ein paar kleine Beispiele, wie viel Wasser wir noch zu dem 
                    o.a. Bedarf hinzurechen müssen: Allein die Herstellung eines Autos erfordert 
                    rund 400.000 Liter sauberes (!) Wasser. Ok, ein Auto kaufen wir nicht jeden Tag 
                    &ndash; es hält im Allgemeinen eine Zeit lang. Die Erzeugung eines 
                    Kilogramm Rindfleisch erfordert 15.000 Liter Wasser. Ja, die meisten von uns essen 
                    auch nicht ein Kilo Rindfleisch pro Tag. Die Herstellung eines Hamburgers jedoch 
                    verbraucht 2.500 Liter Wasser &ndash; überzeugt? Und es gibt Hunderte, nein 
                    Tausende von weiteren Beispielen, die belegen, wie und wo wir Wasser verbrauchen.
                    </p>
                    <p>
                    Auf der anderen Seite stehen viele Milliarden von Menschen auf der Welt, die nicht 
                    einmal die von der UN angegebene Menge von nur 50 Litern sauberes Wasser 
                    täglich zur Verfügung haben, um gesund zu bleiben.
                    </p>
                    <p>
                    Ich bitte uns alle, nicht nur heute am Weltwassertag, sondern immer bei unseren 
                    Handlungen den Wasserverbrauch im Hinterkopf zu behalten und verantwortungsbewusst 
                    mit dieser beileibe nicht uneingeschränkt zur Verfügung stehenden Ressource 
                    achtsam umzugehen. Fangen wir im Kleinen an und sparen dort, wo wir es gleich 
                    erkennen können (z.B. im Haushalt). Fahren wir fort, indem wir uns überlegen, 
                    für welche Nahrungsmittel bei der Erzeugung mehr und für welche weniger 
                    Wasser verbraucht wird und richten unseren Speiseplan vielleicht ein wenig danach aus. 
                    Als Faustregel gilt: die Herstellung tierischer Nahrungsmittel verbraucht mehr Wasser 
                    als die Herstellung pflanzlicher Produkte. 
                    </p>
                    <p>
                    Wenn wir insgesamt unseren Verbrauch an Ressourcen überdenken und etwas 
                    sparsamer sind, können wir alle gemeinsam eine ganze Menge erreichen!
                    </p>
                    <p>
                    Aus Anlass des Weltwassertags möchte ich noch einmal auf meinen 
                    <a href="<?= REQUEST_URI ?>#blog-2013-02-14">Blog-Beitrag vom 14.2.2013</a> aufmerksam machen und Sie alle 
                    dafür sensibilisieren, dass &#187;Wasser und sanitäre Grundversorgung 
                    ein Menschenrecht und keine Handelsware sind!&#171;
                    </p>
                    <p>
                    In diesem Sinne wünsche ich allen Menschen auf dieser Welt nicht nur heute 
                    ausreichend sauberes Wasser.
                    </p>
                    <p>
                    Herzliche Grüße<br />
                    Ihre Doris Paas
                    </p>
                    
                    <br />
                    
                    <hr />
                    
                    <a id="blog-2013-02-26">&nbsp;</a>
                    
                    <p>
                        26.2.2013
                    </p>
                    <br />
                    <h2>
                        Konservierungsstoffe und &ndash;methoden: Gammel ade &ndash; Lebensmittel ohne Verfallsdatum?
                    </h2>
                    <p>
                    Ein meiner Meinung nach sehr empfehlenswerter Beitrag über dieses Thema wurde 
                    am 21.2.2013 in 3Sat ausgestrahlt. In dem Film, der auch nachträglich noch 
                    in der Mediathek aufzurufen ist, erfährt man viel über die Möglichkeiten 
                    der Nahrungsmittelindustrie, verderbliche Lebensmittel haltbar zu machen, welche 
                    Stoffe oder Methoden welche Wirkungen auf den Konsumenten haben (können) 
                    und an welchen Alternativen gearbeitet wird.
                    </p>
                    <p>
                    Es kommt der mir ansonsten eher als radikal bekannte Lebensmittelchemiker Udo 
                    Pollmer zu Worte, der in diesem Beitrag erfreulich sachlich informiert. Und 
                    weiterhin nimmt der Buchautor Hans-Ulrich Grimm (&#187;Vom Verzehr wird abgeraten&#171;) 
                    Stellung zu den Praktiken der Hersteller und vergleicht diese mit den ursprünglichen 
                    Methoden, Mahlzeiten aus frischen Zutaten zuzubereiten.
                    </p>
                    <p>
                    Eine knappe Dreiviertelstunde, die sich absolut lohnt!
                    </p>
                    <p>
                    <a href="http://www.3sat.de/mediathek/index.php?display=1&amp;mode=play&amp;obj=29576" target="_blank">3Sat-Mediathek</a>
                    </p>
                    <p>
                    Ihre Doris Paas
                    </p>
                    
                    <br />
                    
                    <hr />
                    
                    <a id="blog-2013-02-19">&nbsp;</a>
                    
                    <div class="oneline">
                        <div class="left" style="width: 148px;">
                            <img src="<?php echo IMG_PATH; ?>sando.png" alt="Sando Pferd" class="inline" />
                        </div>
                        <div class="left" style="width: 502px;">
                            <p>
                                <a href="http://www.facebook.com/www.dorispaas.de" target="_blank">Facebookeintrag vom 19.2.2013</a>
                            </p>
                            <p>
                                <b>&#187;Ich beziehe Stellung!&#171;</b>
                            </p>
                            <p>
                                Mit Geld spielt man nicht ...
                            </p>
                            <p>
                                dieser Werbespruch einer großen Versicherungsgesellschaft hat sich eingeprägt.
                            </p>
                        </div>
                        <br class="cb" />
                    </div>
                    <br style="clear: left;" />
                    <p>
                    Aber mit der Gesundheit ganzer Völker darf man offensichtlich spielen &ndash; 
                    oder zumindest wird den immer wieder erfolgreichen Versuchen geldgieriger Hersteller 
                    von Nahrungsmitteln (die diese Bezeichnung kaum verdienen) nicht der wirksame 
                    Riegel vorgeschoben. 
                    </p>
                    <p>
                    So wundert es (zumindest mich) wenig, dass Pferdefleischskandale, Dioxinskandale, 
                    Gammelfleischskandale und diverse weitere Skandale nicht abreißen: Jeder 
                    Politiker, der meint, etwas dazu zu sagen zu haben (wie viel das immer auch sei) 
                    &ndash; allen voran die diversen Bundesminister für Ernährung, 
                    Landwirtschaft und Verbraucherschutz &ndash; legen hektischen Aktionismus an den 
                    Tag und verkünden, welche Maßnahmen sie ergreifen werden, damit solchen 
                    Machenschaften ein für alle Mal ein Riegel vorgeschoben wird. 
                    </p>
                    <p>
                        <a href="blog-2013-02-19">Weiterlesen</a>
                    </p>
                    
                    <br />
                    
                    <hr />
                    
                    <a id="blog-2013-02-14">&nbsp;</a>
                    
                    <p>
                        14.2.2013
                    </p>
                    <h2>
                        Wasser als Handelsgut, an dem nur die Reichen teilhaben können?
                    </h2>
                    <p>
                    Nein! Wasser und sanitäre Grundversorgung sind ein Menschenrecht! Wasser ist ein 
                    öffentliches Gut und keine Handelsware!
                    </p>
                    <p>
                    Ich bitte Sie eindringlich, die <b>Europäische Bürgerinitiative</b> mit Ihrer 
                    online-Unterschrift zu unterstützen. 
                    </p>
                    <p>
                    Mit einem Klick auf diesen Link gelangen Sie zu weiteren Informationen und zur 
                    <a href="https://signature.right2water.eu/oct-web-public/index.do?oct_path=%2Fsignup.do&amp;initiativeLang=de&amp;oct_system_state=OPERATIONAL&amp;oct_collector_state=true&amp;currentLanguage=de" target="_blank">online-Aktion</a>.
                    </p>
                    <p>
                    Sollte die Weiterleitung nicht funktionieren, kopieren Sie bitte folgenden Link 
                    in das Adressfeld Ihres Browsers:<br />
                    https://signature.right2water.eu/oct-web-public/index.do?oct_path=%2Fsignup.do&amp;initiativeLang=de&amp;oct_system_state=OPERATIONAL&amp;oct_collector_state=true&amp;currentLanguage=de
                    </p>
                    <p>
                    Ich bedanke mich ganz herzlich.
                    </p>
                    <p>
                    Ihre Doris Paas
                    </p>
                    <p>
                    Einen gleichlautenden Aufruf finden Sie auch auf <a href="http://www.facebook.com/www.dorispaas.de" target="_blank">meiner Facebook-Seite</a>
                    </p>
                    
                    <br />
                    
                    <hr />
                    
                    <a id="blog-2013-01-25">&nbsp;</a>
                    
                    <div class="oneline">
                        <div class="left" style="width: 165px">
                            <a href="http://mahlzeit.tv/videos/laktoseintoleranz-50f3d5b5e80940bd5b000160" target="_blank">
                                <img src="<?php echo IMG_PATH; ?>blog-mahlzeit-tv.png" alt="Blog Mahlzeit-TV" class="inline" />
                            </a>
                        </div>
                        <div class="left" style="width: 485px;">
                            <p>
                                <a href="http://www.facebook.com/www.dorispaas.de" target="_blank">Facebookeintrag vom 25.1.2013</a>
                            </p>
                            <p>
                                Doris Paas proudly presents: 
                            </p>
                            <p>
                                Mein erstes Video.
                            </p>
                        </div>
                        <br class="cb" />
                    </div>
                    <br style="clear: left;" />
                    <p>
                    Dieses Video entstand in Zusammenarbeit mit &#187;Mahlzeit.tv&#171; &ndash; das Thema heißt &#187;Laktose-Intoleranz &ndash; was ist das?&#171;
                    </p>
                    <p>
                    Ihr seid alle herzlich eingeladen, es euch anzuschauen.
                    </p>
                    <p>
                    Viel Spaß und liebe Grüße
                    </p>
                    <p>
                    Doris Paas
                    </p>
                    <p>
                    <a href="http://www.facebook.com/www.dorispaas.de" target="_blank">Zum Facebookeintrag vom 25.1.2013</a>
                    </p>
                    
                    <br />
                    
                    <hr />
                    
                    <a id="blog-2013-01-18">&nbsp;</a>
                    
                    <p>
                    <a href="http://www.facebook.com/www.dorispaas.de" target="_blank">Facebookeintrag vom 18.1.2013</a>
                    </p>
                    <h2>
                        &#187;Studie zur Ermittlung der Wirksamkeit von Probiotika zur Anhebung der Laktose-Toleranzschwelle&#171;
                    </h2>
                    <p>
                    Neben der Möglichkeit bei Laktose-Intoleranz verzehrte Laktose mit 
                    Laktase-Präparaten aufzuspalten und somit bekömmlich zu machen, gibt 
                    es seit einiger Zeit Präparate mit Probiotika, die damit beworben werden, 
                    die Laktose-Toleranzschwelle anheben zu können.
                    </p>
                    <p>
                    Hierzu habe ich in der Zeit von Juli bis Dezember 2012 eine Studie durchgeführt, 
                    um herauszufinden, ob dies tatsächlich eine Alternative zu Laktase-Präparaten 
                    darstellt.
                    </p>
                    <p>
                    Die Auswertung dieser Studie nun erstellt. 
                    <a href="http://www.dorispaas.de/index.php?page=probiotika-studienauswertung" target="_blank">Bitte lest hier das Ergebnis</a>.
                    </p>
                    <p>
                    Ganz ausdrücklich möchte ich mich bei allen bedanken, die sich an dieser Studie 
                    beteiligt haben.
                    </p>
                    <p>
                    Ich hoffe, die gewonnenen Erkenntnisse und das gezogene Fazit hilft allen Menschen 
                    mit Laktose-Intoleranz weiter, die darüber nachdenken ob und ggf. welche 
                    Alternativen es zu der Einnahme von Laktase-Präparaten gibt.
                    </p>
                    <p>
                    Herzliche Grüße<br />
                    Doris Paas
                    </p>
                    <p>
                        <a href="http://www.facebook.com/www.dorispaas.de" target="_blank">Zum Facebookeintrag vom 18.1.2013</a>
                    </p>
                    
                    <br />
                    
                    <hr />
                    
                    <a id="blog-2012-12-24">&nbsp;</a>
                    
                    <p>
                    21.12.2012
                    </p>
                    <h2>
                        Frohe Festtage und einen guten Start in ein gesundes Jahr 2013
                    </h2>
                    <p>
                    Liebe Besucher,
                    </p>
                    <p>
                    Ihnen allen wünsche ich friedliche und besinnliche Festtage und einen guten 
                    Start in ein gesundes Jahr 2013.
                    </p>
                    <p>
                    Auf diesem Wege bedanke ich mich auch ganz herzlich für die vielen wertvollen Gespräche, 
                    Denkanstöße und die offene und wunderbare Kommunikation. Allen Menschen,
                    die mir ihr Vertrauen entgegengebracht und so viele positive Rückmeldungen 
                    und damit Bestätigung gegeben haben, sage ich vielen Dank. Gerne bin ich 
                    auch im kommenden Jahr wieder für Sie da.
                    </p>
                    <p>
                    Ihre Doris Paas
                    </p>
                    
                    <br />
                    
                    <hr />
                    
                    <a id="blog-2012-11-09">&nbsp;</a>
                    
                    <div class="oneline">
                        <div class="left" style="width: 187px">
                            <a href="http://www.ganzheitliche-gesundheitsberatung.de" target="_blank">
                                <img src="<?php echo IMG_PATH; ?>Dopa-Foto.png" alt="Doris Paas" class="inline" />
                            </a>
                        </div>
                        <div class="left" style="width: 463px;">
                            <p>
                                <a href="http://www.facebook.com/www.dorispaas.de" target="_blank">Facebookeintrag vom 9.11.2012</a>
                            </p>
                            <p>
                                Nachdem ich nun seit einigen Jahren Menschen mit Nahrungsmittel-Unverträglichkeiten 
                                berate und mittlerweile mein Spektrum um viele Themen erweitert habe, wurde es 
                                Zeit, eine separate Website für die &#187;Praxis für Ganzheitliche 
                                Gesundheitsberatung und Prävention&#171; ins Netz zu stellen.
                            </p>
                            <p>
                                Deshalb:
                            </p>
                        </div>
                        <br class="cb" />
                    </div>
                    <br style="clear: left;" />
                    <p>
                    Doris Paas proudly presents: <a href="http://www.ganzheitliche-gesundheitsberatung.de" target="_blank">www.ganzheitliche-gesundheitsberatung.de</a>
                    </p>
                    <p>
                    Seid alle ganz herzlich willkommen auf dieser Website &ndash; und natürlich 
                    gerne auch in meiner Beratungspraxis.
                    </p>
                    <p>
                    Liebe Grüße<br />
                    Doris
                    </p>
                    
                    <br />
                    
                    <hr />
                    
                    <a id="blog-2012-10-03">&nbsp;</a>
                    
                    <div class="oneline">
                        <div class="left" style="width: 148px">
                            <a href="http://www.amazon.de/gp/product/380472938X/ref=as_li_qf_sp_asin_tl?ie=UTF8&camp=1638&creative=6742&creativeASIN=380472938X&linkCode=as2&tag=daslaktintobu-21" target="_blank">
                                <img src="<?php echo IMG_PATH; ?>vogelreuter.png" alt="Vogelreuter" class="inline" />
                            </a>
                        </div>
                        <div class="left" style="width: 502px;">
                            <p>
                                <a href="http://www.amazon.de/gp/cdp/member-reviews/A5MX7PXD1ZYMY/ref=cm_cr_pr_auth_rev?ie=UTF8&amp;sort_by=MostRecentReview" target="_blank">Buchrezension bei Amazon.de vom 3.10.2012</a>
                            </p>
                            <p>
                                <b>Dr. Axel Vogelreuter: Nahrungsmittelunverträglichkeiten</b><br />
                                Exzellente Informationen für Fachleute
                            </p>
                        </div>
                        <br class="cb" />
                    </div>
                    <br style="clear: left;" />
                    <p>
                    Auf den ersten Blick mag es irritieren: Kann ein Apotheker wirklich erschöpfend 
                    über Nahrungsmittelunverträglichkeiten informieren? Der zweite Blick, 
                    also der Blick ins gleichnamige Buch, beantwortet diese Frage mit einem eindeutigen 
                    &#187;Ja&#171;. Zumindest gilt dies für den auf dem Rückentext ausgelobten 
                    Adressatenkreis &ndash; für Fachleute wie Berater, Begleiter und Therapeuten, 
                    also für Leser, die bereits umfangreiches Vorwissen mitbringen und sich vor 
                    allem in der durchgängig gebrauchten Verwendung der Fachausdrücke auskennen.<br />
                    </p>
                    <p>
                    <a href="blog-2012-10-03">Weiterlesen</a>
                    </p>
                    
                    <br />
                    
                    <hr />
                    
                    <a id="blog-2012-08-22">&nbsp;</a>
                    
                    <div class="oneline">
                        <div class="left" style="width: 148px">
                            <a href="files/oligosaccharid-unvertraeglichkeit-paas-naturarzt-2012-09.pdf">
                                <img src="<?php echo IMG_PATH; ?>naturarzt.png" alt="Naturarzt" class="inline" />
                            </a>
                        </div>
                        <div class="left" style="width: 502px;">
                            <p>
                                Fachbeitrag: 
                            </p>
                            <p>
                                <b>Oligosaccharid-Unverträglichkeit:<br />
                                Wenn gesundes Essen Beschwerden verursacht</b><br />
                                erschienen in der Zeitschrift &#187;Naturarzt&#171;<br />
                                Ausgabe 9/2012 (22.8.2012)
                            </p>
                        </div>
                        <br class="cb" />
                    </div>
                    <br style="clear: left;" />
                    <p>
                    Immer mehr Menschen haben Probleme nach dem Verzehr bestimmter Lebensmittel. 
                    Bauchschmerzen, Blähungen, Durchfälle oder Verstopfung sind häufige,
                    unliebsame Begleiter ihres Lebens. Eine Reihe von Unverträglichkeiten kann 
                    heute treffsicher diagnostiziert werden. Noch weitgehend unbekannt ist aber die
                    Oligosaccharid-Unverträglichkeit, die eine mögliche Erklärung unklarer 
                    Beschwerden liefert.
                    </p>
                    <p>
                        <a href="files/oligosaccharid-unvertraeglichkeit-paas-naturarzt-2012-09.pdf">Klicken Sie hier, um den kompletten Beitrag zu lesen</a>
                    </p>
                    
                    <br />
                    
                    <hr />
                    
                    <a id="blog-2012-08-18-2">&nbsp;</a>
                    
                    <div class="oneline">
                        <div class="left" style="width: 148px">
                            <a href="http://www.amazon.de/gp/cdp/member-reviews/A5MX7PXD1ZYMY/ref=cm_cr_pr_auth_rev?ie=UTF8&amp;sort_by=MostRecentReview" target="_blank">
                                <img src="<?php echo IMG_PATH; ?>grimm.png" alt="Grimm" class="inline" />
                            </a>
                        </div>
                        <div class="left" style="width: 502px;">
                            <p>
                                <a href="http://www.amazon.de/gp/cdp/member-reviews/A5MX7PXD1ZYMY/ref=cm_cr_pr_auth_rev?ie=UTF8&amp;sort_by=MostRecentReview" target="_blank">Buchrezension bei Amazon.de vom 18.8.2012</a>
                            </p>
                            <p>
                                <b>Hans-Ulrich Grimm: Vom Verzehr wird abgeraten</b><br />
                                Sehr empfehlenswerte Lektüre &ndash; spätestens jetzt wissen wir Bescheid!
                            </p>
                        </div>
                        <br class="cb" />
                    </div>
                    <br style="clear: left;" />
                    <p>
                    Der Titel &#187;Vom Verzehr wird abgeraten&#171; nimmt die Schussfolgerung des Autors 
                    zum Thema schon vorweg und unterstreicht die Gewichtigkeit des Themas. Auch der 
                    Untertitel &#187;Wie uns die Industrie mit Gesundheitsnahrung krank macht&#171; 
                    lädt zum Kauf des Buches ein, und spätestens der Klappentext &#187;Gesunde 
                    Ernährung kann Ihre Gesundheit gefährden &ndash; wenn Sie der Werbung 
                    vertrauen ... &#171; macht den kritischen Konsumenten noch neugieriger. Und er wird 
                    nicht enttäuscht: Das Buch informiert über die diversen Praktiken der 
                    Nahrungsmittelproduzenten, uns mit Gesundheitsversprechen für dumm zu verkaufen.
                    </p>
                    <p>
                        <a href="blog-2012-08-18-2">Weiterlesen</a>
                    </p>
                    
                    <br />
                    
                    <hr />
                    
                    <a id="blog-2012-08-18-1">&nbsp;</a>
                    
                    <p>
                        <a href="http://www.facebook.com/www.dorispaas.de" target="_blank">Facebookeintrag vom 18.8.2012</a>
                    </p>
                    <h2>
                        &#187;Laktose-Intoleranz eine Modeerscheinung? Zeit zu handeln!&#171;
                    </h2>
                    <p>
                    Gestern habe ich einen Vortrag zum Thema &#187;Placebo &ndash; Nocebo&#171; gehört. 
                    Ein guter Vortrag, in dem der Neurologe (selbst ausgewiesener &#187;Schulmediziner&#171;), 
                    dessen Name hier nichts zur Sache tut, eindrücklich geschildert hat, wie 
                    der Placebo- bzw. Noceboeffekt die Wirkung von Medikamenten und/oder Therapien 
                    beeinflussen kann. So weit, so gut.
                    </p>
                    <p>
                    Zur Veranschaulichung des Themas blendete er bei seiner Präsentation auch die 
                    den meisten von uns sicherlich bekannte Karte der Weltverteilung der Laktose-Intoleranz 
                    ein und informierte tatsächlich korrekt über die Entstehung der LI und 
                    auch darüber, dass diese Unverträglichkeit der Normalfall und eben 
                    keine Krankheit ist. Soweit immer noch gut.
                    </p>
                    <p>
                        <a href="blog-2012-08-18-1">Weiterlesen</a>
                    </p>
                    
                    <br />
                    
                    <hr />
                    
                    <a id="mdr-20120823">&nbsp;</a>
                    
                    <div class="oneline">
                        <div class="left" style="width: 148px">
                            <a href="http://www.mdr.de/mediathek/fernsehen/a-z/hauptsachegesund100_letter-H_zc-d2bf5c53_zs-dea15b49.html" target="_blank">
                                <img src="<?php echo IMG_PATH; ?>hauptsache-gesund.png" alt="Hauptsache Gesund" class="inline" />
                            </a>
                        </div>
                        <div class="left" style="width: 502px;">
                            <p>
                                <a href="http://www.mdr.de/mediathek/fernsehen/a-z/hauptsachegesund100_letter-H_zc-d2bf5c53_zs-dea15b49.html" target="_blank">Sendung &#187;Hauptsache gesund&#171; im MDR-Fernsehen am 23.8.2012</a>
                            </p>
                            <p>
                                <b>&#187;Hauptsache gesund &ndash; Milch&#171;</b><br />
                                mit Dr. med Franziska Rubin 
                            </p>
                            <p>
                                Endlich einmal eine empfehlenswerte Sendung im ganzen Milch- und Laktose-Dschungel!
                            </p>
                        </div>
                        <br class="cb" />
                    </div>
                    <br style="clear: left;" />
                    <p>
                    Zugegeben, das Thema dieser Sendung war diesmal nicht, wie bei den ganzen anderen 
                    Sendungen, die derzeit unseren Bildschirm überschwemmen, nur die Laktose-Intoleranz 
                    und die überhöhten Preise der laktosefreien Milchprodukte. 
                    </p>
                    <p>
                    Dieser Beitrag war sehr viel umfassender und beleuchtete die Milch insgesamt.
                    </p>
                    <p>
                    Bitte lesen Sie den <a href="leserbriefmdr20120823">kompletten Kommentar</a>.
                    </p>
                    
                    <br />
                    
                    <hr />
                    
                    <a id="wdr-20120806">&nbsp;</a>
                    
                    <p>
                        <a href="http://www.wdr.de/mediathek/html/regional/2012/08/06/markt_komplett.xml" target="_blank">Sendung &#187;Markt&#171; im WDR-Fernsehen am 6.8.2012</a>
                    </p>
                    <h2>
                        &#187;Laktose: Wenn der Bauch sich bläht&#171;
                    </h2>
                    <p>
                    von Petra Storch 
                    </p>
                    <p>
                    Zu diesem Beitrag habe ich am 22.8.2012 folgenden Kommentar gepostet, den Sie nach 
                    der Freischaltung durch den WDR an 
                    <a href="http://www.wdr.de/mediathek/html/regional/2012/08/06/markt_komplett.xml" target="_blank">gleicher 
                    Stelle</a> lesen können &ndash; bis dato 23.8.2012 &ndash; ist dies leider noch nicht geschehen.
                    </p>
                    <p>
                    Sie können den Kommentar auch <a href="leserbriefwdr20120806">hier</a> aufrufen und lesen.
                    </p>
                    
                    <br />
                    
                    <hr />
                    
                    <a id="facebook20120810">&nbsp;</a>
                    
                    <p>
                        <a href="http://www.facebook.com/www.dorispaas.de" target="_blank">Facebookeintrag vom 10.8.2012</a>
                        <br />
                        zu einem Beitrag in der Zeitschrift Freundin (Ausgabe 6/2012):
                    </p>
                    <h2>
                        &#187;Was kann ich noch essen&#171;
                    </h2>
                    <p>
                    Von Barbara Sonnentag 
                    </p>
                    <p>
                    Der Beitrag in der &#187;Freundin&#171; befasst sich auf 3 Seiten (inkl. 
                    großformatigen Bildern) mit den Nahrungsmittel-Unverträglichkeiten Gluten, 
                    Laktose, Fruktose und Histamin. Augenfällig aufgemachte Prozentzahlen spiegeln 
                    den Tenor des Beitrags: &#187;30% glauben, an einer Nahrungsmittel-Unverträglichkeit 
                    zu leiden, die tatsächlichen Zahlen sind jedoch niedriger.&#171; Und weiter: 
                    &#187;30% reagieren schon auf geringe Mengen Fruktose mit Bauchschmerzen.&#171; 
                    Allein schon diese Teaser zeigen die Ungenauigkeit der Recherche, vor allem aber 
                    die Stoßrichtung dieses Beitrags auf.
                    </p>
                    <p>
                    Vorab: Ich finde es gut, dass immer mehr Medien sich des Themas 
                    &#187;Nahrungsmittel-Unverträglichkeiten&#171; annehmen und versuchen, auch 
                    die Nicht-Betoffenen aufzuklären und bei ihnen Verständnis für die 
                    Probleme zu wecken (die Betroffenen haben sich ohnehin meistens damit befasst und 
                    sind mehr oder weniger informiert).
                    </p>
                    <p>
                        <a href="blog-2012-08-10">Weiterlesen</a>
                    </p>
                    
                    <br />
                    
                    <hr />
                    
                    <a id="tagesspiegel20120806">&nbsp;</a>
                    
                    <p>
                        Tagesspiegel, 6.8.2012:
                    </p>
                    <h2>
                        &#187;Wenn Milch auf den Magen schlägt&#171;
                    </h2>
                    <p>
                    Von Philipp Alvares<br />
                    <i>Rund 15 Prozent der Bevölkerung sind von einer Laktoseintoleranz betroffen. 
                    Der Markt für Spezialprodukte wächst jährlich um rund 20 Prozent. 
                    Doch Experten warnen: Viele Angebote sind teuer &ndash; und überflüssig.</i> <br />
                    <a href="http://www.tagesspiegel.de/weltspiegel/gesundheit/wenn-milch-auf-den-magen-schlaegt/6964588.html" target="_blank">Hier gelangen Sie zu dem Artikel:</a>
                    </p>
                    <p>
                        <b>Kommentar:</b><br />
                    Den Kommentar können Sie auf der gleichen Website lesen, sofern Sie sich dort
                    anmelden und einloggen. Falls Sie keinen Account haben oder keinen erstellen möchten, 
                    können Sie den Kommentar auch hier lesen: <a href="leserbrieftagesspiegel20120806">Bitte klicken Sie hier.</a>
                    </p>
                    
                    <br />
                    
                    <hr />
                    
                    <a id="verbraucherzentrale20120806">&nbsp;</a>
                    
                    <p>
                    Verbraucherzentrale Hamburg, 6.8.2012:
                    </p>
                    <h2>
                        &#187;Weniger Laktose für teuer Geld&#171;
                    </h2>
                    <p>
                    <i>Laktosefreie Lebensmittel sind teuer und in vielen Fällen überflüssig. 
                    Unser Marktcheck ergab, dass von Laktoseintoleranz betroffene Menschen durchschnittlich 
                    2,4-mal so viel für Lebensmittel zahlen müssen, die als laktosefrei deklariert 
                    sind. Und das, obwohl viele Produkte von Natur aus ohnehin gar keinen oder nur 
                    sehr wenig Milchzucker enthalten.</i><br />
                    <a href="http://www.vzhh.de/ernaehrung/257198/weniger-laktose-fuer-teuer-geld.aspx" target="_blank">Hier gelangen Sie zu dem Artikel:</a>
                    </p>
                    <h2>
                        Offener Brief an die Verbraucherzentrale Hamburg
                    </h2>
                    <p>
                    von Laura Camprubi, Stefanie Gieche, Steffi Kochtrotz, Doris Paas und Julia Stüber
                    </p>
                    <p>
                    Sehr geehrte Damen und Herren,
                    </p>
                    <p>
                    mit großem Interesse haben wir Ihren Marktcheck zu laktosefreien Lebensmitteln 
                    gelesen. Wir sind mehrere Bloggerinnen und Autorinnen, die alle selbst von Laktose-Intoleranz 
                    und anderen Allergien und Unverträglichkeiten betroffen sind. Leider finden 
                    wir &ndash; aus Betroffenensicht &ndash;, dass Ihr Artikel an einigen Stellen nicht 
                    hilfreich ist.<br />
                    <a href="leserbriefverbraucherzentrale20120806">Bitte lesen Sie hier weiter:</a>
                    </p>
                    </div>
                </div>
            </div>    
            <br>
            <br> 
            <div class="bodyspacer"></div> 
        </div>