        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br /> 
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>
                <h1 class="header center orange-text">Entspannung</h1>      
            </div>  
        </div> 
        <div class="container">    
            <div class="section">   
                <div class="row margintoprow">        
                    <div class="col s12 m4">
                        <ul class="nav">
                            <li>
                                <b>Abschnitte dieser Seite:</b>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-entspannung#definition">Was ist Entspannung?</b></a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-entspannung#warumentspannung">Warum ist es wichtig, sich zu entspannen?</b></a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-entspannung#stressmanagement">Stressmanagement</b></a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-entspannung#bewegung">Bewegung</b></a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-entspannung#atemtechniken">Atemtechniken</b></a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-entspannung#schlafhygiene">Schlafhygiene</b></a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-entspannung#ernaehrung">Ernährung</b></a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-entspannung#entspannungstechniken">Entspannungstechniken</b></a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-entspannung#beratung">Beratung</b></a>
                            </li> 
                        </ul>
                    </div>
                    <div class="col s12 m8">
                        <img src="<?php echo IMG_PATH; ?>entspannung.png" alt="" class="right" />
                    </div>
                </div>
                <div class="row margintoprow">        
                    <div class="col s12 m12">
                        Was ist das eigentlich &ndash; Entspannung? Wenn wir sagen, wir müssten uns entspannen, 
                        meinen wir nicht nur die Entspannung unserer Muskeln, sondern auch die Entspannung 
                        unseres Nervenkostüms. Beides hängt eng zusammen. Es reicht nicht, nur körperlich 
                        zu entspannen, wir müssen gleichzeitig auch unseren Geist entspannen, um uns 
                        wirklich wohl zu fühlen.
                        <br />
                        <a id="definition"></a>
                        <hr />
                        <h5>Was ist Entspannung?</h5>
                        <hr />
                        Entspannung ist das Gegenteil von Anspannung. Man kann die Muskeln einzelner Körperteile 
                        (z.B. der Arme oder der Hände) anspannen. Lässt man diese Muskeln wieder locker, 
                        entspannt man den entspechenden Körperteil. 
                        <br />
                        <br />
                        Man kann sich aber auch insgesamt angespannt fühlen &ndash; und hier sind es eher 
                        die Nerven, die angespannt und gestresst sind. Stress &ndash; gemeint ist hier der 
                        negative, der sogeannte &#1187;Disstress&#171; &ndash; ist nichts anderes als eine 
                        Anspannung der Nerven, wobei Anspannung hier in übertragenem Sinne gemeint ist, 
                        denn die Nervenfasern an sich sind natürlich nicht wirklich angespannt. 
                        <br />
                        <br />
                        Entspannen kann man sowohl seine Muskulatur als auch seine Nerven, und das Schöne 
                        dabei ist, dass sich das eine auf das andere auswirkt. Sind die Muskeln entspannt, 
                        wirkt dies auch beruhigend auf die nervliche Verfassung. Und wenn wir unseren Geist 
                        entspannen, entkrampfen wir auch unsere Muskeln.
                        <br />
                        <a id="warumentspannung">&nbsp;</a>
                        <hr />
                        <h5>Warum ist es wichtig, sich zu entspannen? </h5>
                        <hr />
                        Im Gegensatz zum Disstress, also dem negativen Stress, ist positiver Stress, der 
                        sogenannte &#187;Eustress&#171;, lebenswichtig. Ohne eine gewisse Anregung könnten 
                        wir nicht leben, uns nicht weiter entwickeln. Erst wenn Körper, Geist und Seele 
                        Impulse aufnehmen, werden wir angeregt und haben Freude am Leben. Eustress ist 
                        unsere Lebenselexier. 
                        <br />
                        <br />
                        Wenn der Druck jedoch zunimmt, und wir diesen nicht mehr als positiv und anregend, 
                        sondern als negativ, belastend und (er)drückend empfinden, wirkt sich Stress 
                        hemmend und gesundheitsschädlich aus. Nicht nur unser Wohlbefinden leidet, Stress 
                        hat auch echte körperliche Folgen, denn jedes unserer Organe wird durch diesen 
                        Stress beeinträchtigt.
                        <br />
                        <br />
                        Für unsere Vorfahren, die noch &#187;echten&#171; Gefahren ausgesetzt waren, waren 
                        diese körperlichen Reaktionen lebenswichtig. Begegnete ihnen eine Gefahr &ndash; 
                        beispielsweise ein Säbelzahntiger, hatten sie nur zwei Möglichkeiten: so schnell 
                        wie möglich weglaufen und sich in Sicherheit bringen oder aber &ndash; sofern sie 
                        gerade Waffen zur Verfügung hatten &ndash; anzugreifen und zu kämpfen. Dazu mussten 
                        lebensrettende Körperfunktionen wie u.a. die Mobilisierung von Kraftreserven 
                        aktiviert werden, unwichtige Funktionen wie z.B. die Verdauung konnten zur 
                        Ressourcenschonung heruntergefahren werden. Für beide Vorgänge sind Stresshormone 
                        erforderlich, die die Organsteuerung übernehmen. Glukose wird aus der Leber freigesetzt, 
                        um die großen (Bein)Muskeln mit Energie zu versorgen, und Atmung und Pulsschlag 
                        werden beschleunigt. Die Versorgung des Gehirns mit Energie wird im Gegenzug 
                        heruntergefahren &ndah; Denkvorgänge sind nicht wichtig, wenn die Hormone die 
                        automatische Steuerung übernehmen. Auch die Verdauung wird verlangsamt, den sie 
                        ist in diesem Moment zum Überleben nachrangig &ndash; die Ernergie wird an anderen 
                        Stellen benötigt. 
                        <br />
                        <br />
                        Die Stresshormone werden durch die körperliche Aktivität (Weglaufen oder Angreifen) 
                        abgebaut, so dass sich die Körperfunktionen normalisieren, sobald die Gefahr vorüber 
                        ist.
                        <br />
                        <br />
                        Glücklicherweise begegnen uns heute keine Säbelzahntiger mehr, aber unser Körper 
                        reagiert noch genauso, wie vor vielen tausend Jahren: Stresshormone werden immer 
                        noch reichlich ausgeschüttet, wenn wir eine Situation als bedrohlich empfinden. 
                        Dies mag z.B. &#187;nur&#171; der schimpfende Chef sein, kann aber auch jede 
                        unnötige Überflutung mit den verschiedensten Reizen und vieles mehr sein. Fatal 
                        ist, dass es keinen guten Eindruck macht, wenn wir vor unserem Chef weglaufen, 
                        und noch viel weniger, wenn wir ihn angreifen. Wir erstarren eher zur Salzsäule 
                        und geben unserem Körper keine Gelegenheit, die ausgeschütteten Stresshormone 
                        durch Bewegung abzubauen.
                        <br />
                        <br />
                        Wenn wir nun abends nach Hause kommen, lähmen die Stresshormone weiter Geist und 
                        Verdauung. Trotzdem haben wir Hunger und plündern den Kühlschrank, um die 
                        Energiereserven aufzufüllen. Insgesamt fühlen wir uns wie gerädert. Die beste 
                        Methode, den Stress abzubauen wäre, eine Runde ums Karree zu joggen oder sich auf 
                        das Fahrrad zu setzen. Leider hindert uns jedoch der mit den Stresshormonen gut 
                        gefütterte, innere Schweinehund daran, und wir fallen aufs Sofa und tun nichts 
                        dergleichen. Die Stresshormone oder deren Reste verbleiben in unserem Körper &ndash; 
                        und wenn sich solche Ereignisse täglich wiederholen, trägt unser Organismus auf 
                        Dauer Schaden davon. Stressbedingte Erkrankungen wir Herzinfarkte, Schlaganfälle, 
                        Übergewicht, Diabetes und viele andere sind die Folgen.
                        <br />
                        <a id="stressmanagement">&nbsp;</a>
                        <hr />
                        <h5>Stressmanagement</h5>
                        <hr />
                        Mit ein wenig Nachdenken können wir viele Stressereignisse vermeiden. Einige aber 
                        lassen sich nicht immer verhindern. Umso wichtiger ist es, Stress zu kompensieren, 
                        um ihn mit einem vernünftigen Stressmanagement unschädlich zu machen. 
                        <br />
                        <br />
                        Je mehr Stress Sie haben und nicht vermeiden können, desto mehr sollten Sie darauf 
                        achten, ihn auf körperlicher und auch auf seelischer Ebene abzubauen.
                        <br />
                        <a id="bewegung">&nbsp;</a>
                        <hr />
                        <h5>Bewegung</h5>
                        <hr />
                        Zuerst einmal sollte man sich so viel wie möglich bewegen, denn Bewegung baut 
                        Stresshormone ab. Suchen Sie sich die zu Ihnen passende Sportart aus, denn Spaß 
                        machen sollte die Bewegung auf jeden Fall. Wird Sport übertrieben oder als gar 
                        Belastung empfunden, erzeugt dies zusätzlichen Stress &ndash; Sie erweisen sich 
                        also einen Bärendienst. Ggf. reicht nach einem stressigen Tag auch ein ausgiebiger 
                        Spaziergang &ndash; das entspannt nicht nur die Muskulatur, Sie können dabei auch 
                        die Seele baumeln lassen und sich mental entspannen.
                        <br />
                        <a id="atemtechniken">&nbsp;</a>
                        <hr />
                        <h5>Atemtechniken</h5>
                        <hr />
                        Ganz wichtig zur Entspannung ist auch das korrekte Atmen. Nicht nur der Brustkorb 
                        ist dabei der Atemraum, wir können auch tief in den Bauch hinein atmen. Dieses 
                        tiefe Luftholen und natürlich auch das sorgfältige Ausatmen versorgt uns zum 
                        einen mit viel lebenswichtigem Sauerstoff. Zum anderen aber fördert es die Durchblutung 
                        aller Muskeln und durch die Aktivität des Zwechfells auch eine gesunde Verdauung. 
                        Nur mit gesundem tiefen Atmen können Stresshormone abgebaut und ausgeschieden und 
                        alle Abfallprodukte unseres Stoffwechsels entsorgt werden.
                        <br />
                        <a id="schlafhygiene">&nbsp;</a>
                        <hr />
                        <h5>Schlafhygiene</h5>
                        <hr />
                        Damit wir uns im Schlaf wirklich entspannen können, müssen einige wichtige Faktoren 
                        berücksichtigt werden. Dies nennt man &#187;Schlafhygiene&#171;.
                        <br />
                        <br />
                        Zuerst einmal benötigen wir <b>ausreichend</b> Schlaf, was jedoch für den einen 
                        ausreichend ist, kann für den anderen bereits zu viel oder aber auch zu wenig sein. 
                        Erwachsene sollten im Schnitt täglich 7-8 Stunden schlafen, um sich regenerieren 
                        zu können. Über- oder unterschreitet man diese Zeitspanne nennenswert und dauerhaft, 
                        kann dies ebenfalls zu Stress führen.
                        <br />
                        <br />
                        Weiterhin sollte das Schlafzimmer <b>gut belüftet</b> sein. Es sollte nicht zu 
                        kalt und nicht zu warm sein &ndash; die optimale Temperatur beträgt im Allgemeinen 
                        zwischen 18 und 19°C.
                        <br />
                        <br />
                        <b>Bett und Bettzeug</b> müssen ebenfalls den Bedürfnissen angepasst sein: Sowohl 
                        eine zu harte als auch eine zu weiche Unterlage sind nicht schlafförderlich. Auch 
                        Kissen und Decke sollten als angenehm empfunden werden &ndash; weder zu warme noch 
                        zu dünne Decken und Kissen sind schlafförderlich. Die Bezüge müssen ausreichend 
                        Schweiß aufsaugen &ndash; Naturfasern ist hier auf jedem Fall der Vorzug vor 
                        Kunstfasern zu geben.
                        <br />
                        <br />
                        Das Schlafzimmer sollte möglichst <b>weitgehend abgedunkelt</b> sein, um den 
                        natürlichen Schlaf-/Wachrhythmus nicht zu beeinträchtigen.
                        <br />
                        <br />
                        Auch sollte dafür gesorgt sein, so <b>ungestört</b> wie möglich zu schlafen. Wenn 
                        Sie die Wahl haben, stellen Sie Ihr Bett im ruhigsten Raum in der Wohnung auf. 
                        Wenn Sie kleine Kinder haben, lassen sich nächteliche Störungen natürlich nicht 
                        immer vermeiden &ndash; suchen Sie hier nach möglichst guten  Lösungen.
                        <br />
                        <br />
                        Schließen Sie den Tag auch mental ab, d.h. lassen Sie noch einmal Revue passieren, 
                        was Sie den Tag über geleistet und erledigt haben. Versuchen Sie ggf., Probleme 
                        nicht mit in die Nacht zu nehmen, sondern (gedacht oder vielleicht sogar real) 
                        in einen Korb neben dem Bett zu legen. Am nächsten Morgen können Sie das Problem 
                        wieder herausnehmen und bearbeiten &ndash; sofern es sich nicht über Nacht von 
                        alleine gelöst hat.
                        <br />
                        <a id="ernaehrung">&nbsp;</a>
                        <hr />
                        <h5>Ernährung</h5>
                        <hr />
                        Ganz wichtig für einen enspannten Körper und Geist ist auch die richtige Ernährung. 
                        Was aber ist <b>richtig für Sie</b>? Nicht jeder verträgt alles, manche Menschen 
                        haben Probleme mit bestimmten Nahrungsmitteln. Achten Sie Darauf, möglichst viele 
                        &#187;<b>gesunde Lebensmittel</b>&#171; zu verzehren, aber beachten Sie auch Ihre individuellen 
                        Erfordernisse.
                        <br />
                        <br />
                        Am einfachsten beherzigen Sie folgende Faustregel: &#187;Je frischer und unverfälschter 
                        ein Lebensmittel ist, desto gesünder ist es&#171;.
                        <br />
                        <br />
                        <b>Die letzte, leichte Mahlzeit</b> sollte möglichst spätestens 3 Stunden vor 
                        dem Schlafengehen eingenommen werden, denn mit vollem Bauch schläft man unruhiger.
                        <br />
                        <a id="entspannungstechniken">&nbsp;</a>
                        <hr />
                        <h5>Entspannungstechniken</h5>
                        <hr />
                        Um Körper und Nerven zu entspannen, eigenen sich nicht nur alle oben angeführten 
                        Maßnahmen. Manchmal können spezielle Entspannungstechniken hilfreich sein, Stress, 
                        der sich nicht vermeiden lässt, zu kompensieren. Hier eignen sich vor allem  
                        &#187;Autogenes Training&#171;, die &#187;Progressive Muskelentspannung&#171; nach 
                        Jacobson, aber auch Joga, Meditation spezielle Atemtechniken und vieles mehr. 
                        Schauen Sie z.B. einmal in das Programm der Volkshochschule in Ihrer Nähe, dort 
                        werden zu den meisten Entspannungsmethoden Kurse angeboten. Nachdem Sie vielleicht 
                        in die eine oder andere Methode hineingeschnuppert und sie erlernt haben, können 
                        Sie dann für sich zu jedem geeigneten Termin gezielt entspannen.
                        <br />
                        <br />
                        <hr>
                        <a id="beratung">&nbsp;</a>
                        <div class="row">
                        <div class="col s12 m2">
                            <a href="http://www.ganzheitliche-gesundheitsberatung.de" target="_blank">
                                <img src="<?php echo IMG_PATH; ?>praxiswebsite.png" alt="" class="inline" /></a>
                        </div>
                        </div>
                        <div class="row">
                        <div class="col s12 m12">
                        <h5>Beratung</h5>
                        <br />
                            Gerne biete ich Ihnen eine individuelle Beratung an &ndash; 
                            auf Wunsch auch telefonisch oder per Skype.
                            <br />
                            Bitte informieren Sie sich auf meiner Praxis-Website <a href="http://www.ganzheitliche-gesundheitsberatung.de" target="_blank">&#187;www.Ganzheitliche-Gesundheitsberatung.de&#171;</a>
                        </div>
                        </div>
                        <hr>
                        Lesen Sie auch folgende Betr&auml;ge:
                        <br />
                        <a href="ganz-gesund" target="_blank">&#149; Ganzheitliche Gesundheit</a>
                        <br />
                        <a href="ganz-saeulenmodell" target="_blank">&#149; Die Säulen der Ganzheitlichen Gesundheit</a>
                        <br />
                        <hr />
                        <a href="javascript: scrollMainToTop();" class="nachoben">nach oben</a>
                    </div>
                </div>
            </div>    
            <br>
            <br> 
            <div class="bodyspacer"></div> 
        </div>