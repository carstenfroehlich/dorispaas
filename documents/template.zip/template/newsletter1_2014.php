        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br /> 
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>
                <h1 class="header center orange-text">DorisPaas-Newsletter</h1>      
            </div>  
        </div> 
        <div class="container">    
            <div class="section">   
                <div class="row margintoprow">        
                    <div class="col s12 m12">
                        <b>Ausgabe 1/2014 (Januar 2014)</b>
                        <br />
                        ----------------------------------------------------------------------------------
                        <br />
                        <br />
                        Liebe Leserin, lieber Leser.
                        <p>
                        Ich w&uuml;nsche Ihnen einen guten Start in das neue Jahr 2014 und ... Ja, 
                        wenn Sie sich selbst entscheiden d&uuml;rften oder aber Ihre Verwandten, Freunde 
                        und Bekannten fragen, welche W&uuml;nsche ganz oben 
                        auf der Liste stehen, so wird mit Sicherheit in den allermeisten F&auml;llen der Wunsch 
                        nach Gesundheit genannt werden. Wenn sich die Menschen derzeit 
                        gesund f&uuml;hlen, ist es der Wunsch nach einer robusten, dauerhaften Gesundheit. 
                        Und wenn sie an Krankheiten leiden, ist es der Wunsch nach mehr Gesundheit und 
                        einer besseren Lebensqualit&auml;t.
                        <br />
                        <br />
                        W&uuml;nschen k&ouml;nnen wir uns die Gesundheit sicherlich, aber ob ein solcher Wunsch so einfach 
                        ohne unser Zutun in Erf&uuml;llung geht, bleibt dahingestellt. Wir k&ouml;nnen aber selbst 
                        sehr viel dazu beitragen, ob wir gesund sind, bleiben oder gesund oder ges&uuml;nder 
                        werden. 
                        <br />
                        <br />
                        <hr>
                        <br />
                        <b>&#149;	<a href="http://www.dorispaas.de/index.php?page=ganz-saeulenmodell" target="_blank">Die S&auml;ulen der ganzheitlichen Gesundheit</a></b>
                        <br />
                        Nat&uuml;rlich sind die landl&auml;ufig bekannten Mittel wie Abh&auml;rtung 
                        und gesundes Essen wichtige S&auml;ulen f&uuml;r unsere Gesundheit, sie reichen 
                        aber bei weitem nicht aus! Es gibt noch viele andere Bausteine, die alle 
                        zusammen dazu beitragen, dass wir gesund bleiben oder wieder gesund werden. 
                        Welche Ma&#223;nahmen dies sind, lesen Sie in diesem Beitrag<br />
                        <br />
                        <hr>
                        <br />
                        <b>&#149;	<a href="http://www.dorispaas.de/index.php?page=ganz-gaergetraenke" target="_blank">Probiotische G&auml;rgetr&auml;nke</a></b>
                        <br />
                        Einen Vorschlag zur St&auml;rkung Ihres Immunsystems, das zu einem gro&#223;en Teil 
                        f&uuml;r eine robuste Gesundheit mitverantwortlich ist, habe ich hier gleich 
                        f&uuml;r Sie: Bereiten Sie sich doch mal ein probiotisches G&auml;rgetr&auml;nk 
                        wie Kefir oder Kombucha zu. Die k&auml;uflichen Produkte dieser Art haben l&auml;ngst 
                        nicht so viele wertvolle Inhaltsstoffe wie ein selbst herstelltes Getr&auml;nk.
                        Hier finden Sie nicht nur Informationen &uuml;ber probiotische G&auml;rgetr&auml;nke,
                        sondern auch gleich die Rezepte.
                        <br />
                        <br />
                        <hr>
                        <br />
                        <b>&#149;	<a href="http://www.dorispaas.de/index.php?page=blog" target="_blank">Blog</a></b>
                        <br />
                        Kennen Sie eigentlich meinen Blog? Nicht, dass ich mich an dieser Stelle verpflichtet 
                        sehe, jeden Tag etwas einzutragen! Aber es gibt doch &ouml;fters Gelegenheiten, 
                        an denen ich mich &ouml;ffentlich zu Ern&auml;hrungs- oder Gesundheitsthemen &auml;u&#223;ere
                        &ndash; und diese Ver&ouml;ffentlichen in den verschiedendsten Medien fasse ich 
                        hier zusammen. Schauen Sie doch einmal in den Blog, mit Sicherheit sind auch 
                        f&uuml;r Sie interessante Themen dabei.
                        <br />
                        <br />
                        <hr>
                        <br />
                        &#149;	S&auml;mtliche neuen Beitr&auml;ge finden Sie immer unter dem Button 
                        &#187;<a href="http://www.dorispaas.de/index.php?page=news" target="_blank">neueste Betr&auml;ge</a>&#171; 
                        in der Seiten-Navigation.
                        <br />
                        &#149;	Den besten &Uuml;berblick &uuml;ber die kompletten Inhalte auf www.DorisPaas.de 
                        finden Sie in der <a href="http://www.dorispaas.de/sitemap-html" target="_blank">Sitemap</a> 
                        in der Seiten-Navigation.
                        <br />
                        <br />
                        <hr>
                        <br />
                        Noch einmal w&uuml;nsche ich Ihnen alles Gute und einen gesunden Winter.
                        Dazu empfehle ich Ihnen u.a. bei jedem Wetter einen t&auml;glichen Spaziergang, auch wenn 
                        wir offensichtlich derzeit keine zuverl&auml;ssigen Prognosen abgeben k&ouml;nnen, 
                        ob wir noch Schnee bekommen oder schon jetzt den Fr&uuml;hling begr&uuml;&#223;en 
                        d&uuml;rfen.  
                        <br />
                        <br />
                        Bis zum n&auml;chsten Newsletter, den Sie in zwei Monaten, also etwa Mitte M&auml;rz 2014 erhalten, sende ich Ihnen ganz herzliche Gr&uuml;&#223;e aus dem Rheinland 
                        <br />
                        <br />
                        Ihre
                        <br />
                        Doris Paas
                        </p>
                        Gerne k&ouml;nnen Sie diesen Newsletter auch an Freunde und Bekannte weiterleiten!
                        <p>
                    </div>
                </div>
            </div>    
            <br>
            <br> 
            <div class="bodyspacer"></div> 
        </div>