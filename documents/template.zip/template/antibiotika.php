        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br /> 
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>
                <h1 class="header center orange-text">Antibiotika </h1>      
                    <div class="row center">        
                    <h5 class="header col s12 light">und Darmgesundheit</h5>      
                    </div>     
            </div>  
        </div> 
        <div class="container">    
            <div class="section">   
                <div class="row margintoprow">        
                    <div class="col s12 m4">
                        <ul class="nav">
                            <li>
                                <b>Abschnitte dieser Seite:</b>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>antibiotika#bakterien">Gute und schlechte Bakterien</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>antibiotika#antibiotikagruppen">Antibiotikagruppen</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>antibiotika#tiermast">Antibiotika in der Tiermedizin und -mast</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>antibiotika#auswirkungen">Auswirkungen von Antibiotika auf unsere Gesundheit</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>antibiotika#fakten">Daten und Fakten</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>antibiotika#wannerforderlich">Wann sind Antibiotika erforderlich?</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>antibiotika#alternativen">Alternativen zu Antibiotika</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>antibiotika#imernstfall">Was tun im Ernstfall?</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>antibiotika#vorbeugung">Was können wir vorbeugend tun?</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>antibiotika#fazit">Fazit</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>antibiotika#beratung">Beratung</a>
                            </li> 
                            <li>
                                <a href="guterrat" target="_blank">War dieser Beitrag hilfreich für Sie?</a>
                            </li> 
                        </ul>
                    </div>
                </div>
                <div class="row margintoprow">        
                    <div class="col s12 m12">
                        <img src="<?php echo IMG_PATH; ?>antibiotika.png" alt="" class="right" />
                        Die Entdeckung des Penicillins durch Alexander Fleming im Jahr 1928 war ein Segen: 
                        konnten doch bakterielle Infektionen, die nicht selten mit dem Tod endeten, mit 
                        diesem Medikament nun wirksam bekämpft werden.
                        <br />
                        <br />
                        Dieses erste, aus einem Schimmelpilz gewonnene Antibiotikum hat mittlerweile 
                        zahlreiche verschiedene Nachfolger erhalten. Die Pharmafirmen stellen viele 
                        Antibiotika her, die zum Teil recht speziell gegen einen bzw. wenige Erreger 
                        wirken oder aber als sogenannte Breitbandantibiotika eine große Streuwirkung 
                        gegen sehr viele Bakterienarten entwickeln.
                        <br />
                        <br />
                        Der Name Antibiotikum ergibt sich aus den griechischen Begriffen &#187;anti&#171; 
                        (gegen) und &#187;bios&#171; (Leben), was die Wirkung verdeutlicht: Antibiotika 
                        richten sich gegen lebende Keime und töten sie ab. Dabei wird nicht immer 
                        unterschieden, ob es sich um krankheitserregende Keime handelt oder aber vielleicht 
                        auch um nützliche Bakterienstämme. 
                        <br />                    
                        <a id="bakterien"></a>
                        <hr>
                        <h5>Gute und schlechte Bakterien</h5>
                        <hr>
                        Unser Körper ist auf den gesamten Körperoberflächen wie der uns umhüllenden Haut, 
                        den Schleimhäuten in Lunge, Blase, Urogenitaltrakt und den Verdauungstrakt vom 
                        Mund durch Magen und Darm von Bakterien besiedelt. Die meisten davon sind sehr 
                        nützlich für uns: Sie schützen unsere Haut und Schleimhäute und unser Verdauungssystem 
                        allein durch ihre Präsenz und Masse vor der Besiedelung mit schädlichen Krankheitserregern 
                        und hindern sie so am Eindringen ins Körperinnere. Diesen Mechanismus nennt man 
                        Kolonisationsresistenz. Je mehr Plätze durch nützliche Bakterien besetzt sind, 
                        desto weniger Platz ist für schädliche Krankheitserreger, die sich so kaum fortpflanzen 
                        können. Darüber hinaus helfen uns die Bakterien, die im Darm &#187;wohnen&#171; 
                        (Darmflora, intestinale Mikrobiota oder Mikrobiom), bei der Verdauung ansonsten 
                        nicht nutzbarer Nahrungsbestandteile. Auch unser Immunsystem und somit unsere 
                        Gesundheit ist zum allergrößten Teil von einer intakten Darmflora abhängig. 
                        <br />
                        <br />
                        In einem so genannten &#187;Mausmodell&#171;, in dem man die Darmflora von Mäusen 
                        komplett vernichtet hatte, waren die Tiere nicht mehr lebensfähig und starben 
                        schon nach kurzer Zeit. Natürlich ist das Mausmodell nicht 1:1 auf den Menschen 
                        übertragbar. Tatsache ist aber, dass eine &#187;schlechte&#171; Darmflora immer 
                        auch für mehr oder weniger schwere Erkrankungen (mit)verantwortlich ist.
                        <br />
                        <br />
                        Diese Nützlinge gilt es zu pflegen und zu erhalten &ndash; das Abtöten durch 
                        Antibiotika hätte fatale Folgen und auch schon das Entgleisen der gesunden Balance 
                        zwischen &#187;gut&#171; und &#187;böse&#171; kann die Entstehung ernster Erkrankungen
                         begünstigen. Wegen der Bedeutung der Qualität unserer Darmflora sollen im Folgenden 
                         die Wirkungen von Antibiotika insbesondere im Hinblick auf den Einfluss auf die 
                         Darmflora betrachten werden.
                        <br />
                        <a id="antibiotikagruppen">&nbsp;</a>
                        <hr>
                        <h5>Antibiotikagruppen</h5>
                        <hr>
                        Jedes Antibiotikum hat seine ganz eigenen Einsatzgebiete: Ist der Krankheitserreger 
                        bekannt, kann auch ein ganz spezielles Antibiotikum gegen genau diese Keimgruppe 
                        eingesetzt werden mit dem Vorteil, dass die meisten anderen Bakterienarten so 
                        weit wie möglich geschont werden. Es lässt sich jedoch nicht vermeiden, dass auch 
                        hier immer die guten Bakterien zu einem gewissen Grad beeinträchtigt werden. 
                        <br />
                        <br />
                        Ist der Krankheitserreger nicht bekannt oder nimmt sich ein behandelnder Arzt 
                        nicht die Zeit, den Erreger zuvor mit geeigneten Tests zu bestimmen, werden 
                        Breitbandantibiotika verschrieben, die nach &#187;Rasenmähermanier&#171; möglichst 
                        viele Bakterienspezies abtöten bzw. dezimieren. Gerade diese Mittel aber verschlechtern 
                        besonders drastisch die Balance unserer Darmflora, denn die Schädlinge sind meist 
                        wesentlich robuster als die nützlichen Keimarten, die oft eher &#187;kleine 
                        Sensibelchen&#171; sind.
                        <br />
                        <br />
                        In manchen Fällen lässt sich die Gabe von Breitbandantibiotika nicht vermeiden, 
                        und wir sollten auch für diese Präparate dankbar sein. Oftmals ist es aber klüger, 
                        zuerst einmal den Keim zu identifizieren und dann ein Mittel mit einem engeren 
                        Wirkspektrum zu verschreiben, das dann auch pfleglicher mit unserer Darmflora umgeht.
                        <br />
                        <a id="tiermast">&nbsp;</a>
                        <hr>
                        <h5>Antibiotika in der Tiermedizin und -mast</h5>
                        <hr>
                        Auch in der Tierwelt werden Antibiotika verwendet &ndash; teils, um Krankheiten 
                        zu heilen, die sich logischerweise insbesondere in der Massentierhaltung unter 
                        den auf engstem Raum zusammengepferchten Lebewesen rasant verbreiten können. Zum 
                        anderen Teil werden sie auch gerade in diesen Haltungsbetrieben vorbeugend 
                        eingesetzt, um Krankheiten erst gar nicht entstehen zu lassen. Bei einer artgerechten 
                        Haltung, in der die Tiere genügend Platz haben und die erforderlichen Lebensbedingungen 
                        erhalten, können sich Krankheitserreger nur sehr viel schwerer und langsamer verbreiten. 
                        Demzufolge ist hier ein prophylaktischer Antibiotika-Einsatz überhaupt nicht erforderlich.
                        <br />
                        <br />
                        Es gibt ein weiteres Anwendungsgebiet von Antibiotika, nämlich als Mastförderungsmittel. 
                        Sie können wachstumsfördernd wirken und die Darmflora eines Tieres dahingehend 
                        verändern, dass die Entwicklung von Spezies gefördert wird, die auch noch eigentlich 
                        unverdauliche Nährstoffreste verarbeiten. So wird dem Stoffwechsel des Tieres mehr 
                        Energie verfügbar gemacht, und die Tiere werden größer und schwerer. Der Einsatz von 
                        Antibiotika als Mastmittel ist zwar eigentlich vom Gesetzgeber verboten, wird aber 
                        von den &#187;Fleischerzeugern&#171; flugs als Infektionsprophylaxe deklariert, 
                        so dass Gesetze ausgehebelt und der für die Hersteller angenehme Nebeneffekt der 
                        Gewinnmaximierung genutzt werden kann. Hierbei ist es unerheblich, ob es sich um 
                        Rind-, Schwein- oder Geflügelfleisch oder auch um Fisch aus so genannten Fischfarmen 
                        oder Aquakulturen handelt. 
                        <br />
                        <br />
                        Dass diese Substanzen auch nach dem Schlachten im Fleisch verbleiben und wir als 
                        Konsumenten dadurch ständig &ndash; wenn auch zugegebenermaßen nur in sehr kleinen 
                        Mengen &ndash; Antibiotika mit der Nahrung zu uns nehmen, wird dabei billigend in 
                        Kauf genommen. 
                        <br />
                        <a id="auswirkungen">&nbsp;</a>
                        <hr>
                        <h5>Auswirkungen von Antibiotika auf unsere Gesundheit</h5>
                        <hr>
                        Durch die ständige Kontaminierung kommt unsere Darmflora je nach Art und Menge 
                        der verzehrten Nahrung fortgesetzt mit Antibiotika in Kontakt &ndash; und wie 
                        bereits erwähnt, sind es hier gerade die sensiblen nützlichen Darmbakterien, denen 
                        dadurch in unserem inneren Ökosystem das (Über)Leben schwer gemacht wird. Kein 
                        Wunder also, dass zahlreiche Krankheiten immer mehr zunehmen, weil unser eigenes 
                        Immunsystem nicht mehr richtig funktionieren kann. Diverse Erkrankungen werden 
                        wahrscheinlich sogar durch eine desolate Darmflora überhaupt erst verursacht &ndash; 
                        wie derzeit in vielen Studien bewiesen werden soll und sicherlich wird.
                        <br />
                        <br />
                        Fatal ist auch, dass sich gerade die schädlichen Darmkeime an die Antibiotika 
                        gewöhnen und so genannte Resistenzen entwickeln können. Dies bedeutet, dass einige 
                        dieser Keime nicht mehr auf Antibiotika ansprechen und mit diesen Mitteln behandelt 
                        werden können. Die Medizin hat zwar viele verschiedene antibiotische Substanzen 
                        zur Verfügung, es gibt aber heute schon einige multiresistente Keime, die auf gar 
                        keine Antibiotikagruppen mehr reagieren. Das ist verhängnisvoll für all jene 
                        &ndash; vor allem ältere &ndash; Menschen, deren Organismus bereits von Vorerkrankungen 
                        geschwächt ist und sich nicht mehr aus eigener Kraft gegen diese Keime wehren 
                        kann. Die Forschung bemüht sich zwar, immer neue Stoffe zu entwickeln, die auch 
                        diese Keime bekämpfen können, aber leider sind die Bakterien, die ja immerhin 
                        die älteste Lebensform auf unserer Erde sind, unseren Wissenschaftlern immer eine 
                        Nasenlänge voraus. Mindestens ebenso schnell, wie neue Substanzen gefunden werden, 
                        entwickeln die verschiedenen Keime auch gegen diese Stoffe Mechanismen, um (uns) 
                        zu überleben.
                        <br />
                        <a id="fakten">&nbsp;</a>
                        <hr>
                        <h5>Daten und Fakten</h5>
                        <hr>
                        Bitte lassen Sie sich einige Daten auf der Zunge zergehen, die Auskunft über den 
                        Verbrauch von Antibiotika geben:
                        <br />
                        <br />
                        <b>&#149;</b> Allein für Deutschland wird der jährliche Verbrauch von Antibiotika in den 
                        verschiedenen Quellen mit 1.000 bis sogar 2.300 Tonnen angegeben. Etwas mehr als 
                        die Hälfte davon entfällt dabei auf die Humanmedizin, der Rest auf die Tiermedizin 
                        und -mast. Die Mengenangaben in Literatur und seriösen Internetbeiträgen schwanken 
                        naturgegeben stark, denn oftmals werden Schätzwerte mit einbezogen, die die hohe 
                        Dunkelziffer ausgleichen sollen. Nachprüfbar ist dies ohne größeren Aufwand nicht, 
                        die Größenordnungen allein reichen aber durchaus, um uns das Fürchten zu lehren! 
                        <br />
                        <br />
                        <b>&#149;</b> Weltweit wurden lt. einer Studie der Tierschutzorganisation PETA (People for the 
                        Ethical Treatment of Animals) im Jahr 2010 insgesamt 63.000 Tonnen Antibiotika 
                        in der Tierzucht und -mast verwendet! 
                        <br />
                        <br />
                        <b>&#149;</b> Ebenfalls von PETA stammt die Angabe, dass im Jahr 2015 bei der Produktion eines 
                        jeden Kilogramm Fleisch 172 mg Medikamente verwendet wurden!
                        <br />
                        <br />
                        <b>&#149;</b> Noch einmal zur Erinnerung: Ein Teil dieser Tausenden von Tonnen bei der Produktion 
                        verwendeten Antibiotika verbleibt nach dem Schlachten im Fleisch, und wir verzehren 
                        sie mit unserer täglichen Nahrung. Sie gelangen in unser Verdauungssystem, so 
                        dass die Darmflora ständig damit kontaminiert wird!
                        <br />
                        <a id="wannerforderlich">&nbsp;</a>
                        <hr>
                        <h5>Wann sind Antibiotika erforderlich? </h5>
                        <hr>
                        In vielen Fälle ist es &ndash; und hier spreche ich jetzt von der Humanmedizin 
                        &ndash; überhaupt nicht erforderlich oder sogar regelrecht falsch, ein Antibiotikum 
                        zu verabreichen. Leider immer noch viel zu häufig sind es Ärzte, die für eine 
                        detaillierte Diagnose zu wenig Sorgfalt walten lassen &ndash; sei es aus Zeitgründen 
                        oder aber auch, weil die Vergütungspraxis der Krankenkassen ein solches Verhalten 
                        begünstigt. Oftmals ist es aber auch der Patient selbst, der voreilig darauf 
                        drängt, ein antibiotisches Medikament verschrieben zu bekommen. 
                        <br />
                        <br />
                        In der heutigen Arbeitswelt, deren Klima immer rauer wird, sehen sich Arbeitnehmer 
                        bedauerlicherweise oft gezwungen, sich nicht die Ruhe zu gönnen, die der erkrankte
                        Körper unmissverständlich einfordert, und gehen trotz Erkältungserkrankungen weiter 
                        zur Arbeit. Zuvor erbitten sie beim Arzt schnellste Hilfe und bedrängen den Mediziner, 
                        ihnen Antibiotika zu verschreiben. Dass sie damit die Heilung in der Regel kaum 
                        beeinflussen können, ist den wenigsten bewusst. Und darüber, dass sie &ndash; 
                        abgesehen von der Ansteckungsgefahr für ihre Arbeitskollegen &ndash; ihrem Körper 
                        einen Bärendienst erweisen, weil die Darmflora geschädigt und damit das Immunsystem 
                        beeinträchtigt wird, wissen auch nur wenige Bescheid.
                        <br />
                        <br />
                        Die allermeisten Erkältungserkrankungen werden durch Viren verursacht, und gegen 
                        Viren kann kein Antibiotikum etwas ausrichten. Erst, wenn sich zusätzlich zu den 
                        viral hervorgerufenen Erkrankungen bakterielle Besiedelungen (beispielsweise in 
                        Form von vereiterten Rachenmandeln) gesellen, ist eine Antibiose sinnvoll, wenngleich 
                        auch hier nicht immer sofort erforderlich. Auch in solchen Fällen kann man manchmal 
                        abwarten, ob sanftere Mittel und Maßnahmen nicht auch zu einem Abheilen führen.
                        <br />
                        <br />
                        Es gibt &ndash; wie bereits oben erwähnt &ndash; Erkrankungen, bei denen eine 
                        Antibiose lebensrettend und unumgänglich ist. Jede bakteriell hervorgerufene 
                        Lungenentzündung, Blinddarmentzündungen und viele andere Erkrankungen, an denen 
                        man vor der Entdeckung des Penicillins noch sehr häufig starb, sind heute mit einem 
                        Antibiotikum relativ leicht zu heilen. Auch bei vielen Operationen &ndash; 
                        insbesondere großen Bauch- oder Herz-OPs oder auch bei dem Einsatz von Endoprothesen 
                        wie z.B. einem künstlichen Hüftgelenk &ndash; kann es sinnvoll sein, sogar vorbeugend 
                        Antibiotika zu verabreichen, so dass sich schwerwiegende Infektionen gar nicht 
                        erst entwickeln können.
                        <br />
                        <br />
                        Bitte beraten Sie sich immer mit Ihrem Arzt, der diese verschreibungspflichtigen 
                        Medikamente ohnehin verordnen muss &ndash; ob und wann die Einnahme eines Antibiotikums 
                        erforderlich ist oder eben auch nicht. Sie dürfen und sollten eine solche Verordnung 
                        durchaus kritisch hinterfragen.
                        <br />
                        <br />
                        Und nicht nur Art und Wirkspektrum des Antibiotikums sollten ggf. klug ausgewählt 
                        werden, es sollte auch geprüft werden, ob ein solches Medikament nicht örtlich 
                        angewandt werden kann. Injizierte und oral eingenommene Antibiotika wirken überall 
                        im Körper &ndash; es gibt kein auf diese Art verabreichtes Mittel, dass erkennen 
                        kann, an welcher Stelle es wirken soll und an welcher Stelle nicht. Zahnärzte 
                        beispielsweise verschreiben gerne bei einer Zahnsanierung und Parodontitisbehandlung 
                        gleich ein Antibiotikum &ndash; und zwar meist zum Einnehmen. Bedenken Sie bitte, 
                        dass diese Mittel auch immer Ihre Darmflora beeinträchtigen. Sinnvoller und sehr 
                        gut machbar wäre hier die lokale Anwendung, d.h. die Verwendung von keimhemmenden 
                        Spül- und Gurgellösungen, die Entzündungskeime an Zahnfleischrändern und -taschen 
                        fast ausschließlich örtlich bekämpfen. Hier gerät nur ein winziger Teil der 
                        Wirksubstanzen in das Verdauungssystem und kann so nur den geringstmöglichen 
                        Schaden anrichten.
                        <br />
                        <br />
                        Es lohnt sich also, (gemeinsam mit dem Arzt) nachzudenken, ob, wann und in welcher 
                        Weise eine Antibiose wirklich erforderlich ist. 
                        <br />
                        <a id="alternativen">&nbsp;</a>
                        <hr>
                        <h5>Alternativen zu Antibiotika</h5>
                        <hr>
                        Wie in unserer Darmflora, in der sich im günstigsten Falle eine gesunde Balance 
                        zwischen &#187;gut&#171; und &#187;böse&#171; eingependelt hat (wobei die Nützlinge 
                        immer einen sehr viel größeren Platz einnehmen als die Schädlinge), geht es immer 
                        und auf jedem Quadratzentimeter unserer Körperoberflächen um einen Kampf zwischen 
                        nützlichen und schädlichen Bakterien. 
                        <br />
                        <br />
                        Mit der Verabreichung von Antibiotika werden im günstigsten Falle tatsächlich 
                        zunächst die Krankheitserreger dezimiert. Dass dabei sozusagen als 
                        &#187;Kollateralschaden&#171; zu einem (meist) mehr oder (selten) weniger großen 
                        Teil auch die guten Keime vernichtet werden, wird dabei noch viel zu wenig beachtet. 
                        Die Folge ist, dass die guten Spezies, die ja schließlich die schlechten allein 
                        durch ihre Überzahl in Schach halten sollen, ihre angestammten Plätze nicht mehr 
                        verteidigen können. So kann sich die auch nach der sorgfältigsten Antibiose immer 
                        noch vorhandene Restpopulation von Krankheitserregern rasch wieder vermehren. 
                        Und hier sind es verhängnisvollerweise dann auch vermehrt diejenigen, die unempfindlicher 
                        gegenüber den angewandten Antibiotika sind, so dass sich die resistenten Stämme 
                        überproportional entwickeln können. Dies kann der Beginn eines Teufelskreises sein: 
                        Immer weniger gute Bakterien können sich einer schnell wachsenden Anzahl von 
                        Krankheitserregern nicht mehr (genügend) entgegenstellen, und die Erkrankung bricht 
                        erneut aus.
                        <br />
                        <br />
                        Auf jeden Fall aber kann es bis zu mehrere Monate dauern, bis sich die aus der 
                        Balance geratene Darmflora wieder vollständig und stabil regeneriert. Wird in 
                        dieser Zeit eine weitere Antibiose erforderlich, bedeutet dies unweigerlich den 
                        Auftakt zu einer verhängnisvollen Abwärtsspirale, denn dann ist bei jeder erneuten 
                        Behandlung, die eingeleitet wird, bevor sich die Darmflora wieder eingependelt hat, 
                        bereits das Anfangsniveau niedriger und die Verschlechterung der Qualität noch 
                        gravierender. 
                        <br />
                        <br />
                        Nachdem leider auch bis heute noch viel zu viele Krankheiten nach diesem Schema 
                        mit Antibiotika behandelt werden, schauen modern und ganzheitlich denkende Ärzte 
                        heute in geeigneten Fällen in die entgegengesetzte Richtung: sie stärken mit der 
                        Gabe von so genannten Probiotika die Verteidigungslinie der Darmflora. Die Bezeichnung 
                        Probiotika leitet sich aus dem lateinischen &#187;pro&#171; (für) her, und 
                        &#187;bios&#171; steht &ndash; wir kennen das schon &ndash; für Leben. Ein 
                        Probiotikum enthält einen oder auch mehrere lebende Bakterienarten, die auch in 
                        einer gesunden Darmflora vorkommen. Mit der Gabe eines solchen Probiotikums kann 
                        die Qualität der Darmflora verbessert werden, und die nun vermehrt vorhandenen 
                        Nützlinge können mit vereinten Kräften die Schädlinge zurückdrängen. 
                        <br />
                        <br />
                        Eingenommene probiotische Keime siedeln sich nicht dauerhaft in unserer Darmflora 
                        an, sie sind als so genannte passagere Keime nur für einen begrenzten Zeitraum 
                        von einigen wenigen Tagen oder Wochen in unserem Darm aktiv und werden dann 
                        ausgeschieden. Unsere eigene Darmflora &ndash; die obligate Darmflora &ndash; geht 
                        jedoch aus dieser Aktion gestärkt hervor, denn die eigenen guten Keime können 
                        sich mit dieser &#187;Schützenhilfe&#171; schon in diesem begrenzten Zeitraum 
                        schneller und besser vermehren.
                        <br />
                        <br />
                        Unterstützen können wir die Vermehrung mit den so genannten Präbiotika 
                        (&#187;prae&#171; bedeutet im Lateinischen vor).  Diese Substanzen sind eigentlich 
                        für unser Verdauungssystem unverdaulich und gelangen deshalb in den Dickdarm, in 
                        dem der allergrößte Teil der Darmflora angesiedelt ist. Dort dienen sie vorrangig 
                        den nützlichen Bakterienspezies als Futter, so dass diese sich schneller vermehren 
                        können und sich die Qualität der Darmflora verbessern kann. Präbiotische Substanzen 
                        werden übrigens keineswegs nur als Präparate angeboten, sondern sind natürlicherweise 
                        in vielen Lebensmitteln enthalten: Alle als ballaststoffreich bekannten Nahrungsmittel 
                        wie Vollkornprodukte, Obst und Gemüse enthalten diese eine gesunde Darmflora 
                        fördernden Bestandteile.
                        <br />
                        <br />
                        Selbstverständlich eignet sich die Einnahme von Pro- und Präbiotika nicht zur 
                        Behandlung einer jeden Erkrankung, aber schon jetzt sind zahlreiche Einsatzgebiete 
                        bekannt. Und es werden auf lange Sicht immer mehr werden, denn die Forschung an 
                        unserem Mikrobiom nimmt einen immer größeren Raum ein und macht rasante und vor 
                        allem interessante Fortschritte.
                        <br />
                        <br />
                        In vielen Fällen können statt der allopathischen &ndash; also im Labor hergestellten 
                        &ndash; Antibiotika auch die natürlichen Antibiotika eine gute Alternative sein. 
                        Diese meist pflanzlichen Substanzen können, wenn sie richtig eingesetzt werden, 
                        zum Teil ebenso potente Wirkungen entfalten wie die pharmazeutischen Präparate. 
                        Immerhin ist ja auch das Ursprungsantibiotikum Penicillin eine natürliche Substanz 
                        aus Schimmelpilzen.
                        <br />
                        <br />
                        In fast allen Kulturen der Welt gibt es in den traditionellen Heilmethoden ein 
                        Wissen über antibiotisch oder zumindest keimhemmend wirkende Pflanzen und natürliche 
                        Substanzen. Dem Laien hingegen sind diese teils hochwirksamen, pflanzlichen Arzneien 
                        kaum noch geläufig. Gerade mal die keimhemmende Kamille mit ihrer heilenden und 
                        lindernden Wirkung insbesondere als Tee kennt hier bei uns so gut wie jeder. Und 
                        dass Knoblauch antibiotisch wirkt, wissen auch noch recht viele Menschen. Dann 
                        aber verliert sich das Wissen um heilende und antibiotisch wirkende natürliche 
                        Substanzen meist im Dunkeln. Das ist schade, denn es gibt so viele Pflanzen, die 
                        uns bei der Krankheitsbekämpfung unterstützen können &ndash; man muss nur darüber
                        Bescheid wissen, um sie im richtigen Moment einzusetzen. 
                        <br />
                        <br />
                        Neben den Pro- und Präbiotika gibt es weitere pflanzliche Mittel, die hervorragende 
                        Wirkungen auf die Darmflora und damit auf unsere Gesundheit haben.  So können 
                        auch die so genannten Heil- oder Vitalpilze gute Dienste leisten und in bestimmten 
                        Fällen, wenn nicht eine Alternative, so doch zumindest eine Ergänzung zu allopathischen, 
                        also den von den Pharmafirmen produzierten Antibiotika darstellen. Nicht nur im 
                        Krankheitsfalle, sondern vor allem auch prophylaktisch können bestimmte Arten dieser 
                        Pilze die Qualität der Darmflora günstig beeinflussen. Darüber hinaus sind sie in 
                        der Lage, die Darmschleimhaut zu pflegen, die als Herberge der Darmkeime möglichst 
                        günstige &#187;Wohnverhältnisse&#171; bieten soll. Insbesondere der Igelstachelbart 
                        (Hericium erinaceus) kann in Kombination mit dem Austernpilz (Pleurotus ostreatus)
                         dafür sorgen, dass sich eine lädierte Darmschleimhaut regeneriert und sich die 
                         individuelle Darmflora schneller zu einer gesunden Balance einpendelt. 
                         Der Reishi-Pilz wirkt entzündungshemmend, so dass er gerne und erfolgreich mit 
                         den beiden Vorgenannten bei Darmsanierungen eingesetzt wird.
                        <br />
                        <br />
                        Viele Erkrankungen können verhindert werden, indem prophylaktisch Pro- und Präbiotika 
                        oder Vitalpilze eingenommen werden und so die Qualität der Darmflora zusätzlich 
                        gestärkt wird. Beispielsweise die gefürchteten Reisedurchfälle kann man abwehren 
                        oder zumindest deren Ausprägung abmildern, indem rechtzeitig etwa zwei Wochen vor 
                        Urlaubsantritt und bis zwei Wochen nach der Rückkehr ein geeignetes Präparat 
                        eingenommen wird. Aber auch die Behandlung einer bereits ausgebrochenen Reisediarrhoe 
                        wird heute von modernen Ärzten in geeigneten Fällen statt mit Antibiotika mit 
                        Probiotika behandelt (lesen Sie hierzu bitte auch den Beitrag
                        <a href="ganz-reisedurchfall" target="_blank">&#187;Reisedurchfall&#171;</a>) 
                        <br />
                        <br />
                        Gegenüber den allopathischen Antibiotika haben die natürlichen Präparate einen 
                        ganz besonderen Vorteil: Die natürlichen Antibiotika gehen in den meisten Fällen 
                        sehr viel pfleglicher mit den nützlichen Darmbakterien um, so dass sich nach 
                        Abschluss der Antibiose die nützlichen Darmbewohner aus einer sehr viel stabileren 
                        Grundlage wieder erholen und eventuell noch vorhandene Erreger erfolgreicher und 
                        schneller zurückdrängen können. Die Pro- und Präbiotika fördern die Entwicklung 
                        der nützlichen Darmbakterien, so dass Krankheitserreger sich nur sehr viel schlechter 
                        vermehren können. Vitalpilze können darüber hinaus die Darmschleimhaut pflegen, 
                        so dass sich nützliche Bakterien dort sehr viel wohler fühlen.
                        <br />
                        <br />
                        Selbstverständlich ist eine ausschließlich mit natürlichen Mitteln arbeitende 
                        Behandlung nicht generell für alle bakteriellen Infektionen und vor allem nicht 
                        für schwerwiegende Fälle geeignet und erhebt auch nicht den Anspruch, jeglichen 
                        Einsatz von Antibiotika überflüssig zu machen. Es ist aber eine Möglichkeit, in 
                        bestimmten Fällen eine Alternative zu einer Antibiose darzustellen und so die 
                        Gesamtmenge der Antibiotika zu reduzieren.
                        <br />
                        <br />
                        Nicht immer sind die natürlichen Substanzen den pharmazeutischen gleichwertig, 
                        können aber in sehr vielen Fällen wenn schon nicht alternativ, so doch ergänzend 
                        eingesetzt werden. Dies setzt natürlich voraus, dass der Arzt über diese Möglichkeiten 
                        Bescheid weiß. Da die Verordnung allopathischer Antibiotika ausschließlich in der 
                        Hand der Ärzteschaft liegt und das Wissen um die natürlichen Wirkstoffe meist bei 
                        den Heilpraktikern, werden dem Patienten in den seltensten (geeigneten) Fällen 
                        beide Alternativen und noch seltener sinnvolle Kombinationen aus allopathischen 
                        und natürlichen Präparaten angeboten.
                        <br />
                        <a id="imernstfall">&nbsp;</a>
                        <hr>
                        <h5>Was tun im Ernstfall?</h5>
                        <hr>
                        Wenn Sie ernsthaft erkrankt sind und Ihr Arzt eine Behandlung mit Antibiotika für 
                        erforderlich hält, sollten Sie gut abwägen, ob bei einer Erkrankung tatsächlich 
                        die Einnahme eines solchen Medikaments erforderlich ist. Ggf. diskutieren Sie 
                        dies intensiv mit Ihrem Arzt, und nehmen Sie ein solches Präparat nur, wenn keine 
                        anderen Alternativen zur Verfügung stehen. Außer in Notfällen sollte auch immer 
                        die Zeit für einen Test sein, mit dem der Erregertyp bestimmt werden kann, um ein 
                        Mittel mit einem möglichst engen Wirkspektrum auswählen zu können. Sollte die 
                        Einnahme eines Antibiotikums wirklich erforderlich sein, sollten Sie dankbar für 
                        diese Medikamente sein. Antibiotika zu verteufeln und generell abzulehnen, wäre 
                        genauso schlecht wie eine zu leichtfertige Verwendung.
                        <br />
                        <br />
                        Bitte nehmen Sie Antibiotika immer nach Vorschrift ein. Reduzieren Sie keinesfalls 
                        die empfohlene Dosis und auch nicht die Einnahmedauer &ndash; das würde nur dazu 
                        führen, dass die Krankheitserreger nicht wirkungsvoll genug bekämpft werden. Eine 
                        geringere Dosierung bringt keine Vorteile gegenüber einer höheren, sondern führt 
                        dazu, dass Krankheitserreger überleben können. Das gleiche gilt für eine verkürzte 
                        Einnahmedauer, zudem werden bei einem zu kurzen Einnahmezyklus Resistenzbildungen 
                        gefördert.
                        <br />
                        <br />
                        Wenn Sie berufstätig sind, lassen Sie sich von Ihrem Arzt krankschreiben und gönnen 
                        Sie Ihrem Körper ab sofort eine Ruhephase und geben Ihrem Immunsystem die Gelegenheit 
                        zu arbeiten, so dass Sie aus eigener Kraft gesund werden können. Auch, wenn Sie 
                        nicht berufstätig sind, sollten Sie schauen, wo und wie Sie Ihre Kräfte schonen können.
                        <br />
                        <br />
                        Beginnen Sie bereits ab der ersten Verwendung des Antibiotikums mit der Einnahme 
                        eines Probiotikums. So stärken Sie die Qualität Ihrer Darmflora, so dass sich die 
                        Balance nicht ganz so arg in Richtung &#187;schlecht&#171; verschieben kann. 
                        Lassen Sie sich hier von spezialisierten Fachkräften geeignete Mittel empfehlen. 
                        Leider müssen diese Nahrungsergänzungs-Präparate immer selbst bezahlt werden, 
                        die Krankenkassen übernehmen die Kosten nicht. Trotzdem ist der Kauf eines solchen 
                        Mittels eine gute Investition, denn es kommt letztendlich Ihrer Darmflora und 
                        damit Ihrer Gesundheit zugute.
                        <br />
                        <br />
                        Antibiotika und Probiotika müssen immer zeitversetzt geschluckt werden, denn bei 
                        gleichzeitiger Einnahme würde jedes antibiotische Präparat die probiotischen Keime 
                        vernichten. Dabei ist es unerheblich, ob Sie ein nur auf spezielle Bakterienarten 
                        wirkendes oder ein Breitbandantibiotikum einnehmen, weil auch engmaschigst wirkende 
                        Mittel zumindest zu einem kleinen Teil auf alle Keime wirkt. Halten Sie einen 
                        Zeitversatz von mindestens zwei Stunden ein.
                        <br />
                        <br />
                        Wenn Sie beispielsweise im Zuge einer geplanten, größeren Operation Antibiotika 
                        erhalten, um einer Infektion vorzubeugen, sollten Sie möglichst schon zwei Wochen 
                        vor dem Termin, spätestens aber gleich im Anschluss die Probiotika einnehmen. Dies 
                        gilt auch, wenn die Antibiotika per Infusion verabreicht werden. Für Ihre Darmflora 
                        ist es unerheblich, auf welchem Wege die antibiotischen Substanzen in Ihren Körper 
                        gelangen, sie sollte auf jeden Fall unterstützt werden.
                        <br />
                        <br />
                        Auch bei einer Dünndarmfehlbesiedelung &ndash; also der Überwucherung des Dünndarms 
                        mit an sich harmlosen Dickdarmkeimen &ndash; ist eine Antibiose leider unerlässlich. 
                        Hierbei stehen allerdings auch natürlich wirkende Antibiotika zur Verfügung 
                        (lesen Sie hierzu bitte auch den Beitrag
                        <a href="duenndarmfehlbesiedelung" target="_blank">&#187;Dünndarmfehlbesiedelung 
                        und ihre Behandlung&#171;</a>).
                        <br />
                        <a id="vorbeugung">&nbsp;</a>
                        <hr>
                        <h5>Was können wir vorbeugend tun?</h5>
                        <hr>
                        Sie selbst können auch vorbeugend sehr viel dazu beitragen, dass Ihre Darmflora 
                        möglichst gesund und Ihr Immunsystem stabil bleibt.
                        <br />
                        <br />
                        1. Achten Sie auf Ihre Ernährung, damit Ihre Darmflora so die besten Voraussetzungen 
                        erhält, sich optimal zu entwickeln: 
                        <br />
                        <b>&#149; </b>Wählen Sie möglichst frische Lebensmittel und bereiten Sie diese 
                        schonend zu, damit möglichst viele Vitalstoffe erhalten bleiben.
                        <br />
                        <b>&#149; </b>Stellen Sie sich einen möglichst abwechslungsreichen Speisezettel zusammen. 
                        <br />
                        <b>&#149; </b>Bevorzugen Sie biologisch erzeugtes Gemüse, Obst und Fleisch, um 
                        den Schadstoffgehalt zu minimieren und wählen Sie Ihre Lebensmittel regional und 
                        nach Jahreszeit und Anbauzyklus aus.
                        <br />
                        <b>&#149; </b>Reduzieren Sie einen ungesunden, hohen Fleischverzehr. 
                        <br />
                        <b>&#149; </b>Bevorzugen Sie hochwertige, pflanzliche Öle vor tierischen Fetten.
                        <br />
                        <b>&#149; </b>Essen Sie sparsam und achtsam und genießen Sie Ihre Mahlzeiten bewusst.
                        <br />
                        <br />
                        2. Trinken Sie ausreichend! Nicht nur Ihr Geist verweigert bei Wassermangel die 
                        Leistung, auch Ihr Verdauungssystem kann nur optimal funktionieren, wenn es genügend 
                        Flüssigkeit erhält. 
                        <br />
                        <br />
                        3. Bewegen Sie sich ausreichend. Wirkungsvoller als &#187;Gewaltsaktionen&#171; 
                        sind kleinere, gleichmäßig über den Tag verteilte Bewegungs- und Atemübungen, 
                        wobei nichts gegen zusätzliche, größere sportliche Aktivitäten spricht, solange 
                        diese Ihnen Spaß machen und Sie keinen Leistungssport betreiben, da exzessiver 
                        Sport die Qualität einer jeden Darmflora negativ beeinflusst. Bewegung und tiefe 
                        Atmung sorgen dafür, dass die Darmmuskulatur ausreichend durchblutet wird und die 
                        Darmmotorik angeregt wird. So können der Stuhl zügig durch den Darm transportiert 
                        und Schad- und Giftstoffe möglichst rasch zum Ausgang befördert werden. Das 
                        Säuremilieu pendelt sich in einem optimalen Bereich ein, so dass Darmschleimhaut 
                        und Darmflora beste Lebensbedingungen haben.
                        <br />
                        <br />
                        4. Vergessen Sie auch nicht, auf Ihre Stressbelastung zu achten. Die beste Möglichkeit 
                        wäre hier, als unangenehm empfundenen Stress zu vermeiden, dies ist aber nicht 
                        immer möglich. Negativen Stress jedoch können Sie kompensieren, indem Sie ganz 
                        bewusst ab und an Entspannungszeiten einplanen. Entweder können Sie hier spezielle 
                        Entspannungstechniken wie Autogenes Training, Progressive Muskelentspannung, Yoga 
                        oder Meditation erlernen und dann zu Hause anwenden. Aber auch Sport, Tanz oder 
                        Singen können entspannend wirken, genauso wie jedes von Ihnen mit Freude ausgeübte 
                        Hobby. Ihr so genanntes &#187;Bauchhirn&#171; &ndash; also das hochempfindliche 
                        Nervengeflecht, das Ihren gesamten Darm versorgt und steuert und das ebenso 
                        leistungsfähig ist wie Ihr Kopfhirn, reagiert hochsensibel auf Stress. Und ein 
                        irritiertes Bauchhirn trägt entscheidend dazu bei, dass sich die Darmflora 
                        verschlechtert. Geben Sie also auch Ihrem Bauchhirn Gelegenheit zur Entspannung 
                        und fördern so die Qualität Ihrer Darmflora.
                        <br />
                        <br />
                        5. Verzichten Sie auf Rauchen und das Trinken von Alkohol &ndash; Ihre Darmflora 
                        raucht und trinkt mit.
                        <br />
                        <a id="fazit">&nbsp;</a>
                        <hr>
                        <h5>Fazit</h5>
                        <hr>
                        Versuchen Sie grundsätzlich zu vermeiden, dass eine Antibiose erforderlich sein 
                        muss. Antibiotika wirken immer schädlich auf Ihre Darmflora und schwächen Ihr 
                        Immunsystem. Dies kann dazu führen, dass Krankheiten entweder schon nach kurzer 
                        Zeit erneut ausbrechen oder andere Erkrankungen folgen. Nehmen Sie deshalb so 
                        selten wie möglich &ndash; günstigstenfalls überhaupt keine &ndash; Antibiotika 
                        ein, wenn andere Alternativen zur Verfügung stehen. 
                        <br />
                        <br />
                        Falls sich eine Antibiose jedoch nicht vermeiden lässt, sollten Sie gemeinsam mit 
                        dem Arzt nur die am besten für diesen Fall geeigneten Mittel wählen. Nach Möglichkeit 
                        entscheiden Sie sich für natürliche Alternativen. Nehmen Sie alle Mittel immer 
                        genau nach Vorschrift ein. Gleichzeitig mit Antibiotika sollten Sie ein Probiotikum 
                        einnehmen, um Ihre Darmflora auf einem möglichst hohen Niveau zu stärken.
                        <br />
                        <br />
                        Sie haben viele Möglichkeiten, Ihre Gesundheit zu stärken und so zu versuchen, 
                        antibiotische Therapien zu vermeiden. Da ein sehr großer Teil Ihres Immunsystems 
                        im Darm angesiedelt ist, bietet hier eine insgesamt darmfreundliche Lebensweise 
                        die allergrößten Chancen. 
                        <br />
                        <br />
                        Wenn möglichst viele Menschen möglichst wenige Antibiotika verwenden müssen und 
                        darüber hinaus auch noch durch ihr Ess- und Kaufverhalten einer antibiotikaintensiven 
                        Massentierhaltung den Riegel vorschieben, fördern wir alle unsere Gesundheit. Wir 
                        verhindern dadurch auch, dass die Menschheit auf längere Sicht aussterben wird und 
                        die Bakterien nicht nur die erste, sondern auch die letzte Lebensform auf unserer 
                        Erde sein wird.
                        <br />
                        <br />
                        <hr>
                        <a id="beratung">&nbsp;</a>
                        <div class="row">
                        <div class="col s12 m2">
                        <h5>Beratung</h5>
                        <br />
                            <a href="http://www.ganzheitliche-gesundheitsberatung.de" target="_blank">
                                <img src="<?php echo IMG_PATH; ?>praxiswebsite.png" alt="" class="inline" /></a>
                        </div>
                        </div>
                        <div class="row">
                        <div class="col s12 m12">
                            Gerne biete ich Ihnen eine individuelle Beratung an &ndash; 
                            auf Wunsch auch telefonisch oder per Skype.
                            <br />
                            Bitte informieren Sie sich auf meiner Praxis-Website <a href="http://www.ganzheitliche-gesundheitsberatung.de" target="_blank">&#187;www.Ganzheitliche-Gesundheitsberatung.de&#171;</a>
                        </div>
                        </div>
                        <hr>
                        <br style="clear: left;" />
                        <a href="guterrat" target="_blank"><img src="<?php echo IMG_PATH; ?>hilfreich.png" alt="" class="left" /></a>
                        <br />
                        <br />
                        <hr>
                        <br />
                        <b>Lesen Sie bitte auch folgende Betr&auml;ge</b>:
                        <br />
                        <a href="duenndarmfehlbesiedelung" target="_blank">&#149; Dünndarmfehlbesiedelung und ihre Behandlung</a>
                        <br />
                        <a href="ganz-reisedurchfall" target="_blank">&#149; Reisedurchfall</a> 
                        <br />
                        <a href="arztsuche" target="_blank">&#149; Wie finde ich einen qualifizierten Arzt?</a>
                        <br />
                        <a href="darmgesundheit" target="_blank">&#149; Darmgesundheit</a>
                        <br />
                        <hr>
                        <a href="javascript: scrollMainToTop();" class="nachoben">nach oben</a>
                    </div>
                </div>
            </div>    
            <br>
            <br> 
            <div class="bodyspacer"></div> 
        </div>