        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br /> 
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>
                <h1 class="header center orange-text">Säulenmodell</h1>      
            </div>  
        </div> 
        <div class="container">    
            <div class="section">   
                <div class="row margintoprow">        
                    <div class="col s12 m12">
                        <img src="<?php echo IMG_PATH; ?>saeulenmodell.png" alt="" class="right" />
                        Gesund sein heißt nicht etwa nur, nicht krank zu sein &ndash; das wäre viel zu 
                        einfach. Es gibt sehr viele Abstufungen von Gesundheit, wobei ein Mensch, den 
                        andere vielleicht als krank bezeichnen würden, selbst durchaus glücklich und 
                        zufrieden sein und sich gesund fühlen kann.
                        <br />
                        <br />
                        Wie ein griechischer Tempel ruht unsere Gesundheit auf vielen Säulen, die alle 
                        gemeinsam das &#187;Gebäude der Gesundheit&#171; stützen. Ist eine Säule schadhaft, so stürzt meist noch nicht das gesamte Gebäude ein. 
                        Die Stabilität jedoch ist beeinträchtigt, und es ist wichtig, diese Säule so schnell und gut wie möglich wieder herzurichten, denn irgendwann beginnt 
                        ansonsten die Decke zu bröckeln. Und wenn mehrere Säulen nicht mehr tragfähig sind oder auch, wenn die erste schadhafte Säule nicht kurzfristig wieder 
                        in Stand gesetzt wird, ist das ganze Gebäude in ernsthafter Gefahr. Nun muss unverzüglich mit der Reparatur begonnen werden, um den kompletten Zusammenbruch 
                        zu verhindern.
                        <br />
                        <br />
                        So wie mit diesem Gleichnis verhält es sich auch mit unserer Gesundheit: Wenn wir 
                        den einen oder anderen gesundheitlichen Aspekt dauerhaft vernachlässigen, passiert meist 
                        zunächst kaum etwas, das wir bemerken. Erst, wenn wir mehrere Faktoren missachten 
                        &ndash; und dies auch noch über längere Zeiträume &ndash; laufen wir ernsthaft Gefahr, 
                        unsere Gesundheit nachhaltig zu ruinieren und unser Leben zu verkürzen.
                        <br />
                        <br />
                        Aber auch, wenn es bei Ihnen bereits mächtig bröckelt im Gebälk &ndash; für einen 
                        Neuanfang ist es nie zu spät. Auch wenn bereits eine oder mehrere Säulen eingebrochen 
                        sind oder sogar schon ein Teil Ihres Gesundheitsgebäudes eingebrochen und eine 
                        Krankheit ausgebrochen ist, können Sie doch noch vieles wieder aufrichten. So gut 
                        wie jede Krankheit lässt sich durch ein neues, gesundheitsbewusstes Verhalten 
                        positiv beeinflussen. Sie haben immer die Möglichkeit, durch verschiedenen Maßnahmen 
                        Ihre Lage zu verbessern. Und sogar bei einer &#187;Ruine&#171; &ndash; um bei unserem 
                        Beispiel zu bleiben &ndash; lässt sich oftmals noch das Fundament oder der eine 
                        oder andere Stein benutzen, um ein neues Gebäude zu errichten. Sie haben immer 
                        die Möglichkeit, durch Änderungen mehr Lebensqualität zu gewinnen und sich wohler 
                        zu fühlen.
                        <br />
                        <br />
                        Welche &#187;Säulen&#171; halten und stützen aber nun eigentlich unsere Gesundheit? 
                        Reicht es nicht, nicht zu rauchen, ab und an etwas Obst und Gemüse zu essen, und 
                        wenn das mal nicht geklappt hat, vielleicht ein paar Vitamintabletten einzunehmen? 
                        Nun, der Verzicht auf Nikotin und Verzehr von Obst und Gemüse und der ist ein Anfang 
                        &ndash; aber doch längst nicht alles. Und Vitamintabletten sind dabei in den 
                        allermeisten Fällen nicht nötig, oftmals sogar eher schädlich als nützlich. Ich 
                        versuche hier einmal, all die Aspekte in einer Liste zusammenzustellen, die 
                        Puzzlesteichnchen für eine stabile Gesundheit sind:
                        <br />
                        <br />
                        &#149; gesunde Ernährung
                        <br />
                        &#149; gesunde Verdauung
                        <br />
                        &#149; gesunde Darmflora
                        <br />
                        &#149; ausreichendes und richtiges Trinken
                        <br />
                        &#149; Nikotinverzicht
                        <br />
                        &#149; weitestgehender Alkoholverzicht
                        <br />
                        &#149; ausreichend Bewegung
                        <br />
                        &#149; richtiges Atmen
                        <br />
                        &#149; genügend frische Luft
                        <br />
                        &#149; genügend Licht
                        <br />
                        &#149; ausreichender und gesunder Schlaf
                        <br />
                        &#149; wenig Disstress, ggf. Ausgleich durch gutes Stressmanagement
                        <br />
                        &#149; ausreichend geistige Anregung
                        <br />
                        &#149; stabiles Immunsystem
                        <br />
                        &#149; verantwortungsbewusster Umgang mit Medikamenten
                        <br />
                        &#149; schonende Methoden bei Rekonvaleszenz
                        <br />
                        &#149; möglichst schadstoffarmes Lebens- und Wohnumfeld
                        <br />
                        &#149; positive, werteorientierte Lebenseinstellung
                        <br />
                        &#149; stabiles, soziales Umfeld
                        <br />
                        &#149; Spaß und Freude
                        <br />
                        &#149; adäquater Umgang mit Enttäuschungen
                        <br />
                        &#149; finanzielle Absicherung
                        <br />
                        <br />
                        Diese Liste will und kann keinen Anspruch auf Vollständigkeit erheben, denn für 
                        jeden einzelnen Menschen kommen mit Sicherheit noch viele, ganz individuelle Aspekte 
                        hinzu. Doch die wichtigsten Punkte sind hier enthalten und zeigen Ihnen, dass in 
                        vielen Bereichen des Lebens ein gesundheitsbewusstes Verhalten vorteilhaft ist.
                        <br />
                        <br />
                        Was aber ist nun &#187;gesunde Ernährung&#171;, was ist &#187;ausreichend 
                        Bewegung&#171; oder &#187;genügend Licht und Luft&#171;? Die Frage müsste eigentlich 
                        heißen: &#187;Was ist <b>für Sie</b> gesunde Ernährung, <b>für Sie</b> ausreichend 
                        Bewegung und <b>für Sie</b> genügend Licht und Luft&#171;. Denn was für den einen 
                        die richtige, gesunde Ernährung ist, bei der er sich wohl fühlt und die ihn mit 
                        den erforderlichen Nährstoffen versorgt, die ihm schmeckt und Wohlbehagen bereitet, 
                        kann einem anderen gar nicht bekommen, so dass er Beschwerden bekommt und sein 
                        Wohlbefinden entscheidend beeinträchtigt ist. Auch die Art und Intensität von 
                        Bewegung &ndash; sei es ein Spaziergang oder eine anstrengende Sportart &ndash; 
                        kann dem einen so richtig Spaß machen, für den anderen bedeutet das Gleiche reinen 
                        Stress.
                        <br />
                        <br />
                        Und so, wie für das eine Gebäude schmale, schlanke Säulen genau das Richtige sind, 
                        bei einem anderen Bauwerk jedoch eher gedrungene Pfeiler für ein gelungenes Gesamtbild 
                        sorgen, so sind all die in der obigen Liste aufgeführten Aspekte zwar als Richtschnur 
                        zu beachten, müssen jedoch von Ihnen ganz individuell ausgestaltet und mit Leben 
                        gefüllt werden.
                        <br />
                        <br />
                        Wenn Sie beschlossen haben, in Zukunft mehr auf Ihre Gesundheit zu achten &ndash; 
                        sei es, weil der Arzt es Ihnen aus verschiedenen Gründen empfohlen hat, oder weil 
                        Sie sich in Ihrer Haut nicht mehr wohl fühlen &ndash; gehen Sie behutsam an diesen 
                        Plan heran. &#187;Rom ist nicht an einem Tag erbaut worden&#171;, heißt es, was 
                        bedeutet, dass Sie sich rasch hoffnungslos überfordert fühlen würden, wenn Sie nun 
                        auf einmal <b>alle</b> Punkte gleichzeitig für sich beachten und ändern würden. 
                        Gehen Sie schrittweise an das Projekt &#187;Gesundheit&#171; heran. Schauen Sie, 
                        welchen Punkt oder welche Punkte Sie am einfachsten ändern können und beginnen Sie 
                        damit. Wenn Sie Freude daran haben und Fortschritte erzielen, können Sie nach und 
                        nach den einen oder anderen weiteren Aspekt hinzunehmen. Wenn Sie in einem ausgewählten 
                        Punkt das Gefühl haben, dass es Ihnen dabei nicht gut geht, betrachten Sie dies 
                        nicht als Niederlage, sondern wenden sich vorerst einem anderen Punkt zu. Sobald 
                        Sie sich zwingen müssen, war die Entscheidung &ndash; zumindest für den Augenblick 
                        &ndash; nicht richtig für Sie. Wichtig ist bei allem, dass Sie Spaß an Ihrem 
                        gesundheitsbewussten Verhalten haben. 
                        <br />
                        <br />
                        Eines ist jedoch für alle Menschen gleichermaßen wichtig: Seien Sie sich in allen 
                        Ihren Tätigkeiten und Verhaltensweisen immer der Tatsache bewusst, dass eine 
                        grundsätzlich gesundheitsbewusste Einstellung Sie auf den richtigen Weg führt und 
                        Ihre Gesundheit ein ganzes Leben lang stabil(er) und belastungsfähig(er) wird oder 
                        bleibt. Bleiben Sie aber bitte bei all Ihren Entscheidungen zum Wohle Ihrer Gesundheit 
                        gelassen und auch nachsichtig mit sich selbst, denn eine allzu fanatische Befolgung 
                        aller &#187;Regeln&#171; ist kontraproduktiv &ndash; Sie dürfen sich sicherlich 
                        auch ab und an einmal etwas zu erlauben, was eigentlich nicht so richtig 
                        &#187;gesund&#171; ist. Die Betonung liegt dabei allerdings auf &#187;ab und 
                        an&#171;.
                        <br />
                        <br />
                        Wenn Sie noch etwas unsicher sind, wo Sie mit Ihrem gesundheitsbewussten 
                        Verhalten beginnen wollen und sollten, helfe ich Ihnen gerne. Wir schauen gemeinsam, 
                        wo bei Ihnen die dringendsten &#187;Baustellen&#171; sind, und wo Sie als erstes 
                        eine Änderung herbeiführen könnten. 
                        <br />
                        <br />
                        Hier können Sie sich über meine Beratungspraxis, 
                        meine Grundsätze und Schwerpunkte informieren: <a href="http://www.ganzheitliche-gesundheitsberatung.de/" target="_blank">www.Ganzheitliche-Gesundheitsberatung.de</a>
                        <br />
                        <br />
                        Ich freue mich auf Ihren Anruf.
                        <br />
                        <br />
                        <a href="<?php echo URL_ROOT; ?>guterrat" target="_blank"><img src="<?php echo IMG_PATH; ?>hilfreich.png" alt="" class="left" /></a>
                        <br />
                        <br />
                        <hr />
                        <b>Bitte lesen Sie auch folgende Beitr&auml;ge:</b>
                        <br />
                        <a href="ganz-gesund">&#149; Ganzheitliche Gesundheit</a>
                        <br />
                        <a href="ganz-magendarm">&#149; Ganzheitliche Betrachtung von Magen-/Darmbeschwerden</a>
                        <br />
                        <a href="ganz-galle">&#149; Verdauungsbeschwerden durch Gallenfunktionsst&ouml;rungen</a>
                        <br />
                        <a href="ganz-schilddruese">&#149; Verdauungsbeschwerden durch Schildr&uuml;senfunktionsst&ouml;rungen</a>
                        <br />
                        <a href="ganz-immun">&#149; Stärkung des Immunsystems</a>
                        <br />
                        <hr />
                        <a href="javascript: scrollMainToTop();" class="nachoben">nach oben</a>
                    </div>
                </div>
            </div>    
            <br>
            <br> 
            <div class="bodyspacer"></div> 
        </div>