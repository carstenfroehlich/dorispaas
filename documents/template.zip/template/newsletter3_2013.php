        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br /> 
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>
                <h1 class="header center orange-text">DorisPaas-Newsletter</h1>      
            </div>  
        </div> 
        <div class="container">    
            <div class="section">   
                <div class="row margintoprow">        
                    <div class="col s12 m12">
                        <b>Ausgabe 3/2013 (Mai 2013)</b>
                        <br />
                        -------------------------------------------------------
                        <br />
                        <br />
                        Liebe Leserin, lieber Leser.
                        <p>
                        Zun&auml;chst einmal w&uuml;nsche ich Ihnen erholsame Pfingstfeiertage. Auch wenn 
                        der Wetterbericht nichts Gutes vorausgesagt hat, hoffe ich, dass Sie die Zeit nutzen 
                        k&ouml;nnen, um Ihre Akkus aufzuladen und es sich richtig gut gehen zu lassen. 
                        Bewusstes Genie&#223;en, Spa&#223; und Entspannung tragen sehr viel zu unserer 
                        Lebensqualit&auml;t bei, und bei allem Stress, dem wir so h&auml;ufig ausgesetzt 
                        sind, sollten wir uns immer wieder die Zeit nehmen, innezuhalten und zu regenerieren.
                        <br />
                        <br />
                        <br />
                        <b>&#149;	<a href="http://www.dorispaas.de/index.php?page=lexikon-darmerkrankungen" target="_blank">Lexikon der Darmerkrankungen</a></b>
                        <br />
                        Ein gro&#223;es und umfangreiches Projekt, das ich in den letzten Monaten nach 
                        und nach bearbeitet habe, ist das &#187;Lexikon der Darmerkrankungen&#171;. Damit 
                        hat die Gruppe der Lexika, die auf 
                        <a href="http://www.dorispaas.de" target="_blank">DorisPaas.de</a> verf&uuml;gbar 
                        sind, einen weiteren Zuwachs erhalten. Selbstverst&auml;ndlich &#187;lebt&#171; 
                        auch diese Sammlung, die im Laufe der Zeit mit Sicherheit noch umfassender werden wird.
                        <br />
                        In diesem Lexikon sind viele Begriffe zum Thema &#187;Darmerkrankungen&#171; 
                        zusammengetragen und mit Stichworten erkl&auml;rt. Sinn dieser Lexika ist es, dass 
                        Sie sich zu einem Begriff rasch eine Beschreibung heraussuchen k&ouml;nnen.
                        Umfangreichere Erl&auml;uterungen zu Hintergr&uuml;nden und Zusammenh&auml;ngen 
                        zu vielen Begriffen sind nat&uuml;rlich auf der gesamten Website zu finden. 
                        <br />
                        <br />
                        <br />
                        <b>&#149;	<a href="http://www.dorispaas.de/index.php?page=faq" target="_blank">Fragen und Antworten</a></b>
                        <br />
                        Fast t&auml;glich werden &uuml;ber die Website Fragen an mich gerichtet. Neben 
                        meiner T&auml;tigkeit in der 
                        <a href="http://www.ganzheitliche-gesundheitsberatung.de" target="_blank">Praxis 
                        f&uuml;r Ganzheitliche Gesundheitsberatung und Pr&auml;vention</a> beantworte ich kurze 
                        Fragen gerne. Zwei davon, auf die ich Sie aufmerksam machen m&ouml;chte, habe ich 
                        f&uuml;r diesen Newsletter ausgew&auml;hlt:
                        <br />
                        <br />
                        &#187;Seit bei meiner Tochter vor 6 Wochen eine 
                        Laktose-Intoleranz festgestellt wurde, koche ich bewusst mit laktosefreien 
                        Produkten, und wir essen diese gemeinsam. Nach dem Genuss dieser laktosefreien 
                        Gerichte bzw. laktosefreier Sahne bekomme ich Magendr&uuml;cken, leichte 
                        &Uuml;belkeit und Stuhldrang. Bei mir ist keine Laktose-Intoleranz bekannt. 
                        Kann man auf laktosefreie Produkte allergisch reagieren?&#171;
                        <br />
                        <a href="http://www.dorispaas.de/index.php?page=faq#frage116" target="_blank">Lesen Sie hier die Antwort</a>
                        <br />
                        <br />
                        &#187;Z&ouml;liakie und Haschimoto Thyreoiditis &#150; Frage zur Thyroxin-Dosis&#171;
                        <br />
                        <a href="http://www.dorispaas.de/index.php?page=faq#frage115" target="_blank">Lesen Sie hier die Antwort</a>
                        <br />
                        <br />
                        <br />
                        <b>&#149;	<a href="http://www.dorispaas.de/index.php?page=videos" target="_blank">Ausblick: neue Videos</a></b>
                        <br />
                        Zum Abschuss m&ouml;chte ich Sie noch ein wenig neugierig machen: Zus&auml;tzlich 
                        zu den Ihnen sicherlich schon bekannten Videos in den Rubriken 
                        <a href="http://www.dorispaas.de/index.php?page=videos" target="_blank">Tutorials</a>
                        und <a href="http://www.dorispaas.de/index.php?page=rezepte" target="_blank">Rezepte</a> 
                        habe ich in Zusammenarbeit mit 
                        <a href="http://mahlzeit.tv/partner/Doris%20Paas" target="_blank">Mahlzeit.tv</a> eine 
                        weitere Reihe von Videos gedreht. Sie befinden sich derzeit in der Endbearbeitung 
                        und werden in K&uuml;rze verlinkt. Bleiben Sie also gespannt und schauen Sie 
                        demn&auml;chst dort vorbei, es sind wieder interessante Tutorials und leckere 
                        Rezepte dabei. 
                         <br />
                        <br />
                        Bis zum n&auml;chsten Newsletter, den Sie in gut zwei Monaten, also etwa Mitte 
                        Juli 2013 erhalten, sende ich Ihnen f&uuml;r heute ganz herzliche Gr&uuml;&#223;e 
                        und &#150; allen Unkenrufen der Meteorologen zum Trotz &#150; ein paar Sonnenstrahlen 
                        aus dem Rheinland<br />
                        <br />
                        Ihre
                        <br />
                        Doris Paas
                        </p>
                        Gerne k&ouml;nnen Sie diesen Newsletter auch an Freunde und Bekannte weiterleiten!
                        <p>
                        -------------------------------------------------------------------------------------------------------------
                        <br />
                        Sie k&ouml;nnen den Erhalt des Newsletters jederzeit abbestellen.
                        Bitte klicken Sie auf <a href="http://www.dorispaas.de/index.php?page=unsubscribe_newsletter&amp;ticket=%UNSUBSCRIBE_TICKET%" target="_blank">diesen Link</a>.
                        <br />
                        Ihre Mailadresse wird im Verteiler gel&ouml;scht, und Sie erhalten keine Mails mehr.
                        </p>
                    </div>
                </div>
            </div>    
            <br>
            <br> 
            <div class="bodyspacer"></div> 
        </div>