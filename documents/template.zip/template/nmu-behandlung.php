        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br />      
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>
                <h1 class="header center orange-text">Behandlungsgrundsätze</h1> 
                    <div class="row center">        
                    <h5 class="header col s12 light">bei Nahrungsmittel-Unverträglichkeiten</h5>      
                    </div>     
            </div>  
        </div>
        <div class="container">    
            <div class="section"> 
                <div class="row margintoprow">        
                    <div class="col s12 m12">          
                        Es gibt für jede Nahrungsmittel-Unverträglichkeit ganz spezielle 
                        Behandlungsmöglichkeiten. Einige Grundsätze gelten jedoch bei allen 
                        Arten von Intoleranzen: die weitestgehende Meidung der unverträglichen Stoffe. 
                        <br />
                        <br />
                        Nachdem die Diagnose &#187;Nahrungsmittel-Unverträglichkeit&#171; gestellt wurde &ndash; 
                        beispielsweise Milchzucker-Unverträglichkeit (Laktoseintoleranz) oder 
                        Fruchtzucker-Unverträglichkeit (Fruktoseintoleranz) oder andere, ist es 
                        erforderlich, die entsprechenden Beschwerdeverursacher in Zukunft weitestgehend 
                        zu meiden.
                        <br />
                        <br />
                        Bevor man nun jedoch voreilig beginnt, alle erdenklichen Bestandteile dauerhaft vom 
                        Speisezettel zu streichen, sollte man zuerst genau ermitteln, welche Nahrungsbestandteile 
                        <b>wirklich</b> Probleme bereiten, denn nicht immer sind es <b>alle</b> möglichen Verdächtigen, 
                        die bei jedem Menschen zu Beschwerden führen müssen. Eine übertriebene 
                        Eliminierung von wertvollen Nahrungsmitteln ist auf Dauer nachteilig für die 
                        Gesundheit. Deshalb ist es immer erforderlich, die wirklichen Beschwerdeverursacher 
                        zu entlarven. Zudem führt eine dauerhaft stark eingeschränkte Speisenauswahl 
                        zu einer drastischen Senkung der Lebensqualität, was bei intelligenter 
                        Herangehensweise überhaupt nicht nötig ist.
                        <br />
                        <br />
                        Am Anfang steht jedoch immer eine Zeit der absoluten Karenz &ndash; also eine Zeit des 
                        völligen Weglassens aller <b>eventuellen</b> Beschwerdeverursacher. Dies kann 
                        &ndash; wenn man möchte &ndash; sogar eine Zeit des Fastens sein, in der wirklich 
                        au&#223;er Getränken keinerlei Nahrung zu sich genommen wird. Aber auch eine 
                        Ernährung mit wenigen, unverdächtigen Lebensmitteln kann dazu führen, 
                        dass die Beschwerden, die einen bisher gequält haben, nachlassen und verschwinden.
                        <br />
                        <br />
                        Nach dieser Zeit der absoluten Karenz, in der man völlig beschwerdefrei geworden 
                        sein sollte, kann man langsam und angepasst an die individuelle(n) Unverträglichkeit(en) 
                        beginnen, vorsichtig das eine oder andere zusätzliche Lebensmittel wieder dem 
                        eingeschränkten Speiseplan hinzuzufügen und schauen, ob es vertragen wird 
                        oder vielleicht auch nicht. Auf diese Weise ist es möglich herauszufiltern, 
                        welche Lebensmittel Beschwerden verursachen und welche verzehrt werden können, 
                        ohne dass Probleme auftauchen.
                        <br />
                        <br />
                        Diese für alle Unverträglichkeiten gleiche Vorgehensweise lesen Sie bitte hier:
                        <br />
                        <br />
                        <a href="nmu-fasten">&#149; Fasten als Vorbereitung der Karenz</a>
                        <br />
                        <a href="nmu-karenz">&#149; Karenz</a>
                        <br />
                        <br />
                        Für alle weiteren, für jede Art der Unverträglichkeit spezifischen 
                        Behandlungswege lesen Sie bitte die unter den verschiedenen Rubriken aufgeführten 
                        Beiträge.
                        <br />
                        <br />
                        <hr />
                        <div class="oneline">
                            <div class="left">
                                <a href="lebensmittel-datenbank-info">
                                    <img src="<?php echo IMG_PATH; ?>lebensmitteldatenbank.png" alt="home video small" class="inline" />
                                </a>
                            </div>
                            <p class="left">
                                <b>Empfehlung:</b>
                                <br />
                                Eine zusätzliche Hilfe bei der Ermittlung geeigneter Lebensmittel stellt die
                                <br />
                                &#187;<b>DorisPaas.de &ndash; Lebensmittel-Datenbank</b>&#171; dar. 
                                Informieren Sie sich <a href="lebensmittel-datenbank-info" target="_blank">hier</a>.
                            </p>
                        </div>
                        <br style="clear: left;" />
                        <br />
                        <hr>
                        <a id="beratung">&nbsp;</a>
                        <div class="row">
                        <div class="col s12 m2">
                            <a href="http://www.ganzheitliche-gesundheitsberatung.de" target="_blank">
                                <img src="<?php echo IMG_PATH; ?>praxiswebsite.png" alt="" class="inline" /></a>
                        </div>
                        </div>
                        <div class="row">
                        <div class="col s12 m12">
                        <h5>Beratung</h5>
                        <br />
                            Gerne biete ich Ihnen eine individuelle Beratung an &ndash; 
                            auf Wunsch auch telefonisch oder per Skype.
                            <br />
                            Bitte informieren Sie sich auf meiner Praxis-Website <a href="http://www.ganzheitliche-gesundheitsberatung.de" target="_blank">&#187;www.Ganzheitliche-Gesundheitsberatung.de&#171;</a>
                        </div>
                        </div>
                        <hr>
                        <a href="guterrat" target="_blank"><img src="<?php echo IMG_PATH; ?>hilfreich.png" alt="" class="left" /></a>
                        <br />
                        <br />
                        <hr />
                        <a href="javascript: scrollMainToTop();" class="nachoben">nach oben</a>
                    </div>
                </div>
            </div>    
            <div class="bodyspacer"></div> 
        </div>