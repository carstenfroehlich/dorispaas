        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br /> 
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>
                <h1 class="header center orange-text">Dünndarmfehlbesiedelung</h1>      
                    <div class="row center">        
                    <h5 class="header col s12 light"> und ihre Behandlung</h5>      
                    </div>     
            </div>  
        </div> 
        <div class="container">    
            <div class="section">   
                <div class="row margintoprow">        
                    <div class="col s12 m3">
                        <ul class="nav">
                            <li>
                                <b>Abschnitte dieser Seite:</b>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>duenndarmfehlbesiedelung#definition">Definition</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>duenndarmfehlbesiedelung#ursachen">Ursachen</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>duenndarmfehlbesiedelung#symptome">Symptome</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>duenndarmfehlbesiedelung#diagnose">Diagnose</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>duenndarmfehlbesiedelung#behandlung">Behandlung</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>duenndarmfehlbesiedelung#beratung">Beratung</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>duenndarmfehlbesiedelung#6saeulen">Die sechs Behandlungssäulen</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>duenndarmfehlbesiedelung#siboschulung">Schulungen für Mediziner und Berater</a>
                            </li> 
                        </ul>
                    </div>
                </div>
                <div class="row margintoprow">        
                    <div class="col s12 m12">
                        <img src="<?php echo IMG_PATH; ?>darmschleimhaut-mikrovilli.png" alt="" class="right" />
                        Wenn Verdauungsbeschwerden wie vor allem Blähungen und weiche Stühle bis hin zu 
                        Durchfällen immer wieder und vor allen meist schon nach einer sehr kurzen Zeit 
                        nach jeder Mahlzeit auftreten, ist es möglich, dass eine Dünndarmfehlbesiedelung 
                        (DDFB) vorliegen könnte.
                        <br />
                        <br />
                        In Zeiten der &#187;Selbstbehandlung durch das Internet&#171;, in der viele Menschen 
                        mit entsprechenden Problemen im WorldWideWeb nach möglichen Ursachen und einer 
                        Behandlung suchen, erlebt die DDFB derzeit jedoch einen wahren Boom: In den einschlägigen Foren 
                        gibt es kaum einen Beitrag, bei dem nicht irgendwann die &#187;Diagnose&#171; 
                        Dünndarmfehlbesiedelung genannt wird. 
                        <br />
                        <br />
                        Aus diesem Grunde ist es wichtig, dass Sie sich bei einem eventuellen Verdacht
                        umfassend über die Hintergründe, über die Ursachen und über Behandlungsmöglichkeiten 
                        informieren, bevor Sie sich zum einen Sorgen machen und zum anderen überflüssige 
                        Diagnostiken und Behandlungen in Kauf nehmen, die u.U. gar nicht erforderlich sind. 
                        Auf dieser Seite möchte ich Ihnen einen Überblick geben.
                        <br />
                        <a id="definition"></a>
                        <hr>
                        <h5>Definition</h5>
                        <hr>
                        Der Dünndarm beherbergt &ndash; wie auch der Dickdarm &ndash; bestimmte Bakterien. 
                        Beim Dickdarm kennen wir die Bakterien als die so genannte &#187;Darmflora&#171; 
                        (auch Mikrobiota oder Mikrobiom genannt). Die Darmflora besteht aus vielen verschiedenen 
                        Bakterienarten &ndash; je weiter die Erforschung dieses interessanten Bereichs 
                        fortschreitet, desto mehr Bakterienarten werden entdeckt. Derzeit geht man von 500 
                        &ndash; 1000 verschiedenen Bakterienarten aus, die die Dickdamflora besiedeln. 
                        Alle zusammengenommen zählt die Dickdarmflora schätzungsweise etwa hundert Milliarden 
                        (10<sup>11</sup>) bis eine Billion (10<sup>12</sup>) einzelne Mikroorganismen pro 
                        Gramm Kot. Zusammen wiegt das Dickdarmbiom etwa 1 &ndash; 2 Kilogramm. Nicht nur 
                        wegen dieser Menge, vor allem aber auch wegen der wichtigen Funktionen, für die 
                        das Mikrobiom im menschlichen Körper verantwortlich ist, wird sie auch als ein 
                        selbstständiges Organ angesehen.
                        <br />
                        <br />
                        Im Dünndarm siedeln nicht nur sehr viel weniger Bakterien. Hier sind es &#187;nur&#171; etwa 
                        eintausend (10<sup>3</sup>) bis zehn Millionen (10<sup>7</sup>) Bakterienindividuen 
                        pro Gramm Stuhl, und es sind wesentlich weniger verschiedene, vor allem aber auch 
                        andere Arten von Bakterien. Im Dickdarm herrschen die so genannten anaerobischen 
                        Bakterienarten vor, im Dünndarm sind es eher die Aerobier wie z.B. die Lactobacillen.
                        <br />
                        <br />
                        Sowohl im Dünndarm als auch im Dickdarm haben alle Bakterienarten ihre ganz spezifischen 
                        Funktionen. Geraten nun Bakterien aus dem Dickdarm nach oben in den Dünndarm, 
                        arbeiten sie trotzdem weiter in der für sie typischen Weise. Das ist so natürlich 
                        eigentlich nicht vorgesehen und hat logischerweise Beschwerden zur Folge.
                        <br />
                        <br />
                        Die Fehlbesiedelung des Dünndarms wird auch als SIBO oder SIBOS bezeichnet. Diese 
                        Bezeichnungen leiten sich von den englischen Begriffen &#187;Small bowel (bacterial) 
                        overgrowth&#171; bzw. &#187;Small intestine overgrowth syndrome&#171; her.
                        <br />
                        <a id="ursachen">&nbsp;</a>
                        <hr>
                        <h5>Ursachen</h5>
                        <hr>
                        Der Dünndarm ist gegenüber dem Dickdarm mit einer Ventilklappe, der Ileozökalklappe, 
                        abgeschlossen (Ileum = Krummdarm. Das terminale Ileum ist das letzte Stück des Dünndarms; Coekum = Blinddarm, 
                        d.h. das erste Stück des Dickdarms). Weitere Bezeichnungen für dieses Ventil sind
                        &#187;Bauhin&#039;sche Klappe&#171; oder &#187;Dickdarmklappe&#171;. Eine korrekt 
                        funktionierende Ileozökalklappe lässt den Speisebrei nur von oben, vom Dünndarm, nach unten 
                        in den Dickdarm hindurch und soll den Rückstrom von Kot aus dem Dickdarm in den 
                        Dünndarm verhindern. Somit sollten bei normaler Funktion dieser Klappe auch keine 
                        nennenswerten Mengen an Dickdarmbakterien in den Dünndarm gelangen.
                        <br />
                        <br />
                        Wenn nun jedoch dieses Ventil nicht mehr richtig schließt, können eben doch Bakterien 
                        von unten nach oben gelangen. Diese können beispielweise mit kleineren Stuhlmengen 
                        oder &ndash; was häufiger der Fall ist &ndash; durch Blähungen in den Dünndarm 
                        transportiert werden.
                        <br />
                        <br />
                        Ursachen hierfür gibt es mehrere: Meist sind es vermehrte Blähungen, die die 
                        Ileozöklaklappe &#187;ausleiern&#171; &ndash; durch den Druck von unten wird das
                        Ventil geöffnet, und Bakterien können aufsteigen. Vermehrte Blähungen sind meist 
                        Begleiterscheinungen von Nahrungsmittel-Unverträglichkeiten. Ungefährlich ist 
                        in dieser Beziehung ein normaler Verzehr von blähenden Nahrungsmitteln wie Hülsenfrüchten, 
                        Kohl oder Zwiebeln &ndash; hier nimmt die Dickdarmklappe nicht gleich Schaden.
                        <br />
                        <br />
                        Aber auch andere Erkrankungen wie z.B. eine Zöliakie, chronisch entzündliche 
                        Darmerkrankungen wie z.B. Morbus Crohn oder Colitis ulcerosa oder auch eine 
                        verlangsamte Darmpassage können zu einer Schädigung und/oder zur Erschlaffung 
                        der Ileozökalklappe und damit zu einer Dünndarmfehlbesiedelung führen.
                        <br />
                        <a id="symptome">&nbsp;</a>
                        <hr>
                        <h5>Symptome</h5>
                        <hr>
                        Wie oben beschrieben, treten bei einer DDFB insbesondere Blähungen, weiche, häufige 
                        Stühle oder auch Durchfälle auf. Im Gegensatz zu den typischen Beschwerden, die 
                        durch Nahrungsmittel-Unverträglichkeiten verursacht werden, treten die Symptome 
                        meist schon nach einer sehr kurzen Zeit nach einer Mahlzeit auf. Der Zusammenhang 
                        erklärt sich wie folgt:
                        <br />
                        <br />
                        Wenn mit der Nahrung Zucker aus dem Magen in den Dünndarm gelangt, wird dieser hier 
                        normalerweise enzymatisch aufgespalten, verarbeitet und ins Blut aufgenommen. Nur 
                        die unverarbeiteten Zuckerreste geraten in den Dickdarm, wo sie von den dortigen 
                        Bakterien verstoffwechselt werden. Diese Reste sind jedoch &ndash; sofern keine 
                        Kohlenhydrat-Unverträglichkeit (z.B. Laktose-, Fruktose-, Sorbit-Intoleranz) 
                        vorliegt, mengenmäßig sehr gering und erzeugen kaum bemerkbare Probleme.
                        <br />
                        <br />
                        Befinden sich nun im Dünndarm Bakterienarten aus der Dickdarmflora und diese in 
                        einer sehr viel dichteren Anzahl und vor allem auch bereits im oberen Abschnitt 
                        der Dünndarms (im Zwölffingerdarm), üben diese Bakterien bereits hier Funktionen 
                        aus, die üblicherweise erst im Dickdarm stattfinden würden: Gelangt Zucker mit der 
                        Nahrung in den Dünndarm, &#187;stürzen sich&#171; die Bakterien darauf und 
                        verstoffwechseln ihn, bevor die enzymatische Verdauung greifen kann.
                        <br />
                        <br />
                        Dies ist auch der Grund, warum die Symptome bereits sehr schnell nach der Mahlzeit 
                        auftreten, denn die Nahrung gelangt ja sehr viel rascher in den Dünndarm als in 
                        den Dickdarm. So sind Beschwerden, die ja auch für Nahrungsmittel-Unverträglichkeiten 
                        typisch sind, aufgrund des zeitnahen Auftretens gut einer DDFB zuzuordnen.
                        <br />
                        <a id="diagnose">&nbsp;</a>
                        <hr>
                        <h5>Diagnose</h5>
                        <hr>
                        Nicht nur die Symptome und die Zeiträume geben einen Hinweis darauf, ob eine 
                        Dünndarmfehlbesiedelung vorliegen könnte. Es gibt auch Tests, mit denen der Arzt 
                        eine Diagnose erhärten kann. 
                        <br />
                        <br />
                        Hierzu wird ein Wasserstoff-Atemtest mit 80g in Wasser gelöster Glukose durchgeführt. 
                        Bei der Besiedelung des Dünndarmes mit »normalen«, Bakterienarten würde Glukose 
                        komplett über die Dünndarm-Schleimhaut aufgenommen. Bei einer DDFB liegt jedoch 
                        eine unnatürliche Besiedelung mit wasserstoffproduzierenden Bakterienarten im 
                        Dünndarm vor. Deshalb steigt der Wasserstoffgehalt in der Ausatemluft beim Glukose-Test 
                        schnell und stark an. Lesen Sie hierzu bitte auch den Beitrag &#187;<a href="atemtest-duenndarmfehlbesiedelung" target="_blank">Wasserstoff-Atemtest mit Glukose</a>&#171;.
                        <br />
                        <br />
                        Auch wenn bei anderen Wasserstoff-Atemtests, die z.B. zur Diagnose von Laktose-, 
                        Fruktose- oder Sorbit-Unverträglichkeiten durchgeführt werden, der Wasserstoffgehalt 
                        in der ersten halben Stunde stark ansteigt kann dies unter bestimmten Bedingungen 
                        ein Hinweis auf eine DDFB sein.
                        Hierbei ist dann der genaue Verlauf der Messkurve zu berücksichtigen, denn aus 
                        diesen Werten kann man nicht nur schlussfolgern, ob eine DDFB vorliegt, sondern 
                        auch, ob die Ileozökalklappe noch weitestgehend intakt oder schon defekt ist. 
                        Im letzteren Fall könnte eine so genannte &#187;Back-Wash-Ileitis&#171; 
                        hinzukommen, bei der Kotbrei um die Ileozökalklappe hin und her spült. Dabei kann 
                        sich das letzte Stück des Dünndarms, das terminale Ileum entzünden, wobei hier 
                        weitere Beschwerden als Indiz hinzukommen. Am besten klärt dies ein Spezialist, 
                        der die entsprechenden Messwerte korrekt zu interpretieren weiß. 
                        <br />
                        <a id="behandlung">&nbsp;</a>
                        <hr>
                        <h5>Behandlung</h5>
                        <hr>
                        Standardmäßig wird die Dünndarmfehlbesiedelung mit Antibiotika behandelt. Hierbei 
                        werden die Bakterien abgetötet, die den Dünndarm besiedeln. Leider wird durch diese 
                        Behandlung jedoch auch die Dickdarmflora stark in Mitleidenschaft gezogen, so dass 
                        die Regeneration meist sehr langwierig ist und auch nicht ohne Folgesymptome abläuft.
                        <br />
                        <br />
                        Besser und nebenwirkungsärmer ist die Behandlung mit natürlichen Mitteln, die nur 
                        mild antibiotisch wirken und weniger unerwünschte Nebenwirkungen haben. Leider hat sich diese alternative 
                        Behandlungsmethode unter Gastroenterologen bisher nur zögerlich durchgesetzt. 
                        <br />
                        <br />
                        Nach jeder Antibiose &ndash; auch nach der der natürlichen Antibiose &ndash; 
                        müssen die Darmschleimhaut und die Darmflora wieder 
                        aufgebaut werden &ndash; auch hier können natürliche Mittel wie geeignete Probiotika
                         und auch <a href="vitalpilze" target="_blank">Vitalpilze</a> zum Einsatz kommen.
                        <br />
                        <br />
                        Bitte &#187;basteln&#171; Sie hier jedoch nie auf eigene Faust, sondern lassen 
                        Sie sich fachgerecht beraten. 
                        <br />
                        <hr>
                        <a id="beratung">&nbsp;</a>
                        <div class="row">
                        <div class="col s12 m2">
                            <a href="http://www.ganzheitliche-gesundheitsberatung.de" target="_blank">
                                <img src="<?php echo IMG_PATH; ?>praxiswebsite.png" alt="" class="inline" /></a>
                        </div>
                        </div>
                        <div class="row">
                        <div class="col s12 m12">
                        <h5>Beratung</h5>
                        <br />
                            Gerne biete ich Ihnen eine individuelle Beratung an &ndash; 
                            auf Wunsch auch telefonisch oder per Skype.
                            <br />
                            Bitte informieren Sie sich auf meiner Praxis-Website <a href="http://www.ganzheitliche-gesundheitsberatung.de" target="_blank">&#187;www.Ganzheitliche-Gesundheitsberatung.de&#171;</a>
                        </div>
                        </div>
                        <hr>
                        Begleitend ist es auf jeden Fall erforderlich, die Ernährung umzustellen und anzupassen. Aus den 
                        Zuckerverzehr sollte man in der Behandlungsphase weitestgehend reduzieren, und auch 
                        nach der Behandlung sollte weniger Zucker verzehrt werden. Darüber hinaus ist zu 
                        schauen, ob evtl. Nahrungsmittel-Unverträglichkeiten vorliegen, die ernährungsmäßig 
                        zu beachten sind. Erst, wenn die Nahrung verträglich ist und keine Verdauungsstörungen 
                        wie Blähungen oder weiche Stühle mehr auftreten, kann sich die bakterielle Besiedelung 
                        des gesamten Darms regenerieren und normalisieren. Weiterhin kann sich nur bei 
                        Symptomfreiheit eine geschädigte Ileozökalklappe erholen, um so zu verhindern, 
                        dass erneut Dickdarmbakterien in den Dünndarm aufsteigen.
                        <br />
                        <a id="6saeulen">&nbsp;</a>
                        <hr>
                        <h5>Die sechs Behandlungssäulen</h5>
                        <hr>
                        Insgesamt basiert eine erfolgreiche Behandlung auf sechs gleich wichtigen Säulen:
                        <br />
                        <br />
                        <b>&#149;</b> Korrekte Diagnose
                        <br />
                        Eine korrekte Diagnose sollte auf der einen Seite alle erforderlichen Maßnahmen 
                        umfassen, auf der anderen Seite aber belastende und oft auch überflüssige und 
                        vielleicht sogar kostenträchtige Untersuchungen vermeiden. 
                        <br />
                        <br />
                        <b>&#149;</b> Antibiose
                        <br />
                        Um die unerwünschten Bakterien aus dem Dünndarm zu entfernen, stehen 
                        verschiedene Mittel und Möglichkeiten zur Verfügung. Sie können sich 
                        zwischen allopathischen (pharmazeutischen) oder natürlichen Mitteln entscheiden.
                        <br />
                        <br />
                        <b>&#149;</b> Behandlungsbegleitende Maßnahmen
                        <br />
                        Gleichzeitig mit der Antibiose sind  verschiedene behandlungsbegleitende Maßnahmen 
                        erforderlich, um den Bakterien im Dünndarm die Lebensgrundlage zu entziehen. Eine 
                        der wichtigsten Maßnahmen ist u.a. eine adäquate Ernährung mit der Beachtung eventueller 
                        Nahrungsmittel-Unverträglichkeiten.
                        <br />
                        <br />
                        <b>&#149;</b> Sanierung der Darmschleimhaut
                        <br />
                        Im Anschluss an die Antibiose bzw. idealerweise ein wenig überschneidend muss die 
                        Darmschleimhaut saniert werden, die mit Sicherheit geschädigt und durchlässig ist.
                        <br />
                        <br />
                        <b>&#149;</b> Sanierung der Dickdarmflora
                        <br />
                        Nach der Sanierung der Darmschleimhaut muss die Dickdarmflora wieder in ein gesundes 
                        Gleichgewicht gebracht werden. 
                        <br />
                        <br />
                        <b>&#149;</b> Gesunderhaltung der Darmflora
                        <br />
                        Während und im Anschluss an die Behandlung müssen dauerhafte Maßnahmen zur Gesunderhaltung 
                        der Darmflora beachtet werden, um einen nachhaltigen Erfolg und die größtmögliche
                        Sicherheit vor Rückfällen gewährleisten.
                        <br />
                        <br />
                        <hr>
                        <br />
                        <a href="guterrat" target="_blank"><img src="<?php echo IMG_PATH; ?>hilfreich.png" alt="" class="left" /></a>
                        <br />
                        <br />
                        <hr />
                        <b>Lesen Sie hierzu bitte auch folgende Beträge:</b>
                        <br />
                        <a href="diagnose" target="_blank">&#149; Diagnose der Laktose-Intoleranz (mit weiteren Atemtests)</a>
                        <br />
                        <a href="rds-ursache-sibo" target="_blank">&#149; Dünndarmfehlbesiedelung als Ursache des Reizdarm-Syndroms</a>
                        <br />
                        <a href="darmgesundheit">&#149; Darmpflege: Gesunder Darm &ndash; gesunder Mensch</a>
                        <br />
                        <a href="verdauung">&#149; Gesunde Verdauung</a>
                        <br />
                        <a href="darmschleimhaut">&#149; Pflege der Darmschleimhaut</a>
                        <br />
                        <a href="darmflora">&#149; Pflege der Darmflora</a>
                        <br />
                        <a href="darmsanierung">&#149; Sanierung der Darmflora</a>
                        <br />
                        <a href="ganz-parasiten">&#149; Parasiten- und Pilzbesiedelung des Darms</a>
                        <br />
                        <a href="ganz-genussmittel">&#149; Genussmittel bei Darmempfindlichkeit</a>
                        <br />
                        <a href="ganz-gaergetraenke">&#149; Probiotische Gärgetränke</a>
                        <br />
                        <a href="vitalpilze">&#149; Vitalpilze</a>
                        <br />
                        <br />
                        <hr>
                        <br />
                        
                        <div class="oneline">
                            <div class="left">
                                <a href="book-ddfb"><img src="<?php echo IMG_PATH; ?>buchzumthema-ddfb.png" alt="Dünndarmfehlbesiedelung" class="inline" /></a>
                            </div>
                            <br class="cb" />
                        </div>
                        <br style="clear: left;" />
                        <br />
                        <hr>
                        <a href="lebensmittel-datenbank-info">
                            <img src="<?php echo IMG_PATH; ?>lebensmitteldatenbank.png" alt="home video small" class="left" />
                        </a>
                        <p class="left">
                            <b>Empfehlung:</b>
                            <br />
                            Eine zusätzliche Hilfe bei der Ermittlung geeigneter Lebensmittel 
                            <br />
                            während und nach der Behandlung einer Dünndarmfehlbesiedelung ist die
                            <br />
                            &#187;<b>DorisPaas.de &ndash; Lebensmittel-Datenbank</b>&#171;
                            <br /> 
                            Informieren Sie sich <a href="lebensmittel-datenbank-info" target="_blank">hier</a>.
                        </p>
                        <br style="clear: left;" />
                        <br />
                        <hr>
                        <a id="siboschulung">&nbsp;</a>
                        <br />
                        <a href="siboschulung">
                            <img src="<?php echo IMG_PATH; ?>schulungslogo-klein.png" alt="Siboschulung" class="left" />
                        </a>
                        <p class="left">
                            Zum Thema &#187;Dünndarmfehlbesiedelung&#171; biete ich 
                            <b>Schulungen</b></a> speziell für Mediziner, Heilpraktiker, Ernährungs- und 
                            Gesundheitsberater und ihr Praxispersonal an.
                            <br />
                            <br />
                            <a href="siboschulung" target="_blank">Bitte klicken Sie hier für mehr Informationen</a>
                        </p>
                        <br style="clear: left;" />
                        <br />
                        <hr>
                        <a href="javascript: scrollMainToTop();" class="nachoben">nach oben</a>
                    </div>
                </div>
            </div>    
            <br>
            <br> 
            <div class="bodyspacer"></div> 
        </div>