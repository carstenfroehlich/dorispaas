        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br /> 
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>
                <h1 class="header center orange-text">Vegane Ernährung</h1> 
                    <div class="row center">        
                    <h5 class="header col s12 light">wie gesund ist sie?</h5>      
                    </div>     
            </div>  
        </div> 
        <div class="container">    
            <div class="section">   
                <div class="row margintoprow">        
                    <div class="col s12 m4">
                        <ul class="nav">
                            <li>
                                <b>Abschnitte dieser Seite:</b>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-vegan#wasist">Was ist Veganismus?</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-vegan#ernaehrungsformen">Welche Ernährungsform ist ursprünglich für den Menschen vorgesehen?</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-vegan#heute">Wie sieht unsere heutige Ernährung unabhängig vom Fleischkonsum aus?</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-vegan#vegangesund">Ist vegane Ernährung gesund?</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-vegan#ersatzprodukte">Ersatzprodukte</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-vegan#fanatismus">(Glücklicherweise nicht immer) eine fanatische Lebenseinstellung</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-vegan#weiterentwicklung">Weiterentwicklung der Ernährungsgrundsätze</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>ganz-vegan#beratung">Beratung</a>
                            </li> 
                            <li>
                                <a href="<?= URL_ROOT ?>guterrat" target="_blank">War dieser Beitrag hilfreich für Sie?</a>
                            </li> 
                        </ul>
                    </div>
                    <div class="col s12 m8">
                        <img src="<?php echo IMG_PATH; ?>vegan.png" alt="vegan" class="right" />
                    </div>
                </div>
                <div class="row margintoprow">        
                    <div class="col s12 m12">
                        Seit langem schon wird die vegane Ernährung in allen Medien sehr kontrovers und 
                        teilweise auch sehr heftig diskutiert, und deshalb möchte ich an dieser Stelle 
                        beleuchten, welche Vor- und Nachteile eine solche Ernährungsform hat.
                        <br />
                        <br />
                        Vorab möchte ich folgendes klarstellen: Wie Sie aus den vielen anderen Beiträgen 
                        auf meiner Website ersehen können, bin ich kein Verfechter des Veganismus. Ich 
                        bemühe mich aber trotzdem, hier alle Punkte aufzuzählen, die für oder gegen eine 
                        vegane Ernährung sprechen. Letztendlich muss dann jeder für sich selbst entscheiden, 
                        ob er vegan leben möchte oder nicht. 
                        <br />
                        <a id="wasist"></a>
                        <hr />
                        <h5>Was ist Veganismus? </h5>
                        <hr />
                        Die Begriffe &#187;vegan&#171; und &#187;vegetarisch&#171; werden häufig gleichbedeutend 
                        benutzt, doch ist eine vegane Ernährung etwas anderes als die vegetarische. Bei 
                        der vegetarischen Ernährung verzichtet der Mensch auf Fleisch. Je nach Ausprägung 
                        und Ausrichtung der vegetarischen Ernährung werden jedoch zusätzlich zu pflanzlichen 
                        Lebensmitteln auch Eier (ovo-vegetarisch), Milch (lacto-vegetarisch) und/oder Fisch 
                        (pesco-vegetarisch) hinzugenommen. Meist jedoch wirkt sich der Vegetarismus nicht 
                        zusätzlich auf das weitere Leben aus: Von lebenden Tieren gewonnene Bestandteile 
                        des täglichen Lebens wie beispielsweise Honig oder Wolle werden nicht grundsätzlich 
                        abgelehnt. 
                        <br />
                        <br />
                        Im Gegensatz zu den Vegetariern leben die Veganer ganz konsequent frei von tierischen 
                        Produkten &ndash; seien sie vom lebenden oder vom toten Tier gewonnen. Den Veganismus 
                        nur als eine Ernährungsform zu betrachten, wäre also viel zu wenig &ndash; er ist 
                        eine Lebensform.
                        <br />
                        <br />
                        Die Motive für eine vegetarische und für eine vegane Ernährung und Lebensweise 
                        können vielfältig sein: Zum einen sind es sehr häufig gesundheitliche Gründe, 
                        die einen Menschen bewegen, auf Fleisch und ggf. auch generell auf tierische 
                        (Nahrungs-)Bestandteile zu verzichten. Sehr oft jedoch ist es (zusätzlich) auch 
                        die Achtung vor dem Tierwohl, das Vegetarier und Veganer in Gefahr sehen. Sie wollen 
                        nicht (Mit-)Verursacher dafür sein, dass Tiere in nicht artgerechter Weise gehalten 
                        und geschlachtet werden oder ihre Produkte wie Eier, Milch, Wolle und viele andere 
                        an die Menschen abgeben müssen.
                        <br />
                        <br />
                        Ganz sicher haben die ethischen Gründe ihre Berechtigung, dass man eine nicht 
                        artgerechte Haltung und natürlich erst recht die Massentierhaltung nicht durch 
                        sein eigenes Konsumverhalten unterstützen sollte. Auch ich bemühe mich, solche 
                        Produkte zu meiden und dadurch die Massentierhaltung überflüssig und für die 
                        Produzenten unattraktiv zu machen.
                        <br />
                        <br />
                        Es ist jedoch kaum möglich ist, objektiv und allgemeingültig bewerten zu können, 
                        ob Tiere leiden, die in so genannter &#187;artgerechter&#171; Haltung aufgezogen 
                        werden. Tiere in Käfigen oder Ställen zu halten, auch wenn sie etwas größer sind, 
                        ist sicherlich nicht artgerecht. Aber hier möchte und muss ich einen Kompromiss 
                        eingehen, der in größtmöglichem Maße dem Tierwohl und den menschlichen Ernährungserfordernissen 
                        gerecht wird. Nebenbei gesagt: Auch Pflanzen sind Lebewesen, die sich u.a. durch 
                        unbekömmliche Giftstoffe vor Fraßfeinden schützen und eben nicht gegessen werden 
                        wollen. Und doch essen wir Pflanzen &ndash; eben weil wir uns ernähren müssen und 
                        dies nicht durch den Verzehr von Nährstoffen rein aus der Erde tun können.
                        <br />
                        <br />
                        Auch ich setze für mich persönlich die Kriterien sehr hoch an, denn beispielsweise 
                        eine Tierhaltung in vom Gesetzgeber sogar für Bioqualität gesetztem Rahmen ist 
                        auch in meinen Augen immer noch keine artgerechte Haltung. Für mich müssen es wirklich 
                        die glücklichen, frei auf einer Wiese laufenden Hühner sein, um die Haltung als 
                        artgerecht anzusehen. Und pflanzliche Nahrung bevorzuge ich in Bioqualität, bei 
                        der die Äcker nicht künstlich gedüngt oder Pestizide aufgebracht werden, was dann 
                        ja auch Tiere &ndash; in diesem Falle Insekten und Vögel &ndash; beeinträchtigt.
                        <br />
                        <a id="ernaehrungsformen">&nbsp;</a>
                        <hr />
                        <h5>Welche Ernährungsform ist ursprünglich für den Menschen vorgesehen?</h5>
                        <hr />
                        Um als erstes bewerten zu können, ob und in welcher Ausprägung eine vegetarische 
                        und/oder vegane Ernährung etwa gesünder ist als fleischhaltige Nahrung, sollten 
                        wir uns vor Augen führen, welche Ernährung ursprünglich für den Menschen vorgesehen,
                         &#187;normal&#171; war.
                        <br />
                        <br />
                        Aufgrund von körperlichen Merkmalen (Anordnung und Ausbildung der Zähne, Länge 
                        des Darms, Vorhandensein bzw. Fehlen verschiedener Enzyme zum Verarbeiten von 
                        Nahrungsbestandteilen) zeigt sich ganz deutlich, dass der Mensch als &#187;Alles(fr)esser&#171; 
                        (Omnivore) eingerichtet ist. 
                        <br />
                        <br />
                        Die Ernährung in der Urzeit des Menschen beweist &ndash; soweit sie uns aus 
                        Fossilienfunden bekannt ist &ndash;, dass sich der Mensch als Sammler und Jäger 
                        überwiegend von pflanzlichen Lebensmitteln ernährt hat, die er auf seinen Wanderungen 
                        fand. Hier wurden Früchte, Blätter, Knollen und Wurzeln und das Mark aus Stängeln 
                        gesammelt, aber auch einzelne Körner von Grashalmen gestreift und verzehrt. Ergänzt 
                        wurde diese Kost durch tierische Proteine, die er durch den Verzehr von gefundenen 
                        Vogeleiern, Würmern oder Insekten aufnahm. Auch kleine Tiere wie Hasen, Mäuse oder 
                        Eichhörnchen konnten ab und an erbeutet werden, mit etwas Glück und vor allem mit 
                        der Erfindung von Waffen später auch ab und an ein größeres Tier. 
                        <br />
                        <br />
                        Je nach den Erfordernissen des Lebensumfeldes konnte es in Extremfall auch sein, 
                        dass Menschen, wie z.B. die Innuit, sich überwiegend von Fleisch und Fisch ernährten. 
                        Dabei wurde jedoch immer der Mageninhalt mitverzehrt, so dass die Menschen auch 
                        hier einen größeren Anteil an pflanzlicher Nahrung zu sich nahmen und dies auch 
                        heute noch tun.
                        <br />
                        <br />
                        Da sich das Verdauungssystem der Menschen in den Jahrtausenden seit diesen Urzeiten, 
                        die entwicklungsgeschichtlich jedoch so gut wie gar nicht ins Gewicht fallen, 
                        nicht verändert hat, täten wir gut daran, uns ebenso wie unsere Vorfahren zu ernähren, 
                        um gesund zu bleiben. Dies bedeutet: viel pflanzliche Kost, möglichst unverarbeitet 
                        oder zumindest sehr schonend zubereitet, dazu wenig Fleisch und tierische Produkte.
                        <br />
                        <br />
                        Gerade in letzter Zeit verbreitet sich die Meinung, dass sich unsere Vorfahren im 
                        Gegensatz zu dem soeben Beschriebenen eher überwiegend von Fleisch und Fett ernährt 
                        haben. Diese Ernährungsform wird als &#187;Paleo- oder Steinzeitdiät&#171; bezeichnet. 
                        Tatsache ist, dass niemand von uns dabei gewesen ist, als unsere Vorfahren lebten. 
                        Wenn jedoch tatsächlich der Mensch wie ein überwiegend fleischfressendes Raubtier 
                        gelebt hätte, hätte er neben einen sehr viel kürzeren Darm vor allem Reißzähne und 
                        Krallen, um seine Beute auch ohne Waffen fangen und essen zu können, und auch die 
                        Organe wie u.a. die Nieren wären für die Verdauung dieser großen Fleisch- und damit 
                        Proteinmengen eingerichtet. Dies ist aber offenkundig nicht der Fall. Somit ist 
                        für die meisten Ernährungswissenschaftler klar, dass Fleisch nicht die Hauptkomponente 
                        der ursprünglichen Ernährung gewesen sein kann. 
                        <br />
                        <br />
                        Bitte lesen Sie hierzu auch meine Rezensionen zum Buch von Dr. David Perlmutter: 
                        &#187;<a href="blog-2014-11-10">Dumm wie Brot &ndash; wie Weizen schleichend Ihr Gehirn zerstört</a>&#171;
                        und zu dem Buch von Dr. William Davis: &#187;<a href="blog-2014-02-17">Weizenwampe</a>&#171;.
                        <br />
                        <br />
                        Tatsache ist auch, dass Menschen, die kein oder nur wenig Fleisch essen, weniger 
                        Darmkrebs haben als die Viel-Fleisch-Esser. Dies mag zu einen daran liegen, dass 
                        ein Darm für die Verdauung von überwiegend fleischhaltiger Nahrung sehr viel kürzer 
                        sein muss, als der von Pflanzenfressern, denn bei der Fleischverdauung entstehen 
                        giftige oder zumindest schädliche Stoffe, die die empfindliche Darmwand schädigen 
                        können, wenn der Speisebrei zu lange im Darm liegt. Fleischiger Speisebrei sollte 
                        so schnell wie möglich zum Ausgang befördert werden. Die kohlenhydratarme Paleokost 
                        kann aber genau dies nicht: Sie liegt lange in unserem dafür viel zu langen Darm 
                        und wird wegen der fehlenden Ballaststoffe auch nur schwer weiter befördert. Es 
                        gibt noch keine Langzeitbeobachtungen, ob und in welchem Maße die Paleokost die 
                        Ausbildung von Darmkrebs begünstigt &ndash; aber allein aus logischen Überlegungen 
                        möchte ich selbst mich keinem Risiko aussetzen.
                        <br />
                        <a id="heute">&nbsp;</a>
                        <hr />
                        <h5>Wie sieht unsere heutige Ernährung unabhängig vom Fleischkonsum aus? </h5>
                        <hr />
                        Leider ernähren wir uns heute &ndash; auch wenn wir unseren Fleischkonsum an unsere 
                        körperlichen Merkmale anpassen &ndash; meist mitnichten so, wie es unsere Physiologie 
                        vorgibt: Entweder essen wir viel zu viel Zucker und Fett und überhaupt zu viel, 
                        oder aber wir verfallen ins andere Extrem und essen überhaupt keine tierischen 
                        Produkte, wodurch uns wertvolle Nährstoffe fehlen, die unser Körper nicht selbst 
                        herstellen kann.
                        <br />
                        <br />
                        Eine gesunde Kost, so wie sie unsere Vorfahren aßen, verbunden mit einer insgesamt 
                        gesunden Lebensweise mit viel Bewegung an der frischen Luft und einer ausgewogenen 
                        Mischung aus Anregung und Entspannung wäre also das, was uns auf Dauer gesund erhält 
                        und uns die Chance auf ein möglichst langes Leben eröffnet. Welche Form der Ernährung 
                        im Allgemeinen aufgrund unserer Körpermerkmale gesund ist, ist an anderer Stelle 
                        ausreichend dargelegt, z.B. im  Beitrag &#187;Fleisch oder kein Fleisch &ndash; was 
                        ist gesunde Ernährung&#171;.
                        <br />
                        <a id="vegangesund">&nbsp;</a>
                        <hr />
                        <h5>Ist vegane Ernährung gesund? </h5>
                        <hr />
                        Diese Frage soll hier generell für alle gesunden Menschen beantwortet werden. Keine 
                        allgemeingültige Antwort kann es natürlich für alle Menschen mit den verschiedensten 
                        Krankheiten, wie u.a. Diabetes oder Nierenproblemen geben, ebenso wenig wie für 
                        Menschen mit Nahrungsmittel-Allergien und/oder Unverträglichkeiten. Trotzdem gelten 
                        auch in diesen Fällen einige Grundsätze.
                        <br />
                        <br />
                        Für den Aufbau unserer eigenen Körperzellen benötigen wir bestimmte Aminosäuren 
                        in einem bestimmten Mengenverhältnis. Eiweiß aus tierischen Quellen kommt diesen 
                        Erfordernissen näher als pflanzliches und ist zudem besser verdaulich. Dabei 
                        entscheidet über die Qualität der Nahrung immer die Aminosäure, die in der geringsten 
                        Menge in der Nahrung vorhanden ist, die also die Zusammensetzung und den Aufbau 
                        unserer körpereigenen Proteine limitiert. Da nutzt es nichts, wenn andere Aminosäuren 
                        im Überfluss vorhanden sind, denn aus diesen &#187;Resten&#171; kann eben kein 
                        vollständiges Eiweißmolekül mehr gebildet werden. Pflanzliche Proteine enthalten 
                        in der überwiegenden Menge unvollständigere Zusammenstellungen von Aminosäuren. 
                        Es ist zwar grundsätzlich möglich, durch eine kluge Zusammenstellung von verschiedenen
                        pflanzlichen Bestandteile die Gesamtqualität des Angebots an Aminosäuren zu steigern, 
                        leider jedoch ist dieses Erfordernis den wenigsten Veganern bekannt. Allesesser 
                        oder Vegetarier, die auch tierische Produkte verzehren, haben es da wesentlich 
                        einfacher, denn in Fleisch bzw. Milch, Eiern und Fisch sind die benötigten Aminosäuren 
                        in ausreichender Menge enthalten.
                        <br />
                        <br />
                        Jede Ernährungsform, die nicht die vom Körper vorgegebenen Erfordernisse beachtet, 
                        muss weniger gesund sein als eine physiologisch angepasste. Und allein aus diesem 
                        Grunde kann der Veganismus nicht gesund sein, denn bei dieser Ernährungsform fehlen 
                        essentielle, d.h. lebenswichtige Nährstoffe, die ausschließlich pflanzliche Nahrung 
                        nicht oder nur in Spuren enthält. Gemeint ist hier das Cobalamin, meist unter dem 
                        Namen Vitamin B12 bekannt. Dieses Vitamin ist nur in tierischer Nahrung wie z.B. 
                        in Fleisch, Eiern oder Fisch enthalten. Veganer müssen es substituieren, d.h. sie 
                        müssen entweder Nahrungs-Ergänzungsmittel einnehmen oder aber mit Vitamin B12 
                        angereicherte Lebensmittel verzehren, denn eine Unterversorgung mit diesem Vitamin 
                        zieht u.a. Störungen der Blutbildung, Schädigungen von Rückenmark und zentralem 
                        Nervensystem bis hin zu Lähmungen oder auch Schwangerschaftskomplikationen nach sich. 
                        Allein dies spricht für mich persönlich gegen den Gesundheitswert und gegen die 
                        Berechtigung einer veganen Ernährung, denn es kann nicht von der Natur vorgesehen 
                        sein, dass man einen lebenswichtigen Bestandteil als Nahrungs-Ergänzung einnehmen 
                        muss, um gesund zu bleiben.
                        <br />
                        <br />
                        Somit steht es für mich außer Frage, dass eine vegane Ernährung nicht gesund ist. 
                        Selbstverständlich muss jeder für sich selbst entscheiden, was er für seinen 
                        Körper tut oder unterlässt. Ich tue mich allerdings schwer damit zu akzeptieren, 
                        wenn Eltern ihre Kinder vegan ernähren, denn sie enthalten oder zumindest erschweren 
                        ihnen so die Möglichkeit, dass aus diesen Kinder gesunde Erwachsene werden. 
                        <br />
                        <a id="ersatzprodukte">&nbsp;</a>
                        <hr />
                        <h5>Ersatzprodukte</h5>
                        <hr />
                        Wenn sich jedoch ein Mensch für sich selbst entscheidet, vegan zu leben, sollte 
                        er dies mit der gleichen Überzeugung tun, wie er es meist nach außen postuliert. 
                        Ersatzprodukte wie &#187;pflanzliches Fleisch&#171; aus Soja oder Seitan, Käse aus 
                        pflanzlichen Ölen und viele weitere Produkte, die dem Esser einen Geschmack wie 
                        tierische Produkte vorgaukeln, kann ich dann nicht mit den meist missionarischen 
                        Äußerungen, wie gut die vegane Ernährung sei, in Einklang bringen. Eine wirklich 
                        leckere, vegane Mahlzeit kann durchaus auch ohne diese &#187;Schummeleien&#171; 
                        zubereitet werden. Ich stehe auf dem Standpunkt, dass all diejenigen, die meinen, 
                        geschmacklich nicht auf Fleisch oder Käse etc. verzichten zu können, dann auch 
                        zu dieser Überzeugung stehen sollten. Warum schauen sie nicht, welche Möglichkeiten 
                        bestehen, Nahrungsmittel aus einer akzeptablen Produktion zu erhalten und so diese 
                        Hersteller zu fördern?
                        <br />
                        <a id="fanatismus">&nbsp;</a>
                        <hr />
                        <h5>(Glücklicherweise nicht immer) eine fanatische Lebenseinstellung</h5>
                        <hr />
                        Zusätzlich zu den o.a. gesundheitlichen Aspekten kommt eben leider eine unter 
                        Veganern sehr verbreitete fanatische Haltung. Ob dies mit den eigenen, eng gesetzten 
                        Grenzen in Bezug auf die Lebensmittelauswahl zusammenhängt, die kompromisslos alle, 
                        aber auch wirklich alle tierischen Bestandteile aus dem Leben ausschließt, vermag 
                        ich nicht abschließend zu beurteilen. Aber vielleicht verleitet eine solche 
                        Lebenseinstellung dazu, auch andere Meinungen nur schwer tolerieren zu können. 
                        <br />
                        <br />
                        Ich selbst akzeptiere, wie gesagt, völlig, wenn Menschen sich nicht gemein machen 
                        wollen mit den Tierquälern in den großen Mastbetrieben &ndash; aber das muss nicht 
                        zwangsläufig dazu führen, auf eine angemessene Ernährung aus überwiegend pflanzlichen 
                        und wenig tierischen Lebensmitteln zu verzichten. Es kann auch durchaus sinnvoll 
                        sein, sich vegetarisch, d.h. ohne Fleisch zu ernähren, dies aber mit Milch, Eier 
                        und/oder Fisch zu ergänzen. Auch eine Ernährung mit nur wenig (artgerecht produziertem) 
                        Fleisch kann sehr gesund sein &ndash; eine solche Ernährungsform nennt sich 
                        &#187;Flexitarismus&#171;.
                        <br />
                        <br />
                        Es mag für alle Ernährungsformen Argumente und auch Gegenargumente geben &ndash; 
                        und mitnichten muss zwangsläufig ein und dieselbe Ernährungsform für alle Menschen 
                        die einzig Richtige sein. Und unabhängig davon, ob ich für mich den Veganismus gut 
                        oder weniger geeignet finde, wünsche ich mir auf jeden Fall, dass sich alle Menschen 
                        &ndash; egal wie sie sich ernähren &ndash; nebeneinander leben lassen. Grundsätzlich 
                        darf keine Lebensform &ndash; egal ob in Bezug auf die Ernährung oder auf andere 
                        Bereiche des Lebens &ndash; dazu führen, alle Andersgesinnten missionieren und 
                        ihnen die eigene Meinung &#187;überstülpen&#171; zu wollen.
                        <br />
                        <a id="weiterentwicklung">&nbsp;</a>
                        <hr />
                        <h5>Weiterentwicklung der Ernährungsgrundsätze</h5>
                        <hr />
                        Wie alles, entwickeln sich auch die Grundsätze der Ernährung kontinuierlich weiter,
                        und wahrscheinlich wird auch in wenigen Jahren schon die vegane Strömung &#187;Schnee von gestern&#171; sein.
                        Anfang des vorigen Jahrhunderts postulierte Max Otto Bruker die radikale 
                        Vollwerternährung als das einzig Seeligmachende. Vor wenigen Jahrzehnten, während 
                        meines Studiums, galt dann das Fleisch als das Non plus ultra, das mindestens täglich 
                        verzehrt werden müsse, um gesund zu bleiben. Dann wieder schwenkte die durch
                        wissenschaftliche Forschungen beflügelte öffentliche Meinung um &ndash; wieder hin 
                        zu der Überzeugung, dass die Vollwertkost mit viel Obst und Gemüse und wenig Fleisch 
                        das Gesündeste sei. Derzeit gibt es zwei große Strömungen: zum einen ist dies der 
                        Veganismus und zum anderen das genaue Gegenteil, die Paleodiät.
                        <br />
                        <br />
                        Was nun wirklich das Richtige bei der Ernährung ist, wird man abschließend sicherlich 
                        nie wissen, und nichts ist in Stein gemeißelt oder gilt für jeden und jede. 
                        Ich meine, dass es &#187;DIE&#171; richtige Ernährung auch gar nicht geben 
                        kann &ndash; jedenfalls nicht DIE richtige Ernährung für jedermann. Ernährung ist 
                        immer individuell. Sie muss zu dem einzelnen Menschen passen, zugeschnitten auf 
                        die gesundheitlichen Bedürfnisse und die zeitlichen Möglichkeiten, die familiären 
                        Umstände, aber auch auf die individuellen Vorlieben. Und letzendlich wird sie sich 
                        auch im Laufe Ihres Lebens mehrfach ändern. Deshalb bitte ich Sie, sich auf der Basis all der 
                        Informationen, die Sie hier und insgesamt auf meiner Website bekommen, eine eigene 
                        Meinung zu bilden. Gerne stehe ich Ihnen mit einer <a href="http://www.ganzheitliche-gesundheitsberatung.de/" target="_blank">
                        Beratung</a> zur Verfügung, wenn Sie weitere Informationen benötigen, insbesondere 
                        dann, wenn Sie Erkrankungen und/oder Nahrungsmittel-Unterträglichkeiten und Allergien 
                        zu berücksichtigen haben.
                        <br />
                        <hr>
                        <a id="beratung">&nbsp;</a>
                        <div class="row">
                        <div class="col s12 m2">
                            <a href="http://www.ganzheitliche-gesundheitsberatung.de" target="_blank">
                                <img src="<?php echo IMG_PATH; ?>praxiswebsite.png" alt="" class="inline" /></a>
                        </div>
                        </div>
                        <div class="row">
                        <div class="col s12 m12">
                        <h5>Beratung</h5>
                        <br />
                            Gerne biete ich Ihnen eine individuelle Beratung an &ndash; 
                            auf Wunsch auch telefonisch oder per Skype.
                            <br />
                            Bitte informieren Sie sich auf meiner Praxis-Website <a href="http://www.ganzheitliche-gesundheitsberatung.de" target="_blank">&#187;www.Ganzheitliche-Gesundheitsberatung.de&#171;</a>
                        </div>
                        </div>
                        <hr>
                        <br />
                        <a href="guterrat" target="_blank"><img src="<?php echo IMG_PATH; ?>hilfreich.png" alt="" class="left" /></a>
                        <br />
                        <br />
                        <hr />
                        <a href="javascript: scrollMainToTop();" class="nachoben">nach oben</a>
                    </div>
                </div>
            </div>    
            <br>
            <br> 
            <div class="bodyspacer"></div> 
        </div>