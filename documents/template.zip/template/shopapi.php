<?php
    header("Content-Type: application/json");
    header('Access-Control-Allow-Origin: *'); 
    $json = json_decode(file_get_contents('php://input'), TRUE);
    $returnjson = array();
    $returnjson['error'] = array();
    
    if($json['action'] == 'add') {
        createCartEntry($json['token'], $json['articleid'], $json['amount']);
        $returnjson['aid'] = $json['articleid'];
        $returnjson['result'] = 'added';
        echo json_encode($returnjson);
        exit();
    } else if($json['action'] == 'update') {
        updateCartEntry($json['token'], $json['articleid'], $json['amount']);
        $returnjson['aid'] = $json['articleid'];
        $returnjson['result'] = 'updated';
        echo json_encode($returnjson);
        exit();
    } else if($json['action'] == 'delete') {
        trashCartEntry($json['cartentryid']);
        $returnjson['result'] = 'deleted';
        echo json_encode($returnjson);
        exit();
    }
    exit();
?>