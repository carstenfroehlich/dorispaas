        <div class="section no-pad-bot" id="index-banner">    
            <div class="container">      
                <br />
                <br /> 
                <div class="right">Letzte Aktualisierung: <b><?= date( "j.n.Y", filemtime( __FILE__ ) ) ?></b></div>
                <h1 class="header center orange-text">DorisPaas-Newsletter</h1>      
            </div>  
        </div> 
        <div class="container">    
            <div class="section">   
                <div class="row margintoprow">        
                    <div class="col s12 m12">
                        <hr />
                        <h5>Ausgabe 61 (Sommer 2022)</h5>
                        <hr />
                        <br />
                        
                        
                        <a href="http://www.dorispaas.de/" target="_blank"><img src="http://www.dorispaas.de/assets/images/nl-2022-02-titel.png" alt="Titelbild" border="0" hspace="0" vspace="0" style="float: left; margin-left: 0px; margin-right: 20px; padding-bottom: 5px;" /></a>
                        Liebe Leserin, lieber Leser.
                        <br />
                        Dieses Mal muss ich mich gleich zu Anfang bei Ihnen entschuldigen: beim Versand des letzten Newsletters ist gewaltig etwas schiefgelaufen. Wegen Server-Problemen haben viele von Ihnen 
                        den Fr&uuml;hjahrs-Newsletter mehrfach bekommen. Ich kann gut verstehen, dass einige Empf&auml;nger sehr ver&auml;rgert gewesen sind. Auch mir w&auml;re es unangenehm, meinen 
                        Postkasten mit zahlreichen gleichlautenden Mails zugesch&uuml;ttet zu bekommen. Ich bedanke mich ganz herzlich bei meinem Programmierer, 
                        der nun f&uuml;r solche F&auml;lle einen Sicherheitsmechanismus eingebaut hat.
                        Leider war aus dem gleichen Grund auch die Funktion zum Abmelden des Newsletters nicht aktiv, so dass viele erfolglos versucht haben, den Versand zu stoppen. Bitte seien Sie 
                        nicht b&ouml;se, wenn Sie deshalb diesen Sommer-Newsletter erhalten, obwohl Sie versucht hatten, sich abzumelden. Der Versand sollte nun wieder korrekt funktionieren. Vielleicht 
                        m&ouml;chten Sie aber &ndash; wenn Sie die Newsletter nun wieder wie &uuml;blich nur einmalig pro Quartal erhalten &ndash; weiter die Informationen lesen. Ich w&uuml;rde mich 
                        sehr freuen.
                        <br />
                        <br />
                        <br />
                        <hr />
                        <br />
                        <a href="http://www.dorispaas.de/internetrat" target="_blank"><img src="http://www.dorispaas.de/assets/images/nl-2022-02-internetrat.png" alt="Internetrat" border="0" hspace="0" vspace="0" style="float: left; margin-left: 0px; margin-right: 20px; padding-bottom: 0px;" /></a>
                        <b>&#149;	<a href="http://www.dorispaas.de/index.php?page=internetrat" target="_blank">Schwerpunktthema: Was kann das Internet f&uuml;r Ihre Gesundheit leisten und was nicht?</a></b>
                        <br />
                        <i>(Menü: Wissensdatenbank/Erfolgreiche Arzt- und Beratersuche/Was kann das Internet f&uuml;r Ihre Gesundheit leisten und was nicht?)</i>
                        <br />
                        Immer h&auml;ufiger suchen Menschen mit gesundheitlichen Problemen Rat im Internet. 
                        Anhand der verschiedenen Symptome kann mit Suchmaschinen geschaut werden, welche 
                        Informationen hierzu im Netz zu finden sind. Das ist zuerst einmal eine gute Sache. 
                        Nur ist es nat&uuml;rlich schwer, zu unterscheiden, welche Informationen seri&ouml;s 
                        sind und welche nicht. Denn leider posten viele Menschen auch Informationen, die 
                        entweder nur auf deren ganz individuelle Situation zutreffen oder aber auch solche, 
                        die schlichtweg falsch sind. Wie also kann ein Suchender, der im Zweifelsfalle 
                        immer mehr oder weniger ein Laie in Bezug auf dieses Thema ist, unterscheiden, welche Informationen 
                        wirklich hilfreich sind? Zuerst einmal sollte man die Quelle der Informationen 
                        auf ihre Glaubw&uuml;rdigkeit &uuml;berpr&uuml;fen. Verschiedene Institute, aber 
                        auch Arztpraxen, Heilpraktiker, Ern&auml;hrungs- und Ganzheitliche Gesundheitsberater 
                        pr&auml;sentieren im Internet nicht nur ihre Leistungen, sondern stellen gleichzeitig 
                        auch grundlegende Informationen zu ihren Schwerpunkten auf ihrer Homepage zur 
                        Verf&uuml;gung. Solche Quellen rangieren auf der Glaubw&uuml;rdigkeitsskala recht 
                        weit oben. Andere hingegen leider sehr viel weniger. Hier die Spreu vom Weizen zu trennen, 
                        ist sehr wichtig &ndash; auch f&uuml;r Ihren sp&auml;teren Behandlungserfolg.
                        <br />
                        <br />
                        <hr />
                        <br />
                        <a href="http://www.dorispaas.de/index.php?page=lebensmittel-datenbank-info" target="_blank"><img src="http://www.dorispaas.de/assets/images/nl-2022-02-datenbank.png" alt="Bild Lebensmittel-Datenbank" border="0" hspace="0" vspace="0" style="float: left; margin-left: 0px; margin-right: 20px; padding-bottom: 10px;" /></a>
                        <b>&#149;	<a href="http://www.dorispaas.de/index.php?page=lebensmittel-datenbank-info" target="_blank">Dorispaas.de &ndash; Lebensmittel-Datenbank</a></b>
                        <br />
                        <i>(Men&uuml;: Wissensdatenbank/Dorispaas.de &ndash; Lebensmittel-Datenbank/Info)</i>
                        <br />
                        Immer wieder beschweren sich Menschen, die an einer Nahrungsmittel-Unvertr&auml;glichkeit oder einer D&uuml;nndarmfehlbesiedelung (SIBO) leiden, 
                        dar&uuml;ber, dass Listen, die angeblich geeignete Lebensmittel enthalten, sich oftmals widersprechen. Was in der einen Liste erlaubt ist, 
                        ist in der anderen verboten. Wer soll da noch durchblicken? Und wenn man es mit mehreren Unvertr&auml;glichkeiten gleichzeitig zu tun hat, wird 
                        die Sache noch un&uuml;bersichtlicher. Oftmals wei&#223; man wegen dieser Schwierigkeiten gar nicht, welch breite Palette an Nahrungsmitteln trotz 
                        allem vertr&auml;glich ist, weil man in der Vielzahl der erforderlichen Pr&uuml;fungen l&auml;ngst die &Uuml;bersicht verloren hat und lieber 
                        &uuml;bervorsichtig ist. Bei der Erstellung der <b>DorisPaas.de &ndash; Lebensmittel-Datenbank</b> habe ich zahlreiche Quellen aus dem Internet und der 
                        Fachliteratur verglichen. Hinzu kamen dann noch meine eigenen Erfahrungen und die von meinen Klienten. F&uuml;r jedes einzelne der mittlerweile 
                        weit mehr als 1350 Lebensmittel habe ich die verschiedenen Informationen auf Stimmigkeit &uuml;berpr&uuml;ft, um sie dann fundiert bewerten zu 
                        k&ouml;nnen und das Ganze dann in ein einfaches Ampelsystem eingebaut. In der Datenbank k&ouml;nnen Sie mehrere Filter setzen, um passende 
                        Lebensmittel f&uuml;r Ihre ganz individuelle Unvertr&auml;glichkeits-Kombination angezeigt zu bekommen.
                        <br />
                        <br />
                        <hr />
                        <br />
                        Liebe Leserin, lieber Leser, einige von Ihnen sind vielleicht schon in die Sommerferien aufgebrochen, oder Sie werden in K&uuml;rze starten. Andere 
                        von Ihnen legen ihren Urlaub vielleicht in eine andere Jahreszeit, weil sie nicht durch Kita- oder Schulferien gebunden sind. Auf jeden Fall hoffen 
                        wir alle auf bestes Wetter, das wir &ndash; wo auch immer wir uns in der n&auml;chsten Zeit aufhalten &ndash; so richtig genie&#223;en wollen. Und das 
                        Ganze bitte m&ouml;glichst unbeschwert, unbeschwert von Verdauungsproblemen und unbeschwert von unn&ouml;tig vielen Restriktionen in Bezug auf vertr&auml;gliche 
                        Nahrungsmittel. Aus diesem Grunde habe ich in diesem Newsletter noch einmal versucht, sie f&uuml;r das Thema der &#187;Belastbarkeit von Ratschl&auml;gen 
                        im Internet&#171; zu sensibilisieren und empfehle Ihnen dar&uuml;ber hinaus die DorisPaas.de &ndash; Lebensmittel-Datenbank, damit Sie im Urlaub und zu 
                        Hause m&ouml;glichst viele verschiedene Lebensmittel genie&#223;en k&ouml;nnen. Aber Sie finden hier auf dieser Website zu wahrscheinlich allen den Themen, 
                        zu den Sie Fragen haben, Beitr&auml;ge und die richtigen Antworten. Nutzen Sie hierf&uuml;r die Navigation oder ggf. auch die 
                        <a href="http://www.dorispaas.de/index.php?page=sitemap-html" target="_blank">Sitemap</a>, um sich in den vielen Seiten zurechtzufinden.                         
                        <br />
                        <br />
                        Ich w&uuml;nsche ich Ihnen einen ganz tollen Sommer. Den n&auml;chsten Newsletter erhalten Sie dann, wenn Sie m&ouml;chten, zum Beginn des kommenden Herbst.
                        <br />
                        Ganz herzliche Gr&uuml;&#223;e aus dem Rheinland 
                        <br />
                        Ihre
                        <br />
                        <img src="http://www.dorispaas.de/assets/images/nl-unterschrift-dopa.png" alt="" border="0" hspace="0" vspace="0" style="float: left; margin-left: 0px; margin-right: 10px; padding-bottom: 0px;" />
                        <p>
                        <br />
                        <br />
                        <br />
                        <hr>
                        <a href="http://www.dorispaas.de/index.php?page=guterrat" target="_blank"><img src="<?php echo IMG_PATH; ?>newsletter-zettel.png" alt="" border="0" hspace="0" vspace="0" style="float: left; margin-left: 0px; margin-right: 20px; padding-bottom: 0px;" /></a>
                        <br />
                        &#149;	S&auml;mtliche neuen Beitr&auml;ge finden Sie immer unter dem Button 
                        &#187;<a href="http://www.dorispaas.de/index.php?page=news" target="_blank">neueste Betr&auml;ge</a>&#171; 
                        in der Seiten-Navigation.
                        <br />
                        &#149;	Den besten &Uuml;berblick &uuml;ber die kompletten Inhalte auf www.DorisPaas.de 
                        finden Sie in der <a href="http://www.dorispaas.de/sitemap-html" target="_blank">Sitemap</a> 
                        in der Seiten-Navigation.
                        <br />
                        &#149;	www.dorispaas.de &ndash; garantiert <a href="http://www.dorispaas.de/guterrat" target="_blank">werbefreie 
                        und unabh&auml;ngige Informationen</a>. 
                        
                        <br />
                        <br />
                        <hr>
                        <br />
                        Sie k&ouml;nnen den Erhalt des Newsletters jederzeit abbestellen.
                        Bitte klicken Sie auf <a href="http://www.dorispaas.de/index.php?page=unsubscribe_newsletter&amp;ticket=%UNSUBSCRIBE_TICKET%" target="_blank">diesen Link</a>.
                        <br />
                        Ihre Mailadresse wird im Verteiler gel&ouml;scht, und Sie erhalten keine Mails mehr.
                        </p>
                    </div>
                </div>
            </div>    
            <br>
            <br> 
            <div class="bodyspacer"></div> 
        </div>